// ============================================================================
// AUTH ROUTES
// apps/api/src/routes/auth.routes.ts
// 
// Authentication endpoints: register, login, refresh, logout, me, password-reset
// Uses unified error handling and validation middleware
// ============================================================================

import { Router, type Request, type Response, type NextFunction } from 'express';
import { authService } from '../services/auth.service.js';
import {
  initializeContext,
  resolveTenantFromHeader,
  requireTenant,
  authParser,
  requireAuth,
  requireTenantAccess,
  loginRateLimiter,
  registrationRateLimiter,
  passwordResetRateLimiter,
  refreshRateLimiter,
} from '../middleware/index.js';
import {
  validate,
  loginSchema,
  registerSchema,
  refreshTokenSchema,
  logoutSchema,
  passwordResetRequestSchema,
  passwordResetConfirmSchema,
} from '../validation/index.js';
import { asyncHandler, sendSuccess } from '../errors/index.js';

const router = Router();

// ============================================================================
// ROUTE: POST /auth/register
// Register a new user in a tenant
// ============================================================================

router.post(
  '/register',
  initializeContext(),
  resolveTenantFromHeader(),
  requireTenant(),
  registrationRateLimiter(),
  validate(registerSchema, 'body'),
  asyncHandler(async (req: Request, res: Response) => {
    const { email, password, name, phone } = req.body;

    const result = await authService.register(
      req.context.tenant!.tenantId,
      { email, password, name, phone },
      {
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      }
    );

    sendSuccess(res, req, result, 201);
  })
);

// ============================================================================
// ROUTE: POST /auth/login
// Login with email and password
// ============================================================================

router.post(
  '/login',
  initializeContext(),
  resolveTenantFromHeader(),
  requireTenant(),
  loginRateLimiter(),
  validate(loginSchema, 'body'),
  asyncHandler(async (req: Request, res: Response) => {
    const { email, password } = req.body;

    const result = await authService.login(
      req.context.tenant!.tenantId,
      { email, password },
      {
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      }
    );

    sendSuccess(res, req, result);
  })
);

// ============================================================================
// ROUTE: POST /auth/refresh
// Refresh access token using refresh token
// ============================================================================

router.post(
  '/refresh',
  initializeContext(),
  refreshRateLimiter(),
  validate(refreshTokenSchema, 'body'),
  asyncHandler(async (req: Request, res: Response) => {
    const { refreshToken } = req.body;

    const result = await authService.refresh(refreshToken, {
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    });

    sendSuccess(res, req, result);
  })
);

// ============================================================================
// ROUTE: POST /auth/logout
// Logout - revoke refresh token
// ============================================================================

router.post(
  '/logout',
  initializeContext(),
  validate(logoutSchema, 'body'),
  asyncHandler(async (req: Request, res: Response) => {
    const { refreshToken } = req.body;

    await authService.logout(refreshToken);
    
    sendSuccess(res, req, { message: 'Logged out successfully' });
  })
);

// ============================================================================
// ROUTE: POST /auth/logout-all
// Logout from all devices
// ============================================================================

router.post(
  '/logout-all',
  initializeContext(),
  resolveTenantFromHeader(),
  requireTenant(),
  authParser(),
  requireAuth(),
  requireTenantAccess(),
  asyncHandler(async (req: Request, res: Response) => {
    const count = await authService.logoutAll(
      req.auth!.tenantId, 
      req.auth!.userId,
      {
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      }
    );

    sendSuccess(res, req, {
      message: `Logged out from ${count} sessions`,
      sessionsRevoked: count,
    });
  })
);

// ============================================================================
// ROUTE: GET /auth/me
// Get current user info
// ============================================================================

router.get(
  '/me',
  initializeContext(),
  resolveTenantFromHeader(),
  requireTenant(),
  authParser(),
  requireAuth(),
  requireTenantAccess(),
  asyncHandler(async (req: Request, res: Response) => {
    const user = await authService.me(req.auth!.tenantId, req.auth!.userId);
    sendSuccess(res, req, user);
  })
);

// ============================================================================
// ROUTE: POST /auth/password-reset/request
// Request password reset (send email)
// ============================================================================

router.post(
  '/password-reset/request',
  initializeContext(),
  resolveTenantFromHeader(),
  requireTenant(),
  passwordResetRateLimiter(),
  validate(passwordResetRequestSchema, 'body'),
  asyncHandler(async (req: Request, res: Response) => {
    const { email } = req.body;

    try {
      const result = await authService.requestPasswordReset(
        req.context.tenant!.tenantId,
        email,
        {
          ipAddress: req.context.ipAddress,
          userAgent: req.context.userAgent,
        }
      );
      sendSuccess(res, req, { message: result.message });
    } catch {
      // Always return success for security (don't reveal if email exists)
      sendSuccess(res, req, { 
        message: 'If an account with that email exists, a password reset link has been sent.' 
      });
    }
  })
);

// ============================================================================
// ROUTE: POST /auth/password-reset/confirm
// Confirm password reset with token
// ============================================================================

router.post(
  '/password-reset/confirm',
  initializeContext(),
  resolveTenantFromHeader(),
  requireTenant(),
  validate(passwordResetConfirmSchema, 'body'),
  asyncHandler(async (req: Request, res: Response) => {
    const { token, newPassword } = req.body;

    const result = await authService.resetPassword(
      req.context.tenant!.tenantId,
      token,
      newPassword,
      {
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      }
    );

    sendSuccess(res, req, { message: result.message });
  })
);

// ============================================================================
// EXPORT
// ============================================================================

export default router;
