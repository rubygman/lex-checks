// ============================================================================
// TASK REPOSITORY
// apps/api/src/repositories/task.repository.ts
// 
// Repository for tasks with Kanban support and tenant scoping
// ============================================================================

import { BaseRepository, type SoftDeletableEntity, type Filter, type ListOptions } from './base.repository.js';
import { query } from '../db/connection.js';
import { parsePostgresError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export interface Task extends SoftDeletableEntity {
  id: string;
  tenant_id: string;
  case_id: string | null;
  client_id: string | null;
  title: string;
  title_he: string | null;
  description: string | null;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  task_type: string | null;
  assigned_to_id: string | null;
  due_date: Date | null;
  reminder_date: Date | null;
  completed_at: Date | null;
  completed_by: string | null;
  estimated_minutes: number | null;
  actual_minutes: number | null;
  is_billable: boolean;
  kanban_order: number;
  tags: string[] | null;
  created_by: string | null;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

export type CreateTaskData = Omit<Task, 'id' | 'tenant_id' | 'created_at' | 'updated_at' | 'deleted_at'>;
export type UpdateTaskData = Partial<CreateTaskData>;

export interface TaskWithDetails extends Task {
  case_title: string | null;
  case_number: string | null;
  client_name: string | null;
  assigned_to_name: string | null;
}

// ============================================================================
// REPOSITORY
// ============================================================================

export class TaskRepository extends BaseRepository<Task> {
  constructor() {
    super({
      tableName: 'tasks',
      supportsSoftDelete: true,
    });
  }

  /**
   * Find tasks by case
   */
  async findByCase(
    tenantId: string, 
    caseId: string,
    options?: { limit?: number; offset?: number; status?: Task['status'] }
  ): Promise<Task[]> {
    this.validateTenantId(tenantId, 'findByCase');

    const filters: Filter[] = [{ field: 'case_id', operator: '=', value: caseId }];
    if (options?.status) {
      filters.push({ field: 'status', operator: '=', value: options.status });
    }

    const result = await this.list(tenantId, {
      filters,
      sort: { field: 'kanban_order', direction: 'ASC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 },
    });

    return result.data;
  }

  /**
   * Find tasks by client
   */
  async findByClient(
    tenantId: string, 
    clientId: string,
    options?: { limit?: number; offset?: number; status?: Task['status'] }
  ): Promise<Task[]> {
    this.validateTenantId(tenantId, 'findByClient');

    const filters: Filter[] = [{ field: 'client_id', operator: '=', value: clientId }];
    if (options?.status) {
      filters.push({ field: 'status', operator: '=', value: options.status });
    }

    const result = await this.list(tenantId, {
      filters,
      sort: { field: 'due_date', direction: 'ASC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 },
    });

    return result.data;
  }

  /**
   * Find tasks by assigned user
   */
  async findByAssignee(
    tenantId: string, 
    userId: string,
    options?: { limit?: number; offset?: number; status?: Task['status'] }
  ): Promise<Task[]> {
    this.validateTenantId(tenantId, 'findByAssignee');

    const filters: Filter[] = [{ field: 'assigned_to_id', operator: '=', value: userId }];
    if (options?.status) {
      filters.push({ field: 'status', operator: '=', value: options.status });
    }

    const result = await this.list(tenantId, {
      filters,
      sort: { field: 'due_date', direction: 'ASC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 },
    });

    return result.data;
  }

  /**
   * Find tasks by status (for Kanban board)
   */
  async findByStatus(
    tenantId: string, 
    status: Task['status'],
    options?: { limit?: number; offset?: number; caseId?: string; clientId?: string; assigneeId?: string }
  ): Promise<Task[]> {
    this.validateTenantId(tenantId, 'findByStatus');

    const filters: Filter[] = [{ field: 'status', operator: '=', value: status }];
    
    if (options?.caseId) {
      filters.push({ field: 'case_id', operator: '=', value: options.caseId });
    }
    if (options?.clientId) {
      filters.push({ field: 'client_id', operator: '=', value: options.clientId });
    }
    if (options?.assigneeId) {
      filters.push({ field: 'assigned_to_id', operator: '=', value: options.assigneeId });
    }

    const result = await this.list(tenantId, {
      filters,
      sort: { field: 'kanban_order', direction: 'ASC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 },
    });

    return result.data;
  }

  /**
   * Get task with full details
   */
  async findByIdWithDetails(tenantId: string, taskId: string): Promise<TaskWithDetails | null> {
    this.validateTenantId(tenantId, 'findByIdWithDetails');

    try {
      const text = `
        SELECT 
          t.*,
          c.title as case_title,
          c.case_number,
          cl.name as client_name,
          u.name as assigned_to_name
        FROM tasks t
        LEFT JOIN cases c ON t.case_id = c.id AND t.tenant_id = c.tenant_id
        LEFT JOIN clients cl ON t.client_id = cl.id AND t.tenant_id = cl.tenant_id
        LEFT JOIN users u ON t.assigned_to_id = u.id AND t.tenant_id = u.tenant_id
        WHERE t.tenant_id = $1 AND t.id = $2 AND t.deleted_at IS NULL
      `;
      const result = await query<TaskWithDetails>(text, [tenantId, taskId]);
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Move task in Kanban (change status and/or order)
   */
  async moveTask(
    tenantId: string,
    taskId: string,
    newStatus: Task['status'],
    newOrder: number
  ): Promise<Task> {
    this.validateTenantId(tenantId, 'moveTask');

    try {
      // Update the task's status and order
      const text = `
        UPDATE tasks
        SET 
          status = $3,
          kanban_order = $4,
          updated_at = CURRENT_TIMESTAMP,
          completed_at = CASE WHEN $3 = 'completed' THEN CURRENT_TIMESTAMP ELSE completed_at END
        WHERE tenant_id = $1 AND id = $2 AND deleted_at IS NULL
        RETURNING *
      `;
      const result = await query<Task>(text, [tenantId, taskId, newStatus, newOrder]);
      
      if (result.rows.length === 0) {
        throw new Error('Task not found');
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Reorder tasks within a status column
   */
  async reorderTasks(
    tenantId: string,
    status: Task['status'],
    taskIds: string[]
  ): Promise<void> {
    this.validateTenantId(tenantId, 'reorderTasks');

    try {
      // Update each task's order
      for (let i = 0; i < taskIds.length; i++) {
        const text = `
          UPDATE tasks
          SET kanban_order = $3, updated_at = CURRENT_TIMESTAMP
          WHERE tenant_id = $1 AND id = $2 AND status = $4 AND deleted_at IS NULL
        `;
        await query(text, [tenantId, taskIds[i], i, status]);
      }
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get overdue tasks
   */
  async findOverdue(
    tenantId: string,
    options?: { limit?: number; assigneeId?: string }
  ): Promise<Task[]> {
    this.validateTenantId(tenantId, 'findOverdue');

    try {
      let text = `
        SELECT * FROM tasks
        WHERE tenant_id = $1
          AND deleted_at IS NULL
          AND status NOT IN ('completed', 'cancelled')
          AND due_date IS NOT NULL
          AND due_date < CURRENT_DATE
      `;
      const params: unknown[] = [tenantId];

      if (options?.assigneeId) {
        text += ` AND assigned_to_id = $${params.length + 1}`;
        params.push(options.assigneeId);
      }

      text += ` ORDER BY due_date ASC LIMIT $${params.length + 1}`;
      params.push(options?.limit ?? 100);

      const result = await query<Task>(text, params);
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get tasks due soon
   */
  async findDueSoon(
    tenantId: string,
    daysAhead: number = 7,
    options?: { limit?: number; assigneeId?: string }
  ): Promise<Task[]> {
    this.validateTenantId(tenantId, 'findDueSoon');

    try {
      let text = `
        SELECT * FROM tasks
        WHERE tenant_id = $1
          AND deleted_at IS NULL
          AND status NOT IN ('completed', 'cancelled')
          AND due_date IS NOT NULL
          AND due_date >= CURRENT_DATE
          AND due_date <= CURRENT_DATE + INTERVAL '1 day' * $2
      `;
      const params: unknown[] = [tenantId, daysAhead];

      if (options?.assigneeId) {
        text += ` AND assigned_to_id = $${params.length + 1}`;
        params.push(options.assigneeId);
      }

      text += ` ORDER BY due_date ASC LIMIT $${params.length + 1}`;
      params.push(options?.limit ?? 100);

      const result = await query<Task>(text, params);
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Mark task as completed
   */
  async markCompleted(tenantId: string, taskId: string, userId: string): Promise<Task> {
    this.validateTenantId(tenantId, 'markCompleted');

    try {
      const text = `
        UPDATE tasks
        SET 
          status = 'completed',
          completed_at = CURRENT_TIMESTAMP,
          completed_by = $3,
          updated_at = CURRENT_TIMESTAMP
        WHERE tenant_id = $1 AND id = $2 AND deleted_at IS NULL
        RETURNING *
      `;
      const result = await query<Task>(text, [tenantId, taskId, userId]);
      
      if (result.rows.length === 0) {
        throw new Error('Task not found');
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get task counts by status for Kanban
   */
  async getCountsByStatus(
    tenantId: string,
    filters?: { caseId?: string; clientId?: string; assigneeId?: string }
  ): Promise<Record<Task['status'], number>> {
    this.validateTenantId(tenantId, 'getCountsByStatus');

    try {
      let text = `
        SELECT status, COUNT(*) as count
        FROM tasks
        WHERE tenant_id = $1 AND deleted_at IS NULL
      `;
      const params: unknown[] = [tenantId];

      if (filters?.caseId) {
        text += ` AND case_id = $${params.length + 1}`;
        params.push(filters.caseId);
      }
      if (filters?.clientId) {
        text += ` AND client_id = $${params.length + 1}`;
        params.push(filters.clientId);
      }
      if (filters?.assigneeId) {
        text += ` AND assigned_to_id = $${params.length + 1}`;
        params.push(filters.assigneeId);
      }

      text += ` GROUP BY status`;

      const result = await query<{ status: Task['status']; count: string }>(text, params);
      
      const counts: Record<Task['status'], number> = {
        pending: 0,
        in_progress: 0,
        completed: 0,
        cancelled: 0,
      };

      for (const row of result.rows) {
        counts[row.status] = parseInt(row.count, 10);
      }

      return counts;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}

// Export singleton instance
export const taskRepository = new TaskRepository();
