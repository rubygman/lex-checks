// ============================================================================
// MAILER INTEGRATION
// apps/api/src/integrations/mailer.ts
// 
// Email sending abstraction for password reset and other transactional emails.
// Default implementation logs safely (no tokens). Replace with real provider.
// ============================================================================

// ============================================================================
// TYPES
// ============================================================================

/**
 * Result of sending an email
 */
export interface SendEmailResult {
  success: boolean;
  messageId?: string;
  error?: string;
}

/**
 * Password reset email data
 */
export interface PasswordResetEmailData {
  email: string;
  resetLink: string;
  userName?: string;
  expiresInMinutes: number;
  tenantName?: string;
}

/**
 * Welcome email data
 */
export interface WelcomeEmailData {
  email: string;
  userName: string;
  loginLink: string;
  tenantName?: string;
}

/**
 * Mailer interface - implement for different providers
 */
export interface Mailer {
  /**
   * Send a password reset email
   * SECURITY: Never log the resetLink as it contains the token
   */
  sendPasswordReset(data: PasswordResetEmailData): Promise<SendEmailResult>;

  /**
   * Send a welcome email to new users
   */
  sendWelcome?(data: WelcomeEmailData): Promise<SendEmailResult>;

  /**
   * Check if the mailer is configured and ready
   */
  isConfigured(): boolean;
}

// ============================================================================
// CONSOLE MAILER (Development/Stub)
// ============================================================================

/**
 * Console mailer for development - logs safely without exposing tokens
 * 
 * SECURITY: This implementation deliberately does NOT log:
 * - Reset tokens
 * - Reset links
 * - Any sensitive authentication data
 * 
 * In production, replace with a real email provider (SendGrid, AWS SES, etc.)
 */
class ConsoleMailer implements Mailer {
  private readonly enabled: boolean;

  constructor() {
    // Only enable in non-production environments
    this.enabled = process.env.NODE_ENV !== 'production';
  }

  async sendPasswordReset(data: PasswordResetEmailData): Promise<SendEmailResult> {
    if (!this.enabled) {
      // In production without a real mailer, fail silently but log warning
      console.warn('[Mailer] Password reset email requested but no mailer configured');
      return {
        success: false,
        error: 'Mailer not configured for production',
      };
    }

    // Log safely - NO token, NO link
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('[Mailer] Password Reset Email');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`  To: ${this.maskEmail(data.email)}`);
    console.log(`  User: ${data.userName || 'Unknown'}`);
    console.log(`  Tenant: ${data.tenantName || 'Unknown'}`);
    console.log(`  Expires in: ${data.expiresInMinutes} minutes`);
    console.log(`  Link: [REDACTED FOR SECURITY]`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('[Mailer] In development mode. Email not actually sent.');
    console.log('[Mailer] To test, check the reset link in your test framework.');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

    return {
      success: true,
      messageId: `dev-${Date.now()}`,
    };
  }

  async sendWelcome(data: WelcomeEmailData): Promise<SendEmailResult> {
    if (!this.enabled) {
      return {
        success: false,
        error: 'Mailer not configured for production',
      };
    }

    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('[Mailer] Welcome Email');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`  To: ${this.maskEmail(data.email)}`);
    console.log(`  User: ${data.userName}`);
    console.log(`  Tenant: ${data.tenantName || 'Unknown'}`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

    return {
      success: true,
      messageId: `dev-${Date.now()}`,
    };
  }

  isConfigured(): boolean {
    return this.enabled;
  }

  /**
   * Mask email for safe logging
   * user@example.com -> u***r@example.com
   */
  private maskEmail(email: string): string {
    const [local, domain] = email.split('@');
    if (!local || !domain) return '***@***';
    
    if (local.length <= 2) {
      return `${local[0]}***@${domain}`;
    }
    
    return `${local[0]}***${local[local.length - 1]}@${domain}`;
  }
}

// ============================================================================
// SENDGRID MAILER (Production Example - Not Implemented)
// ============================================================================

/**
 * Example SendGrid mailer implementation (not active)
 * 
 * To use:
 * 1. Install @sendgrid/mail
 * 2. Set SENDGRID_API_KEY environment variable
 * 3. Create email templates in SendGrid
 * 4. Uncomment and configure this class
 */
/*
class SendGridMailer implements Mailer {
  private readonly apiKey: string;
  private readonly fromEmail: string;
  private readonly resetTemplateId: string;

  constructor() {
    this.apiKey = process.env.SENDGRID_API_KEY || '';
    this.fromEmail = process.env.SENDGRID_FROM_EMAIL || 'noreply@lexmanager.com';
    this.resetTemplateId = process.env.SENDGRID_RESET_TEMPLATE_ID || '';
  }

  async sendPasswordReset(data: PasswordResetEmailData): Promise<SendEmailResult> {
    // Implementation would use SendGrid API
    // sgMail.setApiKey(this.apiKey);
    // await sgMail.send({
    //   to: data.email,
    //   from: this.fromEmail,
    //   templateId: this.resetTemplateId,
    //   dynamicTemplateData: {
    //     resetLink: data.resetLink,
    //     userName: data.userName,
    //     expiresInMinutes: data.expiresInMinutes,
    //   },
    // });
    return { success: true };
  }

  isConfigured(): boolean {
    return !!this.apiKey && !!this.resetTemplateId;
  }
}
*/

// ============================================================================
// MAILER FACTORY
// ============================================================================

/**
 * Create the appropriate mailer based on environment
 * 
 * To add a production mailer:
 * 1. Implement the Mailer interface
 * 2. Add environment detection here
 * 3. Return the appropriate implementation
 */
export function createMailer(): Mailer {
  // Check for production mailer configuration
  // Example: if (process.env.SENDGRID_API_KEY) return new SendGridMailer();
  
  // Default to console mailer
  return new ConsoleMailer();
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

let mailerInstance: Mailer | null = null;

/**
 * Get the mailer instance (singleton)
 */
export function getMailer(): Mailer {
  if (!mailerInstance) {
    mailerInstance = createMailer();
  }
  return mailerInstance;
}

/**
 * Set a custom mailer (for testing or custom providers)
 */
export function setMailer(mailer: Mailer): void {
  mailerInstance = mailer;
}

/**
 * Reset to default mailer (mainly for testing)
 */
export function resetMailer(): void {
  mailerInstance = null;
}

// ============================================================================
// CONVENIENCE FUNCTION
// ============================================================================

/**
 * Send a password reset email
 * 
 * @param email Recipient email address
 * @param resetLink Full URL with token for password reset
 * @param options Additional options
 * @returns Result of the send operation
 * 
 * SECURITY: The resetLink contains a sensitive token.
 * This function ensures it is NEVER logged.
 */
export async function sendPasswordResetEmail(
  email: string,
  resetLink: string,
  options: {
    userName?: string;
    expiresInMinutes?: number;
    tenantName?: string;
  } = {}
): Promise<SendEmailResult> {
  const mailer = getMailer();
  
  return mailer.sendPasswordReset({
    email,
    resetLink,
    userName: options.userName,
    expiresInMinutes: options.expiresInMinutes ?? 60,
    tenantName: options.tenantName,
  });
}
