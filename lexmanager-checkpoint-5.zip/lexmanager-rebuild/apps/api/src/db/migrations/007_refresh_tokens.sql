-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 007: Refresh Tokens Table
-- Stores hashed refresh tokens bound to user, tenant, and device/session
-- SECURITY: Only token hashes are stored - never plaintext tokens
-- ============================================================================

BEGIN;

-- ============================================================================
-- REFRESH TOKENS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS refresh_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Ownership (tenant-scoped)
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Token data (stored hashed, NEVER plain)
    -- Hash is SHA-256 of the random token bytes
    token_hash VARCHAR(128) NOT NULL,
    
    -- Token family for rotation detection
    -- All tokens in a family are invalidated if reuse is detected
    family_id UUID NOT NULL,
    
    -- Device/session binding (optional)
    device_id VARCHAR(255),
    user_agent TEXT,
    ip_address INET,
    
    -- Lifecycle timestamps
    issued_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMPTZ NOT NULL,
    rotated_at TIMESTAMPTZ,      -- Set when this token was used to get a new one
    revoked_at TIMESTAMPTZ,      -- Set when explicitly revoked
    revoke_reason VARCHAR(100),
    
    -- Standard timestamps for soft delete support
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMPTZ,      -- Soft delete support
    
    -- Constraints
    CONSTRAINT uq_refresh_token_hash UNIQUE (token_hash)
);

-- ============================================================================
-- INDEXES
-- ============================================================================

-- Fast lookup by token hash (primary lookup path)
-- This is the main query path for token validation
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_hash ON refresh_tokens(token_hash);

-- User's active tokens (for logout all, token management)
-- Scoped to tenant for multi-tenant isolation
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user ON refresh_tokens(tenant_id, user_id) 
WHERE revoked_at IS NULL AND deleted_at IS NULL;

-- Family lookup (for rotation/reuse detection)
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_family ON refresh_tokens(family_id);

-- Cleanup expired tokens (for background job)
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_expires ON refresh_tokens(expires_at) 
WHERE revoked_at IS NULL AND deleted_at IS NULL;

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_refresh_tokens_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_refresh_tokens_updated_at ON refresh_tokens;
CREATE TRIGGER trg_refresh_tokens_updated_at
    BEFORE UPDATE ON refresh_tokens
    FOR EACH ROW
    EXECUTE FUNCTION update_refresh_tokens_updated_at();

-- ============================================================================
-- PASSWORD RESET TOKENS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Ownership (tenant-scoped)
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Token (stored hashed, NEVER plain)
    token_hash VARCHAR(128) NOT NULL,
    
    -- Lifecycle
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMPTZ NOT NULL,
    used_at TIMESTAMPTZ,
    
    -- Request metadata
    ip_address INET,
    user_agent TEXT,
    
    -- Standard timestamps
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMPTZ,
    
    CONSTRAINT uq_password_reset_token_hash UNIQUE (token_hash)
);

CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_hash ON password_reset_tokens(token_hash);
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_user ON password_reset_tokens(tenant_id, user_id);

-- ============================================================================
-- HELPER FUNCTIONS
-- ============================================================================

-- Function to clean up expired tokens (run periodically via cron/scheduler)
CREATE OR REPLACE FUNCTION cleanup_expired_tokens()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER := 0;
    temp_count INTEGER;
BEGIN
    -- Soft delete expired refresh tokens older than 30 days past expiry
    UPDATE refresh_tokens 
    SET deleted_at = CURRENT_TIMESTAMP
    WHERE expires_at < CURRENT_TIMESTAMP - INTERVAL '30 days'
      AND deleted_at IS NULL;
    
    GET DIAGNOSTICS temp_count = ROW_COUNT;
    deleted_count := deleted_count + temp_count;
    
    -- Soft delete expired password reset tokens
    UPDATE password_reset_tokens 
    SET deleted_at = CURRENT_TIMESTAMP
    WHERE expires_at < CURRENT_TIMESTAMP
      AND deleted_at IS NULL;
    
    GET DIAGNOSTICS temp_count = ROW_COUNT;
    deleted_count := deleted_count + temp_count;
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Function to revoke all tokens in a family (on reuse detection)
-- SECURITY: Called when token reuse is detected - compromised family
CREATE OR REPLACE FUNCTION revoke_token_family(p_family_id UUID, p_reason VARCHAR DEFAULT 'Token reuse detected')
RETURNS INTEGER AS $$
DECLARE
    revoked_count INTEGER;
BEGIN
    UPDATE refresh_tokens 
    SET revoked_at = CURRENT_TIMESTAMP,
        revoke_reason = p_reason,
        updated_at = CURRENT_TIMESTAMP
    WHERE family_id = p_family_id 
      AND revoked_at IS NULL
      AND deleted_at IS NULL;
    
    GET DIAGNOSTICS revoked_count = ROW_COUNT;
    RETURN revoked_count;
END;
$$ LANGUAGE plpgsql;

-- Function to revoke all user tokens (logout all devices)
-- Tenant-scoped for multi-tenant isolation
CREATE OR REPLACE FUNCTION revoke_all_user_tokens(
    p_tenant_id UUID, 
    p_user_id UUID, 
    p_reason VARCHAR DEFAULT 'User logout all'
)
RETURNS INTEGER AS $$
DECLARE
    revoked_count INTEGER;
BEGIN
    UPDATE refresh_tokens 
    SET revoked_at = CURRENT_TIMESTAMP,
        revoke_reason = p_reason,
        updated_at = CURRENT_TIMESTAMP
    WHERE tenant_id = p_tenant_id 
      AND user_id = p_user_id 
      AND revoked_at IS NULL
      AND deleted_at IS NULL;
    
    GET DIAGNOSTICS revoked_count = ROW_COUNT;
    RETURN revoked_count;
END;
$$ LANGUAGE plpgsql;

COMMIT;
