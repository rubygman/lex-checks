// ============================================================================
// CASE SERVICE
// apps/api/src/services/case.service.ts
// 
// All methods require appropriate permissions via Authorizer
// ============================================================================

import { caseRepository, type Case } from '../repositories/index.js';
import { authorizer, PERMISSIONS, type RequestContext } from '../auth/authorizer.js';
import { auditService } from './audit.service.js';
import { softDeleteService } from './soft-delete.service.js';
import { validateClientTenant, validateUserTenant, validateCaseTenant } from '../utils/tenant-validation.js';

// ============================================================================
// TYPES
// ============================================================================

export interface CreateCaseInput {
  client_id: string;
  title: string;
  case_number?: string;
  case_type: string;
  court_name?: string;
  court_case_number?: string;
  description?: string;
  opposing_party?: string;
  opposing_counsel?: string;
  statute_of_limitations?: Date;
  billing_type?: 'hourly' | 'flat_fee' | 'contingency' | 'retainer';
  billing_rate?: number;
  estimated_value?: number;
  lead_attorney_id?: string;
}

export interface UpdateCaseInput {
  title?: string;
  case_type?: string;
  status?: 'active' | 'pending' | 'closed' | 'archived';
  court_name?: string;
  court_case_number?: string;
  description?: string;
  opposing_party?: string;
  opposing_counsel?: string;
  statute_of_limitations?: Date;
  billing_type?: 'hourly' | 'flat_fee' | 'contingency' | 'retainer';
  billing_rate?: number;
  estimated_value?: number;
  outcome?: string;
  closed_at?: Date;
  lead_attorney_id?: string;
}

export interface CaseListOptions {
  clientId?: string;
  status?: string;
  caseType?: string;
  leadAttorneyId?: string;
  search?: string;
  limit?: number;
  offset?: number;
  includeDeleted?: boolean;
}

// ============================================================================
// SERVICE
// ============================================================================

export class CaseService {
  // ==========================================================================
  // VIEW OPERATIONS
  // ==========================================================================

  /**
   * Get case by ID
   * Requires: cases_view
   */
  async getById(
    context: RequestContext,
    tenantId: string,
    caseId: string
  ): Promise<Case | null> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.CASES_VIEW);
    return caseRepository.findById(tenantId, caseId);
  }

  /**
   * Get case by ID or throw
   * Requires: cases_view
   */
  async getByIdOrFail(
    context: RequestContext,
    tenantId: string,
    caseId: string
  ): Promise<Case> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.CASES_VIEW);
    return caseRepository.findByIdOrFail(tenantId, caseId);
  }

  /**
   * List cases
   * Requires: cases_view
   */
  async list(
    context: RequestContext,
    tenantId: string,
    options: CaseListOptions = {}
  ): Promise<{ data: Case[]; pagination: { total: number; limit: number; offset: number; hasMore: boolean } }> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.CASES_VIEW);

    const filters = [];
    
    if (options.clientId) {
      filters.push({ field: 'client_id', operator: '=' as const, value: options.clientId });
    }
    if (options.status) {
      filters.push({ field: 'status', operator: '=' as const, value: options.status });
    }
    if (options.caseType) {
      filters.push({ field: 'case_type', operator: '=' as const, value: options.caseType });
    }
    if (options.leadAttorneyId) {
      filters.push({ field: 'lead_attorney_id', operator: '=' as const, value: options.leadAttorneyId });
    }
    if (options.search) {
      filters.push({ field: 'title', operator: 'ILIKE' as const, value: `%${options.search}%` });
    }

    return caseRepository.list(tenantId, {
      filters,
      pagination: { 
        limit: options.limit ?? 100, 
        offset: options.offset ?? 0 
      },
      includeDeleted: options.includeDeleted,
    });
  }

  /**
   * List cases for a client
   * Requires: cases_view
   */
  async listByClient(
    context: RequestContext,
    tenantId: string,
    clientId: string,
    options: { limit?: number; offset?: number } = {}
  ): Promise<Case[]> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.CASES_VIEW);
    
    const result = await this.list(context, tenantId, {
      clientId,
      ...options,
    });
    
    return result.data;
  }

  // ==========================================================================
  // CREATE OPERATIONS
  // ==========================================================================

  /**
   * Create a new case
   * Requires: cases_create
   */
  async create(
    context: RequestContext,
    tenantId: string,
    input: CreateCaseInput
  ): Promise<Case> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CASES_CREATE);

    // Validate client belongs to tenant
    await validateClientTenant(tenantId, input.client_id);

    // Validate lead attorney if provided
    if (input.lead_attorney_id) {
      await validateUserTenant(tenantId, input.lead_attorney_id);
    }

    // Create case
    const caseRecord = await caseRepository.create(tenantId, {
      client_id: input.client_id,
      title: input.title,
      case_number: input.case_number,
      case_type: input.case_type,
      status: 'active',
      court_name: input.court_name,
      court_case_number: input.court_case_number,
      description: input.description,
      opposing_party: input.opposing_party,
      opposing_counsel: input.opposing_counsel,
      statute_of_limitations: input.statute_of_limitations,
      billing_type: input.billing_type,
      billing_rate: input.billing_rate,
      estimated_value: input.estimated_value,
      lead_attorney_id: input.lead_attorney_id,
    });

    // Audit log
    await auditService.logCreate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'cases',
      caseRecord.id,
      caseRecord as unknown as Record<string, unknown>
    );

    return caseRecord;
  }

  // ==========================================================================
  // UPDATE OPERATIONS
  // ==========================================================================

  /**
   * Update a case
   * Requires: cases_edit
   */
  async update(
    context: RequestContext,
    tenantId: string,
    caseId: string,
    input: UpdateCaseInput
  ): Promise<Case> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CASES_EDIT);

    // Get existing for audit
    const existing = await caseRepository.findByIdOrFail(tenantId, caseId);

    // Validate lead attorney if provided
    if (input.lead_attorney_id) {
      await validateUserTenant(tenantId, input.lead_attorney_id);
    }

    // Update case
    const updated = await caseRepository.update(tenantId, caseId, input);

    // Audit log
    await auditService.logUpdate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'cases',
      caseId,
      existing as unknown as Record<string, unknown>,
      updated as unknown as Record<string, unknown>
    );

    return updated;
  }

  // ==========================================================================
  // DELETE OPERATIONS
  // ==========================================================================

  /**
   * Soft delete a case
   * Requires: cases_delete
   */
  async delete(
    context: RequestContext,
    tenantId: string,
    caseId: string
  ): Promise<void> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CASES_DELETE);

    const caseRecord = await caseRepository.findByIdOrFail(tenantId, caseId);

    await softDeleteService.softDelete(tenantId, 'cases', caseId, {
      deletedBy: auth.userId,
    });

    await auditService.logDelete(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'cases',
      caseId,
      caseRecord as unknown as Record<string, unknown>
    );
  }

  /**
   * Restore a soft-deleted case
   * Requires: cases_delete
   */
  async restore(
    context: RequestContext,
    tenantId: string,
    caseId: string
  ): Promise<void> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CASES_DELETE);

    await softDeleteService.restore(tenantId, 'cases', caseId, {
      restoreRelated: true,
    });

    await auditService.logRestore(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'cases',
      caseId
    );
  }

  // ==========================================================================
  // ASSIGN OPERATIONS
  // ==========================================================================

  /**
   * Assign lead attorney to case
   * Requires: cases_assign
   */
  async assignLeadAttorney(
    context: RequestContext,
    tenantId: string,
    caseId: string,
    attorneyId: string | null
  ): Promise<Case> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CASES_ASSIGN);

    if (attorneyId) {
      await validateUserTenant(tenantId, attorneyId);
    }

    const existing = await caseRepository.findByIdOrFail(tenantId, caseId);
    const updated = await caseRepository.update(tenantId, caseId, {
      lead_attorney_id: attorneyId || undefined,
    });

    await auditService.logUpdate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'cases',
      caseId,
      existing as unknown as Record<string, unknown>,
      updated as unknown as Record<string, unknown>
    );

    return updated;
  }

  // ==========================================================================
  // EXPORT OPERATIONS
  // ==========================================================================

  /**
   * Export cases data
   * Requires: cases_export
   */
  async export(
    context: RequestContext,
    tenantId: string,
    options: { format: 'csv' | 'xlsx'; filters?: CaseListOptions }
  ): Promise<{ data: Case[]; format: string }> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CASES_EXPORT);

    const result = await this.list(context, tenantId, {
      ...options.filters,
      limit: 10000,
      offset: 0,
    });

    await auditService.logExport(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'cases',
      result.data.length,
      options.format
    );

    return {
      data: result.data,
      format: options.format,
    };
  }

  // ==========================================================================
  // STATUS MANAGEMENT
  // ==========================================================================

  /**
   * Close a case
   * Requires: cases_edit
   */
  async close(
    context: RequestContext,
    tenantId: string,
    caseId: string,
    outcome?: string
  ): Promise<Case> {
    return this.update(context, tenantId, caseId, {
      status: 'closed',
      outcome,
      closed_at: new Date(),
    });
  }

  /**
   * Reopen a closed case
   * Requires: cases_edit
   */
  async reopen(
    context: RequestContext,
    tenantId: string,
    caseId: string
  ): Promise<Case> {
    return this.update(context, tenantId, caseId, {
      status: 'active',
      closed_at: undefined,
    });
  }
}

export const caseService = new CaseService();
