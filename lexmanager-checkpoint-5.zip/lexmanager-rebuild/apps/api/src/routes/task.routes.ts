// ============================================================================
// TASK ROUTES
// apps/api/src/routes/task.routes.ts
// 
// Full CRUD + restore + Kanban operations with RBAC and audit
// ============================================================================

import { Router } from 'express';
import { taskService } from '../services/task.service.js';
import {
  initializeContext,
  resolveTenantFromHeader,
  requireTenant,
  authParser,
  requireAuth,
  requireTenantAccess,
  requirePermission,
} from '../middleware/index.js';
import {
  validate,
  validateAll,
  createTaskSchema,
  updateTaskSchema,
  taskQuerySchema,
  idParamSchema,
  z,
} from '../validation/index.js';
import { asyncHandler, sendSuccess } from '../errors/index.js';
import { PERMISSIONS } from '../services/rbac.service.js';

const router = Router();

// All routes require tenant context and authentication
router.use(initializeContext());
router.use(resolveTenantFromHeader());
router.use(requireTenant());
router.use(authParser());
router.use(requireAuth());
router.use(requireTenantAccess());

// Move task schema
const moveTaskSchema = z.object({
  status: z.enum(['pending', 'in_progress', 'completed', 'cancelled']),
  order: z.number().int().min(0).optional(),
});

// ============================================================================
// GET /tasks - List tasks with pagination and filtering
// ============================================================================

router.get(
  '/',
  requirePermission(PERMISSIONS.TASKS_VIEW),
  validate(taskQuerySchema, 'query'),
  asyncHandler(async (req, res) => {
    const { page, limit, q, status, priority, caseId, clientId, assignedToId } = req.query as any;

    const result = await taskService.list(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      {
        search: q,
        status,
        priority,
        caseId,
        clientId,
        assigneeId: assignedToId,
        limit,
        offset: (page - 1) * limit,
      }
    );

    sendSuccess(res, req, result.data, 200, {
      page,
      limit,
      total: result.pagination.total,
      hasMore: result.pagination.hasMore,
    });
  })
);

// ============================================================================
// GET /tasks/kanban - Get Kanban board view
// ============================================================================

router.get(
  '/kanban',
  requirePermission(PERMISSIONS.TASKS_VIEW),
  asyncHandler(async (req, res) => {
    const { caseId, clientId, assigneeId } = req.query as any;

    const board = await taskService.getKanbanBoard(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      { caseId, clientId, assigneeId }
    );

    sendSuccess(res, req, board);
  })
);

// ============================================================================
// GET /tasks/counts - Get task counts by status
// ============================================================================

router.get(
  '/counts',
  requirePermission(PERMISSIONS.TASKS_VIEW),
  asyncHandler(async (req, res) => {
    const { caseId, clientId, assigneeId } = req.query as any;

    const counts = await taskService.getStatusCounts(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      { caseId, clientId, assigneeId }
    );

    sendSuccess(res, req, counts);
  })
);

// ============================================================================
// GET /tasks/overdue - Get overdue tasks
// ============================================================================

router.get(
  '/overdue',
  requirePermission(PERMISSIONS.TASKS_VIEW),
  asyncHandler(async (req, res) => {
    const { limit, assigneeId } = req.query as any;

    const tasks = await taskService.getOverdueTasks(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      { limit: limit ? parseInt(limit, 10) : undefined, assigneeId }
    );

    sendSuccess(res, req, tasks);
  })
);

// ============================================================================
// GET /tasks/due-soon - Get tasks due soon
// ============================================================================

router.get(
  '/due-soon',
  requirePermission(PERMISSIONS.TASKS_VIEW),
  asyncHandler(async (req, res) => {
    const { days, assigneeId } = req.query as any;

    const tasks = await taskService.getTasksDueSoon(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      days ? parseInt(days, 10) : 7,
      { assigneeId }
    );

    sendSuccess(res, req, tasks);
  })
);

// ============================================================================
// POST /tasks - Create a new task
// ============================================================================

router.post(
  '/',
  requirePermission(PERMISSIONS.TASKS_CREATE),
  validate(createTaskSchema, 'body'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const task = await taskService.create(
      context,
      req.auth!.tenantId,
      {
        case_id: req.body.caseId,
        client_id: req.body.clientId,
        title: req.body.title,
        description: req.body.description,
        status: req.body.status || 'pending',
        priority: req.body.priority || 'medium',
        assigned_to_id: req.body.assignedToId,
        due_date: req.body.dueDate,
        reminder_date: req.body.reminderDate,
        estimated_minutes: req.body.estimatedMinutes,
      }
    );

    sendSuccess(res, req, task, 201);
  })
);

// ============================================================================
// GET /tasks/:id - Get task by ID
// ============================================================================

router.get(
  '/:id',
  requirePermission(PERMISSIONS.TASKS_VIEW),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const task = await taskService.getByIdWithDetails(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, task);
  })
);

// ============================================================================
// PATCH /tasks/:id - Update task
// ============================================================================

router.patch(
  '/:id',
  requirePermission(PERMISSIONS.TASKS_EDIT),
  validateAll({
    params: idParamSchema,
    body: updateTaskSchema,
  }),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const updateData: Record<string, unknown> = {};
    if (req.body.title !== undefined) updateData.title = req.body.title;
    if (req.body.description !== undefined) updateData.description = req.body.description;
    if (req.body.status !== undefined) updateData.status = req.body.status;
    if (req.body.priority !== undefined) updateData.priority = req.body.priority;
    if (req.body.assignedToId !== undefined) updateData.assigned_to_id = req.body.assignedToId;
    if (req.body.dueDate !== undefined) updateData.due_date = req.body.dueDate;
    if (req.body.reminderDate !== undefined) updateData.reminder_date = req.body.reminderDate;
    if (req.body.estimatedMinutes !== undefined) updateData.estimated_minutes = req.body.estimatedMinutes;

    const task = await taskService.update(
      context,
      req.auth!.tenantId,
      req.params.id,
      updateData as any
    );

    sendSuccess(res, req, task);
  })
);

// ============================================================================
// PATCH /tasks/:id/move - Move task (Kanban drag-drop)
// ============================================================================

router.patch(
  '/:id/move',
  requirePermission(PERMISSIONS.TASKS_EDIT),
  validateAll({
    params: idParamSchema,
    body: moveTaskSchema,
  }),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const task = await taskService.move(
      context,
      req.auth!.tenantId,
      req.params.id,
      {
        status: req.body.status,
        order: req.body.order,
      }
    );

    sendSuccess(res, req, task);
  })
);

// ============================================================================
// POST /tasks/:id/complete - Mark task as completed
// ============================================================================

router.post(
  '/:id/complete',
  requirePermission(PERMISSIONS.TASKS_EDIT),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const task = await taskService.markCompleted(
      context,
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, task);
  })
);

// ============================================================================
// DELETE /tasks/:id - Soft delete task
// ============================================================================

router.delete(
  '/:id',
  requirePermission(PERMISSIONS.TASKS_DELETE),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    await taskService.delete(
      context,
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, { message: 'Task deleted successfully' });
  })
);

// ============================================================================
// POST /tasks/:id/restore - Restore soft-deleted task
// ============================================================================

router.post(
  '/:id/restore',
  requirePermission(PERMISSIONS.TASKS_DELETE),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    await taskService.restore(
      context,
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, { message: 'Task restored successfully' });
  })
);

export default router;
