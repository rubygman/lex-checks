// ============================================================================
// CORE MODULES INTEGRATION TEST
// apps/api/tests/integration/modules/core-modules.integration.test.ts
// 
// Tests CRUD + restore + audit for clients, cases, tasks, documents, invoices
// ============================================================================

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import pg from 'pg';

const { Pool } = pg;

// Skip if no database available
const DATABASE_URL = process.env.DATABASE_URL;
const shouldRun = !!DATABASE_URL;

describe.skipIf(!shouldRun)('Core Modules Integration', () => {
  let pool: pg.Pool;
  let tenantId: string;
  let userId: string;
  let roleId: string;

  // ============================================================================
  // SETUP
  // ============================================================================

  beforeAll(async () => {
    pool = new Pool({ connectionString: DATABASE_URL });

    // Get admin role
    const roleResult = await pool.query("SELECT id FROM roles WHERE name = 'admin' LIMIT 1");
    if (roleResult.rows.length === 0) {
      const insertRole = await pool.query("INSERT INTO roles (name, display_name) VALUES ('admin', 'Admin') RETURNING id");
      roleId = insertRole.rows[0].id;
    } else {
      roleId = roleResult.rows[0].id;
    }

    // Create test tenant
    const tenantSlug = `test-core-modules-${Date.now()}`;
    const tenantResult = await pool.query(
      "INSERT INTO tenants (name, slug) VALUES ('Core Modules Test', $1) RETURNING id",
      [tenantSlug]
    );
    tenantId = tenantResult.rows[0].id;

    // Create test user
    const userResult = await pool.query(
      `INSERT INTO users (tenant_id, email, password_hash, name, role_id, is_active)
       VALUES ($1, $2, 'test-hash', 'Test User', $3, true) RETURNING id`,
      [tenantId, `core-modules-test-${Date.now()}@test.com`, roleId]
    );
    userId = userResult.rows[0].id;
  });

  afterAll(async () => {
    if (pool && tenantId) {
      // Clean up in reverse order of dependencies
      await pool.query('DELETE FROM audit.logs WHERE tenant_id = $1', [tenantId]);
      await pool.query('DELETE FROM invoice_lines WHERE tenant_id = $1', [tenantId]);
      await pool.query('DELETE FROM invoices WHERE tenant_id = $1', [tenantId]);
      await pool.query('DELETE FROM documents WHERE tenant_id = $1', [tenantId]);
      await pool.query('DELETE FROM tasks WHERE tenant_id = $1', [tenantId]);
      await pool.query('DELETE FROM cases WHERE tenant_id = $1', [tenantId]);
      await pool.query('DELETE FROM clients WHERE tenant_id = $1', [tenantId]);
      await pool.query('DELETE FROM users WHERE tenant_id = $1', [tenantId]);
      await pool.query('DELETE FROM tenants WHERE id = $1', [tenantId]);
    }
    await pool?.end();
  });

  // ============================================================================
  // HELPER FUNCTIONS
  // ============================================================================

  async function logAudit(action: string, entityType: string, entityId: string, data?: any) {
    await pool.query(
      `INSERT INTO audit.logs (tenant_id, user_id, action, action_category, entity_type, entity_id, description, new_values_json, is_financial)
       VALUES ($1, $2, $3, 'data', $4, $5, $6, $7, true)`,
      [tenantId, userId, action, entityType, entityId, `${action} ${entityType}`, data ? JSON.stringify(data) : null]
    );
  }

  async function getAuditLogs(entityType: string, entityId: string) {
    const result = await pool.query(
      'SELECT * FROM audit.logs WHERE tenant_id = $1 AND entity_type = $2 AND entity_id = $3 ORDER BY created_at DESC',
      [tenantId, entityType, entityId]
    );
    return result.rows;
  }

  // ============================================================================
  // TESTS: Client Module
  // ============================================================================

  describe('Client Module', () => {
    let clientId: string;

    it('should create a client', async () => {
      const result = await pool.query(
        `INSERT INTO clients (tenant_id, name, client_type, status, address_country, currency, payment_terms, created_by)
         VALUES ($1, 'Test Client', 'individual', 'active', 'Israel', 'ILS', 30, $2)
         RETURNING *`,
        [tenantId, userId]
      );
      
      expect(result.rows.length).toBe(1);
      clientId = result.rows[0].id;
      expect(result.rows[0].name).toBe('Test Client');
      expect(result.rows[0].tenant_id).toBe(tenantId);

      await logAudit('CREATE', 'clients', clientId, result.rows[0]);
    });

    it('should update a client', async () => {
      const result = await pool.query(
        `UPDATE clients SET name = 'Updated Client', status = 'inactive', updated_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $1 AND id = $2 RETURNING *`,
        [tenantId, clientId]
      );
      
      expect(result.rows.length).toBe(1);
      expect(result.rows[0].name).toBe('Updated Client');
      expect(result.rows[0].status).toBe('inactive');

      await logAudit('UPDATE', 'clients', clientId, result.rows[0]);
    });

    it('should soft delete a client', async () => {
      const result = await pool.query(
        `UPDATE clients SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $1 AND id = $2 RETURNING *`,
        [tenantId, clientId]
      );
      
      expect(result.rows.length).toBe(1);
      expect(result.rows[0].deleted_at).not.toBeNull();

      await logAudit('DELETE', 'clients', clientId);
    });

    it('should restore a soft-deleted client', async () => {
      const result = await pool.query(
        `UPDATE clients SET deleted_at = NULL, updated_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $1 AND id = $2 RETURNING *`,
        [tenantId, clientId]
      );
      
      expect(result.rows.length).toBe(1);
      expect(result.rows[0].deleted_at).toBeNull();

      await logAudit('RESTORE', 'clients', clientId);
    });

    it('should have audit entries for all operations', async () => {
      const logs = await getAuditLogs('clients', clientId);
      
      expect(logs.length).toBe(4);
      expect(logs.map(l => l.action)).toEqual(['RESTORE', 'DELETE', 'UPDATE', 'CREATE']);
    });
  });

  // ============================================================================
  // TESTS: Case Module
  // ============================================================================

  describe('Case Module', () => {
    let clientId: string;
    let caseId: string;

    beforeAll(async () => {
      // Create a client for the case
      const clientResult = await pool.query(
        `INSERT INTO clients (tenant_id, name, client_type, status, address_country, currency, payment_terms)
         VALUES ($1, 'Case Test Client', 'company', 'active', 'Israel', 'ILS', 30) RETURNING id`,
        [tenantId]
      );
      clientId = clientResult.rows[0].id;
    });

    it('should create a case linked to client', async () => {
      const result = await pool.query(
        `INSERT INTO cases (tenant_id, client_id, case_number, title, case_type, status, priority, billing_type, open_date, created_by)
         VALUES ($1, $2, '2025-00001', 'Test Case', 'litigation', 'active', 'high', 'hourly', CURRENT_DATE, $3)
         RETURNING *`,
        [tenantId, clientId, userId]
      );
      
      expect(result.rows.length).toBe(1);
      caseId = result.rows[0].id;
      expect(result.rows[0].client_id).toBe(clientId);
      expect(result.rows[0].tenant_id).toBe(tenantId);

      await logAudit('CREATE', 'cases', caseId, result.rows[0]);
    });

    it('should update case status', async () => {
      const result = await pool.query(
        `UPDATE cases SET status = 'pending', priority = 'urgent', updated_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $1 AND id = $2 RETURNING *`,
        [tenantId, caseId]
      );
      
      expect(result.rows[0].status).toBe('pending');
      expect(result.rows[0].priority).toBe('urgent');

      await logAudit('UPDATE', 'cases', caseId, result.rows[0]);
    });

    it('should soft delete case', async () => {
      await pool.query(
        `UPDATE cases SET deleted_at = CURRENT_TIMESTAMP WHERE tenant_id = $1 AND id = $2`,
        [tenantId, caseId]
      );

      const check = await pool.query(
        'SELECT * FROM cases WHERE tenant_id = $1 AND id = $2',
        [tenantId, caseId]
      );
      expect(check.rows[0].deleted_at).not.toBeNull();

      await logAudit('DELETE', 'cases', caseId);
    });

    it('should restore case', async () => {
      await pool.query(
        `UPDATE cases SET deleted_at = NULL WHERE tenant_id = $1 AND id = $2`,
        [tenantId, caseId]
      );

      await logAudit('RESTORE', 'cases', caseId);

      const logs = await getAuditLogs('cases', caseId);
      expect(logs.length).toBe(4);
    });
  });

  // ============================================================================
  // TESTS: Task Module
  // ============================================================================

  describe('Task Module', () => {
    let taskId: string;

    it('should create a task', async () => {
      const result = await pool.query(
        `INSERT INTO tasks (tenant_id, title, status, priority, kanban_order, is_billable, created_by)
         VALUES ($1, 'Test Task', 'pending', 'medium', 0, true, $2)
         RETURNING *`,
        [tenantId, userId]
      );
      
      expect(result.rows.length).toBe(1);
      taskId = result.rows[0].id;
      expect(result.rows[0].status).toBe('pending');

      await logAudit('CREATE', 'tasks', taskId, result.rows[0]);
    });

    it('should move task (Kanban)', async () => {
      const result = await pool.query(
        `UPDATE tasks SET status = 'in_progress', kanban_order = 1, updated_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $1 AND id = $2 RETURNING *`,
        [tenantId, taskId]
      );
      
      expect(result.rows[0].status).toBe('in_progress');
      expect(result.rows[0].kanban_order).toBe(1);

      await logAudit('UPDATE', 'tasks', taskId, { status: 'in_progress', kanban_order: 1 });
    });

    it('should complete task', async () => {
      const result = await pool.query(
        `UPDATE tasks SET status = 'completed', completed_at = CURRENT_TIMESTAMP, completed_by = $3
         WHERE tenant_id = $1 AND id = $2 RETURNING *`,
        [tenantId, taskId, userId]
      );
      
      expect(result.rows[0].status).toBe('completed');
      expect(result.rows[0].completed_at).not.toBeNull();

      await logAudit('UPDATE', 'tasks', taskId, { status: 'completed' });
    });

    it('should soft delete and restore task', async () => {
      await pool.query(
        `UPDATE tasks SET deleted_at = CURRENT_TIMESTAMP WHERE tenant_id = $1 AND id = $2`,
        [tenantId, taskId]
      );
      await logAudit('DELETE', 'tasks', taskId);

      await pool.query(
        `UPDATE tasks SET deleted_at = NULL WHERE tenant_id = $1 AND id = $2`,
        [tenantId, taskId]
      );
      await logAudit('RESTORE', 'tasks', taskId);

      const logs = await getAuditLogs('tasks', taskId);
      expect(logs.length).toBe(5);
    });
  });

  // ============================================================================
  // TESTS: Document Module
  // ============================================================================

  describe('Document Module', () => {
    let documentId: string;

    it('should create document metadata', async () => {
      const result = await pool.query(
        `INSERT INTO documents (tenant_id, title, document_type, file_name, file_size, mime_type, storage_path, storage_provider, version, is_template, is_confidential, uploaded_by)
         VALUES ($1, 'Test Document', 'contract', 'test.pdf', 1024, 'application/pdf', '/uploads/test.pdf', 'local', 1, false, false, $2)
         RETURNING *`,
        [tenantId, userId]
      );
      
      expect(result.rows.length).toBe(1);
      documentId = result.rows[0].id;

      await logAudit('CREATE', 'documents', documentId, result.rows[0]);
    });

    it('should update document metadata', async () => {
      const result = await pool.query(
        `UPDATE documents SET title = 'Updated Document', is_confidential = true
         WHERE tenant_id = $1 AND id = $2 RETURNING *`,
        [tenantId, documentId]
      );
      
      expect(result.rows[0].title).toBe('Updated Document');
      expect(result.rows[0].is_confidential).toBe(true);

      await logAudit('UPDATE', 'documents', documentId, result.rows[0]);
    });

    it('should soft delete and restore document', async () => {
      await pool.query(
        `UPDATE documents SET deleted_at = CURRENT_TIMESTAMP WHERE tenant_id = $1 AND id = $2`,
        [tenantId, documentId]
      );
      await logAudit('DELETE', 'documents', documentId);

      await pool.query(
        `UPDATE documents SET deleted_at = NULL WHERE tenant_id = $1 AND id = $2`,
        [tenantId, documentId]
      );
      await logAudit('RESTORE', 'documents', documentId);

      const logs = await getAuditLogs('documents', documentId);
      expect(logs.length).toBe(4);
    });
  });

  // ============================================================================
  // TESTS: Invoice Module
  // ============================================================================

  describe('Invoice Module', () => {
    let clientId: string;
    let invoiceId: string;

    beforeAll(async () => {
      const clientResult = await pool.query(
        `INSERT INTO clients (tenant_id, name, client_type, status, address_country, currency, payment_terms)
         VALUES ($1, 'Invoice Test Client', 'company', 'active', 'Israel', 'ILS', 30) RETURNING id`,
        [tenantId]
      );
      clientId = clientResult.rows[0].id;
    });

    it('should create an invoice', async () => {
      const result = await pool.query(
        `INSERT INTO invoices (tenant_id, client_id, invoice_number, status, issue_date, due_date, subtotal, tax_rate, tax_amount, discount_amount, total, paid_amount, balance_due, currency, created_by)
         VALUES ($1, $2, 'INV-2025-00001', 'draft', CURRENT_DATE, CURRENT_DATE + 30, 1000, 17, 170, 0, 1170, 0, 1170, 'ILS', $3)
         RETURNING *`,
        [tenantId, clientId, userId]
      );
      
      expect(result.rows.length).toBe(1);
      invoiceId = result.rows[0].id;
      expect(result.rows[0].total).toBe(1170);

      await logAudit('CREATE', 'invoices', invoiceId, result.rows[0]);
    });

    it('should add invoice line', async () => {
      const result = await pool.query(
        `INSERT INTO invoice_lines (tenant_id, invoice_id, description, quantity, unit_price, amount, sort_order)
         VALUES ($1, $2, 'Legal Services', 10, 100, 1000, 0)
         RETURNING *`,
        [tenantId, invoiceId]
      );
      
      expect(result.rows.length).toBe(1);
      expect(result.rows[0].amount).toBe(1000);
    });

    it('should update invoice status to sent', async () => {
      const result = await pool.query(
        `UPDATE invoices SET status = 'sent', sent_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $1 AND id = $2 RETURNING *`,
        [tenantId, invoiceId]
      );
      
      expect(result.rows[0].status).toBe('sent');
      expect(result.rows[0].sent_at).not.toBeNull();

      await logAudit('UPDATE', 'invoices', invoiceId, { status: 'sent' });
    });

    it('should record payment', async () => {
      const result = await pool.query(
        `UPDATE invoices SET paid_amount = 1170, balance_due = 0, status = 'paid', paid_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $1 AND id = $2 RETURNING *`,
        [tenantId, invoiceId]
      );
      
      expect(result.rows[0].status).toBe('paid');
      expect(result.rows[0].balance_due).toBe(0);

      await logAudit('UPDATE', 'invoices', invoiceId, { status: 'paid', paid_amount: 1170 });
    });

    it('should soft delete and restore invoice', async () => {
      await pool.query(
        `UPDATE invoices SET deleted_at = CURRENT_TIMESTAMP WHERE tenant_id = $1 AND id = $2`,
        [tenantId, invoiceId]
      );
      await logAudit('DELETE', 'invoices', invoiceId);

      await pool.query(
        `UPDATE invoices SET deleted_at = NULL WHERE tenant_id = $1 AND id = $2`,
        [tenantId, invoiceId]
      );
      await logAudit('RESTORE', 'invoices', invoiceId);

      const logs = await getAuditLogs('invoices', invoiceId);
      expect(logs.length).toBe(5);
    });
  });

  // ============================================================================
  // TESTS: Tenant Isolation
  // ============================================================================

  describe('Tenant Isolation', () => {
    let otherTenantId: string;

    beforeAll(async () => {
      const result = await pool.query(
        "INSERT INTO tenants (name, slug) VALUES ('Other Tenant', $1) RETURNING id",
        [`other-tenant-${Date.now()}`]
      );
      otherTenantId = result.rows[0].id;
    });

    afterAll(async () => {
      await pool.query('DELETE FROM tenants WHERE id = $1', [otherTenantId]);
    });

    it('should not see clients from other tenant', async () => {
      // Create client in other tenant
      await pool.query(
        `INSERT INTO clients (tenant_id, name, client_type, status, address_country, currency, payment_terms)
         VALUES ($1, 'Other Tenant Client', 'individual', 'active', 'Israel', 'ILS', 30)`,
        [otherTenantId]
      );

      // Query with our tenant ID - should not see other tenant's client
      const result = await pool.query(
        'SELECT * FROM clients WHERE tenant_id = $1 AND name = $2',
        [tenantId, 'Other Tenant Client']
      );
      
      expect(result.rows.length).toBe(0);
    });
  });
});
