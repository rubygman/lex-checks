// ============================================================================
// AUDIT MUTATION INTEGRATION TEST
// apps/api/tests/integration/audit/audit-mutation.integration.test.ts
// 
// Tests that mutations create audit entries using the audit helper
// ============================================================================

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import pg from 'pg';

const { Pool } = pg;

// Skip if no database available
const DATABASE_URL = process.env.DATABASE_URL;
const shouldRun = !!DATABASE_URL;

describe.skipIf(!shouldRun)('Audit Mutation Integration', () => {
  let pool: pg.Pool;
  let tenantId: string;
  let userId: string;
  let roleId: string;

  // ============================================================================
  // SETUP
  // ============================================================================

  beforeAll(async () => {
    pool = new Pool({ connectionString: DATABASE_URL });

    // Get a role
    const roleResult = await pool.query('SELECT id FROM roles LIMIT 1');
    if (roleResult.rows.length === 0) {
      throw new Error('No roles found. Run migrations first.');
    }
    roleId = roleResult.rows[0].id;

    // Create test tenant
    const tenantSlug = `test-audit-mutation-${Date.now()}`;
    const tenantResult = await pool.query(
      "INSERT INTO tenants (name, slug) VALUES ('Audit Mutation Test', $1) RETURNING id",
      [tenantSlug]
    );
    tenantId = tenantResult.rows[0].id;

    // Create test user
    const userResult = await pool.query(
      `INSERT INTO users (tenant_id, email, password_hash, name, role_id, is_active)
       VALUES ($1, $2, 'test-hash', 'Test User', $3, true) RETURNING id`,
      [tenantId, `audit-mutation-test-${Date.now()}@test.com`, roleId]
    );
    userId = userResult.rows[0].id;
  });

  afterAll(async () => {
    if (pool && tenantId) {
      await pool.query('DELETE FROM audit.logs WHERE tenant_id = $1', [tenantId]);
      await pool.query('DELETE FROM users WHERE tenant_id = $1', [tenantId]);
      await pool.query('DELETE FROM tenants WHERE id = $1', [tenantId]);
    }
    await pool?.end();
  });

  beforeEach(async () => {
    // Clear audit logs between tests
    await pool.query('DELETE FROM audit.logs WHERE tenant_id = $1', [tenantId]);
  });

  // ============================================================================
  // SIMULATE AUDIT LOGGING (what the mutation logger does)
  // ============================================================================

  async function simulateAuditCreate(
    entityType: string,
    entityId: string,
    entityData: Record<string, unknown>
  ) {
    const correlationId = `test-${Date.now()}`;
    
    await pool.query(
      `INSERT INTO audit.logs (
        tenant_id, user_id, action, action_category, entity_type, entity_id,
        description, new_values_json, ip_address, request_id, is_financial
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
      [
        tenantId,
        userId,
        'CREATE',
        'data',
        entityType,
        entityId,
        `Created ${entityType}`,
        JSON.stringify(entityData),
        '127.0.0.1',
        correlationId,
        ['clients', 'cases', 'invoices', 'trust_accounts'].includes(entityType),
      ]
    );

    return correlationId;
  }

  async function simulateAuditUpdate(
    entityType: string,
    entityId: string,
    oldData: Record<string, unknown>,
    newData: Record<string, unknown>
  ) {
    const correlationId = `test-${Date.now()}`;
    
    await pool.query(
      `INSERT INTO audit.logs (
        tenant_id, user_id, action, action_category, entity_type, entity_id,
        description, old_values_json, new_values_json, ip_address, request_id, is_financial
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`,
      [
        tenantId,
        userId,
        'UPDATE',
        'data',
        entityType,
        entityId,
        `Updated ${entityType}`,
        JSON.stringify(oldData),
        JSON.stringify(newData),
        '127.0.0.1',
        correlationId,
        ['clients', 'cases', 'invoices', 'trust_accounts'].includes(entityType),
      ]
    );

    return correlationId;
  }

  async function simulateAuditSoftDelete(
    entityType: string,
    entityId: string,
    entityData?: Record<string, unknown>
  ) {
    const correlationId = `test-${Date.now()}`;
    
    await pool.query(
      `INSERT INTO audit.logs (
        tenant_id, user_id, action, action_category, entity_type, entity_id,
        description, old_values_json, ip_address, request_id, is_financial
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
      [
        tenantId,
        userId,
        'DELETE',
        'data',
        entityType,
        entityId,
        `Deleted ${entityType}`,
        entityData ? JSON.stringify(entityData) : '{}',
        '127.0.0.1',
        correlationId,
        ['clients', 'cases', 'invoices', 'trust_accounts'].includes(entityType),
      ]
    );

    return correlationId;
  }

  async function getAuditLogs(filters: { entityType?: string; entityId?: string; action?: string } = {}) {
    let query = 'SELECT * FROM audit.logs WHERE tenant_id = $1';
    const params: unknown[] = [tenantId];
    let paramIndex = 2;

    if (filters.entityType) {
      query += ` AND entity_type = $${paramIndex++}`;
      params.push(filters.entityType);
    }
    if (filters.entityId) {
      query += ` AND entity_id = $${paramIndex++}`;
      params.push(filters.entityId);
    }
    if (filters.action) {
      query += ` AND action = $${paramIndex++}`;
      params.push(filters.action);
    }

    query += ' ORDER BY created_at DESC';

    const result = await pool.query(query, params);
    return result.rows;
  }

  // ============================================================================
  // TESTS: Create Audit
  // ============================================================================

  describe('Create Mutation Audit', () => {
    it('should create audit entry for client creation', async () => {
      const clientId = '550e8400-e29b-41d4-a716-446655440001';
      const clientData = {
        id: clientId,
        name: 'Test Client',
        email: 'test@example.com',
        clientType: 'individual',
      };

      await simulateAuditCreate('client', clientId, clientData);

      const logs = await getAuditLogs({ entityType: 'client', entityId: clientId });
      
      expect(logs.length).toBe(1);
      expect(logs[0].action).toBe('CREATE');
      expect(logs[0].entity_type).toBe('client');
      expect(logs[0].entity_id).toBe(clientId);
      expect(logs[0].user_id).toBe(userId);
      expect(logs[0].tenant_id).toBe(tenantId);
      expect(logs[0].new_values_json).toBeDefined();
      expect(logs[0].is_financial).toBe(true); // clients are financial
    });

    it('should create audit entry for case creation', async () => {
      const caseId = '550e8400-e29b-41d4-a716-446655440002';
      const caseData = {
        id: caseId,
        title: 'Test Case',
        status: 'active',
      };

      await simulateAuditCreate('case', caseId, caseData);

      const logs = await getAuditLogs({ entityType: 'case', action: 'CREATE' });
      
      expect(logs.length).toBe(1);
      expect(logs[0].action).toBe('CREATE');
      expect(logs[0].is_financial).toBe(true); // cases are financial
    });

    it('should create audit entry for task creation', async () => {
      const taskId = '550e8400-e29b-41d4-a716-446655440003';
      const taskData = {
        id: taskId,
        title: 'Test Task',
        status: 'pending',
      };

      await simulateAuditCreate('task', taskId, taskData);

      const logs = await getAuditLogs({ entityType: 'task', action: 'CREATE' });
      
      expect(logs.length).toBe(1);
      expect(logs[0].action).toBe('CREATE');
      expect(logs[0].is_financial).toBe(false); // tasks are NOT financial
    });
  });

  // ============================================================================
  // TESTS: Update Audit
  // ============================================================================

  describe('Update Mutation Audit', () => {
    it('should create audit entry with old and new values', async () => {
      const clientId = '550e8400-e29b-41d4-a716-446655440004';
      const oldData = { name: 'Old Name', status: 'active' };
      const newData = { name: 'New Name', status: 'inactive' };

      await simulateAuditUpdate('client', clientId, oldData, newData);

      const logs = await getAuditLogs({ entityType: 'client', entityId: clientId });
      
      expect(logs.length).toBe(1);
      expect(logs[0].action).toBe('UPDATE');
      expect(logs[0].old_values_json).toEqual(oldData);
      expect(logs[0].new_values_json).toEqual(newData);
    });

    it('should audit invoice update as financial', async () => {
      const invoiceId = '550e8400-e29b-41d4-a716-446655440005';
      const oldData = { total: 100 };
      const newData = { total: 150 };

      await simulateAuditUpdate('invoice', invoiceId, oldData, newData);

      const logs = await getAuditLogs({ entityType: 'invoice' });
      
      expect(logs.length).toBe(1);
      expect(logs[0].is_financial).toBe(true);
    });
  });

  // ============================================================================
  // TESTS: Soft Delete Audit
  // ============================================================================

  describe('Soft Delete Mutation Audit', () => {
    it('should create audit entry for soft delete', async () => {
      const documentId = '550e8400-e29b-41d4-a716-446655440006';
      const documentData = { title: 'Deleted Document', fileName: 'test.pdf' };

      await simulateAuditSoftDelete('document', documentId, documentData);

      const logs = await getAuditLogs({ entityType: 'document', entityId: documentId });
      
      expect(logs.length).toBe(1);
      expect(logs[0].action).toBe('DELETE');
      expect(logs[0].old_values_json).toEqual(documentData);
    });

    it('should audit trust account deletion', async () => {
      const accountId = '550e8400-e29b-41d4-a716-446655440007';

      await simulateAuditSoftDelete('trust_account', accountId);

      const logs = await getAuditLogs({ entityType: 'trust_account' });
      
      expect(logs.length).toBe(1);
      expect(logs[0].action).toBe('DELETE');
      expect(logs[0].is_financial).toBe(true);
    });
  });

  // ============================================================================
  // TESTS: Audit Entry Properties
  // ============================================================================

  describe('Audit Entry Properties', () => {
    it('should include request correlation ID', async () => {
      const entityId = '550e8400-e29b-41d4-a716-446655440008';
      const correlationId = await simulateAuditCreate('task', entityId, { title: 'Test' });

      const logs = await getAuditLogs({ entityType: 'task', entityId });
      
      expect(logs[0].request_id).toBe(correlationId);
    });

    it('should include IP address', async () => {
      const entityId = '550e8400-e29b-41d4-a716-446655440009';
      await simulateAuditCreate('case', entityId, { title: 'Test' });

      const logs = await getAuditLogs({ entityType: 'case', entityId });
      
      expect(logs[0].ip_address).toBe('127.0.0.1');
    });

    it('should have entry hash for tamper detection', async () => {
      const entityId = '550e8400-e29b-41d4-a716-446655440010';
      await simulateAuditCreate('client', entityId, { name: 'Test' });

      const logs = await getAuditLogs({ entityType: 'client', entityId });
      
      // Entry hash is generated by trigger
      expect(logs[0].entry_hash).toBeDefined();
      expect(logs[0].entry_hash.length).toBe(64); // SHA-256 hex
    });
  });

  // ============================================================================
  // TESTS: Entity History
  // ============================================================================

  describe('Entity History', () => {
    it('should track full entity history', async () => {
      const clientId = '550e8400-e29b-41d4-a716-446655440011';
      
      // Create
      await simulateAuditCreate('client', clientId, { name: 'Client V1' });
      
      // Update 1
      await simulateAuditUpdate('client', clientId, { name: 'Client V1' }, { name: 'Client V2' });
      
      // Update 2
      await simulateAuditUpdate('client', clientId, { name: 'Client V2' }, { name: 'Client V3' });
      
      // Soft delete
      await simulateAuditSoftDelete('client', clientId, { name: 'Client V3' });

      const logs = await getAuditLogs({ entityType: 'client', entityId: clientId });
      
      expect(logs.length).toBe(4);
      
      // Newest first
      expect(logs[0].action).toBe('DELETE');
      expect(logs[1].action).toBe('UPDATE');
      expect(logs[2].action).toBe('UPDATE');
      expect(logs[3].action).toBe('CREATE');
    });
  });
});
