// ============================================================================
// DATABASE LAYER UNIT TESTS
// apps/api/src/tests/unit/db/query-builder.test.ts
// ============================================================================

import { describe, it, expect, beforeEach } from 'vitest';
import {
  QueryBuilder,
  createQueryBuilder,
  buildInsert,
  buildUpdate,
  buildSoftDelete,
  buildHardDelete,
  IMMUTABLE_TABLES,
  GLOBAL_TABLES,
  SOFT_DELETE_TABLES,
} from '../../../db/query-builder.js';
import {
  TenantScopingError,
  ImmutableTableError,
} from '../../../db/errors.js';

describe('QueryBuilder', () => {
  let qb: QueryBuilder;

  beforeEach(() => {
    qb = createQueryBuilder();
  });

  describe('Static helpers', () => {
    it('should identify tenant-scoped tables correctly', () => {
      expect(QueryBuilder.requiresTenantScoping('clients')).toBe(true);
      expect(QueryBuilder.requiresTenantScoping('cases')).toBe(true);
      expect(QueryBuilder.requiresTenantScoping('invoices')).toBe(true);
      expect(QueryBuilder.requiresTenantScoping('roles')).toBe(false);
      expect(QueryBuilder.requiresTenantScoping('permissions')).toBe(false);
    });

    it('should identify immutable tables correctly', () => {
      expect(QueryBuilder.isImmutable('trust_transactions')).toBe(true);
      expect(QueryBuilder.isImmutable('audit.logs')).toBe(true);
      expect(QueryBuilder.isImmutable('clients')).toBe(false);
      expect(QueryBuilder.isImmutable('invoices')).toBe(false);
    });

    it('should identify soft-delete tables correctly', () => {
      expect(QueryBuilder.supportsSoftDelete('clients')).toBe(true);
      expect(QueryBuilder.supportsSoftDelete('cases')).toBe(true);
      expect(QueryBuilder.supportsSoftDelete('trust_transactions')).toBe(false);
      expect(QueryBuilder.supportsSoftDelete('audit.logs')).toBe(false);
    });
  });

  describe('Tenant Scoping Enforcement', () => {
    it('should THROW when building SELECT without tenantId on tenant-scoped table', () => {
      expect(() => {
        qb.table('clients').buildSelect();
      }).toThrow(TenantScopingError);
    });

    it('should THROW when building SELECT with empty tenantId', () => {
      expect(() => {
        qb.table('clients').tenant('').buildSelect();
      }).toThrow(TenantScopingError);
    });

    it('should THROW when building SELECT with whitespace-only tenantId', () => {
      expect(() => {
        qb.table('clients').tenant('   ').buildSelect();
      }).toThrow(TenantScopingError);
    });

    it('should ALLOW SELECT on global tables without tenantId', () => {
      const result = qb.table('roles').buildSelect();
      expect(result.text).toContain('SELECT');
      expect(result.text).not.toContain('tenant_id');
    });

    it('should INCLUDE tenant_id filter when tenantId is provided', () => {
      const tenantId = '550e8400-e29b-41d4-a716-446655440000';
      const result = qb.table('clients').tenant(tenantId).buildSelect();

      expect(result.text).toContain('tenant_id = $');
      expect(result.params).toContain(tenantId);
    });

    it('should THROW descriptive error message for missing tenantId', () => {
      try {
        qb.table('cases').buildSelect();
        expect.fail('Should have thrown');
      } catch (error) {
        expect(error).toBeInstanceOf(TenantScopingError);
        expect((error as TenantScopingError).message).toContain('cases');
        expect((error as TenantScopingError).message).toContain('tenant');
      }
    });
  });

  describe('Soft Delete Filtering', () => {
    const tenantId = '550e8400-e29b-41d4-a716-446655440000';

    it('should AUTOMATICALLY add deleted_at IS NULL for soft-delete tables', () => {
      const result = qb.table('clients').tenant(tenantId).buildSelect();

      expect(result.text).toContain('deleted_at IS NULL');
    });

    it('should NOT add deleted_at filter when includeDeleted is true', () => {
      const result = qb
        .table('clients')
        .tenant(tenantId)
        .includeDeleted(true)
        .buildSelect();

      expect(result.text).not.toContain('deleted_at IS NULL');
    });

    it('should NOT add deleted_at filter for tables without soft delete', () => {
      // roles is a global table without soft delete
      const result = qb.table('roles').buildSelect();

      expect(result.text).not.toContain('deleted_at');
    });
  });

  describe('WHERE Clauses', () => {
    const tenantId = '550e8400-e29b-41d4-a716-446655440000';

    it('should build correct WHERE with equals', () => {
      const result = qb
        .table('clients')
        .tenant(tenantId)
        .whereEquals('status', 'active')
        .buildSelect();

      expect(result.text).toContain('status = $');
      expect(result.params).toContain('active');
    });

    it('should build correct WHERE IN clause', () => {
      const result = qb
        .table('clients')
        .tenant(tenantId)
        .whereIn('status', ['active', 'lead'])
        .buildSelect();

      expect(result.text).toContain('status IN');
      expect(result.params).toContain('active');
      expect(result.params).toContain('lead');
    });

    it('should build correct WHERE with IS NULL', () => {
      const result = qb
        .table('clients')
        .tenant(tenantId)
        .where('email', 'IS NULL')
        .buildSelect();

      expect(result.text).toContain('email IS NULL');
    });

    it('should combine multiple WHERE conditions with AND', () => {
      const result = qb
        .table('clients')
        .tenant(tenantId)
        .whereEquals('status', 'active')
        .where('email', 'IS NOT NULL')
        .buildSelect();

      expect(result.text).toContain('AND');
      expect(result.text).toContain('status = $');
      expect(result.text).toContain('email IS NOT NULL');
    });
  });

  describe('Pagination', () => {
    const tenantId = '550e8400-e29b-41d4-a716-446655440000';

    it('should add LIMIT and OFFSET', () => {
      const result = qb
        .table('clients')
        .tenant(tenantId)
        .paginate(10, 20)
        .buildSelect();

      expect(result.text).toContain('LIMIT 10');
      expect(result.text).toContain('OFFSET 20');
    });
  });

  describe('Sorting', () => {
    const tenantId = '550e8400-e29b-41d4-a716-446655440000';

    it('should add ORDER BY clause', () => {
      const result = qb
        .table('clients')
        .tenant(tenantId)
        .orderBy('created_at', 'DESC')
        .buildSelect();

      expect(result.text).toContain('ORDER BY created_at DESC');
    });
  });

  describe('COUNT queries', () => {
    const tenantId = '550e8400-e29b-41d4-a716-446655440000';

    it('should build COUNT query with tenant scoping', () => {
      const result = qb
        .table('clients')
        .tenant(tenantId)
        .buildCount();

      expect(result.text).toContain('COUNT(*)');
      expect(result.text).toContain('tenant_id = $');
      expect(result.text).toContain('deleted_at IS NULL');
    });

    it('should not include LIMIT/OFFSET in COUNT query', () => {
      const result = qb
        .table('clients')
        .tenant(tenantId)
        .paginate(10, 20)
        .buildCount();

      expect(result.text).not.toContain('LIMIT');
      expect(result.text).not.toContain('OFFSET');
    });
  });
});

describe('buildInsert', () => {
  it('should THROW when inserting into tenant-scoped table without tenantId', () => {
    expect(() => {
      buildInsert('clients', null, { name: 'Test' });
    }).toThrow(TenantScopingError);
  });

  it('should THROW when inserting with empty tenantId', () => {
    expect(() => {
      buildInsert('clients', '', { name: 'Test' });
    }).toThrow(TenantScopingError);
  });

  it('should INCLUDE tenant_id in INSERT', () => {
    const tenantId = '550e8400-e29b-41d4-a716-446655440000';
    const result = buildInsert('clients', tenantId, { name: 'Test Client' });

    expect(result.text).toContain('tenant_id');
    expect(result.params).toContain(tenantId);
    expect(result.text).toContain('RETURNING *');
  });

  it('should ALLOW INSERT into global table without tenantId', () => {
    const result = buildInsert('roles', null, { name: 'custom_role' });

    expect(result.text).toContain('INSERT INTO roles');
    expect(result.text).not.toContain('tenant_id');
  });
});

describe('buildUpdate', () => {
  const tenantId = '550e8400-e29b-41d4-a716-446655440000';
  const recordId = '660e8400-e29b-41d4-a716-446655440001';

  it('should THROW when updating without tenantId', () => {
    expect(() => {
      buildUpdate('clients', '', recordId, { name: 'Updated' });
    }).toThrow(TenantScopingError);
  });

  it('should THROW when updating immutable table', () => {
    expect(() => {
      buildUpdate('trust_transactions', tenantId, recordId, { amount: 100 });
    }).toThrow(ImmutableTableError);
  });

  it('should THROW when updating audit.logs', () => {
    expect(() => {
      buildUpdate('audit.logs', tenantId, recordId, { action: 'UPDATE' });
    }).toThrow(ImmutableTableError);
  });

  it('should INCLUDE tenant_id in WHERE clause', () => {
    const result = buildUpdate('clients', tenantId, recordId, { name: 'Updated Name' });

    expect(result.text).toContain('tenant_id = $');
    expect(result.params).toContain(tenantId);
  });

  it('should INCLUDE deleted_at IS NULL for soft-delete tables', () => {
    const result = buildUpdate('clients', tenantId, recordId, { name: 'Updated Name' });

    expect(result.text).toContain('deleted_at IS NULL');
  });

  it('should ADD updated_at timestamp', () => {
    const result = buildUpdate('clients', tenantId, recordId, { name: 'Updated Name' });

    expect(result.text).toContain('updated_at = $');
  });
});

describe('buildSoftDelete', () => {
  const tenantId = '550e8400-e29b-41d4-a716-446655440000';
  const recordId = '660e8400-e29b-41d4-a716-446655440001';

  it('should THROW when soft-deleting without tenantId', () => {
    expect(() => {
      buildSoftDelete('clients', '', recordId);
    }).toThrow(TenantScopingError);
  });

  it('should THROW when soft-deleting immutable table', () => {
    expect(() => {
      buildSoftDelete('trust_transactions', tenantId, recordId);
    }).toThrow(ImmutableTableError);
  });

  it('should SET deleted_at to CURRENT_TIMESTAMP', () => {
    const result = buildSoftDelete('clients', tenantId, recordId);

    expect(result.text).toContain('SET deleted_at = CURRENT_TIMESTAMP');
  });

  it('should INCLUDE tenant_id in WHERE clause', () => {
    const result = buildSoftDelete('clients', tenantId, recordId);

    expect(result.text).toContain('tenant_id = $');
    expect(result.params).toContain(tenantId);
  });

  it('should only affect non-deleted records', () => {
    const result = buildSoftDelete('clients', tenantId, recordId);

    expect(result.text).toContain('deleted_at IS NULL');
  });
});

describe('buildHardDelete', () => {
  const tenantId = '550e8400-e29b-41d4-a716-446655440000';
  const recordId = '660e8400-e29b-41d4-a716-446655440001';

  it('should THROW when hard-deleting without tenantId', () => {
    expect(() => {
      buildHardDelete('clients', '', recordId);
    }).toThrow(TenantScopingError);
  });

  it('should THROW when hard-deleting immutable table', () => {
    expect(() => {
      buildHardDelete('trust_transactions', tenantId, recordId);
    }).toThrow(ImmutableTableError);
  });

  it('should build DELETE query with tenant scoping', () => {
    const result = buildHardDelete('clients', tenantId, recordId);

    expect(result.text).toContain('DELETE FROM clients');
    expect(result.text).toContain('tenant_id = $');
    expect(result.params).toContain(tenantId);
  });
});
