-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 004: Trust Ledger System - DOWN
-- ============================================================================

BEGIN;

-- Drop indexes
DROP INDEX IF EXISTS idx_trust_tx_reference;
DROP INDEX IF EXISTS idx_trust_tx_case;
DROP INDEX IF EXISTS idx_trust_tx_client;
DROP INDEX IF EXISTS idx_trust_tx_statement;

-- Drop views
DROP VIEW IF EXISTS trust_monthly_summary;
DROP VIEW IF EXISTS trust_balance_history;

-- Drop functions
DROP FUNCTION IF EXISTS get_trust_account_statement(UUID, UUID, TIMESTAMPTZ, TIMESTAMPTZ);
DROP FUNCTION IF EXISTS reconcile_trust_account(UUID, UUID);
DROP FUNCTION IF EXISTS generate_trust_transaction_reference();
DROP FUNCTION IF EXISTS calculate_trust_transaction_balance();
DROP FUNCTION IF EXISTS block_trust_transaction_delete();
DROP FUNCTION IF EXISTS block_trust_transaction_update();

-- Drop triggers
DROP TRIGGER IF EXISTS trg_trust_transactions_generate_reference ON trust_transactions;
DROP TRIGGER IF EXISTS trg_trust_transactions_calculate_balance ON trust_transactions;
DROP TRIGGER IF EXISTS trg_trust_transactions_block_delete ON trust_transactions;
DROP TRIGGER IF EXISTS trg_trust_transactions_block_update ON trust_transactions;

COMMIT;
