// ============================================================================
// SOFT DELETE SERVICE
// apps/api/src/services/soft-delete.service.ts
// 
// Centralized service for soft delete operations with:
// - Retention tracking
// - Restoration capabilities
// - Cascade soft delete
// - Hard delete scheduling
// ============================================================================

import { query, withTransaction } from '../db/connection.js';
import { NotFoundError, DatabaseError, TenantScopingError, parsePostgresError } from '../db/errors.js';
import type pg from 'pg';

// ============================================================================
// TYPES
// ============================================================================

export interface SoftDeleteOptions {
  deletedBy?: string;
  isFinancial?: boolean;
  retentionDays?: number;
  metadata?: Record<string, unknown>;
  cascadeDelete?: CascadeConfig[];
}

export interface CascadeConfig {
  table: string;
  foreignKey: string;
  isFinancial?: boolean;
}

export interface SoftDeletedRecord {
  table_name: string;
  record_id: string;
  deleted_at: Date;
  deleted_by: string | null;
  hard_delete_after: Date;
  days_until_hard_delete: number;
}

export interface RestoreOptions {
  restoreRelated?: boolean;
}

export interface RetentionRecord {
  id: string;
  tenant_id: string;
  table_name: string;
  record_id: string;
  deleted_at: Date;
  retention_days: number;
}

export interface SoftDeleteStats {
  tenant_id: string;
  table_name: string;
  deleted_count: number;
  oldest_deletion: Date;
  newest_deletion: Date;
  eligible_for_hard_delete: number;
}

// ============================================================================
// TABLE CONFIGURATIONS
// Defines which tables support soft delete and their relationships
// ============================================================================

export const SOFT_DELETE_TABLES = {
  tenants: { 
    retentionDays: 365 * 7, // 7 years
    isFinancial: false,
    cascades: [
      { table: 'users', foreignKey: 'tenant_id' },
      { table: 'clients', foreignKey: 'tenant_id' },
      // Note: Cases, tasks, etc. cascade from clients
    ]
  },
  users: { 
    retentionDays: 365 * 7,
    isFinancial: false,
    cascades: []
  },
  clients: { 
    retentionDays: 365 * 7,
    isFinancial: true,
    cascades: [
      { table: 'cases', foreignKey: 'client_id' },
      { table: 'trust_accounts', foreignKey: 'client_id' },
    ]
  },
  cases: { 
    retentionDays: 365 * 7,
    isFinancial: true,
    cascades: [
      { table: 'tasks', foreignKey: 'case_id' },
      { table: 'documents', foreignKey: 'case_id' },
      { table: 'calendar_events', foreignKey: 'case_id' },
      { table: 'time_entries', foreignKey: 'case_id' },
    ]
  },
  tasks: { 
    retentionDays: 365,
    isFinancial: false,
    cascades: []
  },
  documents: { 
    retentionDays: 365 * 7,
    isFinancial: false,
    cascades: []
  },
  calendar_events: { 
    retentionDays: 365,
    isFinancial: false,
    cascades: []
  },
  time_entries: { 
    retentionDays: 365 * 7,
    isFinancial: true,
    cascades: []
  },
  invoices: { 
    retentionDays: 365 * 7,
    isFinancial: true,
    cascades: [
      { table: 'invoice_lines', foreignKey: 'invoice_id' },
      { table: 'payments', foreignKey: 'invoice_id' },
    ]
  },
  payments: { 
    retentionDays: 365 * 7,
    isFinancial: true,
    cascades: []
  },
  trust_accounts: { 
    retentionDays: 365 * 7,
    isFinancial: true,
    cascades: []
    // Note: trust_transactions are IMMUTABLE, never deleted
  },
  custom_field_definitions: {
    retentionDays: 365,
    isFinancial: false,
    cascades: []
  },
} as const;

export type SoftDeleteTable = keyof typeof SOFT_DELETE_TABLES;

// ============================================================================
// SERVICE
// ============================================================================

export class SoftDeleteService {
  /**
   * Soft delete a record with retention tracking
   */
  async softDelete(
    tenantId: string,
    table: SoftDeleteTable,
    recordId: string,
    options: SoftDeleteOptions = {}
  ): Promise<{ deleted: boolean; retentionId: string }> {
    if (!tenantId) {
      throw new TenantScopingError('tenantId is required for soft delete');
    }

    const tableConfig = SOFT_DELETE_TABLES[table];
    const retentionDays = options.retentionDays ?? tableConfig.retentionDays;
    const isFinancial = options.isFinancial ?? tableConfig.isFinancial;

    return withTransaction(async (client) => {
      // 1. Verify record exists and belongs to tenant
      const existsResult = await client.query(
        `SELECT id FROM ${table} WHERE id = $1 AND tenant_id = $2 AND deleted_at IS NULL`,
        [recordId, tenantId]
      );

      if (existsResult.rows.length === 0) {
        throw new NotFoundError(table, recordId);
      }

      // 2. Soft delete the record
      await client.query(
        `UPDATE ${table} SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
         WHERE id = $1 AND tenant_id = $2`,
        [recordId, tenantId]
      );

      // 3. Track in retention table
      const retentionResult = await client.query<{ id: string }>(
        `SELECT track_soft_delete($1, $2, $3, $4, $5, $6, $7) as id`,
        [
          tenantId,
          table,
          recordId,
          options.deletedBy || null,
          isFinancial,
          retentionDays,
          JSON.stringify(options.metadata || {}),
        ]
      );

      // 4. Cascade soft delete to related records if configured
      if (options.cascadeDelete || tableConfig.cascades.length > 0) {
        const cascades = options.cascadeDelete || tableConfig.cascades;
        
        for (const cascade of cascades) {
          await this.cascadeSoftDelete(
            client,
            tenantId,
            cascade.table as SoftDeleteTable,
            cascade.foreignKey,
            recordId,
            {
              deletedBy: options.deletedBy,
              isFinancial: cascade.isFinancial ?? tableConfig.isFinancial,
            }
          );
        }
      }

      return {
        deleted: true,
        retentionId: retentionResult.rows[0]!.id,
      };
    });
  }

  /**
   * Cascade soft delete to related records
   */
  private async cascadeSoftDelete(
    client: pg.PoolClient,
    tenantId: string,
    table: SoftDeleteTable,
    foreignKey: string,
    parentId: string,
    options: { deletedBy?: string; isFinancial?: boolean }
  ): Promise<number> {
    // Find all related records
    const relatedResult = await client.query<{ id: string }>(
      `SELECT id FROM ${table} WHERE ${foreignKey} = $1 AND tenant_id = $2 AND deleted_at IS NULL`,
      [parentId, tenantId]
    );

    const tableConfig = SOFT_DELETE_TABLES[table];
    const retentionDays = tableConfig.retentionDays;

    for (const row of relatedResult.rows) {
      // Soft delete
      await client.query(
        `UPDATE ${table} SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
         WHERE id = $1`,
        [row.id]
      );

      // Track in retention
      await client.query(
        `SELECT track_soft_delete($1, $2, $3, $4, $5, $6, $7)`,
        [
          tenantId,
          table,
          row.id,
          options.deletedBy || null,
          options.isFinancial ?? tableConfig.isFinancial,
          retentionDays,
          JSON.stringify({ cascadedFrom: parentId }),
        ]
      );

      // Recursively cascade if this table has cascades
      if (tableConfig.cascades.length > 0) {
        for (const cascade of tableConfig.cascades) {
          await this.cascadeSoftDelete(
            client,
            tenantId,
            cascade.table as SoftDeleteTable,
            cascade.foreignKey,
            row.id,
            options
          );
        }
      }
    }

    return relatedResult.rows.length;
  }

  /**
   * Restore a soft-deleted record
   */
  async restore(
    tenantId: string,
    table: SoftDeleteTable,
    recordId: string,
    options: RestoreOptions = {}
  ): Promise<{ restored: boolean }> {
    if (!tenantId) {
      throw new TenantScopingError('tenantId is required for restore');
    }

    return withTransaction(async (client) => {
      // 1. Verify record exists (including deleted) and belongs to tenant
      const existsResult = await client.query(
        `SELECT id, deleted_at FROM ${table} WHERE id = $1 AND tenant_id = $2`,
        [recordId, tenantId]
      );

      if (existsResult.rows.length === 0) {
        throw new NotFoundError(table, recordId);
      }

      if (existsResult.rows[0].deleted_at === null) {
        throw new DatabaseError(
          'Record is not deleted',
          'NOT_DELETED',
          400
        );
      }

      // 2. Check if parent record is deleted (would be orphaned)
      const parentCheck = await this.checkParentExists(client, table, recordId, tenantId);
      if (!parentCheck.valid) {
        throw new DatabaseError(
          `Cannot restore: parent ${parentCheck.parentTable} (${parentCheck.parentId}) is deleted or does not exist`,
          'PARENT_DELETED',
          400
        );
      }

      // 3. Restore the record
      await client.query(
        `UPDATE ${table} SET deleted_at = NULL, updated_at = CURRENT_TIMESTAMP
         WHERE id = $1 AND tenant_id = $2`,
        [recordId, tenantId]
      );

      // 4. Remove from retention tracking
      await client.query(
        `SELECT untrack_soft_delete($1, $2)`,
        [table, recordId]
      );

      // 5. Optionally restore related records
      if (options.restoreRelated) {
        const tableConfig = SOFT_DELETE_TABLES[table];
        for (const cascade of tableConfig.cascades) {
          await this.cascadeRestore(
            client,
            tenantId,
            cascade.table as SoftDeleteTable,
            cascade.foreignKey,
            recordId
          );
        }
      }

      return { restored: true };
    });
  }

  /**
   * Check if parent record exists and is not deleted
   */
  private async checkParentExists(
    client: pg.PoolClient,
    table: SoftDeleteTable,
    recordId: string,
    tenantId: string
  ): Promise<{ valid: boolean; parentTable?: string; parentId?: string }> {
    // Define parent relationships
    const parentRelations: Record<string, { table: string; foreignKey: string }> = {
      cases: { table: 'clients', foreignKey: 'client_id' },
      tasks: { table: 'cases', foreignKey: 'case_id' },
      documents: { table: 'cases', foreignKey: 'case_id' },
      calendar_events: { table: 'cases', foreignKey: 'case_id' },
      time_entries: { table: 'cases', foreignKey: 'case_id' },
      invoices: { table: 'clients', foreignKey: 'client_id' },
      invoice_lines: { table: 'invoices', foreignKey: 'invoice_id' },
      payments: { table: 'invoices', foreignKey: 'invoice_id' },
      trust_accounts: { table: 'clients', foreignKey: 'client_id' },
    };

    const relation = parentRelations[table];
    if (!relation) {
      return { valid: true }; // No parent to check
    }

    // Get the parent ID from the record
    const recordResult = await client.query(
      `SELECT ${relation.foreignKey} as parent_id FROM ${table} WHERE id = $1`,
      [recordId]
    );

    if (recordResult.rows.length === 0 || !recordResult.rows[0].parent_id) {
      return { valid: true }; // Optional parent
    }

    const parentId = recordResult.rows[0].parent_id;

    // Check if parent exists and is not deleted
    const parentResult = await client.query(
      `SELECT id FROM ${relation.table} WHERE id = $1 AND tenant_id = $2 AND deleted_at IS NULL`,
      [parentId, tenantId]
    );

    if (parentResult.rows.length === 0) {
      return {
        valid: false,
        parentTable: relation.table,
        parentId,
      };
    }

    return { valid: true };
  }

  /**
   * Cascade restore related records
   */
  private async cascadeRestore(
    client: pg.PoolClient,
    tenantId: string,
    table: SoftDeleteTable,
    foreignKey: string,
    parentId: string
  ): Promise<number> {
    // Find all deleted related records
    const relatedResult = await client.query<{ id: string }>(
      `SELECT id FROM ${table} WHERE ${foreignKey} = $1 AND tenant_id = $2 AND deleted_at IS NOT NULL`,
      [parentId, tenantId]
    );

    const tableConfig = SOFT_DELETE_TABLES[table];

    for (const row of relatedResult.rows) {
      // Restore
      await client.query(
        `UPDATE ${table} SET deleted_at = NULL, updated_at = CURRENT_TIMESTAMP
         WHERE id = $1`,
        [row.id]
      );

      // Remove from retention tracking
      await client.query(
        `SELECT untrack_soft_delete($1, $2)`,
        [table, row.id]
      );

      // Recursively restore if this table has cascades
      if (tableConfig.cascades.length > 0) {
        for (const cascade of tableConfig.cascades) {
          await this.cascadeRestore(
            client,
            tenantId,
            cascade.table as SoftDeleteTable,
            cascade.foreignKey,
            row.id
          );
        }
      }
    }

    return relatedResult.rows.length;
  }

  /**
   * List soft-deleted records for a tenant
   */
  async listDeleted(
    tenantId: string,
    options: {
      table?: SoftDeleteTable;
      limit?: number;
      offset?: number;
    } = {}
  ): Promise<SoftDeletedRecord[]> {
    if (!tenantId) {
      throw new TenantScopingError('tenantId is required');
    }

    try {
      const result = await query<SoftDeletedRecord>(
        `SELECT * FROM get_soft_deleted_records($1, $2, $3, $4)`,
        [
          tenantId,
          options.table || null,
          options.limit ?? 100,
          options.offset ?? 0,
        ]
      );

      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get soft delete statistics for a tenant
   */
  async getStats(tenantId: string): Promise<SoftDeleteStats[]> {
    if (!tenantId) {
      throw new TenantScopingError('tenantId is required');
    }

    try {
      const result = await query<SoftDeleteStats>(
        `SELECT * FROM soft_delete_stats WHERE tenant_id = $1`,
        [tenantId]
      );

      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Check if a record is soft-deleted
   */
  async isDeleted(
    tenantId: string,
    table: SoftDeleteTable,
    recordId: string
  ): Promise<boolean> {
    try {
      const result = await query<{ deleted_at: Date | null }>(
        `SELECT deleted_at FROM ${table} WHERE id = $1 AND tenant_id = $2`,
        [recordId, tenantId]
      );

      if (result.rows.length === 0) {
        throw new NotFoundError(table, recordId);
      }

      return result.rows[0]!.deleted_at !== null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get record including if deleted (for admin/recovery)
   */
  async findIncludingDeleted<T>(
    tenantId: string,
    table: SoftDeleteTable,
    recordId: string
  ): Promise<T | null> {
    try {
      const result = await query<T>(
        `SELECT * FROM ${table} WHERE id = $1 AND tenant_id = $2`,
        [recordId, tenantId]
      );

      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}

export const softDeleteService = new SoftDeleteService();
