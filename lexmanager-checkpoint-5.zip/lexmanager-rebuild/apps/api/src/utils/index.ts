// ============================================================================
// UTILITIES INDEX
// apps/api/src/utils/index.ts
// ============================================================================

// Logger
export { logger, type Logger } from './logger.js';

// Crypto / Password Hashing
export {
  hashPassword,
  verifyPassword,
  needsRehash,
  generateToken,
  generateUrlSafeToken,
  generateOTP,
  sha256,
  hashToken,
  hmacSha256,
  encrypt,
  decrypt,
  deriveKey,
  secureCompare,
} from './crypto.js';

// Tenant Validation (Cross-Tenant Protection)
export {
  // Core functions
  validateSameTenant,
  requireSameTenant,
  validateEntityTenant,
  getEntityTenantId,
  ref,
  
  // Convenience validators
  validateClientTenant,
  validateCaseTenant,
  validateUserTenant,
  validateInvoiceTenant,
  validateTrustAccountTenant,
  
  // Batch validators
  validateTaskReferences,
  validateDocumentReferences,
  validateEventReferences,
  validateTimeEntryReferences,
  validateInvoiceReferences,
  validateTrustTransactionReferences,
  validatePaymentReferences,
  
  // Types
  type EntityReference,
  type TenantValidationResult,
} from './tenant-validation.js';
