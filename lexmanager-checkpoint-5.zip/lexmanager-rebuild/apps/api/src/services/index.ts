// ============================================================================
// SERVICES INDEX
// apps/api/src/services/index.ts
// ============================================================================

// Tenant Service
export { 
  TenantService, 
  tenantService,
  type CreateTenantWithAdminInput,
  type TenantWithStats,
} from './tenant.service.js';

// User Service
export {
  UserService,
  userService,
  type CreateUserInput,
  type UpdateUserInput,
  type ChangePasswordInput,
} from './user.service.js';

// RBAC Service
export {
  RBACService,
  rbacService,
  PERMISSIONS,
  ROLES,
  type PermissionCode,
  type RoleName,
  type PermissionCheck,
  type UserPermissions,
} from './rbac.service.js';

// Soft Delete Service
export {
  SoftDeleteService,
  softDeleteService,
  SOFT_DELETE_TABLES,
  type SoftDeleteTable,
  type SoftDeleteOptions,
  type SoftDeletedRecord,
  type RestoreOptions,
  type SoftDeleteStats,
} from './soft-delete.service.js';

// Trust Service
export {
  TrustService,
  trustService,
  type ReconciliationResult,
  type TransferRequest,
  type TransactionRequest,
} from './trust.service.js';

// Audit Service
export {
  AuditService,
  auditService,
  createAuditedOperation,
  type AuditContext,
  type AuditEntryInput,
  type EntityChange,
} from './audit.service.js';

// Custom Fields Service
export {
  CustomFieldsService,
  customFieldsService,
  type CreateDefinitionInput,
  type UpdateDefinitionInput,
  type CustomFieldResult,
} from './custom-fields.service.js';

// Client Service
export {
  ClientService,
  clientService,
  type CreateClientInput,
  type UpdateClientInput,
  type ClientListOptions,
} from './client.service.js';

// Case Service
export {
  CaseService,
  caseService,
  type CreateCaseInput,
  type UpdateCaseInput,
  type CaseListOptions,
} from './case.service.js';

// Task Service
export {
  TaskService,
  taskService,
  type CreateTaskInput,
  type UpdateTaskInput,
  type TaskListOptions,
  type MoveTaskInput,
} from './task.service.js';

// Document Service
export {
  DocumentService,
  documentService,
  type UploadDocumentInput,
  type UpdateDocumentInput,
  type DocumentListOptions,
} from './document.service.js';

// Calendar Event Service
export {
  CalendarEventService,
  calendarEventService,
  type CreateEventInput,
  type UpdateEventInput,
  type EventListOptions,
} from './calendar-event.service.js';

// Invoice Service
export {
  InvoiceService,
  invoiceService,
  type CreateInvoiceInput,
  type UpdateInvoiceInput,
  type InvoiceListOptions,
} from './invoice.service.js';

// Auth Service
export {
  AuthService,
  authService,
  type RegisterInput,
  type LoginInput,
  type LoginResult,
  type RefreshResult,
  type UserPublic,
  type TokenPayload,
  type RequestMeta,
} from './auth.service.js';

// Security Audit Service
export {
  recordSecurityAudit,
  auditLoginSuccess,
  auditLoginFailed,
  auditRegistration,
  auditRefreshTokenReuse,
  auditLogout,
  auditPasswordResetRequest,
  auditPasswordResetComplete,
  type SecurityAction,
  type AuditMeta,
  type SecurityAuditOptions,
} from './security-audit.js';
