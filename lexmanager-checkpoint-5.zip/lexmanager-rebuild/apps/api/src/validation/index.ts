// ============================================================================
// VALIDATION LAYER
// apps/api/src/validation/index.ts
// 
// Request validation using Zod with standardized error handling.
// All validation errors return code="VALIDATION_ERROR"
// ============================================================================

import { z, ZodError, ZodSchema, type ZodIssue } from 'zod';
import { type Request, type Response, type NextFunction } from 'express';
import { ValidationError } from '../errors/index.js';

// ============================================================================
// VALIDATION MIDDLEWARE
// ============================================================================

/**
 * Validation targets
 */
export type ValidationTarget = 'body' | 'query' | 'params';

/**
 * Validation options
 */
export interface ValidateOptions {
  /** Strip unknown properties (default: true) */
  stripUnknown?: boolean;
}

/**
 * Create validation middleware for a Zod schema
 * 
 * Usage:
 *   router.post('/users', validate(createUserSchema, 'body'), handler)
 */
export function validate<T extends ZodSchema>(
  schema: T,
  target: ValidationTarget = 'body',
  options: ValidateOptions = {}
): (req: Request, res: Response, next: NextFunction) => void {
  const { stripUnknown = true } = options;

  return (req: Request, res: Response, next: NextFunction): void => {
    try {
      const dataToValidate = req[target];
      
      // Parse and validate
      const result = stripUnknown
        ? schema.parse(dataToValidate)
        : schema.parse(dataToValidate);
      
      // Replace with validated/transformed data
      (req as any)[target] = result;
      
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        next(ValidationError.fromZod(error));
      } else {
        next(error);
      }
    }
  };
}

/**
 * Validate multiple targets at once
 * 
 * Usage:
 *   router.post('/users/:id', validateAll({
 *     params: paramsSchema,
 *     body: bodySchema,
 *     query: querySchema
 *   }), handler)
 */
export function validateAll(schemas: {
  body?: ZodSchema;
  query?: ZodSchema;
  params?: ZodSchema;
}): (req: Request, res: Response, next: NextFunction) => void {
  return (req: Request, res: Response, next: NextFunction): void => {
    const errors: { target: string; issues: ZodIssue[] }[] = [];

    for (const [target, schema] of Object.entries(schemas)) {
      if (!schema) continue;
      
      try {
        const dataToValidate = (req as any)[target];
        const result = schema.parse(dataToValidate);
        (req as any)[target] = result;
      } catch (error) {
        if (error instanceof ZodError) {
          errors.push({ target, issues: error.issues });
        } else {
          next(error);
          return;
        }
      }
    }

    if (errors.length > 0) {
      const allIssues = errors.flatMap(e => 
        e.issues.map(issue => ({
          ...issue,
          path: [e.target, ...issue.path],
        }))
      );
      next(new ValidationError(
        `${allIssues.length} validation error${allIssues.length > 1 ? 's' : ''}`,
        allIssues.map(issue => ({
          path: issue.path.join('.'),
          message: issue.message,
          code: issue.code,
        }))
      ));
      return;
    }

    next();
  };
}

// ============================================================================
// COMMON SCHEMA HELPERS
// ============================================================================

/**
 * UUID validation
 */
export const uuidSchema = z.string().uuid('Invalid UUID format');

/**
 * Email validation
 */
export const emailSchema = z
  .string()
  .email('Invalid email format')
  .max(255, 'Email too long')
  .transform(v => v.toLowerCase().trim());

/**
 * Password validation
 */
export const passwordSchema = z
  .string()
  .min(8, 'Password must be at least 8 characters')
  .max(128, 'Password too long')
  .regex(/[A-Z]/, 'Password must contain uppercase letter')
  .regex(/[a-z]/, 'Password must contain lowercase letter')
  .regex(/[0-9]/, 'Password must contain number');

/**
 * Phone validation (flexible format)
 */
export const phoneSchema = z
  .string()
  .regex(/^[\d\s\-\+\(\)]+$/, 'Invalid phone format')
  .max(50, 'Phone number too long')
  .optional()
  .nullable();

/**
 * Pagination query params
 */
export const paginationSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  sortBy: z.string().optional(),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
});

/**
 * Date range query params
 */
export const dateRangeSchema = z.object({
  startDate: z.coerce.date().optional(),
  endDate: z.coerce.date().optional(),
}).refine(
  data => !data.startDate || !data.endDate || data.startDate <= data.endDate,
  { message: 'Start date must be before end date' }
);

/**
 * Search query params
 */
export const searchSchema = z.object({
  q: z.string().max(200).optional(),
  search: z.string().max(200).optional(),
});

// ============================================================================
// AUTH SCHEMAS
// ============================================================================

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, 'Password is required'),
});

export const registerSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  name: z.string().min(1, 'Name is required').max(255, 'Name too long').trim(),
  phone: phoneSchema,
});

export const refreshTokenSchema = z.object({
  refreshToken: z.string().min(1, 'Refresh token is required'),
});

export const logoutSchema = z.object({
  refreshToken: z.string().min(1, 'Refresh token is required'),
});

export const passwordResetRequestSchema = z.object({
  email: emailSchema,
});

export const passwordResetConfirmSchema = z.object({
  token: z.string().min(1, 'Token is required'),
  newPassword: passwordSchema,
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Current password is required'),
  newPassword: passwordSchema,
});

// ============================================================================
// TENANT SCHEMAS
// ============================================================================

export const createTenantSchema = z.object({
  name: z.string().min(1, 'Name is required').max(255),
  slug: z.string()
    .min(2, 'Slug must be at least 2 characters')
    .max(100)
    .regex(/^[a-z0-9\-]+$/, 'Slug must be lowercase alphanumeric with dashes'),
  domain: z.string().max(255).optional().nullable(),
  plan: z.enum(['trial', 'basic', 'professional', 'enterprise']).default('trial'),
});

export const updateTenantSchema = createTenantSchema.partial();

// ============================================================================
// USER SCHEMAS
// ============================================================================

export const createUserSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  name: z.string().min(1).max(255).trim(),
  phone: phoneSchema,
  roleId: uuidSchema.optional(),
});

export const updateUserSchema = z.object({
  name: z.string().min(1).max(255).trim().optional(),
  phone: phoneSchema,
  isActive: z.boolean().optional(),
  roleId: uuidSchema.optional(),
});

// ============================================================================
// CLIENT SCHEMAS
// ============================================================================

export const createClientSchema = z.object({
  name: z.string().min(1, 'Client name is required').max(255).trim(),
  nameHe: z.string().max(255).optional().nullable(),
  email: emailSchema.optional().nullable(),
  phone: phoneSchema,
  phoneSecondary: phoneSchema,
  fax: z.string().max(50).optional().nullable(),
  clientType: z.enum(['individual', 'company', 'government', 'non_profit']).default('individual'),
  status: z.enum(['lead', 'prospect', 'active', 'inactive', 'archived']).default('active'),
  idNumber: z.string().max(50).optional().nullable(),
  companyNumber: z.string().max(50).optional().nullable(),
  vatNumber: z.string().max(50).optional().nullable(),
  address: z.string().max(500).optional().nullable(),
  city: z.string().max(100).optional().nullable(),
  postalCode: z.string().max(20).optional().nullable(),
  country: z.string().max(100).default('Israel'),
  notes: z.string().max(5000).optional().nullable(),
  referralSource: z.string().max(100).optional().nullable(),
});

export const updateClientSchema = createClientSchema.partial();

export const clientQuerySchema = paginationSchema.merge(searchSchema).extend({
  status: z.enum(['lead', 'prospect', 'active', 'inactive', 'archived']).optional(),
  clientType: z.enum(['individual', 'company', 'government', 'non_profit']).optional(),
});

// ============================================================================
// CASE SCHEMAS
// ============================================================================

export const createCaseSchema = z.object({
  clientId: uuidSchema,
  caseNumber: z.string().max(50).optional(),
  title: z.string().min(1, 'Title is required').max(500).trim(),
  titleHe: z.string().max(500).optional().nullable(),
  description: z.string().max(10000).optional().nullable(),
  caseType: z.enum(['litigation', 'contract', 'consultation', 'regulatory', 'corporate', 'real_estate', 'family', 'criminal', 'intellectual_property', 'other']).default('other'),
  status: z.enum(['intake', 'active', 'pending', 'closed', 'archived']).default('intake'),
  priority: z.enum(['low', 'medium', 'high', 'urgent']).default('medium'),
  courtName: z.string().max(255).optional().nullable(),
  courtCaseNumber: z.string().max(100).optional().nullable(),
  judgeName: z.string().max(255).optional().nullable(),
  opposingParty: z.string().max(500).optional().nullable(),
  opposingCounsel: z.string().max(500).optional().nullable(),
  assignedAttorneyId: uuidSchema.optional().nullable(),
  openDate: z.coerce.date().optional(),
  closeDate: z.coerce.date().optional().nullable(),
  statueOfLimitations: z.coerce.date().optional().nullable(),
  billingType: z.enum(['hourly', 'fixed', 'contingency', 'pro_bono']).default('hourly'),
  hourlyRate: z.number().min(0).optional().nullable(),
  fixedFee: z.number().min(0).optional().nullable(),
  retainerAmount: z.number().min(0).optional().nullable(),
  contingencyPercent: z.number().min(0).max(100).optional().nullable(),
});

export const updateCaseSchema = createCaseSchema.partial();

export const caseQuerySchema = paginationSchema.merge(searchSchema).extend({
  status: z.enum(['intake', 'active', 'pending', 'closed', 'archived']).optional(),
  caseType: z.string().optional(),
  clientId: uuidSchema.optional(),
  assignedAttorneyId: uuidSchema.optional(),
});

// ============================================================================
// TASK SCHEMAS
// ============================================================================

export const createTaskSchema = z.object({
  caseId: uuidSchema.optional().nullable(),
  clientId: uuidSchema.optional().nullable(),
  title: z.string().min(1, 'Title is required').max(500).trim(),
  description: z.string().max(5000).optional().nullable(),
  status: z.enum(['pending', 'in_progress', 'completed', 'cancelled']).default('pending'),
  priority: z.enum(['low', 'medium', 'high', 'urgent']).default('medium'),
  assignedToId: uuidSchema.optional().nullable(),
  dueDate: z.coerce.date().optional().nullable(),
  reminderDate: z.coerce.date().optional().nullable(),
  estimatedMinutes: z.number().int().min(0).optional().nullable(),
});

export const updateTaskSchema = createTaskSchema.partial();

export const taskQuerySchema = paginationSchema.merge(searchSchema).extend({
  status: z.enum(['pending', 'in_progress', 'completed', 'cancelled']).optional(),
  priority: z.enum(['low', 'medium', 'high', 'urgent']).optional(),
  caseId: uuidSchema.optional(),
  clientId: uuidSchema.optional(),
  assignedToId: uuidSchema.optional(),
  dueBefore: z.coerce.date().optional(),
  dueAfter: z.coerce.date().optional(),
});

// ============================================================================
// DOCUMENT SCHEMAS
// ============================================================================

export const createDocumentSchema = z.object({
  caseId: uuidSchema.optional().nullable(),
  clientId: uuidSchema.optional().nullable(),
  title: z.string().min(1, 'Title is required').max(500).trim(),
  description: z.string().max(2000).optional().nullable(),
  documentType: z.enum(['contract', 'pleading', 'correspondence', 'evidence', 'court_filing', 'invoice', 'receipt', 'other']).default('other'),
  fileName: z.string().max(255),
  fileSize: z.number().int().min(0),
  mimeType: z.string().max(100),
  storagePath: z.string().max(1000),
});

export const updateDocumentSchema = z.object({
  title: z.string().min(1).max(500).trim().optional(),
  description: z.string().max(2000).optional().nullable(),
  documentType: z.enum(['contract', 'pleading', 'correspondence', 'evidence', 'court_filing', 'invoice', 'receipt', 'other']).optional(),
});

export const documentQuerySchema = paginationSchema.merge(searchSchema).extend({
  documentType: z.string().optional(),
  caseId: uuidSchema.optional(),
  clientId: uuidSchema.optional(),
});

// ============================================================================
// INVOICE SCHEMAS
// ============================================================================

export const createInvoiceSchema = z.object({
  clientId: uuidSchema,
  caseId: uuidSchema.optional().nullable(),
  invoiceNumber: z.string().max(50).optional(),
  status: z.enum(['draft', 'sent', 'paid', 'partially_paid', 'overdue', 'cancelled', 'void']).default('draft'),
  issueDate: z.coerce.date(),
  dueDate: z.coerce.date(),
  subtotal: z.number().min(0),
  taxRate: z.number().min(0).max(100).default(17),
  taxAmount: z.number().min(0),
  total: z.number().min(0),
  notes: z.string().max(2000).optional().nullable(),
  termsAndConditions: z.string().max(5000).optional().nullable(),
  lines: z.array(z.object({
    description: z.string().min(1).max(500),
    quantity: z.number().min(0),
    unitPrice: z.number().min(0),
    amount: z.number().min(0),
    timeEntryId: uuidSchema.optional().nullable(),
  })).min(1, 'At least one line item is required'),
});

export const updateInvoiceSchema = createInvoiceSchema.partial();

export const invoiceQuerySchema = paginationSchema.merge(dateRangeSchema).extend({
  status: z.enum(['draft', 'sent', 'paid', 'partially_paid', 'overdue', 'cancelled', 'void']).optional(),
  clientId: uuidSchema.optional(),
  caseId: uuidSchema.optional(),
});

// ============================================================================
// TRUST ACCOUNT SCHEMAS
// ============================================================================

export const createTrustAccountSchema = z.object({
  clientId: uuidSchema,
  accountName: z.string().min(1).max(255).trim(),
  accountNumber: z.string().max(50).optional(),
  bankName: z.string().max(255).optional().nullable(),
  currency: z.string().length(3).default('ILS'),
});

export const trustDepositSchema = z.object({
  amount: z.number().positive('Amount must be positive'),
  description: z.string().min(1).max(500),
  reference: z.string().max(100).optional(),
  caseId: uuidSchema.optional().nullable(),
});

export const trustWithdrawalSchema = z.object({
  amount: z.number().positive('Amount must be positive'),
  description: z.string().min(1).max(500),
  reference: z.string().max(100).optional(),
  caseId: uuidSchema.optional().nullable(),
});

export const trustTransferSchema = z.object({
  toAccountId: uuidSchema,
  amount: z.number().positive('Amount must be positive'),
  description: z.string().min(1).max(500),
});

// ============================================================================
// CUSTOM FIELD SCHEMAS
// ============================================================================

export const createCustomFieldDefinitionSchema = z.object({
  entityType: z.enum(['client', 'case', 'task', 'document', 'invoice']),
  fieldKey: z.string()
    .min(1)
    .max(50)
    .regex(/^[a-z][a-z0-9_]*$/, 'Field key must start with letter and contain only lowercase letters, numbers, underscores'),
  fieldName: z.string().min(1).max(100).trim(),
  fieldNameHe: z.string().max(100).optional().nullable(),
  fieldType: z.enum(['text', 'number', 'date', 'boolean', 'select', 'multiselect', 'url', 'email', 'phone']),
  description: z.string().max(500).optional().nullable(),
  isRequired: z.boolean().default(false),
  defaultValue: z.unknown().optional(),
  options: z.array(z.string()).optional().nullable(),
  validation: z.object({
    min: z.number().optional(),
    max: z.number().optional(),
    pattern: z.string().optional(),
  }).optional().nullable(),
  displayOrder: z.number().int().min(0).default(0),
});

export const updateCustomFieldDefinitionSchema = createCustomFieldDefinitionSchema.partial().omit({
  entityType: true,
  fieldKey: true,
  fieldType: true,
});

export const setCustomFieldValueSchema = z.object({
  value: z.unknown(),
});

// ============================================================================
// AUDIT LOG SCHEMAS
// ============================================================================

export const auditLogQuerySchema = paginationSchema.merge(dateRangeSchema).extend({
  entityType: z.string().optional(),
  entityId: uuidSchema.optional(),
  userId: uuidSchema.optional(),
  action: z.enum(['CREATE', 'UPDATE', 'DELETE', 'RESTORE', 'VIEW', 'EXPORT', 'IMPORT', 'LOGIN', 'LOGOUT']).optional(),
});

// ============================================================================
// ID PARAM SCHEMA
// ============================================================================

export const idParamSchema = z.object({
  id: uuidSchema,
});

export const clientIdParamSchema = z.object({
  clientId: uuidSchema,
});

export const caseIdParamSchema = z.object({
  caseId: uuidSchema,
});

// ============================================================================
// EXPORTS
// ============================================================================

export { z, ZodError, type ZodSchema };
