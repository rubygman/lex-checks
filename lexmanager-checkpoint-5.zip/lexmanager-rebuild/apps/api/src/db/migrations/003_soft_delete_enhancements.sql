-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 003: Soft Delete Enhancements
-- Adds retention tracking and cascade soft delete support
-- ============================================================================

BEGIN;

-- ============================================================================
-- RETENTION TRACKING TABLE
-- Tracks soft-deleted records for eventual hard deletion
-- ============================================================================

CREATE TABLE IF NOT EXISTS soft_delete_retention (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL,  -- No FK to allow tenant deletion
    table_name          VARCHAR(100) NOT NULL,
    record_id           UUID NOT NULL,
    deleted_at          TIMESTAMPTZ NOT NULL,
    deleted_by          UUID,           -- User who deleted (if known)
    retention_days      INTEGER NOT NULL DEFAULT 2557,  -- 7 years default
    hard_delete_after   TIMESTAMPTZ NOT NULL,
    is_financial        BOOLEAN DEFAULT FALSE,  -- Financial records have longer retention
    metadata_json       JSONB DEFAULT '{}',     -- Additional context
    created_at          TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE (table_name, record_id)
);

CREATE INDEX idx_soft_delete_retention_tenant ON soft_delete_retention(tenant_id);
CREATE INDEX idx_soft_delete_retention_table ON soft_delete_retention(table_name);
CREATE INDEX idx_soft_delete_retention_hard_delete ON soft_delete_retention(hard_delete_after);
CREATE INDEX idx_soft_delete_retention_lookup ON soft_delete_retention(table_name, record_id);

-- ============================================================================
-- FUNCTION: Track soft delete in retention table
-- Called by application code when soft-deleting records
-- ============================================================================

CREATE OR REPLACE FUNCTION track_soft_delete(
    p_tenant_id UUID,
    p_table_name TEXT,
    p_record_id UUID,
    p_deleted_by UUID DEFAULT NULL,
    p_is_financial BOOLEAN DEFAULT FALSE,
    p_retention_days INTEGER DEFAULT NULL,
    p_metadata JSONB DEFAULT '{}'
) RETURNS UUID AS $$
DECLARE
    v_retention_days INTEGER;
    v_hard_delete_after TIMESTAMPTZ;
    v_id UUID;
BEGIN
    -- Determine retention period
    IF p_retention_days IS NOT NULL THEN
        v_retention_days := p_retention_days;
    ELSIF p_is_financial THEN
        v_retention_days := 2557;  -- 7 years for financial
    ELSE
        v_retention_days := 365;   -- 1 year default
    END IF;
    
    v_hard_delete_after := CURRENT_TIMESTAMP + (v_retention_days || ' days')::INTERVAL;
    
    -- Insert or update retention record
    INSERT INTO soft_delete_retention (
        tenant_id, table_name, record_id, deleted_at, deleted_by,
        retention_days, hard_delete_after, is_financial, metadata_json
    ) VALUES (
        p_tenant_id, p_table_name, p_record_id, CURRENT_TIMESTAMP, p_deleted_by,
        v_retention_days, v_hard_delete_after, p_is_financial, p_metadata
    )
    ON CONFLICT (table_name, record_id) 
    DO UPDATE SET
        deleted_at = CURRENT_TIMESTAMP,
        deleted_by = COALESCE(p_deleted_by, soft_delete_retention.deleted_by),
        hard_delete_after = v_hard_delete_after,
        is_financial = COALESCE(p_is_financial, soft_delete_retention.is_financial),
        metadata_json = soft_delete_retention.metadata_json || p_metadata
    RETURNING id INTO v_id;
    
    RETURN v_id;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- FUNCTION: Remove soft delete tracking (for restore)
-- ============================================================================

CREATE OR REPLACE FUNCTION untrack_soft_delete(
    p_table_name TEXT,
    p_record_id UUID
) RETURNS BOOLEAN AS $$
DECLARE
    v_deleted INTEGER;
BEGIN
    DELETE FROM soft_delete_retention
    WHERE table_name = p_table_name AND record_id = p_record_id;
    
    GET DIAGNOSTICS v_deleted = ROW_COUNT;
    
    RETURN v_deleted > 0;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- FUNCTION: Get records eligible for hard deletion
-- Used by retention cleanup job
-- ============================================================================

CREATE OR REPLACE FUNCTION get_records_for_hard_deletion(
    p_limit INTEGER DEFAULT 1000
) RETURNS TABLE (
    id UUID,
    tenant_id UUID,
    table_name VARCHAR(100),
    record_id UUID,
    deleted_at TIMESTAMPTZ,
    retention_days INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        sdr.id,
        sdr.tenant_id,
        sdr.table_name,
        sdr.record_id,
        sdr.deleted_at,
        sdr.retention_days
    FROM soft_delete_retention sdr
    WHERE sdr.hard_delete_after <= CURRENT_TIMESTAMP
    ORDER BY sdr.hard_delete_after ASC
    LIMIT p_limit;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- FUNCTION: Get soft-deleted records for a tenant
-- Useful for admin recovery interfaces
-- ============================================================================

CREATE OR REPLACE FUNCTION get_soft_deleted_records(
    p_tenant_id UUID,
    p_table_name TEXT DEFAULT NULL,
    p_limit INTEGER DEFAULT 100,
    p_offset INTEGER DEFAULT 0
) RETURNS TABLE (
    table_name VARCHAR(100),
    record_id UUID,
    deleted_at TIMESTAMPTZ,
    deleted_by UUID,
    hard_delete_after TIMESTAMPTZ,
    days_until_hard_delete INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        sdr.table_name,
        sdr.record_id,
        sdr.deleted_at,
        sdr.deleted_by,
        sdr.hard_delete_after,
        EXTRACT(DAY FROM sdr.hard_delete_after - CURRENT_TIMESTAMP)::INTEGER as days_until_hard_delete
    FROM soft_delete_retention sdr
    WHERE sdr.tenant_id = p_tenant_id
      AND (p_table_name IS NULL OR sdr.table_name = p_table_name)
    ORDER BY sdr.deleted_at DESC
    LIMIT p_limit
    OFFSET p_offset;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- VIEW: All soft-deleted records with remaining time
-- ============================================================================

CREATE OR REPLACE VIEW soft_deleted_records AS
SELECT 
    sdr.id,
    sdr.tenant_id,
    sdr.table_name,
    sdr.record_id,
    sdr.deleted_at,
    sdr.deleted_by,
    sdr.retention_days,
    sdr.hard_delete_after,
    sdr.is_financial,
    sdr.metadata_json,
    EXTRACT(DAY FROM sdr.hard_delete_after - CURRENT_TIMESTAMP)::INTEGER as days_remaining,
    sdr.hard_delete_after <= CURRENT_TIMESTAMP as eligible_for_hard_delete
FROM soft_delete_retention sdr;

-- ============================================================================
-- HELPER VIEWS: Count soft-deleted records per table per tenant
-- Useful for dashboard/admin stats
-- ============================================================================

CREATE OR REPLACE VIEW soft_delete_stats AS
SELECT 
    tenant_id,
    table_name,
    COUNT(*) as deleted_count,
    MIN(deleted_at) as oldest_deletion,
    MAX(deleted_at) as newest_deletion,
    COUNT(*) FILTER (WHERE hard_delete_after <= CURRENT_TIMESTAMP) as eligible_for_hard_delete
FROM soft_delete_retention
GROUP BY tenant_id, table_name;

COMMIT;
