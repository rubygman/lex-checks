// ============================================================================
// ROUTES INDEX
// apps/api/src/routes/index.ts
// ============================================================================

export { default as authRoutes } from './auth.routes.js';
export { default as clientRoutes } from './client.routes.js';
export { default as caseRoutes } from './case.routes.js';
export { default as taskRoutes } from './task.routes.js';
export { default as documentRoutes } from './document.routes.js';
export { default as invoiceRoutes } from './invoice.routes.js';
export { default as trustRoutes } from './trust.routes.js';
export { default as customFieldRoutes } from './custom-field.routes.js';
export { default as auditRoutes } from './audit.routes.js';
