// ============================================================================
// BASE REPOSITORY UNIT TESTS
// apps/api/tests/unit/repositories/base.repository.test.ts
// ============================================================================

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { BaseRepository, type SoftDeletableEntity } from '../../../src/repositories/base.repository.js';
import { ImmutableRepository, type ImmutableEntity } from '../../../src/repositories/immutable.repository.js';
import {
  TenantScopingError,
  ImmutableTableError,
} from '../../../src/db/errors.js';

// Mock the database connection
vi.mock('../../../src/db/connection.js', () => ({
  query: vi.fn().mockResolvedValue({ rows: [], rowCount: 0 }),
  withTransaction: vi.fn((callback) => callback({ query: vi.fn().mockResolvedValue({ rows: [], rowCount: 0 }) })),
}));

// Test entity interface
interface TestEntity extends SoftDeletableEntity {
  id: string;
  tenant_id: string;
  name: string;
  status: string;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

// Concrete test repository
class TestRepository extends BaseRepository<TestEntity> {
  constructor() {
    super({
      tableName: 'test_entities',
      supportsSoftDelete: true,
    });
  }
}

// Immutable test entity
interface TestImmutableEntity extends ImmutableEntity {
  id: string;
  tenant_id: string;
  data: string;
  created_at: Date;
}

// Concrete immutable repository for testing
class TestImmutableRepository extends ImmutableRepository<TestImmutableEntity> {
  constructor() {
    super({
      tableName: 'trust_transactions',
    });
  }
}

describe('BaseRepository', () => {
  let repo: TestRepository;
  const validTenantId = '550e8400-e29b-41d4-a716-446655440000';
  const validRecordId = '660e8400-e29b-41d4-a716-446655440001';

  beforeEach(() => {
    repo = new TestRepository();
    vi.clearAllMocks();
  });

  describe('Tenant ID Validation - ALL methods must require tenantId', () => {
    
    describe('findById', () => {
      it('should THROW TenantScopingError when tenantId is undefined', async () => {
        await expect(
          repo.findById(undefined as unknown as string, validRecordId)
        ).rejects.toThrow(TenantScopingError);
      });

      it('should THROW TenantScopingError when tenantId is null', async () => {
        await expect(
          repo.findById(null as unknown as string, validRecordId)
        ).rejects.toThrow(TenantScopingError);
      });

      it('should THROW TenantScopingError when tenantId is empty string', async () => {
        await expect(
          repo.findById('', validRecordId)
        ).rejects.toThrow(TenantScopingError);
      });

      it('should THROW TenantScopingError when tenantId is whitespace', async () => {
        await expect(
          repo.findById('   ', validRecordId)
        ).rejects.toThrow(TenantScopingError);
      });

      it('should include operation name in error message', async () => {
        try {
          await repo.findById('', validRecordId);
          expect.fail('Should have thrown');
        } catch (error) {
          expect(error).toBeInstanceOf(TenantScopingError);
          expect((error as TenantScopingError).message).toContain('findById');
        }
      });
    });

    describe('findByIdOrFail', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.findByIdOrFail('', validRecordId)
        ).rejects.toThrow(TenantScopingError);
      });
    });

    describe('findByIds', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.findByIds('', [validRecordId])
        ).rejects.toThrow(TenantScopingError);
      });

      it('should return empty array for empty ids without throwing', async () => {
        const result = await repo.findByIds(validTenantId, []);
        expect(result).toEqual([]);
      });
    });

    describe('list', () => {
      it('should THROW TenantScopingError when tenantId is undefined', async () => {
        await expect(
          repo.list(undefined as unknown as string)
        ).rejects.toThrow(TenantScopingError);
      });

      it('should THROW TenantScopingError when tenantId is null', async () => {
        await expect(
          repo.list(null as unknown as string)
        ).rejects.toThrow(TenantScopingError);
      });

      it('should THROW TenantScopingError when tenantId is empty', async () => {
        await expect(
          repo.list('')
        ).rejects.toThrow(TenantScopingError);
      });
    });

    describe('findOne', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.findOne('', [{ field: 'name', operator: '=', value: 'test' }])
        ).rejects.toThrow(TenantScopingError);
      });
    });

    describe('exists', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.exists('', validRecordId)
        ).rejects.toThrow(TenantScopingError);
      });
    });

    describe('count', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.count(null as unknown as string)
        ).rejects.toThrow(TenantScopingError);
      });
    });

    describe('create', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.create('', { name: 'Test', status: 'active' } as any)
        ).rejects.toThrow(TenantScopingError);
      });

      it('should THROW TenantScopingError when tenantId is undefined', async () => {
        await expect(
          repo.create(undefined as unknown as string, { name: 'Test', status: 'active' } as any)
        ).rejects.toThrow(TenantScopingError);
      });
    });

    describe('createMany', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.createMany('', [{ name: 'Test', status: 'active' }] as any)
        ).rejects.toThrow(TenantScopingError);
      });

      it('should return empty array for empty data without throwing', async () => {
        const result = await repo.createMany(validTenantId, []);
        expect(result).toEqual([]);
      });
    });

    describe('update', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.update('', validRecordId, { name: 'Updated' })
        ).rejects.toThrow(TenantScopingError);
      });

      it('should THROW TenantScopingError when tenantId is null', async () => {
        await expect(
          repo.update(null as unknown as string, validRecordId, { name: 'Updated' })
        ).rejects.toThrow(TenantScopingError);
      });
    });

    describe('softDelete', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.softDelete('', validRecordId)
        ).rejects.toThrow(TenantScopingError);
      });
    });

    describe('restore', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.restore('', validRecordId)
        ).rejects.toThrow(TenantScopingError);
      });
    });

    describe('hardDelete', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.hardDelete('', validRecordId)
        ).rejects.toThrow(TenantScopingError);
      });
    });

    describe('rawQuery', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.rawQuery('', 'SELECT * FROM test WHERE tenant_id = $1', [''])
        ).rejects.toThrow(TenantScopingError);
      });

      it('should THROW TenantScopingError when query lacks tenant_id', async () => {
        await expect(
          repo.rawQuery(validTenantId, 'SELECT * FROM test', [validTenantId])
        ).rejects.toThrow(TenantScopingError);
      });

      it('should THROW TenantScopingError when first param is not tenantId', async () => {
        await expect(
          repo.rawQuery(validTenantId, 'SELECT * FROM test WHERE tenant_id = $1', ['wrong-id'])
        ).rejects.toThrow(TenantScopingError);
      });
    });
  });

  describe('Error Message Quality', () => {
    it('should include table name in error message', async () => {
      try {
        await repo.findById('', validRecordId);
        expect.fail('Should have thrown');
      } catch (error) {
        expect((error as TenantScopingError).message).toContain('test_entities');
      }
    });

    it('should indicate what was received', async () => {
      try {
        await repo.findById(undefined as unknown as string, validRecordId);
        expect.fail('Should have thrown');
      } catch (error) {
        expect((error as TenantScopingError).message).toContain('undefined');
      }
    });

    it('should indicate null when null is passed', async () => {
      try {
        await repo.findById(null as unknown as string, validRecordId);
        expect.fail('Should have thrown');
      } catch (error) {
        expect((error as TenantScopingError).message).toContain('null');
      }
    });
  });
});

describe('ImmutableRepository', () => {
  let repo: TestImmutableRepository;
  const validTenantId = '550e8400-e29b-41d4-a716-446655440000';
  const validRecordId = '660e8400-e29b-41d4-a716-446655440001';

  beforeEach(() => {
    repo = new TestImmutableRepository();
    vi.clearAllMocks();
  });

  describe('Tenant ID Validation', () => {
    describe('findById', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.findById('', validRecordId)
        ).rejects.toThrow(TenantScopingError);
      });
    });

    describe('list', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.list('')
        ).rejects.toThrow(TenantScopingError);
      });
    });

    describe('count', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.count('')
        ).rejects.toThrow(TenantScopingError);
      });
    });

    describe('append', () => {
      it('should THROW TenantScopingError when tenantId is missing', async () => {
        await expect(
          repo.append('', { data: 'test' } as any)
        ).rejects.toThrow(TenantScopingError);
      });
    });
  });

  describe('Immutability Enforcement', () => {
    describe('update', () => {
      it('should ALWAYS THROW ImmutableTableError', async () => {
        await expect(
          repo.update()
        ).rejects.toThrow(ImmutableTableError);
      });

      it('should include table name in error', async () => {
        try {
          await repo.update();
          expect.fail('Should have thrown');
        } catch (error) {
          expect((error as ImmutableTableError).message).toContain('trust_transactions');
          expect((error as ImmutableTableError).message).toContain('immutable');
        }
      });
    });

    describe('delete', () => {
      it('should ALWAYS THROW ImmutableTableError', async () => {
        await expect(
          repo.delete()
        ).rejects.toThrow(ImmutableTableError);
      });

      it('should mention compliance in error', async () => {
        try {
          await repo.delete();
          expect.fail('Should have thrown');
        } catch (error) {
          expect((error as ImmutableTableError).message).toContain('compliance');
        }
      });
    });

    describe('softDelete', () => {
      it('should ALWAYS THROW ImmutableTableError', async () => {
        await expect(
          repo.softDelete()
        ).rejects.toThrow(ImmutableTableError);
      });

      it('should mention append-only in error', async () => {
        try {
          await repo.softDelete();
          expect.fail('Should have thrown');
        } catch (error) {
          expect((error as ImmutableTableError).message).toContain('append-only');
        }
      });
    });
  });
});

describe('Immutable Table Protection via BaseRepository', () => {
  // Test that even if someone creates a BaseRepository for an immutable table,
  // the updates/deletes are still blocked

  class BadImmutableRepo extends BaseRepository<any> {
    constructor() {
      super({
        tableName: 'trust_transactions',
        isImmutable: true, // Explicitly marked
      });
    }
  }

  let repo: BadImmutableRepo;
  const validTenantId = '550e8400-e29b-41d4-a716-446655440000';
  const validRecordId = '660e8400-e29b-41d4-a716-446655440001';

  beforeEach(() => {
    repo = new BadImmutableRepo();
  });

  it('should THROW ImmutableTableError on update', async () => {
    await expect(
      repo.update(validTenantId, validRecordId, { data: 'changed' })
    ).rejects.toThrow(ImmutableTableError);
  });

  it('should THROW ImmutableTableError on softDelete', async () => {
    await expect(
      repo.softDelete(validTenantId, validRecordId)
    ).rejects.toThrow(ImmutableTableError);
  });

  it('should THROW ImmutableTableError on hardDelete', async () => {
    await expect(
      repo.hardDelete(validTenantId, validRecordId)
    ).rejects.toThrow(ImmutableTableError);
  });

  it('should THROW ImmutableTableError on restore', async () => {
    await expect(
      repo.restore(validTenantId, validRecordId)
    ).rejects.toThrow(ImmutableTableError);
  });
});

describe('Complete Coverage: No Unscoped Operations Possible', () => {
  /**
   * This test suite verifies the CRITICAL requirement:
   * "There is no repository method that can execute without tenantId"
   */

  class FullTestRepository extends BaseRepository<TestEntity> {
    constructor() {
      super({ tableName: 'clients', supportsSoftDelete: true });
    }
  }

  let repo: FullTestRepository;

  beforeEach(() => {
    repo = new FullTestRepository();
  });

  const invalidTenantIds = [
    { value: undefined, name: 'undefined' },
    { value: null, name: 'null' },
    { value: '', name: 'empty string' },
    { value: '   ', name: 'whitespace' },
    { value: '\t\n', name: 'tabs and newlines' },
  ];

  const methods = [
    { name: 'findById', call: (r: FullTestRepository, t: string) => r.findById(t, 'id') },
    { name: 'findByIdOrFail', call: (r: FullTestRepository, t: string) => r.findByIdOrFail(t, 'id') },
    { name: 'findByIds', call: (r: FullTestRepository, t: string) => r.findByIds(t, ['id']) },
    { name: 'list', call: (r: FullTestRepository, t: string) => r.list(t) },
    { name: 'findOne', call: (r: FullTestRepository, t: string) => r.findOne(t, []) },
    { name: 'exists', call: (r: FullTestRepository, t: string) => r.exists(t, 'id') },
    { name: 'count', call: (r: FullTestRepository, t: string) => r.count(t) },
    { name: 'create', call: (r: FullTestRepository, t: string) => r.create(t, {} as any) },
    { name: 'update', call: (r: FullTestRepository, t: string) => r.update(t, 'id', {}) },
    { name: 'softDelete', call: (r: FullTestRepository, t: string) => r.softDelete(t, 'id') },
    { name: 'restore', call: (r: FullTestRepository, t: string) => r.restore(t, 'id') },
    { name: 'hardDelete', call: (r: FullTestRepository, t: string) => r.hardDelete(t, 'id') },
  ];

  for (const method of methods) {
    for (const invalid of invalidTenantIds) {
      it(`${method.name} should THROW for ${invalid.name} tenantId`, async () => {
        await expect(
          method.call(repo, invalid.value as unknown as string)
        ).rejects.toThrow(TenantScopingError);
      });
    }
  }
});
