-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 006: Custom Fields System Enhancements
-- Adds validation functions and helper views
-- ============================================================================

BEGIN;

-- ============================================================================
-- VALIDATION FUNCTION FOR CUSTOM FIELD VALUES
-- Validates that the value matches the field type and options
-- ============================================================================

CREATE OR REPLACE FUNCTION validate_custom_field_value()
RETURNS TRIGGER AS $$
DECLARE
    v_definition RECORD;
    v_option_values TEXT[];
    v_selected_values TEXT[];
    v_value TEXT;
BEGIN
    -- Get the field definition
    SELECT * INTO v_definition
    FROM custom_field_definitions
    WHERE id = NEW.definition_id
      AND tenant_id = NEW.tenant_id
      AND deleted_at IS NULL;

    IF v_definition IS NULL THEN
        RAISE EXCEPTION 'Custom field definition % not found or deleted', NEW.definition_id;
    END IF;

    -- Verify entity_type matches
    IF v_definition.entity_type != NEW.entity_type THEN
        RAISE EXCEPTION 'Entity type mismatch: definition is for %, but value is for %',
            v_definition.entity_type, NEW.entity_type;
    END IF;

    -- Validate based on field type
    CASE v_definition.field_type
        WHEN 'text' THEN
            IF NEW.value_text IS NULL AND v_definition.is_required THEN
                RAISE EXCEPTION 'Required text field % cannot be null', v_definition.field_key;
            END IF;

        WHEN 'number' THEN
            IF NEW.value_number IS NULL AND v_definition.is_required THEN
                RAISE EXCEPTION 'Required number field % cannot be null', v_definition.field_key;
            END IF;

        WHEN 'boolean' THEN
            IF NEW.value_boolean IS NULL AND v_definition.is_required THEN
                RAISE EXCEPTION 'Required boolean field % cannot be null', v_definition.field_key;
            END IF;

        WHEN 'date' THEN
            IF NEW.value_date IS NULL AND v_definition.is_required THEN
                RAISE EXCEPTION 'Required date field % cannot be null', v_definition.field_key;
            END IF;

        WHEN 'datetime' THEN
            IF NEW.value_datetime IS NULL AND v_definition.is_required THEN
                RAISE EXCEPTION 'Required datetime field % cannot be null', v_definition.field_key;
            END IF;

        WHEN 'select' THEN
            IF NEW.value_text IS NULL AND v_definition.is_required THEN
                RAISE EXCEPTION 'Required select field % cannot be null', v_definition.field_key;
            END IF;
            
            -- Validate against options
            IF NEW.value_text IS NOT NULL THEN
                SELECT array_agg(opt->>'value')
                INTO v_option_values
                FROM jsonb_array_elements(v_definition.options_json->'options') AS opt;

                IF v_option_values IS NULL OR NOT (NEW.value_text = ANY(v_option_values)) THEN
                    RAISE EXCEPTION 'Invalid option "%" for select field %. Valid options: %',
                        NEW.value_text, v_definition.field_key, v_option_values;
                END IF;
            END IF;

        WHEN 'multi_select' THEN
            IF (NEW.value_json IS NULL OR NEW.value_json = '[]'::jsonb) AND v_definition.is_required THEN
                RAISE EXCEPTION 'Required multi_select field % cannot be empty', v_definition.field_key;
            END IF;
            
            -- Validate all selected values against options
            IF NEW.value_json IS NOT NULL AND NEW.value_json != '[]'::jsonb THEN
                SELECT array_agg(opt->>'value')
                INTO v_option_values
                FROM jsonb_array_elements(v_definition.options_json->'options') AS opt;

                SELECT array_agg(val::text)
                INTO v_selected_values
                FROM jsonb_array_elements_text(NEW.value_json) AS val;

                FOREACH v_value IN ARRAY v_selected_values LOOP
                    IF v_option_values IS NULL OR NOT (v_value = ANY(v_option_values)) THEN
                        RAISE EXCEPTION 'Invalid option "%" for multi_select field %. Valid options: %',
                            v_value, v_definition.field_key, v_option_values;
                    END IF;
                END LOOP;
            END IF;

        WHEN 'json' THEN
            IF NEW.value_json IS NULL AND v_definition.is_required THEN
                RAISE EXCEPTION 'Required json field % cannot be null', v_definition.field_key;
            END IF;

        ELSE
            RAISE EXCEPTION 'Unknown field type: %', v_definition.field_type;
    END CASE;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_custom_field_values_validate ON custom_field_values;
CREATE TRIGGER trg_custom_field_values_validate
    BEFORE INSERT OR UPDATE ON custom_field_values
    FOR EACH ROW
    EXECUTE FUNCTION validate_custom_field_value();

-- ============================================================================
-- VIEW: Custom fields with values for easy querying
-- ============================================================================

CREATE OR REPLACE VIEW custom_fields_with_values AS
SELECT 
    cfd.id as definition_id,
    cfd.tenant_id,
    cfd.entity_type,
    cfd.field_key,
    cfd.field_type,
    cfd.label,
    cfd.label_he,
    cfd.description,
    cfd.is_required,
    cfd.is_searchable,
    cfd.display_order,
    cfd.default_value_json,
    cfd.options_json,
    cfv.id as value_id,
    cfv.entity_id,
    cfv.value_text,
    cfv.value_number,
    cfv.value_boolean,
    cfv.value_date,
    cfv.value_datetime,
    cfv.value_json,
    CASE cfd.field_type
        WHEN 'text' THEN cfv.value_text
        WHEN 'number' THEN cfv.value_number::text
        WHEN 'boolean' THEN cfv.value_boolean::text
        WHEN 'date' THEN cfv.value_date::text
        WHEN 'datetime' THEN cfv.value_datetime::text
        WHEN 'select' THEN cfv.value_text
        WHEN 'multi_select' THEN cfv.value_json::text
        WHEN 'json' THEN cfv.value_json::text
    END as display_value,
    cfv.created_at as value_created_at,
    cfv.updated_at as value_updated_at
FROM custom_field_definitions cfd
LEFT JOIN custom_field_values cfv ON 
    cfd.id = cfv.definition_id 
    AND cfd.tenant_id = cfv.tenant_id
WHERE cfd.deleted_at IS NULL;

-- ============================================================================
-- FUNCTION: Get all custom field values for an entity
-- Returns definition + value merged, ordered by display_order
-- ============================================================================

CREATE OR REPLACE FUNCTION get_custom_fields_for_entity(
    p_tenant_id UUID,
    p_entity_type VARCHAR(50),
    p_entity_id UUID
) RETURNS TABLE (
    definition_id UUID,
    field_key VARCHAR(100),
    field_type VARCHAR(20),
    label VARCHAR(255),
    label_he VARCHAR(255),
    description TEXT,
    is_required BOOLEAN,
    display_order INTEGER,
    options JSONB,
    value_id UUID,
    value_text TEXT,
    value_number NUMERIC,
    value_boolean BOOLEAN,
    value_date DATE,
    value_datetime TIMESTAMPTZ,
    value_json JSONB,
    display_value TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        cfd.id as definition_id,
        cfd.field_key,
        cfd.field_type,
        cfd.label,
        cfd.label_he,
        cfd.description,
        cfd.is_required,
        cfd.display_order,
        cfd.options_json as options,
        cfv.id as value_id,
        cfv.value_text,
        cfv.value_number,
        cfv.value_boolean,
        cfv.value_date,
        cfv.value_datetime,
        cfv.value_json,
        CASE cfd.field_type
            WHEN 'text' THEN cfv.value_text
            WHEN 'number' THEN cfv.value_number::text
            WHEN 'boolean' THEN cfv.value_boolean::text
            WHEN 'date' THEN cfv.value_date::text
            WHEN 'datetime' THEN cfv.value_datetime::text
            WHEN 'select' THEN cfv.value_text
            WHEN 'multi_select' THEN cfv.value_json::text
            WHEN 'json' THEN cfv.value_json::text
        END as display_value
    FROM custom_field_definitions cfd
    LEFT JOIN custom_field_values cfv ON 
        cfd.id = cfv.definition_id 
        AND cfv.entity_id = p_entity_id
        AND cfv.tenant_id = p_tenant_id
    WHERE cfd.tenant_id = p_tenant_id
      AND cfd.entity_type = p_entity_type
      AND cfd.deleted_at IS NULL
    ORDER BY cfd.display_order ASC, cfd.field_key ASC;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- FUNCTION: Get select option label by value
-- Returns the label (or label_he) for a select/multi_select option
-- ============================================================================

CREATE OR REPLACE FUNCTION get_select_option_label(
    p_options_json JSONB,
    p_value TEXT,
    p_lang VARCHAR(2) DEFAULT 'en'
) RETURNS TEXT AS $$
DECLARE
    v_option JSONB;
BEGIN
    FOR v_option IN SELECT * FROM jsonb_array_elements(p_options_json->'options')
    LOOP
        IF v_option->>'value' = p_value THEN
            IF p_lang = 'he' AND v_option->>'label_he' IS NOT NULL THEN
                RETURN v_option->>'label_he';
            ELSE
                RETURN v_option->>'label';
            END IF;
        END IF;
    END LOOP;
    RETURN p_value;  -- Return raw value if not found
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================

-- Index for entity lookups
CREATE INDEX IF NOT EXISTS idx_custom_field_values_entity 
ON custom_field_values(tenant_id, entity_type, entity_id);

-- Index for definition lookups
CREATE INDEX IF NOT EXISTS idx_custom_field_defs_entity_type 
ON custom_field_definitions(tenant_id, entity_type) 
WHERE deleted_at IS NULL;

-- Index for searchable fields
CREATE INDEX IF NOT EXISTS idx_custom_field_values_search_text 
ON custom_field_values(tenant_id, value_text) 
WHERE value_text IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_custom_field_values_search_number 
ON custom_field_values(tenant_id, value_number) 
WHERE value_number IS NOT NULL;

COMMIT;
