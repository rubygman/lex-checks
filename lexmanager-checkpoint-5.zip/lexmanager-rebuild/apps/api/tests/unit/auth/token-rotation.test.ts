// ============================================================================
// TOKEN ROTATION UNIT TESTS
// apps/api/tests/unit/auth/token-rotation.test.ts
// 
// Tests for refresh token rotation, reuse detection, and family revocation
// ============================================================================

import { describe, it, expect, beforeEach } from 'vitest';

// ============================================================================
// MOCK REFRESH TOKEN STORE
// ============================================================================

interface MockRefreshToken {
  id: string;
  tenantId: string;
  userId: string;
  tokenHash: string;
  familyId: string;
  issuedAt: Date;
  expiresAt: Date;
  rotatedAt: Date | null;
  revokedAt: Date | null;
  revokeReason: string | null;
}

class MockRefreshTokenStore {
  private tokens = new Map<string, MockRefreshToken>();
  private idCounter = 0;

  create(data: {
    tenantId: string;
    userId: string;
    tokenHash: string;
    familyId: string;
    expiresAt: Date;
  }): MockRefreshToken {
    const token: MockRefreshToken = {
      id: `token-${++this.idCounter}`,
      ...data,
      issuedAt: new Date(),
      rotatedAt: null,
      revokedAt: null,
      revokeReason: null,
    };
    this.tokens.set(token.tokenHash, token);
    return token;
  }

  findByHash(tokenHash: string): MockRefreshToken | null {
    return this.tokens.get(tokenHash) || null;
  }

  markRotated(tokenId: string): void {
    for (const token of this.tokens.values()) {
      if (token.id === tokenId) {
        token.rotatedAt = new Date();
        break;
      }
    }
  }

  revokeFamily(familyId: string, reason: string): number {
    let count = 0;
    for (const token of this.tokens.values()) {
      if (token.familyId === familyId && !token.revokedAt) {
        token.revokedAt = new Date();
        token.revokeReason = reason;
        count++;
      }
    }
    return count;
  }

  revokeAllForUser(tenantId: string, userId: string, reason: string): number {
    let count = 0;
    for (const token of this.tokens.values()) {
      if (token.tenantId === tenantId && token.userId === userId && !token.revokedAt) {
        token.revokedAt = new Date();
        token.revokeReason = reason;
        count++;
      }
    }
    return count;
  }

  getByFamily(familyId: string): MockRefreshToken[] {
    return Array.from(this.tokens.values()).filter(t => t.familyId === familyId);
  }

  clear(): void {
    this.tokens.clear();
    this.idCounter = 0;
  }
}

// ============================================================================
// TOKEN ROTATION SERVICE
// ============================================================================

class TokenRotationService {
  constructor(private store: MockRefreshTokenStore) {}

  issueToken(tenantId: string, userId: string, familyId?: string): {
    tokenHash: string;
    familyId: string;
    token: MockRefreshToken;
  } {
    const tokenHash = `hash-${Math.random().toString(36).substring(2)}`;
    const family = familyId || `family-${Math.random().toString(36).substring(2)}`;
    
    const token = this.store.create({
      tenantId,
      userId,
      tokenHash,
      familyId: family,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    });

    return { tokenHash, familyId: family, token };
  }

  rotate(tokenHash: string): {
    success: true;
    newTokenHash: string;
    familyId: string;
  } | {
    success: false;
    error: string;
    familyRevoked?: boolean;
  } {
    const existingToken = this.store.findByHash(tokenHash);

    if (!existingToken) {
      return { success: false, error: 'INVALID_TOKEN' };
    }

    if (existingToken.revokedAt) {
      return { success: false, error: 'TOKEN_REVOKED' };
    }

    if (new Date() > existingToken.expiresAt) {
      return { success: false, error: 'TOKEN_EXPIRED' };
    }

    // CRITICAL: Reuse detection
    if (existingToken.rotatedAt) {
      this.store.revokeFamily(existingToken.familyId, 'Token reuse detected');
      return { 
        success: false,
        error: 'TOKEN_REUSE',
        familyRevoked: true,
      };
    }

    this.store.markRotated(existingToken.id);

    const newToken = this.issueToken(
      existingToken.tenantId,
      existingToken.userId,
      existingToken.familyId
    );

    return {
      success: true,
      newTokenHash: newToken.tokenHash,
      familyId: existingToken.familyId,
    };
  }

  logout(tokenHash: string): boolean {
    const token = this.store.findByHash(tokenHash);
    if (token && !token.revokedAt) {
      token.revokedAt = new Date();
      token.revokeReason = 'User logout';
      return true;
    }
    return false;
  }

  logoutAll(tenantId: string, userId: string): number {
    return this.store.revokeAllForUser(tenantId, userId, 'User logout all');
  }
}

// ============================================================================
// TESTS
// ============================================================================

describe('Token Rotation', () => {
  let store: MockRefreshTokenStore;
  let service: TokenRotationService;

  beforeEach(() => {
    store = new MockRefreshTokenStore();
    service = new TokenRotationService(store);
  });

  describe('Token Issuance', () => {
    it('should issue token with unique hash', () => {
      const r1 = service.issueToken('tenant-1', 'user-1');
      const r2 = service.issueToken('tenant-1', 'user-1');
      expect(r1.tokenHash).not.toBe(r2.tokenHash);
    });

    it('should create unique family when not specified', () => {
      const r1 = service.issueToken('tenant-1', 'user-1');
      const r2 = service.issueToken('tenant-1', 'user-1');
      expect(r1.familyId).not.toBe(r2.familyId);
    });

    it('should use specified family ID', () => {
      const result = service.issueToken('tenant-1', 'user-1', 'my-family');
      expect(result.familyId).toBe('my-family');
    });
  });

  describe('Valid Token Rotation', () => {
    it('should rotate valid token successfully', () => {
      const initial = service.issueToken('tenant-1', 'user-1');
      const result = service.rotate(initial.tokenHash);

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.newTokenHash).toBeDefined();
        expect(result.familyId).toBe(initial.familyId);
      }
    });

    it('should mark old token as rotated', () => {
      const initial = service.issueToken('tenant-1', 'user-1');
      service.rotate(initial.tokenHash);

      const oldToken = store.findByHash(initial.tokenHash);
      expect(oldToken?.rotatedAt).not.toBeNull();
    });

    it('should maintain family across multiple rotations', () => {
      const initial = service.issueToken('tenant-1', 'user-1');
      const r1 = service.rotate(initial.tokenHash);
      expect(r1.success).toBe(true);
      
      if (r1.success) {
        const r2 = service.rotate(r1.newTokenHash);
        expect(r2.success).toBe(true);
        if (r2.success) {
          expect(r2.familyId).toBe(initial.familyId);
        }
      }
    });
  });

  describe('Token Reuse Detection (CRITICAL)', () => {
    it('should detect reuse of rotated token', () => {
      const initial = service.issueToken('tenant-1', 'user-1');
      
      // First rotation succeeds
      const r1 = service.rotate(initial.tokenHash);
      expect(r1.success).toBe(true);

      // Attempting to use old token again = REUSE ATTACK
      const r2 = service.rotate(initial.tokenHash);
      expect(r2.success).toBe(false);
      if (!r2.success) {
        expect(r2.error).toBe('TOKEN_REUSE');
        expect(r2.familyRevoked).toBe(true);
      }
    });

    it('should revoke entire family on reuse detection', () => {
      const initial = service.issueToken('tenant-1', 'user-1');
      const familyId = initial.familyId;

      // Rotate a few times
      const r1 = service.rotate(initial.tokenHash);
      expect(r1.success).toBe(true);
      
      if (r1.success) {
        const r2 = service.rotate(r1.newTokenHash);
        expect(r2.success).toBe(true);
      }

      // Now try to reuse the original token
      service.rotate(initial.tokenHash);

      // ALL tokens in family should be revoked
      const familyTokens = store.getByFamily(familyId);
      expect(familyTokens.length).toBeGreaterThan(0);
      familyTokens.forEach(token => {
        expect(token.revokedAt).not.toBeNull();
        expect(token.revokeReason).toBe('Token reuse detected');
      });
    });

    it('should invalidate new token after family revocation', () => {
      const initial = service.issueToken('tenant-1', 'user-1');
      
      const r1 = service.rotate(initial.tokenHash);
      expect(r1.success).toBe(true);

      // Reuse attack
      service.rotate(initial.tokenHash);

      // Try to use the "new" token - should fail
      if (r1.success) {
        const r3 = service.rotate(r1.newTokenHash);
        expect(r3.success).toBe(false);
        if (!r3.success) {
          expect(r3.error).toBe('TOKEN_REVOKED');
        }
      }
    });
  });

  describe('Invalid Token Handling', () => {
    it('should reject non-existent token', () => {
      const result = service.rotate('non-existent-hash');
      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toBe('INVALID_TOKEN');
      }
    });

    it('should reject revoked token', () => {
      const initial = service.issueToken('tenant-1', 'user-1');
      service.logout(initial.tokenHash);

      const result = service.rotate(initial.tokenHash);
      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toBe('TOKEN_REVOKED');
      }
    });

    it('should reject expired token', () => {
      const token = store.create({
        tenantId: 'tenant-1',
        userId: 'user-1',
        tokenHash: 'expired-hash',
        familyId: 'family-1',
        expiresAt: new Date(Date.now() - 1000), // Already expired
      });

      const result = service.rotate('expired-hash');
      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toBe('TOKEN_EXPIRED');
      }
    });
  });

  describe('Logout', () => {
    it('should revoke single token on logout', () => {
      const initial = service.issueToken('tenant-1', 'user-1');
      const success = service.logout(initial.tokenHash);

      expect(success).toBe(true);
      
      const token = store.findByHash(initial.tokenHash);
      expect(token?.revokedAt).not.toBeNull();
      expect(token?.revokeReason).toBe('User logout');
    });

    it('should revoke all user tokens on logout-all', () => {
      // Create multiple sessions
      const s1 = service.issueToken('tenant-1', 'user-1');
      const s2 = service.issueToken('tenant-1', 'user-1');
      const s3 = service.issueToken('tenant-1', 'user-1');
      
      // Different user's token (should not be affected)
      const other = service.issueToken('tenant-1', 'user-2');

      const count = service.logoutAll('tenant-1', 'user-1');
      expect(count).toBe(3);

      // User-1's tokens should be revoked
      expect(store.findByHash(s1.tokenHash)?.revokedAt).not.toBeNull();
      expect(store.findByHash(s2.tokenHash)?.revokedAt).not.toBeNull();
      expect(store.findByHash(s3.tokenHash)?.revokedAt).not.toBeNull();

      // User-2's token should NOT be revoked
      expect(store.findByHash(other.tokenHash)?.revokedAt).toBeNull();
    });
  });

  describe('Tenant Isolation', () => {
    it('should not affect tokens from other tenants on logout-all', () => {
      const t1u1 = service.issueToken('tenant-1', 'user-1');
      const t2u1 = service.issueToken('tenant-2', 'user-1'); // Same user ID, different tenant

      service.logoutAll('tenant-1', 'user-1');

      // Tenant-1's token should be revoked
      expect(store.findByHash(t1u1.tokenHash)?.revokedAt).not.toBeNull();

      // Tenant-2's token should NOT be revoked
      expect(store.findByHash(t2u1.tokenHash)?.revokedAt).toBeNull();
    });
  });

  describe('Race Condition Prevention (Atomic Rotation)', () => {
    it('should only allow one concurrent rotation to succeed', () => {
      const initial = service.issueToken('tenant-1', 'user-1');
      
      // Simulate two concurrent rotation attempts
      // First one succeeds
      const r1 = service.rotate(initial.tokenHash);
      expect(r1.success).toBe(true);

      // Second one (using same original token) should fail as reuse
      const r2 = service.rotate(initial.tokenHash);
      expect(r2.success).toBe(false);
      if (!r2.success) {
        expect(r2.error).toBe('TOKEN_REUSE');
        expect(r2.familyRevoked).toBe(true);
      }
    });

    it('should revoke family when concurrent rotation detected', () => {
      const initial = service.issueToken('tenant-1', 'user-1');
      const familyId = initial.familyId;

      // First rotation succeeds and issues new token
      const r1 = service.rotate(initial.tokenHash);
      expect(r1.success).toBe(true);

      // Simulate concurrent rotation with original token
      // (represents attacker who stole token trying to use it)
      service.rotate(initial.tokenHash);

      // Check that all tokens in family are revoked
      const familyTokens = store.getByFamily(familyId);
      familyTokens.forEach(token => {
        expect(token.revokedAt).not.toBeNull();
      });
    });

    it('should make legitimate new token unusable after race detection', () => {
      const initial = service.issueToken('tenant-1', 'user-1');

      // Legitimate user rotates token
      const r1 = service.rotate(initial.tokenHash);
      expect(r1.success).toBe(true);
      if (!r1.success) return;

      // Attacker tries to use original token (race condition/theft)
      const attackerResult = service.rotate(initial.tokenHash);
      expect(attackerResult.success).toBe(false);

      // Even the legitimate user's new token should now be revoked
      const legitimateNewToken = service.rotate(r1.newTokenHash);
      expect(legitimateNewToken.success).toBe(false);
      if (!legitimateNewToken.success) {
        expect(legitimateNewToken.error).toBe('TOKEN_REVOKED');
      }
    });
  });
});
