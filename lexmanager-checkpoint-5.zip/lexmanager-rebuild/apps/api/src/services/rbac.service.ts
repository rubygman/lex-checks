// ============================================================================
// RBAC SERVICE
// apps/api/src/services/rbac.service.ts
// ============================================================================

import { 
  roleRepository, 
  permissionRepository, 
  type Role, 
  type Permission,
  type RoleWithPermissions,
} from '../repositories/rbac.repository.js';
import { userRepository, type UserWithRole } from '../repositories/user.repository.js';
import { NotFoundError, DatabaseError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export interface PermissionCheck {
  allowed: boolean;
  reason?: string;
}

export interface UserPermissions {
  userId: string;
  roleId: string;
  roleName: string;
  permissions: string[];
}

// ============================================================================
// PERMISSION CODES (for type safety)
// ============================================================================

export const PERMISSIONS = {
  // Cases
  CASES_VIEW: 'cases_view',
  CASES_CREATE: 'cases_create',
  CASES_EDIT: 'cases_edit',
  CASES_DELETE: 'cases_delete',
  CASES_ASSIGN: 'cases_assign',
  CASES_EXPORT: 'cases_export',

  // Clients
  CLIENTS_VIEW: 'clients_view',
  CLIENTS_CREATE: 'clients_create',
  CLIENTS_EDIT: 'clients_edit',
  CLIENTS_DELETE: 'clients_delete',
  CLIENTS_EXPORT: 'clients_export',

  // Documents
  DOCS_VIEW: 'docs_view',
  DOCS_UPLOAD: 'docs_upload',
  DOCS_EDIT: 'docs_edit',
  DOCS_DELETE: 'docs_delete',
  DOCS_DOWNLOAD: 'docs_download',

  // Calendar
  CALENDAR_VIEW: 'calendar_view',
  CALENDAR_CREATE: 'calendar_create',
  CALENDAR_EDIT: 'calendar_edit',
  CALENDAR_DELETE: 'calendar_delete',

  // Finance
  FINANCE_VIEW: 'finance_view',
  FINANCE_CREATE: 'finance_create',
  FINANCE_EDIT: 'finance_edit',
  FINANCE_DELETE: 'finance_delete',
  FINANCE_REPORTS: 'finance_reports',
  INVOICES_VIEW: 'invoices_view',
  INVOICES_CREATE: 'invoices_create',
  INVOICES_EDIT: 'invoices_edit',
  INVOICES_DELETE: 'invoices_delete',

  // Time Tracking
  TIME_VIEW_OWN: 'time_view_own',
  TIME_VIEW_ALL: 'time_view_all',
  TIME_CREATE: 'time_create',
  TIME_EDIT_OWN: 'time_edit_own',
  TIME_EDIT_ALL: 'time_edit_all',
  TIME_DELETE: 'time_delete',
  TIME_APPROVE: 'time_approve',

  // Trust
  TRUST_VIEW: 'trust_view',
  TRUST_DEPOSIT: 'trust_deposit',
  TRUST_WITHDRAW: 'trust_withdraw',
  TRUST_TRANSFER: 'trust_transfer',
  TRUST_REPORTS: 'trust_reports',

  // Communication
  EMAIL_SEND: 'email_send',
  SMS_SEND: 'sms_send',
  COMM_LOG_VIEW: 'comm_log_view',
  COMM_LOG_CREATE: 'comm_log_create',

  // Tasks
  TASKS_VIEW: 'tasks_view',
  TASKS_CREATE: 'tasks_create',
  TASKS_EDIT: 'tasks_edit',
  TASKS_DELETE: 'tasks_delete',
  TASKS_ASSIGN: 'tasks_assign',

  // Reports
  REPORTS_VIEW: 'reports_view',
  REPORTS_CREATE: 'reports_create',
  REPORTS_EXPORT: 'reports_export',

  // Administration
  SETTINGS_VIEW: 'settings_view',
  SETTINGS_EDIT: 'settings_edit',
  USERS_MANAGE: 'users_manage',
  ROLES_MANAGE: 'roles_manage',
  CUSTOM_FIELDS_MANAGE: 'custom_fields_manage',
  TEMPLATES_MANAGE: 'templates_manage',
  BACKUP_MANAGE: 'backup_manage',
  AUDIT_LOG_VIEW: 'audit_log_view',
} as const;

export type PermissionCode = typeof PERMISSIONS[keyof typeof PERMISSIONS];

// ============================================================================
// ROLE NAMES
// ============================================================================

export const ROLES = {
  ADMIN: 'admin',
  ATTORNEY: 'attorney',
  PARALEGAL: 'paralegal',
  STAFF: 'staff',
} as const;

export type RoleName = typeof ROLES[keyof typeof ROLES];

// ============================================================================
// SERVICE
// ============================================================================

export class RBACService {
  // In-memory cache for role permissions (cleared on server restart)
  private rolePermissionsCache = new Map<string, Set<string>>();

  /**
   * Load all permissions for a role
   */
  async loadPermissionsForRole(roleId: string): Promise<string[]> {
    // Check cache first
    const cached = this.rolePermissionsCache.get(roleId);
    if (cached) {
      return Array.from(cached);
    }

    // Load from database
    const permissions = await permissionRepository.getCodesForRole(roleId);
    
    // Cache result
    this.rolePermissionsCache.set(roleId, new Set(permissions));
    
    return permissions;
  }

  /**
   * Load permissions for a role by name
   */
  async loadPermissionsForRoleName(roleName: string): Promise<string[]> {
    const role = await roleRepository.findByName(roleName);
    if (!role) {
      throw new NotFoundError('Role', roleName);
    }
    return this.loadPermissionsForRole(role.id);
  }

  /**
   * Check if a user has a specific permission
   */
  async checkPermission(
    tenantId: string,
    userId: string,
    permissionCode: PermissionCode | string
  ): Promise<PermissionCheck> {
    // Get user with role
    const user = await userRepository.findByIdWithRole(tenantId, userId);
    
    if (!user) {
      return {
        allowed: false,
        reason: 'User not found',
      };
    }

    if (!user.is_active) {
      return {
        allowed: false,
        reason: 'User account is deactivated',
      };
    }

    // Load role permissions
    const permissions = await this.loadPermissionsForRole(user.role_id);
    
    // Check if permission exists
    const hasPermission = permissions.includes(permissionCode);

    return {
      allowed: hasPermission,
      reason: hasPermission ? undefined : `User role '${user.role_name}' does not have permission '${permissionCode}'`,
    };
  }

  /**
   * Check if a user has ANY of the specified permissions
   */
  async checkAnyPermission(
    tenantId: string,
    userId: string,
    permissionCodes: (PermissionCode | string)[]
  ): Promise<PermissionCheck> {
    const user = await userRepository.findByIdWithRole(tenantId, userId);
    
    if (!user) {
      return { allowed: false, reason: 'User not found' };
    }

    if (!user.is_active) {
      return { allowed: false, reason: 'User account is deactivated' };
    }

    const permissions = await this.loadPermissionsForRole(user.role_id);
    const hasAny = permissionCodes.some(code => permissions.includes(code));

    return {
      allowed: hasAny,
      reason: hasAny ? undefined : `User role '${user.role_name}' does not have any of the required permissions`,
    };
  }

  /**
   * Check if a user has ALL of the specified permissions
   */
  async checkAllPermissions(
    tenantId: string,
    userId: string,
    permissionCodes: (PermissionCode | string)[]
  ): Promise<PermissionCheck> {
    const user = await userRepository.findByIdWithRole(tenantId, userId);
    
    if (!user) {
      return { allowed: false, reason: 'User not found' };
    }

    if (!user.is_active) {
      return { allowed: false, reason: 'User account is deactivated' };
    }

    const permissions = await this.loadPermissionsForRole(user.role_id);
    const missingPermissions = permissionCodes.filter(code => !permissions.includes(code));

    return {
      allowed: missingPermissions.length === 0,
      reason: missingPermissions.length === 0 
        ? undefined 
        : `Missing permissions: ${missingPermissions.join(', ')}`,
    };
  }

  /**
   * Get all permissions for a user
   */
  async getUserPermissions(tenantId: string, userId: string): Promise<UserPermissions | null> {
    const user = await userRepository.findByIdWithRole(tenantId, userId);
    
    if (!user) {
      return null;
    }

    const permissions = await this.loadPermissionsForRole(user.role_id);

    return {
      userId: user.id,
      roleId: user.role_id,
      roleName: user.role_name,
      permissions,
    };
  }

  /**
   * Require permission (throws if not allowed)
   */
  async requirePermission(
    tenantId: string,
    userId: string,
    permissionCode: PermissionCode | string
  ): Promise<void> {
    const check = await this.checkPermission(tenantId, userId, permissionCode);
    
    if (!check.allowed) {
      throw new DatabaseError(
        check.reason || 'Permission denied',
        'PERMISSION_DENIED',
        403
      );
    }
  }

  /**
   * Require any of the specified permissions
   */
  async requireAnyPermission(
    tenantId: string,
    userId: string,
    permissionCodes: (PermissionCode | string)[]
  ): Promise<void> {
    const check = await this.checkAnyPermission(tenantId, userId, permissionCodes);
    
    if (!check.allowed) {
      throw new DatabaseError(
        check.reason || 'Permission denied',
        'PERMISSION_DENIED',
        403
      );
    }
  }

  /**
   * Require all of the specified permissions
   */
  async requireAllPermissions(
    tenantId: string,
    userId: string,
    permissionCodes: (PermissionCode | string)[]
  ): Promise<void> {
    const check = await this.checkAllPermissions(tenantId, userId, permissionCodes);
    
    if (!check.allowed) {
      throw new DatabaseError(
        check.reason || 'Permission denied',
        'PERMISSION_DENIED',
        403
      );
    }
  }

  /**
   * Check if user is admin
   */
  async isAdmin(tenantId: string, userId: string): Promise<boolean> {
    const user = await userRepository.findByIdWithRole(tenantId, userId);
    return user?.role_name === ROLES.ADMIN;
  }

  /**
   * Get all roles
   */
  async getAllRoles(): Promise<Role[]> {
    return roleRepository.listAll();
  }

  /**
   * Get role by ID with permissions
   */
  async getRoleWithPermissions(roleId: string): Promise<RoleWithPermissions | null> {
    return roleRepository.findByIdWithPermissions(roleId);
  }

  /**
   * Get role by name
   */
  async getRoleByName(name: string): Promise<Role | null> {
    return roleRepository.findByName(name);
  }

  /**
   * Get all permissions
   */
  async getAllPermissions(): Promise<Permission[]> {
    return permissionRepository.listAll();
  }

  /**
   * Get permissions grouped by category
   */
  async getPermissionsByCategory(): Promise<Map<string, Permission[]>> {
    const permissions = await permissionRepository.listAll();
    const grouped = new Map<string, Permission[]>();

    for (const permission of permissions) {
      const category = permission.category;
      if (!grouped.has(category)) {
        grouped.set(category, []);
      }
      grouped.get(category)!.push(permission);
    }

    return grouped;
  }

  /**
   * Clear permission cache (call when role permissions are updated)
   */
  clearCache(): void {
    this.rolePermissionsCache.clear();
  }

  /**
   * Clear cache for specific role
   */
  clearRoleCache(roleId: string): void {
    this.rolePermissionsCache.delete(roleId);
  }
}

export const rbacService = new RBACService();
