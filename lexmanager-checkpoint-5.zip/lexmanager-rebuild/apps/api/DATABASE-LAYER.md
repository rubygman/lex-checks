# Database Layer Implementation

## Overview

This document describes the database layer implementation for LexManager, focusing on the **strict tenant scoping** and **soft delete** patterns that ensure data isolation and compliance.

## Core Principles

### 1. Tenant Scoping is MANDATORY

**Every** business table query **MUST** be scoped by `tenant_id`. This is enforced at multiple levels:

```
┌─────────────────────────────────────────────────────────────┐
│                    APPLICATION LAYER                         │
│  Service calls repository.findById(tenantId, id)            │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    REPOSITORY LAYER                          │
│  BaseRepository.validateTenantId() - THROWS if invalid      │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    QUERY BUILDER                             │
│  QueryBuilder.validateTenantScoping() - THROWS if missing   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    GENERATED SQL                             │
│  WHERE tenant_id = $1 AND deleted_at IS NULL ...            │
└─────────────────────────────────────────────────────────────┘
```

### 2. Soft Delete by Default

All queries automatically exclude soft-deleted records (`deleted_at IS NULL`) unless explicitly requested:

```typescript
// Default: excludes deleted
const clients = await clientRepo.list(tenantId);

// Explicit: includes deleted
const allClients = await clientRepo.list(tenantId, { includeDeleted: true });
```

### 3. Immutable Tables are Protected

Tables marked as immutable (`trust_transactions`, `audit.logs`) **cannot** be updated or deleted:

```typescript
// These will THROW ImmutableTableError
await trustTransactionRepo.update();    // ❌ THROWS
await trustTransactionRepo.delete();    // ❌ THROWS
await trustTransactionRepo.softDelete(); // ❌ THROWS

// Only append is allowed
await trustTransactionRepo.append(tenantId, data); // ✅ OK
```

## File Structure

```
apps/api/src/
├── db/
│   ├── connection.ts      # PostgreSQL pool & query helpers
│   ├── query-builder.ts   # Type-safe query builder with tenant enforcement
│   ├── errors.ts          # Custom database errors
│   └── index.ts           # Exports
│
├── repositories/
│   ├── base.repository.ts      # Abstract base with tenant validation
│   ├── immutable.repository.ts # For append-only tables
│   └── index.ts                # Concrete repositories
│
└── tests/
    ├── unit/
    │   ├── db/query-builder.test.ts
    │   └── repositories/base.repository.test.ts
    └── integration/
        └── db/tenant-scoping.integration.test.ts
```

## Error Types

| Error | Code | When Thrown |
|-------|------|-------------|
| `TenantScopingError` | `TENANT_SCOPING_REQUIRED` | Query lacks valid tenantId |
| `ImmutableTableError` | `IMMUTABLE_TABLE` | Attempting UPDATE/DELETE on immutable table |
| `NotFoundError` | `NOT_FOUND` | Record not found (within tenant scope) |
| `DuplicateError` | `DUPLICATE_ENTRY` | Unique constraint violation |
| `ForeignKeyError` | `FOREIGN_KEY_VIOLATION` | FK constraint violation |
| `CrossTenantAccessError` | `CROSS_TENANT_ACCESS` | Attempting cross-tenant reference |

## Usage Examples

### Creating a Repository

```typescript
import { BaseRepository, type SoftDeletableEntity } from './base.repository.js';

interface Case extends SoftDeletableEntity {
  id: string;
  tenant_id: string;
  title: string;
  client_id: string;
  status: string;
  // ... other fields
}

class CaseRepository extends BaseRepository<Case> {
  constructor() {
    super({
      tableName: 'cases',
      supportsSoftDelete: true,
    });
  }

  // Custom methods always require tenantId
  async findByClient(tenantId: string, clientId: string): Promise<Case[]> {
    this.validateTenantId(tenantId, 'findByClient');
    
    const result = await this.list(tenantId, {
      filters: [{ field: 'client_id', operator: '=', value: clientId }]
    });
    
    return result.data;
  }
}
```

### Using the Repository

```typescript
const caseRepo = new CaseRepository();

// ✅ CORRECT: Always pass tenantId
const cases = await caseRepo.list(user.tenantId);
const case1 = await caseRepo.findById(user.tenantId, caseId);
const newCase = await caseRepo.create(user.tenantId, caseData);

// ❌ WRONG: Will throw TenantScopingError
const cases = await caseRepo.list('');           // Empty string
const cases = await caseRepo.list(undefined);    // Undefined
const cases = await caseRepo.list(null);         // Null
```

### Using QueryBuilder Directly

```typescript
import { createQueryBuilder } from './db/query-builder.js';

// Build a complex query
const qb = createQueryBuilder()
  .table('cases')
  .tenant(tenantId)                    // REQUIRED
  .select('id', 'title', 'status')
  .whereEquals('status', 'active')
  .where('created_at', '>', startDate)
  .orderBy('created_at', 'DESC')
  .paginate(20, 0);

const { text, params } = qb.buildSelect();
// text: SELECT id, title, status FROM cases WHERE cases.tenant_id = $3 AND cases.deleted_at IS NULL AND status = $1 AND created_at > $2 ORDER BY created_at DESC LIMIT 20 OFFSET 0
```

## Test Coverage

### Unit Tests Verify:

1. **Tenant scoping enforcement**: Every method throws `TenantScopingError` for invalid tenantId
2. **Soft delete filtering**: Deleted records excluded by default
3. **Immutable protection**: UPDATE/DELETE blocked on immutable tables
4. **Error messages**: Include operation name, table name, and received value

### Integration Tests Verify:

1. **Tenant isolation**: Queries only return same-tenant records
2. **Cross-tenant protection**: Cannot update/delete other tenant's records
3. **Soft delete behavior**: Deleted records hidden, restorable
4. **Count accuracy**: Counts respect tenant scope and soft delete

## Running Tests

```bash
# Unit tests (no database required)
pnpm test

# Integration tests (requires PostgreSQL)
DATABASE_URL=postgresql://... pnpm test:integration

# With coverage
pnpm test:coverage
```

## Security Guarantees

1. **No unscoped queries**: It is impossible to execute a query without tenantId on tenant-scoped tables
2. **Defense in depth**: Validation at repository AND query builder levels
3. **Immutable audit trail**: Trust transactions and audit logs cannot be modified
4. **Soft delete protection**: Accidentally deleted data can be restored

## Global Tables (No Tenant Scoping)

These tables are intentionally not tenant-scoped:

- `roles` - System-defined roles
- `permissions` - System-defined permissions  
- `role_permissions` - Role-permission mappings

```typescript
// Global tables don't require tenantId
const roles = await query('SELECT * FROM roles');
```
