// ============================================================================
// AUDIT SERVICE
// apps/api/src/services/audit.service.ts
// 
// Automatic audit logging for all mutations with RBAC for reading
// ============================================================================

import {
  auditLogRepository,
  type AuditLogEntry,
  type AuditAction,
  type AuditCategory,
  type AuditLogFilters,
  type HashChainVerificationResult,
} from '../repositories/audit-log.repository.js';
import { rbacService, PERMISSIONS } from './rbac.service.js';
import { TenantScopingError, DatabaseError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export interface AuditContext {
  tenantId: string;
  userId?: string;
  ipAddress?: string;
  userAgent?: string;
  requestId?: string;
}

export interface AuditEntryInput {
  action: AuditAction;
  entityType: string;
  entityId?: string;
  description: string;
  changes?: Record<string, unknown>;
  oldValues?: Record<string, unknown>;
  newValues?: Record<string, unknown>;
  isFinancial?: boolean;
}

export interface EntityChange {
  field: string;
  oldValue: unknown;
  newValue: unknown;
}

// ============================================================================
// ENTITY TYPE CONFIGURATIONS
// Defines which entities are financial (longer retention)
// ============================================================================

const FINANCIAL_ENTITIES = new Set([
  'clients',
  'cases',
  'invoices',
  'invoice_lines',
  'payments',
  'time_entries',
  'trust_accounts',
  'trust_transactions',
]);

// ============================================================================
// SERVICE
// ============================================================================

export class AuditService {
  // ==========================================================================
  // AUDIT LOG WRITING (No permission check - internal use)
  // ==========================================================================

  /**
   * Log a create action
   */
  async logCreate(
    context: AuditContext,
    entityType: string,
    entityId: string,
    entityData: Record<string, unknown>
  ): Promise<AuditLogEntry> {
    this.validateContext(context);

    return auditLogRepository.append(context.tenantId, {
      user_id: context.userId,
      action: 'CREATE',
      action_category: 'data',
      entity_type: entityType,
      entity_id: entityId,
      description: `Created ${entityType}`,
      new_values_json: this.sanitizeData(entityData),
      ip_address: context.ipAddress,
      user_agent: context.userAgent,
      request_id: context.requestId,
      is_financial: FINANCIAL_ENTITIES.has(entityType),
    });
  }

  /**
   * Log an update action
   */
  async logUpdate(
    context: AuditContext,
    entityType: string,
    entityId: string,
    oldData: Record<string, unknown>,
    newData: Record<string, unknown>
  ): Promise<AuditLogEntry> {
    this.validateContext(context);

    const changes = this.calculateChanges(oldData, newData);

    return auditLogRepository.append(context.tenantId, {
      user_id: context.userId,
      action: 'UPDATE',
      action_category: 'data',
      entity_type: entityType,
      entity_id: entityId,
      description: `Updated ${entityType}`,
      changes_json: { fields: changes.map(c => c.field) },
      old_values_json: this.sanitizeData(oldData),
      new_values_json: this.sanitizeData(newData),
      ip_address: context.ipAddress,
      user_agent: context.userAgent,
      request_id: context.requestId,
      is_financial: FINANCIAL_ENTITIES.has(entityType),
    });
  }

  /**
   * Log a delete action (soft delete)
   */
  async logDelete(
    context: AuditContext,
    entityType: string,
    entityId: string,
    entityData?: Record<string, unknown>
  ): Promise<AuditLogEntry> {
    this.validateContext(context);

    return auditLogRepository.append(context.tenantId, {
      user_id: context.userId,
      action: 'DELETE',
      action_category: 'data',
      entity_type: entityType,
      entity_id: entityId,
      description: `Deleted ${entityType}`,
      old_values_json: entityData ? this.sanitizeData(entityData) : {},
      ip_address: context.ipAddress,
      user_agent: context.userAgent,
      request_id: context.requestId,
      is_financial: FINANCIAL_ENTITIES.has(entityType),
    });
  }

  /**
   * Log a restore action
   */
  async logRestore(
    context: AuditContext,
    entityType: string,
    entityId: string
  ): Promise<AuditLogEntry> {
    this.validateContext(context);

    return auditLogRepository.append(context.tenantId, {
      user_id: context.userId,
      action: 'RESTORE',
      action_category: 'data',
      entity_type: entityType,
      entity_id: entityId,
      description: `Restored ${entityType}`,
      ip_address: context.ipAddress,
      user_agent: context.userAgent,
      request_id: context.requestId,
      is_financial: FINANCIAL_ENTITIES.has(entityType),
    });
  }

  /**
   * Log a login event
   */
  async logLogin(
    context: AuditContext,
    success: boolean,
    email?: string
  ): Promise<AuditLogEntry> {
    this.validateContext(context);

    return auditLogRepository.append(context.tenantId, {
      user_id: context.userId,
      action: 'LOGIN',
      action_category: 'auth',
      entity_type: 'user',
      entity_id: context.userId,
      description: success ? 'User logged in' : `Failed login attempt${email ? ` for ${email}` : ''}`,
      changes_json: { success },
      ip_address: context.ipAddress,
      user_agent: context.userAgent,
      request_id: context.requestId,
      is_financial: false,
    });
  }

  /**
   * Log a logout event
   */
  async logLogout(context: AuditContext): Promise<AuditLogEntry> {
    this.validateContext(context);

    return auditLogRepository.append(context.tenantId, {
      user_id: context.userId,
      action: 'LOGOUT',
      action_category: 'auth',
      entity_type: 'user',
      entity_id: context.userId,
      description: 'User logged out',
      ip_address: context.ipAddress,
      user_agent: context.userAgent,
      request_id: context.requestId,
      is_financial: false,
    });
  }

  /**
   * Log an export action
   */
  async logExport(
    context: AuditContext,
    entityType: string,
    recordCount: number,
    exportFormat: string
  ): Promise<AuditLogEntry> {
    this.validateContext(context);

    return auditLogRepository.append(context.tenantId, {
      user_id: context.userId,
      action: 'EXPORT',
      action_category: 'data',
      entity_type: entityType,
      description: `Exported ${recordCount} ${entityType} records as ${exportFormat}`,
      changes_json: { recordCount, format: exportFormat },
      ip_address: context.ipAddress,
      user_agent: context.userAgent,
      request_id: context.requestId,
      is_financial: FINANCIAL_ENTITIES.has(entityType),
    });
  }

  /**
   * Log a security event
   */
  async logSecurityEvent(
    context: AuditContext,
    eventType: string,
    description: string,
    details?: Record<string, unknown>
  ): Promise<AuditLogEntry> {
    this.validateContext(context);

    return auditLogRepository.append(context.tenantId, {
      user_id: context.userId,
      action: 'VIEW',  // Using VIEW as generic action
      action_category: 'security',
      entity_type: eventType,
      description,
      changes_json: details || {},
      ip_address: context.ipAddress,
      user_agent: context.userAgent,
      request_id: context.requestId,
      is_financial: false,
    });
  }

  /**
   * Generic log entry (for custom use cases)
   */
  async log(context: AuditContext, input: AuditEntryInput): Promise<AuditLogEntry> {
    this.validateContext(context);

    return auditLogRepository.append(context.tenantId, {
      user_id: context.userId,
      action: input.action,
      action_category: this.determineCategory(input.action),
      entity_type: input.entityType,
      entity_id: input.entityId,
      description: input.description,
      changes_json: input.changes || {},
      old_values_json: input.oldValues || {},
      new_values_json: input.newValues || {},
      ip_address: context.ipAddress,
      user_agent: context.userAgent,
      request_id: context.requestId,
      is_financial: input.isFinancial ?? FINANCIAL_ENTITIES.has(input.entityType),
    });
  }

  // ==========================================================================
  // AUDIT LOG READING (Requires admin/audit_log_view permission)
  // ==========================================================================

  /**
   * Get audit log by ID
   * Requires: audit_log_view permission
   */
  async getAuditLog(
    tenantId: string,
    userId: string,
    logId: string
  ): Promise<AuditLogEntry | null> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.AUDIT_LOG_VIEW);
    return auditLogRepository.findById(tenantId, logId);
  }

  /**
   * List audit logs with filters
   * Requires: audit_log_view permission
   */
  async listAuditLogs(
    tenantId: string,
    userId: string,
    filters: AuditLogFilters = {},
    options: { limit?: number; offset?: number } = {}
  ): Promise<AuditLogEntry[]> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.AUDIT_LOG_VIEW);
    return auditLogRepository.list(tenantId, filters, options);
  }

  /**
   * Get audit logs for a specific entity
   * Requires: audit_log_view permission
   */
  async getEntityHistory(
    tenantId: string,
    userId: string,
    entityType: string,
    entityId: string,
    options: { limit?: number; offset?: number } = {}
  ): Promise<AuditLogEntry[]> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.AUDIT_LOG_VIEW);
    return auditLogRepository.findByEntity(tenantId, entityType, entityId, options);
  }

  /**
   * Get audit logs for a specific user's actions
   * Requires: audit_log_view permission
   */
  async getUserActivity(
    tenantId: string,
    requestingUserId: string,
    targetUserId: string,
    options: { limit?: number; offset?: number } = {}
  ): Promise<AuditLogEntry[]> {
    await rbacService.requirePermission(tenantId, requestingUserId, PERMISSIONS.AUDIT_LOG_VIEW);
    return auditLogRepository.findByUser(tenantId, targetUserId, options);
  }

  /**
   * Count audit log entries
   * Requires: audit_log_view permission
   */
  async countAuditLogs(
    tenantId: string,
    userId: string,
    filters: AuditLogFilters = {}
  ): Promise<number> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.AUDIT_LOG_VIEW);
    return auditLogRepository.count(tenantId, filters);
  }

  /**
   * Verify hash chain integrity (tamper detection)
   * Requires: audit_log_view permission
   */
  async verifyIntegrity(
    tenantId: string,
    userId: string,
    startDate?: Date,
    endDate?: Date
  ): Promise<HashChainVerificationResult> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.AUDIT_LOG_VIEW);
    return auditLogRepository.verifyHashChain(tenantId, startDate, endDate);
  }

  /**
   * Get audit log statistics
   * Requires: audit_log_view permission
   */
  async getStatistics(
    tenantId: string,
    userId: string
  ): Promise<{
    entityType: string;
    action: string;
    entryCount: number;
    firstEntry: Date;
    lastEntry: Date;
    financialCount: number;
  }[]> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.AUDIT_LOG_VIEW);
    return auditLogRepository.getStatistics(tenantId);
  }

  // ==========================================================================
  // HELPERS
  // ==========================================================================

  /**
   * Validate audit context
   */
  private validateContext(context: AuditContext): void {
    if (!context.tenantId || context.tenantId.trim() === '') {
      throw new TenantScopingError('Audit context must include a valid tenantId');
    }
  }

  /**
   * Determine action category
   */
  private determineCategory(action: AuditAction): AuditCategory {
    switch (action) {
      case 'LOGIN':
      case 'LOGOUT':
        return 'auth';
      case 'CREATE':
      case 'UPDATE':
      case 'DELETE':
      case 'RESTORE':
      case 'VIEW':
      case 'EXPORT':
      case 'IMPORT':
        return 'data';
      default:
        return 'system';
    }
  }

  /**
   * Calculate changes between old and new data
   */
  private calculateChanges(
    oldData: Record<string, unknown>,
    newData: Record<string, unknown>
  ): EntityChange[] {
    const changes: EntityChange[] = [];
    const allKeys = new Set([...Object.keys(oldData), ...Object.keys(newData)]);

    for (const key of allKeys) {
      // Skip internal fields
      if (['updated_at', 'created_at', 'deleted_at'].includes(key)) {
        continue;
      }

      const oldValue = oldData[key];
      const newValue = newData[key];

      // Compare as JSON strings for complex types
      const oldStr = JSON.stringify(oldValue);
      const newStr = JSON.stringify(newValue);

      if (oldStr !== newStr) {
        changes.push({
          field: key,
          oldValue,
          newValue,
        });
      }
    }

    return changes;
  }

  /**
   * Sanitize data for audit logging (remove sensitive fields)
   */
  private sanitizeData(data: Record<string, unknown>): Record<string, unknown> {
    const sensitiveFields = [
      'password',
      'password_hash',
      'token',
      'secret',
      'api_key',
      'private_key',
    ];

    const sanitized: Record<string, unknown> = {};

    for (const [key, value] of Object.entries(data)) {
      if (sensitiveFields.some(f => key.toLowerCase().includes(f))) {
        sanitized[key] = '[REDACTED]';
      } else if (typeof value === 'object' && value !== null) {
        sanitized[key] = this.sanitizeData(value as Record<string, unknown>);
      } else {
        sanitized[key] = value;
      }
    }

    return sanitized;
  }
}

export const auditService = new AuditService();

// ============================================================================
// AUDIT MIDDLEWARE HELPER
// Use this to wrap repository operations with automatic auditing
// ============================================================================

export function createAuditedOperation<T>(
  auditContext: AuditContext,
  entityType: string
) {
  return {
    /**
     * Wrap a create operation with automatic auditing
     */
    async create(operation: () => Promise<T>): Promise<T> {
      const result = await operation();
      await auditService.logCreate(
        auditContext,
        entityType,
        (result as any).id,
        result as Record<string, unknown>
      );
      return result;
    },

    /**
     * Wrap an update operation with automatic auditing
     */
    async update(
      oldData: Record<string, unknown>,
      operation: () => Promise<T>
    ): Promise<T> {
      const result = await operation();
      await auditService.logUpdate(
        auditContext,
        entityType,
        (result as any).id,
        oldData,
        result as Record<string, unknown>
      );
      return result;
    },

    /**
     * Wrap a delete operation with automatic auditing
     */
    async delete(
      entityId: string,
      entityData: Record<string, unknown>,
      operation: () => Promise<void>
    ): Promise<void> {
      await operation();
      await auditService.logDelete(auditContext, entityType, entityId, entityData);
    },
  };
}
