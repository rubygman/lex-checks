// ============================================================================
// AUTHORIZATION INTEGRATION TESTS
// apps/api/tests/integration/auth/authorization.integration.test.ts
// 
// Tests that forbidden actions return 403 and permitted actions succeed
// ============================================================================

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import pg from 'pg';
import { 
  authorizer, 
  AuthorizationError, 
  AuthenticationError,
  TenantAccessError,
  type RequestContext,
  PERMISSIONS,
} from '../../../src/auth/authorizer.js';
import { clientService } from '../../../src/services/client.service.js';
import { caseService } from '../../../src/services/case.service.js';
import { documentService } from '../../../src/services/document.service.js';
import { calendarEventService } from '../../../src/services/calendar-event.service.js';
import { invoiceService } from '../../../src/services/invoice.service.js';
import { trustService } from '../../../src/services/trust.service.js';
import { auditService } from '../../../src/services/audit.service.js';

const { Pool } = pg;

const DATABASE_URL = process.env.DATABASE_URL;
const shouldRun = DATABASE_URL && DATABASE_URL.includes('localhost');

describe.skipIf(!shouldRun)('Authorization Integration', () => {
  let pool: pg.Pool;
  let tenantId: string;
  let tenant2Id: string;
  
  let adminUserId: string;
  let attorneyUserId: string;
  let paralegalUserId: string;
  let staffUserId: string;
  
  let adminRoleId: string;
  let attorneyRoleId: string;
  let paralegalRoleId: string;
  let staffRoleId: string;

  let clientId: string;
  let caseId: string;

  let adminContext: RequestContext;
  let attorneyContext: RequestContext;
  let paralegalContext: RequestContext;
  let staffContext: RequestContext;
  let unauthenticatedContext: RequestContext;
  let otherTenantContext: RequestContext;

  beforeAll(async () => {
    pool = new Pool({ connectionString: DATABASE_URL });

    const roles = await pool.query('SELECT id, name FROM roles');
    for (const role of roles.rows) {
      switch (role.name) {
        case 'admin': adminRoleId = role.id; break;
        case 'attorney': attorneyRoleId = role.id; break;
        case 'paralegal': paralegalRoleId = role.id; break;
        case 'staff': staffRoleId = role.id; break;
      }
    }

    const tenantResult = await pool.query(
      "INSERT INTO tenants (name, slug) VALUES ('Auth Test', $1) RETURNING id",
      [`auth-test-${Date.now()}`]
    );
    tenantId = tenantResult.rows[0].id;

    const tenant2Result = await pool.query(
      "INSERT INTO tenants (name, slug) VALUES ('Other', $1) RETURNING id",
      [`other-${Date.now()}`]
    );
    tenant2Id = tenant2Result.rows[0].id;

    const createUser = async (email: string, roleId: string, tid: string = tenantId) => {
      const result = await pool.query(
        `INSERT INTO users (tenant_id, email, password_hash, name, role_id)
         VALUES ($1, $2, 'hash', $3, $4) RETURNING id`,
        [tid, email, email.split('@')[0], roleId]
      );
      return result.rows[0].id;
    };

    adminUserId = await createUser(`admin-${Date.now()}@test.com`, adminRoleId);
    attorneyUserId = await createUser(`attorney-${Date.now()}@test.com`, attorneyRoleId);
    paralegalUserId = await createUser(`paralegal-${Date.now()}@test.com`, paralegalRoleId);
    staffUserId = await createUser(`staff-${Date.now()}@test.com`, staffRoleId);
    const otherTenantUserId = await createUser(`other-${Date.now()}@test.com`, adminRoleId, tenant2Id);

    const buildContext = async (userId: string, tid: string, roleId: string, roleName: string): Promise<RequestContext> => {
      const permissions = await pool.query(
        `SELECT p.code FROM permissions p
         JOIN role_permissions rp ON p.id = rp.permission_id
         WHERE rp.role_id = $1`,
        [roleId]
      );
      
      return {
        auth: {
          userId,
          tenantId: tid,
          roleId,
          roleName,
          email: `${roleName}@test.com`,
          isActive: true,
          permissions: new Set(permissions.rows.map(r => r.code)),
        },
        ipAddress: '127.0.0.1',
        userAgent: 'TestAgent',
      };
    };

    adminContext = await buildContext(adminUserId, tenantId, adminRoleId, 'admin');
    attorneyContext = await buildContext(attorneyUserId, tenantId, attorneyRoleId, 'attorney');
    paralegalContext = await buildContext(paralegalUserId, tenantId, paralegalRoleId, 'paralegal');
    staffContext = await buildContext(staffUserId, tenantId, staffRoleId, 'staff');
    otherTenantContext = await buildContext(otherTenantUserId, tenant2Id, adminRoleId, 'admin');
    unauthenticatedContext = { ipAddress: '127.0.0.1' };

    const clientResult = await pool.query(
      `INSERT INTO clients (tenant_id, name, client_type, status, address_country, currency, payment_terms)
       VALUES ($1, 'Test Client', 'individual', 'active', 'Israel', 'ILS', 30) RETURNING id`,
      [tenantId]
    );
    clientId = clientResult.rows[0].id;

    const caseResult = await pool.query(
      `INSERT INTO cases (tenant_id, client_id, title, case_type, status)
       VALUES ($1, $2, 'Test Case', 'Civil', 'active') RETURNING id`,
      [tenantId, clientId]
    );
    caseId = caseResult.rows[0].id;
  });

  afterAll(async () => {
    await pool.query('DELETE FROM tenants WHERE id IN ($1, $2)', [tenantId, tenant2Id]);
    await pool.end();
  });

  // ============================================================================
  // AUTHENTICATION TESTS
  // ============================================================================

  describe('Authentication', () => {
    it('should reject unauthenticated requests', () => {
      expect(() => authorizer.requireAuth(unauthenticatedContext)).toThrow(AuthenticationError);
    });

    it('should accept authenticated requests', () => {
      expect(() => authorizer.requireAuth(adminContext)).not.toThrow();
    });

    it('should reject deactivated users', () => {
      const deactivatedContext: RequestContext = {
        auth: { ...adminContext.auth!, isActive: false },
      };
      expect(() => authorizer.requireAuth(deactivatedContext)).toThrow(AuthenticationError);
    });
  });

  // ============================================================================
  // TENANT ACCESS TESTS
  // ============================================================================

  describe('Tenant Access', () => {
    it('should allow access to own tenant', () => {
      expect(() => authorizer.requireTenantAccess(adminContext, tenantId)).not.toThrow();
    });

    it('should deny access to other tenant', () => {
      expect(() => authorizer.requireTenantAccess(adminContext, tenant2Id)).toThrow(TenantAccessError);
    });

    it('should deny cross-tenant data access', async () => {
      await expect(clientService.getById(otherTenantContext, tenantId, clientId)).rejects.toThrow(TenantAccessError);
    });
  });

  // ============================================================================
  // CLIENT SERVICE PERMISSION TESTS
  // ============================================================================

  describe('Client Service Permissions', () => {
    it('admin can view clients', async () => {
      await expect(clientService.getById(adminContext, tenantId, clientId)).resolves.not.toThrow();
    });

    it('staff can view clients', async () => {
      await expect(clientService.getById(staffContext, tenantId, clientId)).resolves.not.toThrow();
    });

    it('admin can create clients', async () => {
      await expect(
        clientService.create(adminContext, tenantId, {
          name: 'New Client', client_type: 'individual', address_country: 'Israel', currency: 'ILS', payment_terms: 30,
        })
      ).resolves.not.toThrow();
    });

    it('staff CANNOT create clients - returns 403', async () => {
      await expect(
        clientService.create(staffContext, tenantId, {
          name: 'Forbidden', client_type: 'individual', address_country: 'Israel', currency: 'ILS', payment_terms: 30,
        })
      ).rejects.toThrow(AuthorizationError);
    });

    it('attorney CANNOT delete clients - returns 403', async () => {
      await expect(clientService.delete(attorneyContext, tenantId, clientId)).rejects.toThrow(AuthorizationError);
    });

    it('staff CANNOT export clients - returns 403', async () => {
      await expect(clientService.export(staffContext, tenantId, { format: 'csv' })).rejects.toThrow(AuthorizationError);
    });
  });

  // ============================================================================
  // CASE SERVICE PERMISSION TESTS
  // ============================================================================

  describe('Case Service Permissions', () => {
    it('attorney can create cases', async () => {
      await expect(
        caseService.create(attorneyContext, tenantId, { client_id: clientId, title: 'Attorney Case', case_type: 'Civil' })
      ).resolves.not.toThrow();
    });

    it('staff CANNOT create cases - returns 403', async () => {
      await expect(
        caseService.create(staffContext, tenantId, { client_id: clientId, title: 'Forbidden', case_type: 'Civil' })
      ).rejects.toThrow(AuthorizationError);
    });

    it('attorney CANNOT delete cases - returns 403', async () => {
      await expect(caseService.delete(attorneyContext, tenantId, caseId)).rejects.toThrow(AuthorizationError);
    });

    it('staff CANNOT assign lead attorney - returns 403', async () => {
      await expect(caseService.assignLeadAttorney(staffContext, tenantId, caseId, attorneyUserId)).rejects.toThrow(AuthorizationError);
    });
  });

  // ============================================================================
  // INVOICE SERVICE PERMISSION TESTS
  // ============================================================================

  describe('Invoice Service Permissions', () => {
    let invoiceId: string;

    beforeAll(async () => {
      const result = await pool.query(
        `INSERT INTO invoices (tenant_id, client_id, invoice_number, invoice_type, status, issue_date, due_date, created_by)
         VALUES ($1, $2, 'INV-TEST', 'tax_invoice', 'draft', CURRENT_DATE, CURRENT_DATE + 30, $3) RETURNING id`,
        [tenantId, clientId, adminUserId]
      );
      invoiceId = result.rows[0].id;
    });

    it('admin can view invoices', async () => {
      await expect(invoiceService.getById(adminContext, tenantId, invoiceId)).resolves.not.toThrow();
    });

    it('staff CANNOT view invoices - returns 403', async () => {
      await expect(invoiceService.getById(staffContext, tenantId, invoiceId)).rejects.toThrow(AuthorizationError);
    });

    it('paralegal CANNOT create invoices - returns 403', async () => {
      await expect(
        invoiceService.create(paralegalContext, tenantId, {
          client_id: clientId, invoice_type: 'tax_invoice', issue_date: new Date(), due_date: new Date(),
        })
      ).rejects.toThrow(AuthorizationError);
    });

    it('staff CANNOT access finance reports - returns 403', async () => {
      await expect(
        invoiceService.getSummaryReport(staffContext, tenantId, new Date('2024-01-01'), new Date('2024-12-31'))
      ).rejects.toThrow(AuthorizationError);
    });
  });

  // ============================================================================
  // TRUST SERVICE PERMISSION TESTS
  // ============================================================================

  describe('Trust Service Permissions', () => {
    let trustAccountId: string;

    beforeAll(async () => {
      const result = await pool.query(
        `INSERT INTO trust_accounts (tenant_id, client_id, account_name, currency)
         VALUES ($1, $2, 'Test Trust', 'ILS') RETURNING id`,
        [tenantId, clientId]
      );
      trustAccountId = result.rows[0].id;
    });

    it('admin can view trust accounts', async () => {
      await expect(trustService.getAccount(adminContext, tenantId, adminUserId, trustAccountId)).resolves.not.toThrow();
    });

    it('staff CANNOT view trust accounts - returns 403', async () => {
      await expect(trustService.getAccount(staffContext, tenantId, staffUserId, trustAccountId)).rejects.toThrow(AuthorizationError);
    });

    it('staff CANNOT make deposits - returns 403', async () => {
      await expect(
        trustService.recordDeposit(staffContext, tenantId, staffUserId, {
          trustAccountId, clientId, amount: 1000, description: 'Forbidden',
        })
      ).rejects.toThrow(AuthorizationError);
    });
  });

  // ============================================================================
  // AUDIT LOG PERMISSION TESTS
  // ============================================================================

  describe('Audit Log Permissions (Admin-Only)', () => {
    it('admin can view audit logs', async () => {
      await expect(auditService.listAuditLogs(tenantId, adminUserId)).resolves.not.toThrow();
    });

    it('attorney CANNOT view audit logs - returns 403', async () => {
      await expect(auditService.listAuditLogs(tenantId, attorneyUserId)).rejects.toThrow(/PERMISSION_DENIED/);
    });

    it('paralegal CANNOT view audit logs - returns 403', async () => {
      await expect(auditService.listAuditLogs(tenantId, paralegalUserId)).rejects.toThrow(/PERMISSION_DENIED/);
    });

    it('staff CANNOT view audit logs - returns 403', async () => {
      await expect(auditService.listAuditLogs(tenantId, staffUserId)).rejects.toThrow(/PERMISSION_DENIED/);
    });

    it('staff CANNOT verify integrity - returns 403', async () => {
      await expect(auditService.verifyIntegrity(tenantId, staffUserId)).rejects.toThrow(/PERMISSION_DENIED/);
    });
  });

  // ============================================================================
  // ERROR CODE VERIFICATION
  // ============================================================================

  describe('Error Codes', () => {
    it('returns 401 for unauthenticated', async () => {
      try {
        await clientService.getById(unauthenticatedContext, tenantId, clientId);
        expect.fail('Should throw');
      } catch (error) {
        expect((error as AuthenticationError).statusCode).toBe(401);
        expect((error as AuthenticationError).code).toBe('AUTHENTICATION_REQUIRED');
      }
    });

    it('returns 403 for unauthorized', async () => {
      try {
        await clientService.delete(staffContext, tenantId, clientId);
        expect.fail('Should throw');
      } catch (error) {
        expect((error as AuthorizationError).statusCode).toBe(403);
        expect((error as AuthorizationError).code).toBe('PERMISSION_DENIED');
        expect((error as AuthorizationError).requiredPermission).toBe('clients_delete');
      }
    });

    it('returns 403 for cross-tenant access', () => {
      try {
        authorizer.requireTenantAccess(adminContext, tenant2Id);
        expect.fail('Should throw');
      } catch (error) {
        expect((error as TenantAccessError).statusCode).toBe(403);
        expect((error as TenantAccessError).code).toBe('TENANT_ACCESS_DENIED');
      }
    });
  });
});
