-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 001: Initial Schema - DOWN (Rollback)
-- ============================================================================

BEGIN;

-- Drop views first
DROP VIEW IF EXISTS active_trust_accounts;
DROP VIEW IF EXISTS active_payments;
DROP VIEW IF EXISTS active_invoices;
DROP VIEW IF EXISTS active_time_entries;
DROP VIEW IF EXISTS active_events;
DROP VIEW IF EXISTS active_documents;
DROP VIEW IF EXISTS active_tasks;
DROP VIEW IF EXISTS active_cases;
DROP VIEW IF EXISTS active_clients;
DROP VIEW IF EXISTS active_users;
DROP VIEW IF EXISTS active_tenants;

-- Drop triggers
DROP TRIGGER IF EXISTS trg_invoice_immutability ON invoices;
DROP TRIGGER IF EXISTS trg_cases_validate_tenant ON cases;
DROP TRIGGER IF EXISTS trg_trust_tx_balance_before ON trust_transactions;
DROP TRIGGER IF EXISTS trg_trust_tx_update_balance ON trust_transactions;
DROP TRIGGER IF EXISTS trg_audit_no_delete ON audit.logs;
DROP TRIGGER IF EXISTS trg_audit_no_update ON audit.logs;
DROP TRIGGER IF EXISTS trg_trust_tx_no_delete ON trust_transactions;
DROP TRIGGER IF EXISTS trg_trust_tx_no_update ON trust_transactions;
DROP TRIGGER IF EXISTS trg_settings_updated_at ON settings;
DROP TRIGGER IF EXISTS trg_custom_field_vals_updated_at ON custom_field_values;
DROP TRIGGER IF EXISTS trg_custom_field_defs_updated_at ON custom_field_definitions;
DROP TRIGGER IF EXISTS trg_trust_accounts_updated_at ON trust_accounts;
DROP TRIGGER IF EXISTS trg_invoices_updated_at ON invoices;
DROP TRIGGER IF EXISTS trg_time_updated_at ON time_entries;
DROP TRIGGER IF EXISTS trg_events_updated_at ON calendar_events;
DROP TRIGGER IF EXISTS trg_documents_updated_at ON documents;
DROP TRIGGER IF EXISTS trg_tasks_updated_at ON tasks;
DROP TRIGGER IF EXISTS trg_cases_updated_at ON cases;
DROP TRIGGER IF EXISTS trg_clients_updated_at ON clients;
DROP TRIGGER IF EXISTS trg_users_updated_at ON users;
DROP TRIGGER IF EXISTS trg_tenants_updated_at ON tenants;

-- Drop trigger functions
DROP FUNCTION IF EXISTS prevent_issued_invoice_modification();
DROP FUNCTION IF EXISTS validate_case_client_tenant();
DROP FUNCTION IF EXISTS calculate_trust_balance_after();
DROP FUNCTION IF EXISTS update_trust_account_balance();
DROP FUNCTION IF EXISTS prevent_audit_modification();
DROP FUNCTION IF EXISTS prevent_trust_tx_modification();
DROP FUNCTION IF EXISTS update_updated_at_column();

-- Drop tables in reverse dependency order
DROP TABLE IF EXISTS audit.logs;
DROP TABLE IF EXISTS settings;
DROP TABLE IF EXISTS custom_field_values;
DROP TABLE IF EXISTS custom_field_definitions;
DROP TABLE IF EXISTS invoice_counters;
DROP TABLE IF EXISTS trust_transactions;
DROP TABLE IF EXISTS trust_accounts;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS invoice_lines;
DROP TABLE IF EXISTS invoices;
DROP TABLE IF EXISTS time_entries;
DROP TABLE IF EXISTS calendar_events;
DROP TABLE IF EXISTS documents;
DROP TABLE IF EXISTS tasks;
DROP TABLE IF EXISTS cases;
DROP TABLE IF EXISTS clients;
DROP TABLE IF EXISTS refresh_tokens;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS role_permissions;
DROP TABLE IF EXISTS permissions;
DROP TABLE IF EXISTS roles;
DROP TABLE IF EXISTS tenants;

-- Drop audit schema
DROP SCHEMA IF EXISTS audit CASCADE;

COMMIT;
