// ============================================================================
// CASE ROUTES
// apps/api/src/routes/case.routes.ts
// 
// Full CRUD + restore with RBAC, validation, tenant scoping, and audit logging
// ============================================================================

import { Router } from 'express';
import { caseService } from '../services/case.service.js';
import {
  initializeContext,
  resolveTenantFromHeader,
  requireTenant,
  authParser,
  requireAuth,
  requireTenantAccess,
  requirePermission,
} from '../middleware/index.js';
import {
  validate,
  validateAll,
  createCaseSchema,
  updateCaseSchema,
  caseQuerySchema,
  idParamSchema,
  z,
} from '../validation/index.js';
import { asyncHandler, sendSuccess } from '../errors/index.js';
import { PERMISSIONS } from '../services/rbac.service.js';

const router = Router();

// All routes require tenant context and authentication
router.use(initializeContext());
router.use(resolveTenantFromHeader());
router.use(requireTenant());
router.use(authParser());
router.use(requireAuth());
router.use(requireTenantAccess());

// ============================================================================
// GET /cases - List cases with pagination and search
// ============================================================================

router.get(
  '/',
  requirePermission(PERMISSIONS.CASES_VIEW),
  validate(caseQuerySchema, 'query'),
  asyncHandler(async (req, res) => {
    const { page, limit, sortBy, sortOrder, q, status, caseType, clientId, assignedAttorneyId } = req.query as any;

    const result = await caseService.list(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      {
        search: q,
        status,
        caseType,
        clientId,
        assignedAttorneyId,
        limit,
        offset: (page - 1) * limit,
      }
    );

    sendSuccess(res, req, result.data, 200, {
      page,
      limit,
      total: result.pagination.total,
      hasMore: result.pagination.hasMore,
    });
  })
);

// ============================================================================
// POST /cases - Create a new case
// ============================================================================

router.post(
  '/',
  requirePermission(PERMISSIONS.CASES_CREATE),
  validate(createCaseSchema, 'body'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const caseData = await caseService.create(
      context,
      req.auth!.tenantId,
      {
        client_id: req.body.clientId,
        title: req.body.title,
        case_type: req.body.caseType || 'other',
        status: req.body.status || 'intake',
        court_name: req.body.courtName,
        court_case_number: req.body.courtCaseNumber,
        description: req.body.description,
        opposing_party: req.body.opposingParty,
        opposing_counsel: req.body.opposingCounsel,
        statute_of_limitations: req.body.statueOfLimitations,
        billing_type: req.body.billingType || 'hourly',
        billing_rate: req.body.hourlyRate,
        lead_attorney_id: req.body.assignedAttorneyId,
      }
    );

    sendSuccess(res, req, caseData, 201);
  })
);

// ============================================================================
// GET /cases/:id - Get case by ID
// ============================================================================

router.get(
  '/:id',
  requirePermission(PERMISSIONS.CASES_VIEW),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const caseData = await caseService.getByIdOrFail(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, caseData);
  })
);

// ============================================================================
// PATCH /cases/:id - Update case
// ============================================================================

router.patch(
  '/:id',
  requirePermission(PERMISSIONS.CASES_EDIT),
  validateAll({
    params: idParamSchema,
    body: updateCaseSchema,
  }),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    // Build update data
    const updateData: Record<string, unknown> = {};
    if (req.body.title !== undefined) updateData.title = req.body.title;
    if (req.body.titleHe !== undefined) updateData.title_he = req.body.titleHe;
    if (req.body.description !== undefined) updateData.description = req.body.description;
    if (req.body.caseType !== undefined) updateData.case_type = req.body.caseType;
    if (req.body.status !== undefined) updateData.status = req.body.status;
    if (req.body.priority !== undefined) updateData.priority = req.body.priority;
    if (req.body.courtName !== undefined) updateData.court_name = req.body.courtName;
    if (req.body.courtCaseNumber !== undefined) updateData.court_case_number = req.body.courtCaseNumber;
    if (req.body.judgeName !== undefined) updateData.judge_name = req.body.judgeName;
    if (req.body.opposingParty !== undefined) updateData.opposing_party = req.body.opposingParty;
    if (req.body.opposingCounsel !== undefined) updateData.opposing_counsel = req.body.opposingCounsel;
    if (req.body.assignedAttorneyId !== undefined) updateData.lead_attorney_id = req.body.assignedAttorneyId;

    const caseData = await caseService.update(
      context,
      req.auth!.tenantId,
      req.params.id,
      updateData as any
    );

    sendSuccess(res, req, caseData);
  })
);

// ============================================================================
// DELETE /cases/:id - Soft delete case
// ============================================================================

router.delete(
  '/:id',
  requirePermission(PERMISSIONS.CASES_DELETE),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    await caseService.delete(
      context,
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, { message: 'Case deleted successfully' });
  })
);

// ============================================================================
// POST /cases/:id/restore - Restore soft-deleted case
// ============================================================================

router.post(
  '/:id/restore',
  requirePermission(PERMISSIONS.CASES_DELETE),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    await caseService.restore(
      context,
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, { message: 'Case restored successfully' });
  })
);

export default router;
