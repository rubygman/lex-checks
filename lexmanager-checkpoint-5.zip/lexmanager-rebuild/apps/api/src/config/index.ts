// ============================================================================
// SECURE CONFIGURATION
// apps/api/src/config/index.ts
// 
// Structured config with validation at boot - fails fast on missing secrets
// ============================================================================

import { z } from 'zod';

// ============================================================================
// ENVIRONMENT SCHEMAS
// ============================================================================

const DatabaseConfigSchema = z.object({
  host: z.string().min(1),
  port: z.coerce.number().int().min(1).max(65535).default(5432),
  database: z.string().min(1),
  user: z.string().min(1),
  password: z.string().min(1),
  ssl: z.enum(['require', 'prefer', 'disable']).default('require'),
  poolMin: z.coerce.number().int().min(1).default(2),
  poolMax: z.coerce.number().int().min(1).default(10),
});

const JWTConfigSchema = z.object({
  accessSecret: z.string().min(32, 'JWT access secret must be at least 32 characters'),
  refreshSecret: z.string().min(32, 'JWT refresh secret must be at least 32 characters'),
  accessExpiresIn: z.string().default('15m'),  // Short-lived
  refreshExpiresIn: z.string().default('7d'),
  issuer: z.string().default('lexmanager'),
  audience: z.string().default('lexmanager-api'),
});

const EncryptionConfigSchema = z.object({
  // Master key for envelope encryption (in production, this comes from KMS)
  masterKey: z.string().min(32, 'Master encryption key must be at least 32 characters'),
  // Key ID for key rotation support
  keyId: z.string().default('v1'),
  // Algorithm
  algorithm: z.enum(['aes-256-gcm']).default('aes-256-gcm'),
});

const RateLimitConfigSchema = z.object({
  // Global rate limit
  globalWindowMs: z.coerce.number().default(60000),  // 1 minute
  globalMaxRequests: z.coerce.number().default(100),
  // Login rate limit (stricter)
  loginWindowMs: z.coerce.number().default(900000),  // 15 minutes
  loginMaxAttempts: z.coerce.number().default(5),
  // Sensitive endpoints
  sensitiveWindowMs: z.coerce.number().default(60000),
  sensitiveMaxRequests: z.coerce.number().default(20),
});

const ServerConfigSchema = z.object({
  port: z.coerce.number().int().min(1).max(65535).default(3000),
  host: z.string().default('0.0.0.0'),
  env: z.enum(['development', 'staging', 'production']).default('development'),
  trustProxy: z.coerce.boolean().default(true),
  corsOrigins: z.string().transform(s => s.split(',').map(o => o.trim())).default(''),
});

const LoggingConfigSchema = z.object({
  level: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
  format: z.enum(['json', 'pretty']).default('json'),
  // Redaction patterns for sensitive data
  redactPatterns: z.array(z.string()).default([
    '\\d{9}',  // Israeli ID (9 digits)
    '\\d{4}[- ]?\\d{4}[- ]?\\d{4}[- ]?\\d{4}',  // Credit card
    '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}',  // Email (optional)
  ]),
});

const ConfigSchema = z.object({
  server: ServerConfigSchema,
  database: DatabaseConfigSchema,
  jwt: JWTConfigSchema,
  encryption: EncryptionConfigSchema,
  rateLimit: RateLimitConfigSchema,
  logging: LoggingConfigSchema,
});

export type Config = z.infer<typeof ConfigSchema>;
export type DatabaseConfig = z.infer<typeof DatabaseConfigSchema>;
export type JWTConfig = z.infer<typeof JWTConfigSchema>;
export type EncryptionConfig = z.infer<typeof EncryptionConfigSchema>;

// ============================================================================
// LOAD AND VALIDATE CONFIG
// ============================================================================

function loadConfig(): Config {
  const rawConfig = {
    server: {
      port: process.env.PORT,
      host: process.env.HOST,
      env: process.env.NODE_ENV,
      trustProxy: process.env.TRUST_PROXY,
      corsOrigins: process.env.CORS_ORIGINS,
    },
    database: {
      host: process.env.DB_HOST,
      port: process.env.DB_PORT,
      database: process.env.DB_NAME,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      ssl: process.env.DB_SSL,
      poolMin: process.env.DB_POOL_MIN,
      poolMax: process.env.DB_POOL_MAX,
    },
    jwt: {
      accessSecret: process.env.JWT_ACCESS_SECRET,
      refreshSecret: process.env.JWT_REFRESH_SECRET,
      accessExpiresIn: process.env.JWT_ACCESS_EXPIRES_IN,
      refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN,
      issuer: process.env.JWT_ISSUER,
      audience: process.env.JWT_AUDIENCE,
    },
    encryption: {
      masterKey: process.env.ENCRYPTION_MASTER_KEY,
      keyId: process.env.ENCRYPTION_KEY_ID,
      algorithm: process.env.ENCRYPTION_ALGORITHM,
    },
    rateLimit: {
      globalWindowMs: process.env.RATE_LIMIT_WINDOW_MS,
      globalMaxRequests: process.env.RATE_LIMIT_MAX_REQUESTS,
      loginWindowMs: process.env.RATE_LIMIT_LOGIN_WINDOW_MS,
      loginMaxAttempts: process.env.RATE_LIMIT_LOGIN_MAX_ATTEMPTS,
      sensitiveWindowMs: process.env.RATE_LIMIT_SENSITIVE_WINDOW_MS,
      sensitiveMaxRequests: process.env.RATE_LIMIT_SENSITIVE_MAX_REQUESTS,
    },
    logging: {
      level: process.env.LOG_LEVEL,
      format: process.env.LOG_FORMAT,
    },
  };

  const result = ConfigSchema.safeParse(rawConfig);

  if (!result.success) {
    console.error('❌ Configuration validation failed:');
    console.error(result.error.format());
    console.error('\nRequired environment variables:');
    console.error('  DB_HOST, DB_NAME, DB_USER, DB_PASSWORD');
    console.error('  JWT_ACCESS_SECRET (min 32 chars)');
    console.error('  JWT_REFRESH_SECRET (min 32 chars)');
    console.error('  ENCRYPTION_MASTER_KEY (min 32 chars)');
    process.exit(1);
  }

  return result.data;
}

// Singleton config instance
let configInstance: Config | null = null;

export function getConfig(): Config {
  if (!configInstance) {
    configInstance = loadConfig();
  }
  return configInstance;
}

// For testing - reset config
export function resetConfig(): void {
  configInstance = null;
}

// ============================================================================
// ENVIRONMENT CHECKS
// ============================================================================

export function isProduction(): boolean {
  return getConfig().server.env === 'production';
}

export function isDevelopment(): boolean {
  return getConfig().server.env === 'development';
}

// ============================================================================
// VALIDATION HELPERS
// ============================================================================

export function validateSecrets(): void {
  const config = getConfig();

  // Ensure secrets are not default/weak values
  const weakPatterns = [
    'secret', 'password', '12345', 'changeme', 'default',
    'test', 'demo', 'example', 'placeholder'
  ];

  const secrets = [
    { name: 'JWT_ACCESS_SECRET', value: config.jwt.accessSecret },
    { name: 'JWT_REFRESH_SECRET', value: config.jwt.refreshSecret },
    { name: 'ENCRYPTION_MASTER_KEY', value: config.encryption.masterKey },
    { name: 'DB_PASSWORD', value: config.database.password },
  ];

  for (const { name, value } of secrets) {
    const lowerValue = value.toLowerCase();
    for (const pattern of weakPatterns) {
      if (lowerValue.includes(pattern)) {
        if (isProduction()) {
          throw new Error(`Weak secret detected for ${name} in production`);
        } else {
          console.warn(`⚠️  Weak secret detected for ${name} - acceptable in development only`);
        }
      }
    }
  }

  // Ensure access and refresh secrets are different
  if (config.jwt.accessSecret === config.jwt.refreshSecret) {
    throw new Error('JWT_ACCESS_SECRET and JWT_REFRESH_SECRET must be different');
  }

  console.log('✅ All secrets validated');
}
