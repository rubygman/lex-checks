-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 005: Audit Log System
-- Immutable audit trail with SHA-256 hash chain for tamper detection
-- ============================================================================

BEGIN;

-- ============================================================================
-- IMMUTABILITY TRIGGERS FOR AUDIT.LOGS
-- Prevents ANY modification to audit entries after creation
-- ============================================================================

-- Block UPDATE on audit.logs
CREATE OR REPLACE FUNCTION audit.block_audit_log_update()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'UPDATE not allowed on immutable table audit.logs. Audit entries cannot be modified for compliance and security purposes.';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_audit_logs_block_update ON audit.logs;
CREATE TRIGGER trg_audit_logs_block_update
    BEFORE UPDATE ON audit.logs
    FOR EACH ROW
    EXECUTE FUNCTION audit.block_audit_log_update();

-- Block DELETE on audit.logs
CREATE OR REPLACE FUNCTION audit.block_audit_log_delete()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'DELETE not allowed on immutable table audit.logs. Audit entries cannot be deleted for compliance and security purposes.';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_audit_logs_block_delete ON audit.logs;
CREATE TRIGGER trg_audit_logs_block_delete
    BEFORE DELETE ON audit.logs
    FOR EACH ROW
    EXECUTE FUNCTION audit.block_audit_log_delete();

-- ============================================================================
-- HASH CHAIN TRIGGER
-- Calculates entry_hash and links to previous_hash for tamper detection
-- ============================================================================

CREATE OR REPLACE FUNCTION audit.calculate_audit_hash()
RETURNS TRIGGER AS $$
DECLARE
    v_previous_hash VARCHAR(64);
    v_hash_content TEXT;
BEGIN
    -- Get the previous entry's hash for this tenant (chain per tenant)
    SELECT entry_hash INTO v_previous_hash
    FROM audit.logs
    WHERE tenant_id = NEW.tenant_id
    ORDER BY created_at DESC, id DESC
    LIMIT 1;

    -- Set previous_hash (NULL for first entry in tenant)
    NEW.previous_hash := v_previous_hash;

    -- Build hash content from immutable fields
    -- Includes: tenant_id, user_id, action, entity_type, entity_id, 
    -- description, changes_json, previous_hash, created_at
    v_hash_content := COALESCE(NEW.tenant_id::TEXT, '') || '|' ||
                      COALESCE(NEW.user_id::TEXT, '') || '|' ||
                      COALESCE(NEW.action, '') || '|' ||
                      COALESCE(NEW.action_category, '') || '|' ||
                      COALESCE(NEW.entity_type, '') || '|' ||
                      COALESCE(NEW.entity_id::TEXT, '') || '|' ||
                      COALESCE(NEW.description, '') || '|' ||
                      COALESCE(NEW.changes_json::TEXT, '{}') || '|' ||
                      COALESCE(NEW.old_values_json::TEXT, '{}') || '|' ||
                      COALESCE(NEW.new_values_json::TEXT, '{}') || '|' ||
                      COALESCE(v_previous_hash, 'GENESIS') || '|' ||
                      COALESCE(NEW.created_at::TEXT, CURRENT_TIMESTAMP::TEXT);

    -- Calculate SHA-256 hash
    NEW.entry_hash := encode(digest(v_hash_content, 'sha256'), 'hex');

    -- Set retention date if not provided (7 years default for financial, 3 years otherwise)
    IF NEW.retention_date IS NULL THEN
        IF NEW.is_financial THEN
            NEW.retention_date := CURRENT_DATE + INTERVAL '7 years';
        ELSE
            NEW.retention_date := CURRENT_DATE + INTERVAL '3 years';
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_audit_logs_calculate_hash ON audit.logs;
CREATE TRIGGER trg_audit_logs_calculate_hash
    BEFORE INSERT ON audit.logs
    FOR EACH ROW
    EXECUTE FUNCTION audit.calculate_audit_hash();

-- ============================================================================
-- HASH CHAIN VERIFICATION FUNCTION
-- Verifies integrity of the audit chain for a tenant
-- ============================================================================

CREATE OR REPLACE FUNCTION audit.verify_hash_chain(
    p_tenant_id UUID,
    p_start_date TIMESTAMPTZ DEFAULT NULL,
    p_end_date TIMESTAMPTZ DEFAULT NULL
) RETURNS TABLE (
    total_entries BIGINT,
    verified_entries BIGINT,
    broken_entries BIGINT,
    is_valid BOOLEAN,
    first_broken_id UUID,
    first_broken_at TIMESTAMPTZ
) AS $$
DECLARE
    v_total BIGINT := 0;
    v_verified BIGINT := 0;
    v_broken BIGINT := 0;
    v_first_broken_id UUID;
    v_first_broken_at TIMESTAMPTZ;
    v_record RECORD;
    v_expected_hash VARCHAR(64);
    v_hash_content TEXT;
    v_previous_hash VARCHAR(64) := NULL;
BEGIN
    -- Iterate through entries in order
    FOR v_record IN
        SELECT *
        FROM audit.logs
        WHERE tenant_id = p_tenant_id
          AND (p_start_date IS NULL OR created_at >= p_start_date)
          AND (p_end_date IS NULL OR created_at <= p_end_date)
        ORDER BY created_at ASC, id ASC
    LOOP
        v_total := v_total + 1;

        -- Build expected hash content
        v_hash_content := COALESCE(v_record.tenant_id::TEXT, '') || '|' ||
                          COALESCE(v_record.user_id::TEXT, '') || '|' ||
                          COALESCE(v_record.action, '') || '|' ||
                          COALESCE(v_record.action_category, '') || '|' ||
                          COALESCE(v_record.entity_type, '') || '|' ||
                          COALESCE(v_record.entity_id::TEXT, '') || '|' ||
                          COALESCE(v_record.description, '') || '|' ||
                          COALESCE(v_record.changes_json::TEXT, '{}') || '|' ||
                          COALESCE(v_record.old_values_json::TEXT, '{}') || '|' ||
                          COALESCE(v_record.new_values_json::TEXT, '{}') || '|' ||
                          COALESCE(v_previous_hash, 'GENESIS') || '|' ||
                          COALESCE(v_record.created_at::TEXT, '');

        v_expected_hash := encode(digest(v_hash_content, 'sha256'), 'hex');

        -- Check if stored hash matches expected
        IF v_record.entry_hash = v_expected_hash AND 
           (v_record.previous_hash IS NOT DISTINCT FROM v_previous_hash) THEN
            v_verified := v_verified + 1;
        ELSE
            v_broken := v_broken + 1;
            IF v_first_broken_id IS NULL THEN
                v_first_broken_id := v_record.id;
                v_first_broken_at := v_record.created_at;
            END IF;
        END IF;

        -- Update previous hash for next iteration
        v_previous_hash := v_record.entry_hash;
    END LOOP;

    RETURN QUERY SELECT 
        v_total,
        v_verified,
        v_broken,
        (v_broken = 0) as is_valid,
        v_first_broken_id,
        v_first_broken_at;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- AUDIT LOG SEARCH FUNCTION
-- Efficient search with proper indexing
-- ============================================================================

CREATE OR REPLACE FUNCTION audit.search_logs(
    p_tenant_id UUID,
    p_entity_type TEXT DEFAULT NULL,
    p_entity_id UUID DEFAULT NULL,
    p_user_id UUID DEFAULT NULL,
    p_action TEXT DEFAULT NULL,
    p_action_category TEXT DEFAULT NULL,
    p_start_date TIMESTAMPTZ DEFAULT NULL,
    p_end_date TIMESTAMPTZ DEFAULT NULL,
    p_search_text TEXT DEFAULT NULL,
    p_limit INTEGER DEFAULT 100,
    p_offset INTEGER DEFAULT 0
) RETURNS TABLE (
    id UUID,
    tenant_id UUID,
    user_id UUID,
    action TEXT,
    action_category TEXT,
    entity_type TEXT,
    entity_id UUID,
    description TEXT,
    changes_json JSONB,
    old_values_json JSONB,
    new_values_json JSONB,
    ip_address INET,
    user_agent TEXT,
    request_id VARCHAR(36),
    created_at TIMESTAMPTZ,
    entry_hash VARCHAR(64),
    is_financial BOOLEAN
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        l.id,
        l.tenant_id,
        l.user_id,
        l.action::TEXT,
        l.action_category::TEXT,
        l.entity_type::TEXT,
        l.entity_id,
        l.description::TEXT,
        l.changes_json,
        l.old_values_json,
        l.new_values_json,
        l.ip_address,
        l.user_agent::TEXT,
        l.request_id,
        l.created_at,
        l.entry_hash,
        l.is_financial
    FROM audit.logs l
    WHERE l.tenant_id = p_tenant_id
      AND (p_entity_type IS NULL OR l.entity_type = p_entity_type)
      AND (p_entity_id IS NULL OR l.entity_id = p_entity_id)
      AND (p_user_id IS NULL OR l.user_id = p_user_id)
      AND (p_action IS NULL OR l.action = p_action)
      AND (p_action_category IS NULL OR l.action_category = p_action_category)
      AND (p_start_date IS NULL OR l.created_at >= p_start_date)
      AND (p_end_date IS NULL OR l.created_at <= p_end_date)
      AND (p_search_text IS NULL OR l.description ILIKE '%' || p_search_text || '%')
    ORDER BY l.created_at DESC, l.id DESC
    LIMIT p_limit
    OFFSET p_offset;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- AUDIT LOG STATISTICS VIEW
-- ============================================================================

CREATE OR REPLACE VIEW audit.log_statistics AS
SELECT 
    tenant_id,
    entity_type,
    action,
    COUNT(*) as entry_count,
    MIN(created_at) as first_entry,
    MAX(created_at) as last_entry,
    COUNT(*) FILTER (WHERE is_financial) as financial_count
FROM audit.logs
GROUP BY tenant_id, entity_type, action;

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================

-- Primary lookup patterns
CREATE INDEX IF NOT EXISTS idx_audit_logs_tenant_date 
ON audit.logs(tenant_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_audit_logs_entity 
ON audit.logs(tenant_id, entity_type, entity_id);

CREATE INDEX IF NOT EXISTS idx_audit_logs_user 
ON audit.logs(tenant_id, user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_audit_logs_action 
ON audit.logs(tenant_id, action, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_audit_logs_category 
ON audit.logs(tenant_id, action_category, created_at DESC);

-- For hash chain verification (ordered traversal)
CREATE INDEX IF NOT EXISTS idx_audit_logs_chain 
ON audit.logs(tenant_id, created_at ASC, id ASC);

-- For retention queries
CREATE INDEX IF NOT EXISTS idx_audit_logs_retention 
ON audit.logs(retention_date) WHERE retention_date IS NOT NULL;

COMMIT;
