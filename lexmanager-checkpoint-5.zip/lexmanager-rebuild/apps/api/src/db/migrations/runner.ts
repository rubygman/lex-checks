// ============================================================================
// MIGRATION RUNNER
// apps/api/src/db/migrations/runner.ts
// ============================================================================

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import pg from 'pg';

const { Pool } = pg;

// ============================================================================
// TYPES
// ============================================================================

interface MigrationFile {
  version: string;
  name: string;
  filename: string;
  filepath: string;
  checksum: string;
  sql: string;
}

interface AppliedMigration {
  version: string;
  name: string;
  checksum: string;
  applied_at: Date;
}

interface MigrationStatus {
  version: string;
  name: string;
  status: 'applied' | 'pending' | 'modified';
  applied_at?: Date;
  checksum?: string;
}

// ============================================================================
// CONFIGURATION
// ============================================================================

const MIGRATIONS_DIR = path.join(import.meta.dirname, '.');
const MIGRATIONS_TABLE = 'schema_migrations';

// ============================================================================
// UTILITIES
// ============================================================================

/**
 * Calculate SHA-256 checksum of file content
 */
function calculateChecksum(content: string): string {
  return crypto.createHash('sha256').update(content, 'utf8').digest('hex');
}

/**
 * Parse migration filename to extract version and name
 * Expected format: 001_initial_schema.sql or 001_initial_schema_down.sql
 */
function parseMigrationFilename(filename: string): { version: string; name: string; isDown: boolean } | null {
  const match = filename.match(/^(\d+)_(.+?)(_down)?\.sql$/);
  if (!match) return null;
  
  return {
    version: match[1]!,
    name: match[2]!,
    isDown: !!match[3],
  };
}

/**
 * Load all migration files from the migrations directory
 */
function loadMigrationFiles(): { up: MigrationFile[]; down: Map<string, MigrationFile> } {
  const files = fs.readdirSync(MIGRATIONS_DIR).filter(f => f.endsWith('.sql')).sort();
  
  const upMigrations: MigrationFile[] = [];
  const downMigrations = new Map<string, MigrationFile>();
  
  for (const filename of files) {
    const parsed = parseMigrationFilename(filename);
    if (!parsed) continue;
    
    const filepath = path.join(MIGRATIONS_DIR, filename);
    const sql = fs.readFileSync(filepath, 'utf8');
    const checksum = calculateChecksum(sql);
    
    const migration: MigrationFile = {
      version: parsed.version,
      name: parsed.name,
      filename,
      filepath,
      checksum,
      sql,
    };
    
    if (parsed.isDown) {
      downMigrations.set(parsed.version, migration);
    } else {
      upMigrations.push(migration);
    }
  }
  
  return { up: upMigrations, down: downMigrations };
}

// ============================================================================
// MIGRATION RUNNER CLASS
// ============================================================================

export class MigrationRunner {
  private pool: pg.Pool;
  private verbose: boolean;
  
  constructor(connectionString: string, verbose: boolean = true) {
    this.pool = new Pool({ connectionString });
    this.verbose = verbose;
  }
  
  private log(message: string): void {
    if (this.verbose) {
      console.log(message);
    }
  }
  
  private logError(message: string): void {
    console.error(`❌ ${message}`);
  }
  
  private logSuccess(message: string): void {
    if (this.verbose) {
      console.log(`✅ ${message}`);
    }
  }
  
  private logWarning(message: string): void {
    if (this.verbose) {
      console.log(`⚠️  ${message}`);
    }
  }
  
  /**
   * Ensure the schema_migrations table exists
   */
  async ensureMigrationsTable(): Promise<void> {
    await this.pool.query(`
      CREATE TABLE IF NOT EXISTS ${MIGRATIONS_TABLE} (
        version VARCHAR(20) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        checksum VARCHAR(64) NOT NULL,
        applied_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
      )
    `);
  }
  
  /**
   * Get all applied migrations from the database
   */
  async getAppliedMigrations(): Promise<AppliedMigration[]> {
    await this.ensureMigrationsTable();
    
    const result = await this.pool.query<AppliedMigration>(`
      SELECT version, name, checksum, applied_at
      FROM ${MIGRATIONS_TABLE}
      ORDER BY version ASC
    `);
    
    return result.rows;
  }
  
  /**
   * Record a migration as applied
   */
  async recordMigration(migration: MigrationFile): Promise<void> {
    await this.pool.query(`
      INSERT INTO ${MIGRATIONS_TABLE} (version, name, checksum)
      VALUES ($1, $2, $3)
    `, [migration.version, migration.name, migration.checksum]);
  }
  
  /**
   * Remove a migration record (for rollback)
   */
  async removeMigrationRecord(version: string): Promise<void> {
    await this.pool.query(`
      DELETE FROM ${MIGRATIONS_TABLE}
      WHERE version = $1
    `, [version]);
  }
  
  /**
   * Get migration status (applied, pending, modified)
   */
  async status(): Promise<MigrationStatus[]> {
    const { up: migrations } = loadMigrationFiles();
    const applied = await this.getAppliedMigrations();
    const appliedMap = new Map(applied.map(m => [m.version, m]));
    
    const statuses: MigrationStatus[] = [];
    
    for (const migration of migrations) {
      const appliedMigration = appliedMap.get(migration.version);
      
      if (!appliedMigration) {
        statuses.push({
          version: migration.version,
          name: migration.name,
          status: 'pending',
        });
      } else if (appliedMigration.checksum !== migration.checksum) {
        statuses.push({
          version: migration.version,
          name: migration.name,
          status: 'modified',
          applied_at: appliedMigration.applied_at,
          checksum: appliedMigration.checksum,
        });
      } else {
        statuses.push({
          version: migration.version,
          name: migration.name,
          status: 'applied',
          applied_at: appliedMigration.applied_at,
          checksum: appliedMigration.checksum,
        });
      }
    }
    
    return statuses;
  }
  
  /**
   * Run all pending migrations (migrate up)
   */
  async migrateUp(): Promise<{ applied: string[]; errors: string[] }> {
    const { up: migrations } = loadMigrationFiles();
    const applied = await this.getAppliedMigrations();
    const appliedMap = new Map(applied.map(m => [m.version, m]));
    
    const results = { applied: [] as string[], errors: [] as string[] };
    
    for (const migration of migrations) {
      const appliedMigration = appliedMap.get(migration.version);
      
      // Skip already applied migrations
      if (appliedMigration) {
        // Check for checksum mismatch (modified migration)
        if (appliedMigration.checksum !== migration.checksum) {
          const error = `Migration ${migration.version}_${migration.name} has been modified after being applied. ` +
            `Original checksum: ${appliedMigration.checksum.substring(0, 8)}..., ` +
            `Current checksum: ${migration.checksum.substring(0, 8)}...`;
          this.logError(error);
          results.errors.push(error);
          // Stop processing on checksum mismatch
          break;
        }
        continue;
      }
      
      // Apply the migration
      this.log(`Applying migration ${migration.version}_${migration.name}...`);
      
      const client = await this.pool.connect();
      try {
        await client.query('BEGIN');
        await client.query(migration.sql);
        await client.query(`
          INSERT INTO ${MIGRATIONS_TABLE} (version, name, checksum)
          VALUES ($1, $2, $3)
        `, [migration.version, migration.name, migration.checksum]);
        await client.query('COMMIT');
        
        results.applied.push(`${migration.version}_${migration.name}`);
        this.logSuccess(`Applied ${migration.version}_${migration.name}`);
      } catch (error) {
        await client.query('ROLLBACK');
        const errorMsg = `Failed to apply ${migration.version}_${migration.name}: ${error instanceof Error ? error.message : error}`;
        this.logError(errorMsg);
        results.errors.push(errorMsg);
        break; // Stop on first error
      } finally {
        client.release();
      }
    }
    
    if (results.applied.length === 0 && results.errors.length === 0) {
      this.log('No pending migrations.');
    }
    
    return results;
  }
  
  /**
   * Rollback the last applied migration (migrate down)
   */
  async migrateDown(): Promise<{ rolledBack: string | null; error: string | null }> {
    const { down: downMigrations } = loadMigrationFiles();
    const applied = await this.getAppliedMigrations();
    
    if (applied.length === 0) {
      this.log('No migrations to rollback.');
      return { rolledBack: null, error: null };
    }
    
    // Get the last applied migration
    const lastMigration = applied[applied.length - 1]!;
    const downMigration = downMigrations.get(lastMigration.version);
    
    if (!downMigration) {
      const error = `No down migration found for ${lastMigration.version}_${lastMigration.name}`;
      this.logError(error);
      return { rolledBack: null, error };
    }
    
    this.log(`Rolling back migration ${lastMigration.version}_${lastMigration.name}...`);
    
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(downMigration.sql);
      await client.query(`
        DELETE FROM ${MIGRATIONS_TABLE}
        WHERE version = $1
      `, [lastMigration.version]);
      await client.query('COMMIT');
      
      const rolledBack = `${lastMigration.version}_${lastMigration.name}`;
      this.logSuccess(`Rolled back ${rolledBack}`);
      return { rolledBack, error: null };
    } catch (error) {
      await client.query('ROLLBACK');
      const errorMsg = `Failed to rollback: ${error instanceof Error ? error.message : error}`;
      this.logError(errorMsg);
      return { rolledBack: null, error: errorMsg };
    } finally {
      client.release();
    }
  }
  
  /**
   * Reset database (drop all, recreate)
   * WARNING: This is destructive!
   */
  async reset(): Promise<{ success: boolean; error: string | null }> {
    this.logWarning('Resetting database - this will DROP ALL DATA!');
    
    const client = await this.pool.connect();
    try {
      // Drop all tables in public schema
      await client.query(`
        DO $$ 
        DECLARE
          r RECORD;
        BEGIN
          -- Drop all tables in public schema
          FOR r IN (SELECT tablename FROM pg_tables WHERE schemaname = 'public') LOOP
            EXECUTE 'DROP TABLE IF EXISTS public.' || quote_ident(r.tablename) || ' CASCADE';
          END LOOP;
          
          -- Drop audit schema if exists
          DROP SCHEMA IF EXISTS audit CASCADE;
          
          -- Drop all views
          FOR r IN (SELECT viewname FROM pg_views WHERE schemaname = 'public') LOOP
            EXECUTE 'DROP VIEW IF EXISTS public.' || quote_ident(r.viewname) || ' CASCADE';
          END LOOP;
          
          -- Drop all functions
          FOR r IN (SELECT proname, oidvectortypes(proargtypes) as args 
                    FROM pg_proc 
                    INNER JOIN pg_namespace ns ON (pg_proc.pronamespace = ns.oid) 
                    WHERE ns.nspname = 'public') LOOP
            EXECUTE 'DROP FUNCTION IF EXISTS public.' || quote_ident(r.proname) || '(' || r.args || ') CASCADE';
          END LOOP;
        END $$;
      `);
      
      this.logSuccess('Database reset complete.');
      return { success: true, error: null };
    } catch (error) {
      const errorMsg = `Failed to reset database: ${error instanceof Error ? error.message : error}`;
      this.logError(errorMsg);
      return { success: false, error: errorMsg };
    } finally {
      client.release();
    }
  }
  
  /**
   * Close the database connection pool
   */
  async close(): Promise<void> {
    await this.pool.end();
  }
}

// ============================================================================
// CLI INTERFACE
// ============================================================================

async function printStatus(runner: MigrationRunner): Promise<void> {
  const statuses = await runner.status();
  
  console.log('\n📋 Migration Status:');
  console.log('─'.repeat(70));
  console.log('Version  Name                                    Status     Applied At');
  console.log('─'.repeat(70));
  
  for (const status of statuses) {
    const statusIcon = status.status === 'applied' ? '✅' : 
                       status.status === 'pending' ? '⏳' : '⚠️';
    const appliedAt = status.applied_at 
      ? status.applied_at.toISOString().split('T')[0] 
      : '-';
    
    console.log(
      `${status.version.padEnd(8)} ${status.name.padEnd(40).substring(0, 40)} ${statusIcon} ${status.status.padEnd(10)} ${appliedAt}`
    );
  }
  
  console.log('─'.repeat(70));
  
  const pending = statuses.filter(s => s.status === 'pending').length;
  const applied = statuses.filter(s => s.status === 'applied').length;
  const modified = statuses.filter(s => s.status === 'modified').length;
  
  console.log(`Total: ${statuses.length} | Applied: ${applied} | Pending: ${pending} | Modified: ${modified}\n`);
  
  if (modified > 0) {
    console.log('⚠️  WARNING: Modified migrations detected. This may indicate tampering.');
    console.log('   Consider running db:reset if in development.\n');
  }
}

async function main(): Promise<void> {
  const command = process.argv[2];
  const DATABASE_URL = process.env.DATABASE_URL;
  
  if (!DATABASE_URL) {
    console.error('❌ DATABASE_URL environment variable is required');
    process.exit(1);
  }
  
  const runner = new MigrationRunner(DATABASE_URL);
  
  try {
    switch (command) {
      case 'up':
      case 'migrate': {
        console.log('\n🚀 Running migrations...\n');
        const result = await runner.migrateUp();
        
        if (result.errors.length > 0) {
          process.exit(1);
        }
        
        await printStatus(runner);
        break;
      }
      
      case 'down':
      case 'rollback': {
        console.log('\n⏪ Rolling back last migration...\n');
        const result = await runner.migrateDown();
        
        if (result.error) {
          process.exit(1);
        }
        
        await printStatus(runner);
        break;
      }
      
      case 'status': {
        await printStatus(runner);
        break;
      }
      
      case 'reset': {
        // Require confirmation in production
        if (process.env.NODE_ENV === 'production') {
          console.error('❌ db:reset is not allowed in production');
          process.exit(1);
        }
        
        const confirm = process.argv[3];
        if (confirm !== '--confirm') {
          console.log('\n⚠️  This will DROP ALL DATA in the database!');
          console.log('   Run with --confirm to proceed: db:reset --confirm\n');
          process.exit(1);
        }
        
        console.log('\n🗑️  Resetting database...\n');
        const result = await runner.reset();
        
        if (!result.success) {
          process.exit(1);
        }
        break;
      }
      
      default:
        console.log(`
Usage: db:migrate <command>

Commands:
  up, migrate    Run all pending migrations
  down, rollback Rollback the last applied migration
  status         Show migration status
  reset          Drop all tables and recreate (requires --confirm)

Examples:
  pnpm db:migrate
  pnpm db:migrate:down
  pnpm db:migrate:status
  pnpm db:reset --confirm
`);
        process.exit(1);
    }
  } finally {
    await runner.close();
  }
}

// Run if executed directly
main().catch((error) => {
  console.error('Migration runner error:', error);
  process.exit(1);
});

export { MigrationRunner, MigrationStatus, AppliedMigration };
