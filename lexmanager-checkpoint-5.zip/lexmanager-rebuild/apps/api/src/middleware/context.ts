// ============================================================================
// REQUEST CONTEXT MIDDLEWARE
// apps/api/src/middleware/context.ts
// 
// Initializes request context with correlationId, ipAddress, userAgent
// Provides global Express Request typing extension
// ============================================================================

import type { Request, Response, NextFunction, RequestHandler } from 'express';
import crypto from 'crypto';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Tenant context resolved from header
 */
export interface TenantContext {
  tenantId: string;
  tenantSlug: string;
  tenantName: string;
  isActive: boolean;
}

/**
 * Request context attached to every request
 */
export interface RequestContext {
  /** Unique correlation ID for request tracing */
  correlationId: string;
  /** Client IP address (best-effort) */
  ipAddress: string;
  /** Client user agent string */
  userAgent: string;
  /** Tenant context (set by tenant resolver) */
  tenant?: TenantContext;
}

// ============================================================================
// GLOBAL EXPRESS TYPE EXTENSION
// ============================================================================

declare global {
  namespace Express {
    interface Request {
      /** Request context with correlation ID, IP, user agent, and optional tenant */
      context: RequestContext;
    }
  }
}

// ============================================================================
// MIDDLEWARE: INITIALIZE CONTEXT
// ============================================================================

/**
 * Initialize request context
 * 
 * Must be the first middleware in the chain.
 * Attaches:
 * - correlationId: UUID for request tracing (from header or generated)
 * - ipAddress: Client IP (handles proxied requests)
 * - userAgent: Client user agent string
 * - tenant: undefined (set later by tenant resolver)
 */
export function initializeContext(): RequestHandler {
  return (req: Request, res: Response, next: NextFunction): void => {
    // Generate or use existing correlation ID
    const correlationId = 
      (req.headers['x-correlation-id'] as string) ||
      (req.headers['x-request-id'] as string) ||
      generateCorrelationId();

    // Initialize context object
    req.context = {
      correlationId,
      ipAddress: getClientIp(req),
      userAgent: req.headers['user-agent'] || 'unknown',
      tenant: undefined,
    };

    // Set correlation ID in response header for client tracking
    res.setHeader('X-Correlation-ID', correlationId);

    next();
  };
}

// ============================================================================
// HELPERS
// ============================================================================

/**
 * Generate a unique correlation ID
 * Format: UUID v4
 */
function generateCorrelationId(): string {
  return crypto.randomUUID();
}

/**
 * Extract client IP address from request
 * Handles proxied requests (X-Forwarded-For) and direct connections
 */
function getClientIp(req: Request): string {
  // Check X-Forwarded-For header (set by proxies/load balancers)
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) {
    // X-Forwarded-For can be a comma-separated list; first is the client
    const ips = Array.isArray(forwarded) ? forwarded[0] : forwarded.split(',')[0];
    return ips?.trim() || 'unknown';
  }

  // Check X-Real-IP header (used by some proxies)
  const realIp = req.headers['x-real-ip'];
  if (realIp && typeof realIp === 'string') {
    return realIp.trim();
  }

  // Fall back to direct connection IP
  return req.ip || req.socket?.remoteAddress || 'unknown';
}

// ============================================================================
// HELPER: GET CONTEXT
// ============================================================================

/**
 * Get request context with type safety
 * Throws if context is not initialized (should never happen if middleware is used)
 */
export function getRequestContext(req: Request): RequestContext {
  if (!req.context) {
    throw new Error('Request context not initialized. Ensure initializeContext() middleware is applied.');
  }
  return req.context;
}
