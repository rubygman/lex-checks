// ============================================================================
// TRUST SERVICE
// apps/api/src/services/trust.service.ts
// 
// Trust Ledger operations with RBAC enforcement
// ============================================================================

import { 
  trustAccountRepository, 
  type TrustAccount, 
  type TrustAccountWithClient,
  type CreateTrustAccountData,
  type UpdateTrustAccountData,
} from '../repositories/trust-account.repository.js';
import {
  trustTransactionRepository,
  type TrustTransaction,
  type TrustTransactionWithDetails,
  type CreateTrustTransactionData,
  type TrustTransactionType,
  type TransactionFilters,
} from '../repositories/trust-transaction.repository.js';
import { rbacService, PERMISSIONS } from './rbac.service.js';
import { query, withTransaction } from '../db/connection.js';
import { 
  validateTrustAccountTenant, 
  validateClientTenant,
  validateCaseTenant,
  validateUserTenant,
  validateTrustTransactionReferences,
} from '../utils/tenant-validation.js';
import { 
  DatabaseError, 
  NotFoundError, 
  TenantScopingError,
  parsePostgresError,
} from '../db/errors.js';
import type pg from 'pg';

// ============================================================================
// TYPES
// ============================================================================

export interface ReconciliationResult {
  accountId: string;
  accountName: string;
  storedBalance: number;
  calculatedBalance: number;
  lastTransactionId: string | null;
  lastTransactionDate: Date | null;
  transactionCount: number;
  isReconciled: boolean;
  discrepancy: number;
}

export interface TransferRequest {
  fromAccountId: string;
  toAccountId: string;
  amount: number;
  description: string;
  createdBy: string;
  caseId?: string;
}

export interface TransactionRequest {
  trustAccountId: string;
  clientId: string;
  transactionType: TrustTransactionType;
  amount: number;
  description: string;
  createdBy: string;
  caseId?: string;
  externalReference?: string;
  paymentMethod?: string;
  checkNumber?: string;
  bankReference?: string;
  invoiceId?: string;
  paymentId?: string;
  metadata?: Record<string, unknown>;
}

// ============================================================================
// SERVICE
// ============================================================================

export class TrustService {
  // ==========================================================================
  // TRUST ACCOUNT MANAGEMENT
  // ==========================================================================

  /**
   * Create a new trust account
   * Requires: trust_view permission (to create accounts)
   */
  async createTrustAccount(
    tenantId: string,
    userId: string,
    data: {
      clientId: string;
      accountName: string;
      accountNumber?: string;
      bankName?: string;
      bankBranch?: string;
      currency?: string;
      notes?: string;
    }
  ): Promise<TrustAccount> {
    // RBAC check
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.TRUST_VIEW);

    // Validate tenant scoping
    await validateClientTenant(tenantId, data.clientId);

    // Create account
    return trustAccountRepository.createAccount(tenantId, {
      client_id: data.clientId,
      account_name: data.accountName,
      account_number: data.accountNumber,
      bank_name: data.bankName,
      bank_branch: data.bankBranch,
      currency: data.currency,
      notes: data.notes,
      created_by: userId,
    });
  }

  /**
   * Get trust account by ID
   * Requires: trust_view permission
   */
  async getAccount(
    tenantId: string,
    userId: string,
    accountId: string
  ): Promise<TrustAccountWithClient | null> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.TRUST_VIEW);
    return trustAccountRepository.findByIdWithClient(tenantId, accountId);
  }

  /**
   * List trust accounts for client
   * Requires: trust_view permission
   */
  async getAccountsByClient(
    tenantId: string,
    userId: string,
    clientId: string
  ): Promise<TrustAccount[]> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.TRUST_VIEW);
    return trustAccountRepository.findByClient(tenantId, clientId);
  }

  /**
   * List all trust accounts
   * Requires: trust_view permission
   */
  async listAccounts(
    tenantId: string,
    userId: string,
    options?: { activeOnly?: boolean; limit?: number; offset?: number }
  ): Promise<TrustAccountWithClient[]> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.TRUST_VIEW);
    return trustAccountRepository.listWithClients(tenantId, {
      activeOnly: options?.activeOnly,
      pagination: options ? { limit: options.limit ?? 100, offset: options.offset ?? 0 } : undefined,
    });
  }

  /**
   * Update trust account metadata (not balance)
   * Requires: trust_view permission
   */
  async updateAccount(
    tenantId: string,
    userId: string,
    accountId: string,
    data: UpdateTrustAccountData
  ): Promise<TrustAccount> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.TRUST_VIEW);
    return trustAccountRepository.updateAccount(tenantId, accountId, data);
  }

  // ==========================================================================
  // TRANSACTION RECORDING
  // ==========================================================================

  /**
   * Record a trust transaction
   * Requires: trust_deposit or trust_withdraw depending on type
   */
  async recordTransaction(
    tenantId: string,
    userId: string,
    request: TransactionRequest
  ): Promise<TrustTransaction> {
    // RBAC check based on transaction type
    const requiredPermission = this.getPermissionForTransactionType(request.transactionType);
    await rbacService.requirePermission(tenantId, userId, requiredPermission);

    // Validate all cross-tenant references
    await validateTrustTransactionReferences(tenantId, {
      trustAccountId: request.trustAccountId,
      clientId: request.clientId,
      caseId: request.caseId,
      invoiceId: request.invoiceId,
      paymentId: request.paymentId,
      createdBy: request.createdBy,
    });

    // Record the transaction
    return trustTransactionRepository.recordTransaction(tenantId, {
      trust_account_id: request.trustAccountId,
      client_id: request.clientId,
      case_id: request.caseId,
      transaction_type: request.transactionType,
      amount: request.amount,
      description: request.description,
      external_reference: request.externalReference,
      payment_method: request.paymentMethod,
      check_number: request.checkNumber,
      bank_reference: request.bankReference,
      invoice_id: request.invoiceId,
      payment_id: request.paymentId,
      metadata_json: request.metadata,
      created_by: request.createdBy,
    });
  }

  /**
   * Record a deposit
   * Requires: trust_deposit permission
   */
  async recordDeposit(
    tenantId: string,
    userId: string,
    data: {
      trustAccountId: string;
      clientId: string;
      amount: number;
      description: string;
      caseId?: string;
      externalReference?: string;
      paymentMethod?: string;
      checkNumber?: string;
    }
  ): Promise<TrustTransaction> {
    return this.recordTransaction(tenantId, userId, {
      trustAccountId: data.trustAccountId,
      clientId: data.clientId,
      transactionType: 'deposit',
      amount: data.amount,
      description: data.description,
      createdBy: userId,
      caseId: data.caseId,
      externalReference: data.externalReference,
      paymentMethod: data.paymentMethod,
      checkNumber: data.checkNumber,
    });
  }

  /**
   * Record a withdrawal
   * Requires: trust_withdraw permission
   */
  async recordWithdrawal(
    tenantId: string,
    userId: string,
    data: {
      trustAccountId: string;
      clientId: string;
      amount: number;
      description: string;
      caseId?: string;
      externalReference?: string;
      paymentMethod?: string;
    }
  ): Promise<TrustTransaction> {
    return this.recordTransaction(tenantId, userId, {
      trustAccountId: data.trustAccountId,
      clientId: data.clientId,
      transactionType: 'withdrawal',
      amount: data.amount,
      description: data.description,
      createdBy: userId,
      caseId: data.caseId,
      externalReference: data.externalReference,
      paymentMethod: data.paymentMethod,
    });
  }

  /**
   * Transfer between trust accounts
   * Requires: trust_transfer permission
   */
  async recordTransfer(
    tenantId: string,
    userId: string,
    request: TransferRequest
  ): Promise<{ outTransaction: TrustTransaction; inTransaction: TrustTransaction }> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.TRUST_TRANSFER);

    // Validate both accounts belong to tenant
    await validateTrustAccountTenant(tenantId, request.fromAccountId);
    await validateTrustAccountTenant(tenantId, request.toAccountId);

    // Get source account to verify client
    const fromAccount = await trustAccountRepository.findByIdOrFail(tenantId, request.fromAccountId);
    const toAccount = await trustAccountRepository.findByIdOrFail(tenantId, request.toAccountId);

    return withTransaction(async (client) => {
      // Record transfer_out
      const outResult = await client.query<TrustTransaction>(
        `INSERT INTO trust_transactions (
          tenant_id, trust_account_id, client_id, case_id,
          transaction_type, amount, currency, description,
          metadata_json, created_by
        ) VALUES ($1, $2, $3, $4, 'transfer_out', $5, $6, $7, $8, $9)
        RETURNING *`,
        [
          tenantId,
          request.fromAccountId,
          fromAccount.client_id,
          request.caseId || null,
          request.amount,
          fromAccount.currency,
          `${request.description} (Transfer to: ${toAccount.account_name})`,
          JSON.stringify({ transfer_to: request.toAccountId }),
          request.createdBy,
        ]
      );
      const outTransaction = outResult.rows[0]!;

      // Record transfer_in with reference to transfer_out
      const inResult = await client.query<TrustTransaction>(
        `INSERT INTO trust_transactions (
          tenant_id, trust_account_id, client_id, case_id,
          transaction_type, amount, currency, description,
          related_transaction_id, metadata_json, created_by
        ) VALUES ($1, $2, $3, $4, 'transfer_in', $5, $6, $7, $8, $9, $10)
        RETURNING *`,
        [
          tenantId,
          request.toAccountId,
          toAccount.client_id,
          request.caseId || null,
          request.amount,
          toAccount.currency,
          `${request.description} (Transfer from: ${fromAccount.account_name})`,
          outTransaction.id,
          JSON.stringify({ transfer_from: request.fromAccountId }),
          request.createdBy,
        ]
      );
      const inTransaction = inResult.rows[0]!;

      return { outTransaction, inTransaction };
    });
  }

  // ==========================================================================
  // TRANSACTION QUERIES
  // ==========================================================================

  /**
   * List transactions with filters
   * Requires: trust_view permission
   */
  async listTransactions(
    tenantId: string,
    userId: string,
    filters: TransactionFilters = {},
    options: { limit?: number; offset?: number } = {}
  ): Promise<TrustTransactionWithDetails[]> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.TRUST_VIEW);
    return trustTransactionRepository.listTransactions(tenantId, filters, options);
  }

  /**
   * Get transaction by ID
   * Requires: trust_view permission
   */
  async getTransaction(
    tenantId: string,
    userId: string,
    transactionId: string
  ): Promise<TrustTransactionWithDetails | null> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.TRUST_VIEW);
    return trustTransactionRepository.findByIdWithDetails(tenantId, transactionId);
  }

  /**
   * Get account statement
   * Requires: trust_reports permission
   */
  async getAccountStatement(
    tenantId: string,
    userId: string,
    trustAccountId: string,
    startDate: Date,
    endDate: Date
  ) {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.TRUST_REPORTS);
    return trustTransactionRepository.getStatement(tenantId, trustAccountId, startDate, endDate);
  }

  // ==========================================================================
  // RECONCILIATION
  // ==========================================================================

  /**
   * Reconcile trust account balance
   * Compares stored balance with calculated balance from transactions
   * Requires: trust_reports permission
   */
  async reconcileBalance(
    tenantId: string,
    userId: string,
    trustAccountId: string
  ): Promise<ReconciliationResult> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.TRUST_REPORTS);

    try {
      const result = await query<{
        account_id: string;
        account_name: string;
        stored_balance: number;
        calculated_balance: number;
        last_transaction_id: string | null;
        last_transaction_date: Date | null;
        transaction_count: number;
        is_reconciled: boolean;
        discrepancy: number;
      }>(
        `SELECT * FROM reconcile_trust_account($1, $2)`,
        [tenantId, trustAccountId]
      );

      if (result.rows.length === 0) {
        throw new NotFoundError('TrustAccount', trustAccountId);
      }

      const row = result.rows[0]!;

      return {
        accountId: row.account_id,
        accountName: row.account_name,
        storedBalance: parseFloat(row.stored_balance?.toString() || '0'),
        calculatedBalance: parseFloat(row.calculated_balance?.toString() || '0'),
        lastTransactionId: row.last_transaction_id,
        lastTransactionDate: row.last_transaction_date,
        transactionCount: row.transaction_count,
        isReconciled: row.is_reconciled,
        discrepancy: parseFloat(row.discrepancy?.toString() || '0'),
      };
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Mark account as reconciled (after manual review)
   * Requires: trust_reports permission
   */
  async markReconciled(
    tenantId: string,
    userId: string,
    trustAccountId: string
  ): Promise<TrustAccount> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.TRUST_REPORTS);

    // Get current balance
    const account = await trustAccountRepository.findByIdOrFail(tenantId, trustAccountId);

    // Record reconciliation
    return trustAccountRepository.recordReconciliation(tenantId, trustAccountId, account.balance);
  }

  // ==========================================================================
  // REPORTS & STATISTICS
  // ==========================================================================

  /**
   * Get total trust balance for tenant
   * Requires: trust_reports permission
   */
  async getTotalBalance(tenantId: string, userId: string): Promise<number> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.TRUST_REPORTS);
    return trustAccountRepository.getTotalBalance(tenantId);
  }

  /**
   * Get balance history for charting
   * Requires: trust_reports permission
   */
  async getBalanceHistory(
    tenantId: string,
    userId: string,
    trustAccountId: string,
    limit: number = 100
  ) {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.TRUST_REPORTS);
    return trustTransactionRepository.getBalanceHistory(tenantId, trustAccountId, limit);
  }

  // ==========================================================================
  // HELPERS
  // ==========================================================================

  /**
   * Get required permission for transaction type
   */
  private getPermissionForTransactionType(type: TrustTransactionType): string {
    switch (type) {
      case 'deposit':
      case 'refund':
        return PERMISSIONS.TRUST_DEPOSIT;
      case 'withdrawal':
      case 'fee_deduction':
        return PERMISSIONS.TRUST_WITHDRAW;
      case 'transfer_in':
      case 'transfer_out':
        return PERMISSIONS.TRUST_TRANSFER;
      default:
        return PERMISSIONS.TRUST_VIEW;
    }
  }
}

export const trustService = new TrustService();
