-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 005: Audit Log System - DOWN
-- ============================================================================

BEGIN;

-- Drop indexes
DROP INDEX IF EXISTS audit.idx_audit_logs_retention;
DROP INDEX IF EXISTS audit.idx_audit_logs_chain;
DROP INDEX IF EXISTS audit.idx_audit_logs_category;
DROP INDEX IF EXISTS audit.idx_audit_logs_action;
DROP INDEX IF EXISTS audit.idx_audit_logs_user;
DROP INDEX IF EXISTS audit.idx_audit_logs_entity;
DROP INDEX IF EXISTS audit.idx_audit_logs_tenant_date;

-- Drop view
DROP VIEW IF EXISTS audit.log_statistics;

-- Drop functions
DROP FUNCTION IF EXISTS audit.search_logs(UUID, TEXT, UUID, UUID, TEXT, TEXT, TIMESTAMPTZ, TIMESTAMPTZ, TEXT, INTEGER, INTEGER);
DROP FUNCTION IF EXISTS audit.verify_hash_chain(UUID, TIMESTAMPTZ, TIMESTAMPTZ);
DROP FUNCTION IF EXISTS audit.calculate_audit_hash();
DROP FUNCTION IF EXISTS audit.block_audit_log_delete();
DROP FUNCTION IF EXISTS audit.block_audit_log_update();

-- Drop triggers
DROP TRIGGER IF EXISTS trg_audit_logs_calculate_hash ON audit.logs;
DROP TRIGGER IF EXISTS trg_audit_logs_block_delete ON audit.logs;
DROP TRIGGER IF EXISTS trg_audit_logs_block_update ON audit.logs;

COMMIT;
