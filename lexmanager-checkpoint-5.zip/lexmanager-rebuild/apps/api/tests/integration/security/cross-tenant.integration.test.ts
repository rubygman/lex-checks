// ============================================================================
// CROSS-TENANT PROTECTION INTEGRATION TESTS
// apps/api/tests/integration/security/cross-tenant.integration.test.ts
// ============================================================================

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import pg from 'pg';
import {
  validateSameTenant,
  requireSameTenant,
  ref,
  validateClientTenant,
  validateTaskReferences,
  validateTrustTransactionReferences,
} from '../../../src/utils/tenant-validation.js';
import { CrossTenantAccessError, NotFoundError } from '../../../src/db/errors.js';

const { Pool } = pg;

// Skip if no database connection
const DATABASE_URL = process.env.DATABASE_URL;
const shouldRun = DATABASE_URL && DATABASE_URL.includes('localhost');

describe.skipIf(!shouldRun)('Cross-Tenant Protection', () => {
  let pool: pg.Pool;
  
  // Tenant 1 data
  let tenant1Id: string;
  let user1Id: string;
  let client1Id: string;
  let case1Id: string;
  let trustAccount1Id: string;
  
  // Tenant 2 data
  let tenant2Id: string;
  let user2Id: string;
  let client2Id: string;
  let case2Id: string;
  let trustAccount2Id: string;

  beforeAll(async () => {
    pool = new Pool({ connectionString: DATABASE_URL });

    // Get admin role ID
    const roleResult = await pool.query("SELECT id FROM roles WHERE name = 'admin' LIMIT 1");
    const adminRoleId = roleResult.rows[0].id;

    // Create Tenant 1 with full data hierarchy
    const t1Result = await pool.query(
      "INSERT INTO tenants (name, slug) VALUES ('Tenant One', $1) RETURNING id",
      [`tenant-one-${Date.now()}`]
    );
    tenant1Id = t1Result.rows[0].id;

    const u1Result = await pool.query(
      `INSERT INTO users (tenant_id, email, password_hash, name, role_id)
       VALUES ($1, $2, 'hash', 'User One', $3) RETURNING id`,
      [tenant1Id, `user1-${Date.now()}@test.com`, adminRoleId]
    );
    user1Id = u1Result.rows[0].id;

    const c1Result = await pool.query(
      `INSERT INTO clients (tenant_id, name, client_type, status, address_country, currency, payment_terms)
       VALUES ($1, 'Client One', 'individual', 'active', 'Israel', 'ILS', 30) RETURNING id`,
      [tenant1Id]
    );
    client1Id = c1Result.rows[0].id;

    const case1Result = await pool.query(
      `INSERT INTO cases (tenant_id, client_id, title, case_type, status)
       VALUES ($1, $2, 'Case One', 'Civil', 'active') RETURNING id`,
      [tenant1Id, client1Id]
    );
    case1Id = case1Result.rows[0].id;

    const ta1Result = await pool.query(
      `INSERT INTO trust_accounts (tenant_id, client_id, account_name, currency)
       VALUES ($1, $2, 'Trust One', 'ILS') RETURNING id`,
      [tenant1Id, client1Id]
    );
    trustAccount1Id = ta1Result.rows[0].id;

    // Create Tenant 2 with full data hierarchy
    const t2Result = await pool.query(
      "INSERT INTO tenants (name, slug) VALUES ('Tenant Two', $1) RETURNING id",
      [`tenant-two-${Date.now()}`]
    );
    tenant2Id = t2Result.rows[0].id;

    const u2Result = await pool.query(
      `INSERT INTO users (tenant_id, email, password_hash, name, role_id)
       VALUES ($1, $2, 'hash', 'User Two', $3) RETURNING id`,
      [tenant2Id, `user2-${Date.now()}@test.com`, adminRoleId]
    );
    user2Id = u2Result.rows[0].id;

    const c2Result = await pool.query(
      `INSERT INTO clients (tenant_id, name, client_type, status, address_country, currency, payment_terms)
       VALUES ($1, 'Client Two', 'individual', 'active', 'Israel', 'ILS', 30) RETURNING id`,
      [tenant2Id]
    );
    client2Id = c2Result.rows[0].id;

    const case2Result = await pool.query(
      `INSERT INTO cases (tenant_id, client_id, title, case_type, status)
       VALUES ($1, $2, 'Case Two', 'Civil', 'active') RETURNING id`,
      [tenant2Id, client2Id]
    );
    case2Id = case2Result.rows[0].id;

    const ta2Result = await pool.query(
      `INSERT INTO trust_accounts (tenant_id, client_id, account_name, currency)
       VALUES ($1, $2, 'Trust Two', 'ILS') RETURNING id`,
      [tenant2Id, client2Id]
    );
    trustAccount2Id = ta2Result.rows[0].id;
  });

  afterAll(async () => {
    // Cleanup
    await pool.query('DELETE FROM tenants WHERE id IN ($1, $2)', [tenant1Id, tenant2Id]);
    await pool.end();
  });

  // ============================================================================
  // DATABASE TRIGGER TESTS
  // These test the PostgreSQL triggers that prevent cross-tenant references
  // ============================================================================

  describe('Database Trigger Protection', () => {
    describe('Cases -> Clients', () => {
      it('should ALLOW creating case with same-tenant client', async () => {
        const result = await pool.query(
          `INSERT INTO cases (tenant_id, client_id, title, case_type, status)
           VALUES ($1, $2, 'Valid Case', 'Civil', 'active') RETURNING id`,
          [tenant1Id, client1Id]
        );
        expect(result.rows[0].id).toBeDefined();
        
        // Cleanup
        await pool.query('DELETE FROM cases WHERE id = $1', [result.rows[0].id]);
      });

      it('should BLOCK creating case with cross-tenant client', async () => {
        await expect(
          pool.query(
            `INSERT INTO cases (tenant_id, client_id, title, case_type, status)
             VALUES ($1, $2, 'Invalid Case', 'Civil', 'active')`,
            [tenant1Id, client2Id]  // client2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });
    });

    describe('Tasks -> Cases/Clients/Users', () => {
      it('should ALLOW creating task with same-tenant references', async () => {
        const result = await pool.query(
          `INSERT INTO tasks (tenant_id, case_id, client_id, assigned_to, title, status)
           VALUES ($1, $2, $3, $4, 'Valid Task', 'todo') RETURNING id`,
          [tenant1Id, case1Id, client1Id, user1Id]
        );
        expect(result.rows[0].id).toBeDefined();
        
        // Cleanup
        await pool.query('DELETE FROM tasks WHERE id = $1', [result.rows[0].id]);
      });

      it('should BLOCK creating task with cross-tenant case', async () => {
        await expect(
          pool.query(
            `INSERT INTO tasks (tenant_id, case_id, title, status)
             VALUES ($1, $2, 'Invalid Task', 'todo')`,
            [tenant1Id, case2Id]  // case2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });

      it('should BLOCK creating task with cross-tenant assigned_to', async () => {
        await expect(
          pool.query(
            `INSERT INTO tasks (tenant_id, assigned_to, title, status)
             VALUES ($1, $2, 'Invalid Task', 'todo')`,
            [tenant1Id, user2Id]  // user2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });
    });

    describe('Documents -> Cases/Clients', () => {
      it('should BLOCK creating document with cross-tenant case', async () => {
        await expect(
          pool.query(
            `INSERT INTO documents (tenant_id, case_id, uploaded_by, title, filename, mime_type, size_bytes, storage_key)
             VALUES ($1, $2, $3, 'Invalid Doc', 'file.pdf', 'application/pdf', 1000, 'key')`,
            [tenant1Id, case2Id, user1Id]  // case2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });

      it('should BLOCK creating document with cross-tenant uploader', async () => {
        await expect(
          pool.query(
            `INSERT INTO documents (tenant_id, uploaded_by, title, filename, mime_type, size_bytes, storage_key)
             VALUES ($1, $2, 'Invalid Doc', 'file.pdf', 'application/pdf', 1000, 'key')`,
            [tenant1Id, user2Id]  // user2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });
    });

    describe('Time Entries -> Cases/Clients/Users', () => {
      it('should BLOCK creating time entry with cross-tenant case', async () => {
        await expect(
          pool.query(
            `INSERT INTO time_entries (tenant_id, case_id, client_id, user_id, description, work_date, duration_minutes)
             VALUES ($1, $2, $3, $4, 'Work', CURRENT_DATE, 60)`,
            [tenant1Id, case2Id, client1Id, user1Id]  // case2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });

      it('should BLOCK creating time entry with cross-tenant user', async () => {
        await expect(
          pool.query(
            `INSERT INTO time_entries (tenant_id, case_id, client_id, user_id, description, work_date, duration_minutes)
             VALUES ($1, $2, $3, $4, 'Work', CURRENT_DATE, 60)`,
            [tenant1Id, case1Id, client1Id, user2Id]  // user2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });
    });

    describe('Invoices -> Clients/Cases', () => {
      it('should BLOCK creating invoice with cross-tenant client', async () => {
        await expect(
          pool.query(
            `INSERT INTO invoices (tenant_id, client_id, invoice_number, invoice_type, status, issue_date, due_date)
             VALUES ($1, $2, 'INV-001', 'tax_invoice', 'draft', CURRENT_DATE, CURRENT_DATE + 30)`,
            [tenant1Id, client2Id]  // client2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });

      it('should BLOCK creating invoice with cross-tenant case', async () => {
        await expect(
          pool.query(
            `INSERT INTO invoices (tenant_id, client_id, case_id, invoice_number, invoice_type, status, issue_date, due_date)
             VALUES ($1, $2, $3, 'INV-002', 'tax_invoice', 'draft', CURRENT_DATE, CURRENT_DATE + 30)`,
            [tenant1Id, client1Id, case2Id]  // case2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });
    });

    describe('Trust Accounts -> Clients', () => {
      it('should BLOCK creating trust account with cross-tenant client', async () => {
        await expect(
          pool.query(
            `INSERT INTO trust_accounts (tenant_id, client_id, account_name, currency)
             VALUES ($1, $2, 'Invalid Trust', 'ILS')`,
            [tenant1Id, client2Id]  // client2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });
    });

    describe('Trust Transactions (CRITICAL)', () => {
      it('should BLOCK creating trust transaction with cross-tenant trust account', async () => {
        await expect(
          pool.query(
            `INSERT INTO trust_transactions (tenant_id, trust_account_id, client_id, transaction_type, amount, currency, description, created_by)
             VALUES ($1, $2, $3, 'deposit', 1000, 'ILS', 'Invalid', $4)`,
            [tenant1Id, trustAccount2Id, client1Id, user1Id]  // trustAccount2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });

      it('should BLOCK creating trust transaction with cross-tenant client', async () => {
        await expect(
          pool.query(
            `INSERT INTO trust_transactions (tenant_id, trust_account_id, client_id, transaction_type, amount, currency, description, created_by)
             VALUES ($1, $2, $3, 'deposit', 1000, 'ILS', 'Invalid', $4)`,
            [tenant1Id, trustAccount1Id, client2Id, user1Id]  // client2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });

      it('should BLOCK creating trust transaction with cross-tenant case', async () => {
        await expect(
          pool.query(
            `INSERT INTO trust_transactions (tenant_id, trust_account_id, client_id, case_id, transaction_type, amount, currency, description, created_by)
             VALUES ($1, $2, $3, $4, 'deposit', 1000, 'ILS', 'Invalid', $5)`,
            [tenant1Id, trustAccount1Id, client1Id, case2Id, user1Id]  // case2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });

      it('should BLOCK creating trust transaction with cross-tenant created_by', async () => {
        await expect(
          pool.query(
            `INSERT INTO trust_transactions (tenant_id, trust_account_id, client_id, transaction_type, amount, currency, description, created_by)
             VALUES ($1, $2, $3, 'deposit', 1000, 'ILS', 'Invalid', $4)`,
            [tenant1Id, trustAccount1Id, client1Id, user2Id]  // user2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });

      it('should ALLOW creating trust transaction with all same-tenant references', async () => {
        const result = await pool.query(
          `INSERT INTO trust_transactions (tenant_id, trust_account_id, client_id, case_id, transaction_type, amount, currency, description, created_by)
           VALUES ($1, $2, $3, $4, 'deposit', 1000, 'ILS', 'Valid deposit', $5) RETURNING id`,
          [tenant1Id, trustAccount1Id, client1Id, case1Id, user1Id]
        );
        expect(result.rows[0].id).toBeDefined();
        // Note: Cannot delete trust_transactions due to immutability trigger
      });
    });

    describe('Calendar Events -> Cases/Clients', () => {
      it('should BLOCK creating event with cross-tenant case', async () => {
        await expect(
          pool.query(
            `INSERT INTO calendar_events (tenant_id, case_id, title, event_type, start_at, end_at)
             VALUES ($1, $2, 'Invalid Event', 'meeting', NOW(), NOW() + INTERVAL '1 hour')`,
            [tenant1Id, case2Id]  // case2Id belongs to tenant2
          )
        ).rejects.toThrow(/cross-tenant/i);
      });
    });
  });

  // ============================================================================
  // SERVICE LAYER VALIDATION TESTS
  // These test the TypeScript validation utilities
  // ============================================================================

  describe('Service Layer Validation', () => {
    describe('validateSameTenant', () => {
      it('should return valid=true for same-tenant references', async () => {
        const result = await validateSameTenant(
          tenant1Id,
          ref('clients', client1Id, 'Client'),
          ref('cases', case1Id, 'Case'),
          ref('users', user1Id, 'User')
        );

        expect(result.valid).toBe(true);
        expect(result.errors).toHaveLength(0);
      });

      it('should return valid=false for cross-tenant references', async () => {
        const result = await validateSameTenant(
          tenant1Id,
          ref('clients', client1Id, 'Client'),
          ref('cases', case2Id, 'Case')  // Belongs to tenant2
        );

        expect(result.valid).toBe(false);
        expect(result.errors.length).toBeGreaterThan(0);
        expect(result.errors[0]).toContain('different tenant');
      });

      it('should return valid=false for non-existent references', async () => {
        const result = await validateSameTenant(
          tenant1Id,
          ref('clients', '00000000-0000-0000-0000-000000000000', 'Client')
        );

        expect(result.valid).toBe(false);
        expect(result.errors[0]).toContain('not found');
      });

      it('should ignore null references', async () => {
        const result = await validateSameTenant(
          tenant1Id,
          ref('clients', client1Id, 'Client'),
          null,
          ref('cases', null, 'Case'),
          undefined
        );

        expect(result.valid).toBe(true);
      });
    });

    describe('requireSameTenant', () => {
      it('should not throw for same-tenant references', async () => {
        await expect(
          requireSameTenant(
            tenant1Id,
            ref('clients', client1Id),
            ref('cases', case1Id)
          )
        ).resolves.not.toThrow();
      });

      it('should throw CrossTenantAccessError for cross-tenant references', async () => {
        await expect(
          requireSameTenant(
            tenant1Id,
            ref('clients', client1Id),
            ref('cases', case2Id)  // Belongs to tenant2
          )
        ).rejects.toThrow(CrossTenantAccessError);
      });
    });

    describe('validateClientTenant', () => {
      it('should not throw for same-tenant client', async () => {
        await expect(
          validateClientTenant(tenant1Id, client1Id)
        ).resolves.not.toThrow();
      });

      it('should throw for cross-tenant client', async () => {
        await expect(
          validateClientTenant(tenant1Id, client2Id)
        ).rejects.toThrow(CrossTenantAccessError);
      });
    });

    describe('validateTaskReferences', () => {
      it('should not throw for valid same-tenant task references', async () => {
        await expect(
          validateTaskReferences(tenant1Id, {
            caseId: case1Id,
            clientId: client1Id,
            assignedTo: user1Id,
          })
        ).resolves.not.toThrow();
      });

      it('should throw for cross-tenant task references', async () => {
        await expect(
          validateTaskReferences(tenant1Id, {
            caseId: case2Id,  // Belongs to tenant2
            clientId: client1Id,
          })
        ).rejects.toThrow(CrossTenantAccessError);
      });
    });

    describe('validateTrustTransactionReferences', () => {
      it('should not throw for valid same-tenant trust transaction', async () => {
        await expect(
          validateTrustTransactionReferences(tenant1Id, {
            trustAccountId: trustAccount1Id,
            clientId: client1Id,
            caseId: case1Id,
            createdBy: user1Id,
          })
        ).resolves.not.toThrow();
      });

      it('should throw for cross-tenant trust account', async () => {
        await expect(
          validateTrustTransactionReferences(tenant1Id, {
            trustAccountId: trustAccount2Id,  // Belongs to tenant2
            clientId: client1Id,
            createdBy: user1Id,
          })
        ).rejects.toThrow(CrossTenantAccessError);
      });

      it('should throw for cross-tenant client in trust transaction', async () => {
        await expect(
          validateTrustTransactionReferences(tenant1Id, {
            trustAccountId: trustAccount1Id,
            clientId: client2Id,  // Belongs to tenant2
            createdBy: user1Id,
          })
        ).rejects.toThrow(CrossTenantAccessError);
      });
    });
  });

  // ============================================================================
  // EDGE CASES
  // ============================================================================

  describe('Edge Cases', () => {
    it('should handle validation with empty tenantId', async () => {
      const result = await validateSameTenant(
        '',  // Empty tenantId
        ref('clients', client1Id)
      );

      expect(result.valid).toBe(false);
      expect(result.errors[0]).toContain('tenantId is required');
    });

    it('should handle multiple cross-tenant violations', async () => {
      const result = await validateSameTenant(
        tenant1Id,
        ref('clients', client2Id, 'Client'),  // Wrong tenant
        ref('cases', case2Id, 'Case'),        // Wrong tenant
        ref('users', user2Id, 'User')         // Wrong tenant
      );

      expect(result.valid).toBe(false);
      expect(result.errors.length).toBe(3);
    });

    it('should handle mix of valid and invalid references', async () => {
      const result = await validateSameTenant(
        tenant1Id,
        ref('clients', client1Id, 'Client'),  // Valid
        ref('cases', case2Id, 'Case'),        // Invalid
        ref('users', user1Id, 'User')         // Valid
      );

      expect(result.valid).toBe(false);
      expect(result.errors.length).toBe(1);
      expect(result.errors[0]).toContain('Case');
    });
  });
});
