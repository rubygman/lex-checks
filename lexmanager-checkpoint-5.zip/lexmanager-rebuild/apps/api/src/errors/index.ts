// ============================================================================
// UNIFIED ERROR HANDLING
// apps/api/src/errors/index.ts
// 
// Global error standard for consistent API responses.
// All errors use the same envelope: { error: { code, message, details? }, correlationId }
// ============================================================================

import { type Request, type Response, type NextFunction } from 'express';
import { ZodError, type ZodIssue } from 'zod';
import { isProduction } from '../config/index.js';

// ============================================================================
// ERROR CODES
// ============================================================================

/**
 * Standard error codes used across the API
 */
export const ErrorCodes = {
  // Validation errors (400)
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  INVALID_INPUT: 'INVALID_INPUT',
  MISSING_FIELD: 'MISSING_FIELD',
  INVALID_FORMAT: 'INVALID_FORMAT',
  
  // Authentication errors (401)
  UNAUTHORIZED: 'UNAUTHORIZED',
  INVALID_TOKEN: 'INVALID_TOKEN',
  TOKEN_EXPIRED: 'TOKEN_EXPIRED',
  TOKEN_REVOKED: 'TOKEN_REVOKED',
  TOKEN_REUSE: 'TOKEN_REUSE',
  INVALID_CREDENTIALS: 'INVALID_CREDENTIALS',
  
  // Authorization errors (403)
  FORBIDDEN: 'FORBIDDEN',
  PERMISSION_DENIED: 'PERMISSION_DENIED',
  TENANT_ACCESS_DENIED: 'TENANT_ACCESS_DENIED',
  CROSS_TENANT_ACCESS: 'CROSS_TENANT_ACCESS',
  ACCOUNT_INACTIVE: 'ACCOUNT_INACTIVE',
  TENANT_INACTIVE: 'TENANT_INACTIVE',
  
  // Not found errors (404)
  NOT_FOUND: 'NOT_FOUND',
  RESOURCE_NOT_FOUND: 'RESOURCE_NOT_FOUND',
  ROUTE_NOT_FOUND: 'ROUTE_NOT_FOUND',
  
  // Conflict errors (409)
  CONFLICT: 'CONFLICT',
  DUPLICATE_ENTRY: 'DUPLICATE_ENTRY',
  ALREADY_EXISTS: 'ALREADY_EXISTS',
  
  // Rate limiting (429)
  RATE_LIMITED: 'RATE_LIMITED',
  TOO_MANY_REQUESTS: 'TOO_MANY_REQUESTS',
  
  // Server errors (500)
  INTERNAL_ERROR: 'INTERNAL_ERROR',
  DATABASE_ERROR: 'DATABASE_ERROR',
  SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE',
} as const;

export type ErrorCode = typeof ErrorCodes[keyof typeof ErrorCodes];

// ============================================================================
// ERROR ENVELOPE
// ============================================================================

/**
 * Standard error response envelope
 * This shape is used for ALL error responses
 */
export interface ErrorEnvelope {
  error: {
    code: string;
    message: string;
    details?: Record<string, unknown> | unknown[];
  };
  correlationId: string;
}

/**
 * Create a standardized error response
 */
export function createErrorEnvelope(
  code: string,
  message: string,
  correlationId: string,
  details?: Record<string, unknown> | unknown[]
): ErrorEnvelope {
  return {
    error: {
      code,
      message,
      ...(details !== undefined ? { details } : {}),
    },
    correlationId,
  };
}

// ============================================================================
// BASE APPLICATION ERROR
// ============================================================================

/**
 * Base error class for all application errors
 * Provides consistent structure for error handling
 */
export class AppError extends Error {
  public readonly code: string;
  public readonly statusCode: number;
  public readonly details?: Record<string, unknown> | unknown[];
  public readonly isOperational: boolean;

  constructor(
    message: string,
    code: string = ErrorCodes.INTERNAL_ERROR,
    statusCode: number = 500,
    details?: Record<string, unknown> | unknown[],
    isOperational: boolean = true
  ) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.statusCode = statusCode;
    this.details = details;
    this.isOperational = isOperational;
    
    Error.captureStackTrace(this, this.constructor);
  }

  /**
   * Convert to error envelope
   */
  toEnvelope(correlationId: string): ErrorEnvelope {
    return createErrorEnvelope(
      this.code,
      this.message,
      correlationId,
      this.details
    );
  }
}

// ============================================================================
// SPECIFIC ERROR CLASSES
// ============================================================================

/**
 * Validation error (400)
 */
export class ValidationError extends AppError {
  constructor(
    message: string = 'Validation failed',
    details?: Record<string, unknown> | unknown[]
  ) {
    super(message, ErrorCodes.VALIDATION_ERROR, 400, details);
    this.name = 'ValidationError';
  }

  /**
   * Create from Zod error
   */
  static fromZod(zodError: ZodError): ValidationError {
    const details = zodError.issues.map((issue: ZodIssue) => ({
      path: issue.path.join('.'),
      message: issue.message,
      code: issue.code,
    }));
    
    const message = zodError.issues.length === 1
      ? zodError.issues[0].message
      : `${zodError.issues.length} validation errors`;
    
    return new ValidationError(message, details);
  }
}

/**
 * Authentication error (401)
 */
export class AuthenticationError extends AppError {
  constructor(
    message: string = 'Authentication required',
    code: string = ErrorCodes.UNAUTHORIZED
  ) {
    super(message, code, 401);
    this.name = 'AuthenticationError';
  }
}

/**
 * Authorization error (403)
 */
export class AuthorizationError extends AppError {
  constructor(
    message: string = 'Access denied',
    code: string = ErrorCodes.FORBIDDEN
  ) {
    super(message, code, 403);
    this.name = 'AuthorizationError';
  }
}

/**
 * Not found error (404)
 */
export class NotFoundError extends AppError {
  constructor(
    resource: string,
    identifier?: string
  ) {
    const message = identifier
      ? `${resource} not found: ${identifier}`
      : `${resource} not found`;
    super(message, ErrorCodes.NOT_FOUND, 404);
    this.name = 'NotFoundError';
  }
}

/**
 * Conflict error (409)
 */
export class ConflictError extends AppError {
  constructor(
    message: string = 'Resource conflict',
    code: string = ErrorCodes.CONFLICT,
    details?: Record<string, unknown>
  ) {
    super(message, code, 409, details);
    this.name = 'ConflictError';
  }
}

/**
 * Rate limit error (429)
 */
export class RateLimitError extends AppError {
  public readonly retryAfterSeconds: number;

  constructor(
    message: string = 'Too many requests',
    retryAfterSeconds: number = 60
  ) {
    super(message, ErrorCodes.RATE_LIMITED, 429, { retryAfterSeconds });
    this.name = 'RateLimitError';
    this.retryAfterSeconds = retryAfterSeconds;
  }
}

/**
 * Database error (500)
 */
export class DatabaseError extends AppError {
  constructor(
    message: string = 'Database operation failed',
    code: string = ErrorCodes.DATABASE_ERROR,
    statusCode: number = 500
  ) {
    super(message, code, statusCode);
    this.name = 'DatabaseError';
  }
}

// ============================================================================
// ERROR MAPPER
// ============================================================================

/**
 * Map known error types to AppError
 */
export function normalizeError(error: unknown): AppError {
  // Already an AppError
  if (error instanceof AppError) {
    return error;
  }

  // Zod validation error
  if (error instanceof ZodError) {
    return ValidationError.fromZod(error);
  }

  // Legacy DatabaseError from db/errors.ts
  if (
    error instanceof Error &&
    'code' in error &&
    'statusCode' in error &&
    error.constructor.name.includes('Error')
  ) {
    const dbError = error as Error & { code: string; statusCode: number };
    return new AppError(
      dbError.message,
      dbError.code,
      dbError.statusCode
    );
  }

  // Generic Error
  if (error instanceof Error) {
    return new AppError(
      error.message,
      ErrorCodes.INTERNAL_ERROR,
      500,
      undefined,
      false
    );
  }

  // Unknown error type
  return new AppError(
    'An unexpected error occurred',
    ErrorCodes.INTERNAL_ERROR,
    500,
    undefined,
    false
  );
}

// ============================================================================
// SENSITIVE DATA PROTECTION
// ============================================================================

const SENSITIVE_PATTERNS = [
  /password/i,
  /token/i,
  /secret/i,
  /api[_-]?key/i,
  /auth/i,
  /credential/i,
  /bearer/i,
];

/**
 * Check if a string might contain sensitive data
 */
function isSensitiveKey(key: string): boolean {
  return SENSITIVE_PATTERNS.some(pattern => pattern.test(key));
}

/**
 * Sanitize error details to prevent sensitive data leaks
 */
export function sanitizeErrorDetails(
  details: unknown
): Record<string, unknown> | unknown[] | undefined {
  if (details === undefined || details === null) {
    return undefined;
  }

  if (Array.isArray(details)) {
    return details.map(item => 
      typeof item === 'object' && item !== null
        ? sanitizeErrorDetails(item)
        : item
    ) as unknown[];
  }

  if (typeof details === 'object') {
    const sanitized: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(details)) {
      if (isSensitiveKey(key)) {
        sanitized[key] = '[REDACTED]';
      } else if (typeof value === 'object' && value !== null) {
        sanitized[key] = sanitizeErrorDetails(value);
      } else {
        sanitized[key] = value;
      }
    }
    return sanitized;
  }

  return undefined;
}

// ============================================================================
// EXPRESS ERROR MIDDLEWARE
// ============================================================================

/**
 * Global error handling middleware
 * Must be registered LAST in the middleware chain
 */
export function errorHandler(
  err: Error,
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  // Get correlation ID from context
  const correlationId = req.context?.correlationId || 'unknown';

  // Normalize the error
  const appError = normalizeError(err);

  // Log the error
  const logPayload = {
    correlationId,
    code: appError.code,
    message: appError.message,
    statusCode: appError.statusCode,
    isOperational: appError.isOperational,
    path: req.path,
    method: req.method,
    ip: req.context?.ipAddress,
    userId: req.auth?.userId,
    tenantId: req.context?.tenant?.tenantId,
    ...(isProduction() ? {} : { stack: appError.stack }),
  };

  // Log level based on status code
  if (appError.statusCode >= 500) {
    console.error('[ERROR]', JSON.stringify(logPayload));
  } else if (appError.statusCode >= 400) {
    console.warn('[WARN]', JSON.stringify(logPayload));
  }

  // Prepare response
  let message = appError.message;
  let details = appError.details;

  // In production, hide internal error details
  if (isProduction()) {
    if (appError.statusCode >= 500 || !appError.isOperational) {
      message = 'An unexpected error occurred';
      details = undefined;
    } else {
      // Sanitize details even for operational errors
      details = sanitizeErrorDetails(details) as Record<string, unknown> | unknown[] | undefined;
    }
  }

  // Build response envelope
  const envelope = createErrorEnvelope(
    appError.code,
    message,
    correlationId,
    details
  );

  // Set headers for rate limiting
  if (appError instanceof RateLimitError) {
    res.setHeader('Retry-After', appError.retryAfterSeconds);
  }

  // Send response
  res.status(appError.statusCode).json(envelope);
}

/**
 * 404 Not Found handler
 * Register BEFORE the error handler
 */
export function notFoundHandler(
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  const correlationId = req.context?.correlationId || 'unknown';
  
  const envelope = createErrorEnvelope(
    ErrorCodes.ROUTE_NOT_FOUND,
    `Route ${req.method} ${req.path} not found`,
    correlationId
  );

  res.status(404).json(envelope);
}

// ============================================================================
// ASYNC HANDLER WRAPPER
// ============================================================================

/**
 * Wrap async route handlers to catch errors automatically
 * Usage: router.get('/path', asyncHandler(async (req, res) => { ... }))
 */
export function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<void>
) {
  return (req: Request, res: Response, next: NextFunction): void => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

// ============================================================================
// SUCCESS RESPONSE HELPERS
// ============================================================================

/**
 * Standard success response envelope
 */
export interface SuccessEnvelope<T = unknown> {
  data: T;
  correlationId: string;
  meta?: {
    page?: number;
    limit?: number;
    total?: number;
    hasMore?: boolean;
  };
}

/**
 * Create a standardized success response
 */
export function createSuccessEnvelope<T>(
  data: T,
  correlationId: string,
  meta?: SuccessEnvelope['meta']
): SuccessEnvelope<T> {
  return {
    data,
    correlationId,
    ...(meta ? { meta } : {}),
  };
}

/**
 * Send a success response
 */
export function sendSuccess<T>(
  res: Response,
  req: Request,
  data: T,
  statusCode: number = 200,
  meta?: SuccessEnvelope['meta']
): void {
  const correlationId = req.context?.correlationId || 'unknown';
  res.status(statusCode).json(createSuccessEnvelope(data, correlationId, meta));
}
