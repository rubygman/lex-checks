-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 007: Refresh Tokens Table - DOWN
-- ============================================================================

BEGIN;

DROP FUNCTION IF EXISTS revoke_all_user_tokens(UUID, UUID, VARCHAR);
DROP FUNCTION IF EXISTS revoke_token_family(UUID, VARCHAR);
DROP FUNCTION IF EXISTS cleanup_expired_tokens();

DROP TABLE IF EXISTS password_reset_tokens;
DROP TABLE IF EXISTS refresh_tokens;

COMMIT;
