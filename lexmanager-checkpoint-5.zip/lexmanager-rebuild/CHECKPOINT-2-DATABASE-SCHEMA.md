# CHECKPOINT 2: Database Schema

## Entity Relationship Diagram (Text)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              MULTI-TENANT CORE                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────┐         ┌─────────────┐         ┌─────────────────────┐   │
│  │   TENANTS   │◄────────│    USERS    │────────►│       ROLES         │   │
│  │  (Root)     │ 1    N  │(tenant-scoped)│  N   1 │  (global)           │   │
│  │             │         │             │         │                     │   │
│  │ • id (PK)   │         │ • tenant_id │         │ • id (PK)           │   │
│  │ • name      │         │ • email     │         │ • name              │   │
│  │ • slug      │         │ • role_id   │         │ • name_he           │   │
│  │ • deleted_at│         │ • deleted_at│         │                     │   │
│  └──────┬──────┘         └──────┬──────┘         └──────────┬──────────┘   │
│         │                       │                           │              │
│         │                       │                           │              │
│         │                       │              ┌────────────┴────────────┐ │
│         │                       │              │    ROLE_PERMISSIONS     │ │
│         │                       │              │                         │ │
│         │                       │              │ • role_id (FK)          │ │
│         │                       │              │ • permission_id (FK)    │ │
│         │                       │              └────────────┬────────────┘ │
│         │                       │                           │              │
│         │                       │              ┌────────────┴────────────┐ │
│         │                       │              │      PERMISSIONS        │ │
│         │                       │              │                         │ │
│         │                       │              │ • id (PK)               │ │
│         │                       │              │ • code (UNIQUE)         │ │
│         │                       │              │ • category              │ │
│         │                       │              └─────────────────────────┘ │
│         │                       │                                          │
└─────────┼───────────────────────┼──────────────────────────────────────────┘
          │                       │
          │ tenant_id (ALL TABLES)│
          ▼                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                             BUSINESS ENTITIES                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────┐                    ┌─────────────────┐                 │
│  │     CLIENTS     │◄───────────────────│      CASES      │                 │
│  │                 │ 1                N │                 │                 │
│  │ • id (PK)       │                    │ • id (PK)       │                 │
│  │ • tenant_id (FK)│                    │ • tenant_id (FK)│                 │
│  │ • name          │                    │ • client_id (FK)│                 │
│  │ • israeli_id    │                    │ • title         │                 │
│  │ • company_number│                    │ • case_number   │                 │
│  │ • deleted_at    │                    │ • status        │                 │
│  └────────┬────────┘                    │ • deleted_at    │                 │
│           │                             └────────┬────────┘                 │
│           │                                      │                          │
│           │ 1                                    │ 1                        │
│           │                                      │                          │
│           ▼ N                                    ▼ N                        │
│  ┌─────────────────┐                    ┌─────────────────┐                 │
│  │ TRUST_ACCOUNTS  │                    │      TASKS      │                 │
│  │                 │                    │                 │                 │
│  │ • id (PK)       │                    │ • id (PK)       │                 │
│  │ • tenant_id (FK)│                    │ • tenant_id (FK)│                 │
│  │ • client_id (FK)│                    │ • case_id (FK)  │                 │
│  │ • balance       │                    │ • client_id (FK)│                 │
│  │ • deleted_at    │                    │ • deleted_at    │                 │
│  └────────┬────────┘                    └─────────────────┘                 │
│           │                                                                 │
│           │ 1                                                               │
│           ▼ N (APPEND-ONLY)                                                 │
│  ┌─────────────────┐                    ┌─────────────────┐                 │
│  │TRUST_TRANSACTIONS│                   │    DOCUMENTS    │                 │
│  │ (IMMUTABLE)     │                    │                 │                 │
│  │                 │                    │ • id (PK)       │                 │
│  │ • id (PK)       │                    │ • tenant_id (FK)│                 │
│  │ • tenant_id     │                    │ • case_id (FK)  │                 │
│  │ • amount        │                    │ • client_id (FK)│                 │
│  │ • balance_after │                    │ • version       │                 │
│  │ • NO deleted_at │                    │ • parent_id (FK)│                 │
│  └─────────────────┘                    │ • deleted_at    │                 │
│                                         └─────────────────┘                 │
│                                                                             │
│  ┌─────────────────┐      ┌─────────────────┐     ┌─────────────────┐      │
│  │   TIME_ENTRIES  │      │    INVOICES     │     │  INVOICE_LINES  │      │
│  │                 │      │                 │     │                 │      │
│  │ • id (PK)       │      │ • id (PK)       │◄────│ • invoice_id(FK)│      │
│  │ • tenant_id (FK)│      │ • tenant_id (FK)│  1 N│ • tenant_id (FK)│      │
│  │ • case_id (FK)  │      │ • client_id (FK)│     │                 │      │
│  │ • invoice_id(FK)│─────►│ • invoice_number│     └─────────────────┘      │
│  │ • deleted_at    │  N  1│ • status        │                              │
│  └─────────────────┘      │ • issued_at     │     ┌─────────────────┐      │
│                           │ • deleted_at    │     │    PAYMENTS     │      │
│                           └────────┬────────┘     │                 │      │
│                                    │              │ • invoice_id(FK)│      │
│                                    │ 1            │ • deleted_at    │      │
│                                    ▼ N            └─────────────────┘      │
│                           ┌─────────────────┐                              │
│                           │CALENDAR_EVENTS  │                              │
│                           │                 │                              │
│                           │ • case_id (FK)  │                              │
│                           │ • deleted_at    │                              │
│                           └─────────────────┘                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                            CUSTOM FIELDS SYSTEM                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌───────────────────────────┐          ┌───────────────────────────┐      │
│  │ CUSTOM_FIELD_DEFINITIONS  │◄─────────│   CUSTOM_FIELD_VALUES     │      │
│  │                           │  1     N │                           │      │
│  │ • id (PK)                 │          │ • definition_id (FK)      │      │
│  │ • tenant_id (FK)          │          │ • tenant_id (FK)          │      │
│  │ • entity_type             │          │ • entity_type             │      │
│  │ • field_key               │          │ • entity_id               │      │
│  │ • field_type              │          │ • value_text              │      │
│  │ • options_json            │          │ • value_number            │      │
│  │ • deleted_at              │          │ • value_date              │      │
│  └───────────────────────────┘          │ • value_bool              │      │
│                                         │ • value_json              │      │
│  entity_type: client | case |           └───────────────────────────┘      │
│               task | document |                                            │
│               invoice                                                      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                              AUDIT SYSTEM                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌───────────────────────────┐          ┌───────────────────────────┐      │
│  │     audit.LOGS            │          │       SETTINGS            │      │
│  │     (IMMUTABLE)           │          │                           │      │
│  │                           │          │ • tenant_id (FK)          │      │
│  │ • id (PK)                 │          │ • user_id (FK) [nullable] │      │
│  │ • tenant_id (NO FK)       │          │ • category                │      │
│  │ • user_id                 │          │ • key                     │      │
│  │ • action                  │          │ • value_json              │      │
│  │ • entity_type             │          └───────────────────────────┘      │
│  │ • changes_json            │                                             │
│  │ • entry_hash (SHA-256)    │                                             │
│  │ • previous_hash           │                                             │
│  │ • retention_date          │                                             │
│  │ • NO updated_at           │                                             │
│  │ • NO deleted_at           │                                             │
│  └───────────────────────────┘                                             │
│                                                                             │
│  Note: audit.logs has NO foreign keys to allow tenant deletion             │
│        while preserving audit history for compliance                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Complete Index List

### Tenants
| Index Name | Columns | Condition | Purpose |
|------------|---------|-----------|---------|
| `idx_tenants_slug` | `slug` | `deleted_at IS NULL` | Fast tenant lookup by slug |
| `idx_tenants_domain` | `domain` | `domain IS NOT NULL AND deleted_at IS NULL` | Custom domain routing |
| `idx_tenants_deleted_at` | `deleted_at` | - | Soft delete queries |

### Users
| Index Name | Columns | Condition | Purpose |
|------------|---------|-----------|---------|
| `idx_users_tenant` | `tenant_id` | `deleted_at IS NULL` | Tenant-scoped queries |
| `idx_users_email` | `email` | `deleted_at IS NULL` | Login lookup |
| `idx_users_role` | `role_id` | - | Role-based queries |
| `idx_users_deleted_at` | `deleted_at` | - | Soft delete queries |

### Clients
| Index Name | Columns | Condition | Purpose |
|------------|---------|-----------|---------|
| `idx_clients_tenant` | `tenant_id` | `deleted_at IS NULL` | Tenant-scoped list |
| `idx_clients_status` | `tenant_id, status` | `deleted_at IS NULL` | Filter by status |
| `idx_clients_assigned` | `assigned_to` | `deleted_at IS NULL` | My clients |
| `idx_clients_name_trgm` | `name` (GIN trigram) | - | Fuzzy Hebrew search |
| `idx_clients_deleted_at` | `deleted_at` | - | Soft delete queries |

### Cases
| Index Name | Columns | Condition | Purpose |
|------------|---------|-----------|---------|
| `idx_cases_tenant` | `tenant_id` | `deleted_at IS NULL` | Tenant-scoped list |
| `idx_cases_client` | `client_id` | `deleted_at IS NULL` | Cases by client |
| `idx_cases_status` | `tenant_id, status` | `deleted_at IS NULL` | Filter by status |
| `idx_cases_type` | `tenant_id, case_type` | `deleted_at IS NULL` | Filter by type |
| `idx_cases_assigned` | `assigned_to` | `deleted_at IS NULL` | My cases |
| `idx_cases_due_date` | `due_date` | `NOT IN (closed, archived)` | Upcoming deadlines |
| `idx_cases_title_trgm` | `title` (GIN trigram) | - | Fuzzy Hebrew search |
| `idx_cases_tags` | `tags` (GIN) | - | Tag filtering |
| `idx_cases_deleted_at` | `deleted_at` | - | Soft delete queries |

### Tasks
| Index Name | Columns | Condition | Purpose |
|------------|---------|-----------|---------|
| `idx_tasks_tenant` | `tenant_id` | `deleted_at IS NULL` | Tenant-scoped list |
| `idx_tasks_case` | `case_id` | `deleted_at IS NULL` | Tasks by case |
| `idx_tasks_client` | `client_id` | `deleted_at IS NULL` | Tasks by client |
| `idx_tasks_assigned` | `assigned_to` | `deleted_at IS NULL` | My tasks |
| `idx_tasks_status` | `tenant_id, status` | `deleted_at IS NULL` | Filter by status |
| `idx_tasks_due` | `due_date` | `NOT IN (done, cancelled)` | Upcoming tasks |
| `idx_tasks_deleted_at` | `deleted_at` | - | Soft delete queries |

### Documents
| Index Name | Columns | Condition | Purpose |
|------------|---------|-----------|---------|
| `idx_documents_tenant` | `tenant_id` | `deleted_at IS NULL` | Tenant-scoped list |
| `idx_documents_case` | `case_id` | `deleted_at IS NULL` | Documents by case |
| `idx_documents_client` | `client_id` | `deleted_at IS NULL` | Documents by client |
| `idx_documents_category` | `tenant_id, category` | `deleted_at IS NULL` | Filter by category |
| `idx_documents_latest` | `parent_id` | `is_latest = TRUE` | Latest versions only |
| `idx_documents_title_trgm` | `title` (GIN trigram) | - | Fuzzy Hebrew search |
| `idx_documents_ocr_trgm` | `ocr_text` (GIN trigram) | `ocr_text IS NOT NULL` | Full-text search |
| `idx_documents_tags` | `tags` (GIN) | - | Tag filtering |
| `idx_documents_deleted_at` | `deleted_at` | - | Soft delete queries |

### Calendar Events
| Index Name | Columns | Condition | Purpose |
|------------|---------|-----------|---------|
| `idx_events_tenant` | `tenant_id` | `deleted_at IS NULL` | Tenant-scoped list |
| `idx_events_case` | `case_id` | `deleted_at IS NULL` | Events by case |
| `idx_events_client` | `client_id` | `deleted_at IS NULL` | Events by client |
| `idx_events_dates` | `tenant_id, start_at, end_at` | `deleted_at IS NULL` | Date range queries |
| `idx_events_type` | `tenant_id, event_type` | `deleted_at IS NULL` | Filter by type |
| `idx_events_deleted_at` | `deleted_at` | - | Soft delete queries |

### Time Entries
| Index Name | Columns | Condition | Purpose |
|------------|---------|-----------|---------|
| `idx_time_tenant` | `tenant_id` | `deleted_at IS NULL` | Tenant-scoped list |
| `idx_time_case` | `case_id` | `deleted_at IS NULL` | Time by case |
| `idx_time_client` | `client_id` | `deleted_at IS NULL` | Time by client |
| `idx_time_user` | `user_id` | `deleted_at IS NULL` | My time entries |
| `idx_time_date` | `work_date` | `deleted_at IS NULL` | Date range queries |
| `idx_time_unbilled` | `tenant_id, client_id` | `billed=FALSE AND billable=TRUE` | Unbilled time lookup |
| `idx_time_invoice` | `invoice_id` | `invoice_id IS NOT NULL` | Invoice line items |
| `idx_time_deleted_at` | `deleted_at` | - | Soft delete queries |

### Invoices
| Index Name | Columns | Condition | Purpose |
|------------|---------|-----------|---------|
| `idx_invoices_tenant` | `tenant_id` | `deleted_at IS NULL` | Tenant-scoped list |
| `idx_invoices_client` | `client_id` | `deleted_at IS NULL` | Invoices by client |
| `idx_invoices_case` | `case_id` | `deleted_at IS NULL` | Invoices by case |
| `idx_invoices_status` | `tenant_id, status` | `deleted_at IS NULL` | Filter by status |
| `idx_invoices_due` | `due_date` | `status NOT IN (paid, void)` | Overdue tracking |
| `idx_invoices_number` | `invoice_number` | - | Invoice number lookup |
| `idx_invoices_deleted_at` | `deleted_at` | - | Soft delete queries |

### Trust Transactions (NO deleted_at - immutable)
| Index Name | Columns | Condition | Purpose |
|------------|---------|-----------|---------|
| `idx_trust_tx_tenant` | `tenant_id` | - | Tenant-scoped queries |
| `idx_trust_tx_account` | `trust_account_id` | - | Account history |
| `idx_trust_tx_client` | `client_id` | - | Client trust history |
| `idx_trust_tx_case` | `case_id` | `case_id IS NOT NULL` | Case-related transactions |
| `idx_trust_tx_date` | `created_at` | - | Date range queries |
| `idx_trust_tx_invoice` | `invoice_id` | `invoice_id IS NOT NULL` | Invoice reconciliation |

### Audit Logs (NO deleted_at - immutable)
| Index Name | Columns | Condition | Purpose |
|------------|---------|-----------|---------|
| `idx_audit_logs_tenant` | `tenant_id` | - | Tenant audit trail |
| `idx_audit_logs_user` | `user_id` | `user_id IS NOT NULL` | User activity |
| `idx_audit_logs_action` | `action` | - | Filter by action type |
| `idx_audit_logs_entity` | `entity_type, entity_id` | `entity_id IS NOT NULL` | Entity history |
| `idx_audit_logs_created` | `created_at` | - | Date range queries |
| `idx_audit_logs_retention` | `retention_date` | - | Retention cleanup |
| `idx_audit_logs_hash` | `entry_hash` | - | Integrity verification |

### Custom Fields
| Index Name | Columns | Condition | Purpose |
|------------|---------|-----------|---------|
| `idx_custom_field_defs_tenant` | `tenant_id` | `deleted_at IS NULL` | Tenant definitions |
| `idx_custom_field_defs_entity` | `tenant_id, entity_type` | `deleted_at IS NULL` | Entity-specific fields |
| `idx_custom_field_values_tenant` | `tenant_id` | - | Tenant values |
| `idx_custom_field_values_definition` | `definition_id` | - | Definition lookup |
| `idx_custom_field_values_entity` | `entity_type, entity_id` | - | Entity values |
| `idx_custom_field_values_lookup` | `tenant_id, entity_type, entity_id` | - | Fast lookup |

---

## Complete Constraints List

### Primary Keys
- All tables have UUID primary keys using `uuid_generate_v4()`

### Foreign Keys
| Table | Column | References | On Delete |
|-------|--------|------------|-----------|
| `users` | `tenant_id` | `tenants(id)` | CASCADE |
| `users` | `role_id` | `roles(id)` | RESTRICT |
| `clients` | `tenant_id` | `tenants(id)` | CASCADE |
| `clients` | `assigned_to` | `users(id)` | SET NULL |
| `cases` | `tenant_id` | `tenants(id)` | CASCADE |
| `cases` | `client_id` | `clients(id)` | RESTRICT |
| `tasks` | `tenant_id` | `tenants(id)` | CASCADE |
| `tasks` | `case_id` | `cases(id)` | SET NULL |
| `documents` | `tenant_id` | `tenants(id)` | CASCADE |
| `documents` | `parent_id` | `documents(id)` | SET NULL |
| `invoices` | `tenant_id` | `tenants(id)` | CASCADE |
| `invoices` | `client_id` | `clients(id)` | RESTRICT |
| `invoice_lines` | `invoice_id` | `invoices(id)` | CASCADE |
| `trust_accounts` | `tenant_id` | `tenants(id)` | CASCADE |
| `trust_accounts` | `client_id` | `clients(id)` | RESTRICT |
| `trust_transactions` | `tenant_id` | `tenants(id)` | RESTRICT |
| `trust_transactions` | `trust_account_id` | `trust_accounts(id)` | RESTRICT |
| `custom_field_definitions` | `tenant_id` | `tenants(id)` | CASCADE |
| `custom_field_values` | `definition_id` | `custom_field_definitions(id)` | CASCADE |
| `audit.logs` | - | NO FKs | - (immutable) |

### Unique Constraints
| Table | Constraint Name | Columns | Notes |
|-------|-----------------|---------|-------|
| `tenants` | `tenants_slug_key` | `slug` | Global unique slug |
| `roles` | `roles_name_key` | `name` | Global unique role name |
| `permissions` | `permissions_code_key` | `code` | Global unique permission code |
| `users` | `uq_users_tenant_email` | `(tenant_id, email)` | Unique email per tenant |
| `clients` | `uq_clients_tenant_israeli_id` | `(tenant_id, israeli_id)` | Unique ת.ז. per tenant |
| `clients` | `uq_clients_tenant_company_number` | `(tenant_id, company_number)` | Unique ח.פ. per tenant |
| `cases` | `uq_cases_tenant_case_number` | `(tenant_id, case_number)` | Unique case# per tenant |
| `invoices` | `uq_invoices_tenant_number` | `(tenant_id, invoice_number)` | Unique invoice# per tenant |
| `trust_accounts` | `uq_trust_tenant_client` | `(tenant_id, client_id)` | One trust account per client |
| `custom_field_definitions` | `uq_custom_field_def` | `(tenant_id, entity_type, field_key)` | Unique field per entity type |
| `custom_field_values` | `uq_custom_field_value` | `(tenant_id, definition_id, entity_type, entity_id)` | One value per field per entity |
| `settings` | `uq_settings` | `(tenant_id, user_id, category, key)` | Unique setting key |

### Check Constraints
| Table | Constraint Name | Condition |
|-------|-----------------|-----------|
| `time_entries` | `time_entries_duration_minutes_check` | `duration_minutes > 0` |
| `payments` | `payments_amount_check` | `amount > 0` |
| `invoices` | `chk_invoice_type` | `invoice_type IN (...)` |
| `invoices` | `chk_invoice_status` | `status IN (...)` |
| `trust_transactions` | `chk_trust_tx_type` | `transaction_type IN (...)` |
| `custom_field_definitions` | `chk_field_type` | `field_type IN (...)` |
| `custom_field_definitions` | `chk_entity_type` | `entity_type IN (...)` |
| `custom_field_values` | `chk_cf_entity_type` | `entity_type IN (...)` |

---

## Triggers

| Trigger | Table | Event | Purpose |
|---------|-------|-------|---------|
| `trg_*_updated_at` | All with `updated_at` | BEFORE UPDATE | Auto-update timestamp |
| `trg_trust_tx_no_update` | `trust_transactions` | BEFORE UPDATE | Prevent updates (immutable) |
| `trg_trust_tx_no_delete` | `trust_transactions` | BEFORE DELETE | Prevent deletes (immutable) |
| `trg_audit_no_update` | `audit.logs` | BEFORE UPDATE | Prevent updates (immutable) |
| `trg_audit_no_delete` | `audit.logs` | BEFORE DELETE | Prevent deletes (immutable) |
| `trg_trust_tx_balance_before` | `trust_transactions` | BEFORE INSERT | Calculate `balance_after` |
| `trg_trust_tx_update_balance` | `trust_transactions` | AFTER INSERT | Update account balance |
| `trg_cases_validate_tenant` | `cases` | BEFORE INSERT/UPDATE | Ensure client same tenant |
| `trg_invoice_immutability` | `invoices` | BEFORE UPDATE | Prevent changes after issue |

---

## Soft Delete Implementation

### Pattern
All business tables (except immutable tables) have:
```sql
deleted_at TIMESTAMPTZ  -- NULL means active, timestamp means deleted
```

### Query Pattern
**Application code MUST always add:**
```sql
WHERE deleted_at IS NULL
```

**Or use the provided views:**
```sql
-- Instead of: SELECT * FROM clients WHERE tenant_id = $1 AND deleted_at IS NULL
-- Use: SELECT * FROM active_clients WHERE tenant_id = $1
```

### Views Provided
- `active_tenants`
- `active_users`
- `active_clients`
- `active_cases`
- `active_tasks`
- `active_documents`
- `active_events`
- `active_time_entries`
- `active_invoices`
- `active_payments`
- `active_trust_accounts`

### Restoration
To restore a soft-deleted record:
```sql
UPDATE clients SET deleted_at = NULL WHERE id = $1;
```

### Permanent Deletion (Compliance)
After retention period, records may be hard-deleted:
```sql
DELETE FROM clients WHERE deleted_at < NOW() - INTERVAL '7 years';
```

---

## Trust Ledger Design

### Principles
1. **APPEND-ONLY**: No UPDATE or DELETE operations allowed (enforced by triggers)
2. **Complete Trail**: Every transaction includes running balance
3. **Referential Integrity**: Links to invoices, payments, cases for audit
4. **Cross-Tenant Protection**: Trigger validates tenant consistency

### Transaction Types
| Type | Amount Sign | Description |
|------|-------------|-------------|
| `deposit` | Positive | Client deposits funds |
| `withdrawal` | Negative | Funds withdrawn from trust |
| `transfer_in` | Positive | Transfer from another trust account |
| `transfer_out` | Negative | Transfer to another trust account |
| `fee_deduction` | Negative | Attorney fees deducted |
| `refund` | Negative | Refund to client |

### Example: Recording a Deposit
```sql
INSERT INTO trust_transactions (
    tenant_id, trust_account_id, client_id, case_id,
    transaction_type, amount, currency,
    description, reference_number, created_by
) VALUES (
    $1, $2, $3, $4,
    'deposit', 50000.00, 'ILS',
    'Initial retainer deposit', 'CHK-12345', $5
);
-- balance_after is calculated automatically by trigger
-- trust_accounts.balance is updated automatically by trigger
```

### Balance Reconciliation Query
```sql
SELECT 
    ta.id,
    ta.account_name,
    ta.balance AS current_balance,
    (SELECT balance_after FROM trust_transactions 
     WHERE trust_account_id = ta.id 
     ORDER BY created_at DESC LIMIT 1) AS last_tx_balance
FROM trust_accounts ta
WHERE ta.tenant_id = $1 AND ta.deleted_at IS NULL;
```

---

## Custom Fields Design

### Definition Storage
```sql
-- Define a custom field for cases
INSERT INTO custom_field_definitions (
    tenant_id, entity_type, field_key, label, label_he,
    field_type, is_required, display_order
) VALUES (
    $1, 'case', 'court_district', 'Court District', 'מחוז בית משפט',
    'select', FALSE, 1
);

-- Add options for select field
UPDATE custom_field_definitions 
SET options_json = '[
    {"value": "tel_aviv", "label": "Tel Aviv", "label_he": "תל אביב"},
    {"value": "jerusalem", "label": "Jerusalem", "label_he": "ירושלים"},
    {"value": "haifa", "label": "Haifa", "label_he": "חיפה"}
]'
WHERE id = $2;
```

### Value Storage
Each field type stores in its appropriate column:
| Field Type | Storage Column |
|------------|----------------|
| `text`, `textarea`, `url`, `email`, `phone` | `value_text` |
| `number`, `decimal` | `value_number` |
| `date` | `value_date` |
| `datetime` | `value_datetime` |
| `boolean` | `value_bool` |
| `select`, `multi_select` | `value_json` |

### Query Custom Fields for Entity
```sql
SELECT 
    cfd.field_key,
    cfd.label,
    cfd.label_he,
    cfd.field_type,
    cfv.value_text,
    cfv.value_number,
    cfv.value_date,
    cfv.value_bool,
    cfv.value_json
FROM custom_field_definitions cfd
LEFT JOIN custom_field_values cfv ON 
    cfv.definition_id = cfd.id AND 
    cfv.entity_type = 'case' AND 
    cfv.entity_id = $1
WHERE cfd.tenant_id = $2 
  AND cfd.entity_type = 'case'
  AND cfd.deleted_at IS NULL
ORDER BY cfd.display_order;
```

---

## Design Decisions & Rationale

### 1. UUID Primary Keys
**Why**: 
- Globally unique across distributed systems
- No sequential guessing for security
- Safe for multi-tenant merge/migration scenarios
- Client-side ID generation possible

### 2. Multi-Tenant with `tenant_id`
**Why**:
- All business data isolated per tenant
- Single database deployment (cost-effective)
- Shared infrastructure, separate data
- Easy tenant-specific backups via `WHERE tenant_id = X`

### 3. Soft Delete with `deleted_at`
**Why**:
- Legal compliance: Data retention requirements
- Accidental deletion recovery
- Referential integrity preserved
- Audit trail maintained
- Hard delete only after retention period

### 4. Immutable Trust Transactions
**Why**:
- Israeli Bar Association requirements
- Complete audit trail for client funds
- Prevents fraud/tampering
- Balance reconciliation always possible
- 7-year retention compliance

### 5. Immutable Audit Logs in Separate Schema
**Why**:
- Cannot be modified even by admins
- Hash chain for tamper detection
- Separate schema for access control
- No FK to tenant (survives tenant deletion)
- Retention date for automated cleanup

### 6. Typed Custom Field Values
**Why**:
- Proper indexing per type
- Type-safe queries and sorting
- Validation at database level
- Efficient storage (not all JSON)

### 7. Invoice Immutability After Issuance
**Why**:
- Israeli tax compliance
- Prevents post-issuance fraud
- Credit notes required for corrections
- Legal document integrity

### 8. Trigram Indexes for Hebrew Search
**Why**:
- Hebrew text doesn't tokenize well with standard full-text
- `pg_trgm` provides fuzzy matching
- Works for partial name searches
- Handles Hebrew diacritics

### 9. Tenant-Scoped Unique Constraints
**Why**:
- Same email can exist in different tenants
- Invoice numbers unique per firm only
- Israeli ID unique per tenant (same person can be client of multiple firms)

### 10. Denormalized Trust Balance
**Why**:
- Performance: No aggregate query needed
- Trigger maintains consistency
- `balance_after` in transactions enables verification
- Trade-off: Slight redundancy for major speed gain

---

## Files Delivered

| File | Description |
|------|-------------|
| `apps/api/src/db/migrations/001_initial_schema.sql` | Complete UP migration |
| `apps/api/src/db/migrations/001_initial_schema_down.sql` | Complete DOWN migration |
| `apps/api/src/db/seeds/001_roles_permissions.sql` | Roles & permissions seed data |

---

## Migration Execution

```bash
# Start PostgreSQL
pnpm docker:up

# Wait for healthy status
docker-compose -f infra/docker/docker-compose.yml ps

# Run migrations
psql $DATABASE_URL -f apps/api/src/db/migrations/001_initial_schema.sql

# Run seeds
psql $DATABASE_URL -f apps/api/src/db/seeds/001_roles_permissions.sql

# Verify
psql $DATABASE_URL -c "\dt"
psql $DATABASE_URL -c "\dt audit.*"
```

---

**CHECKPOINT READY**
