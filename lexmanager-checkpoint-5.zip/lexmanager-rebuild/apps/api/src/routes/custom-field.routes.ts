// ============================================================================
// CUSTOM FIELDS ROUTES
// apps/api/src/routes/custom-field.routes.ts
// 
// Custom field definitions and values with RBAC and audit
// ============================================================================

import { Router } from 'express';
import { customFieldsService } from '../services/custom-fields.service.js';
import {
  initializeContext,
  resolveTenantFromHeader,
  requireTenant,
  authParser,
  requireAuth,
  requireTenantAccess,
  requirePermission,
} from '../middleware/index.js';
import {
  validate,
  validateAll,
  createCustomFieldDefinitionSchema,
  updateCustomFieldDefinitionSchema,
  setCustomFieldValueSchema,
  idParamSchema,
  z,
} from '../validation/index.js';
import { asyncHandler, sendSuccess } from '../errors/index.js';
import { PERMISSIONS } from '../services/rbac.service.js';

const router = Router();

// All routes require tenant context and authentication
router.use(initializeContext());
router.use(resolveTenantFromHeader());
router.use(requireTenant());
router.use(authParser());
router.use(requireAuth());
router.use(requireTenantAccess());

// Entity type param schema
const entityTypeParamSchema = z.object({
  entityType: z.enum(['client', 'case', 'task', 'document', 'invoice']),
});

const entityParamSchema = z.object({
  entityType: z.enum(['client', 'case', 'task', 'document', 'invoice']),
  entityId: z.string().uuid(),
});

// ============================================================================
// DEFINITIONS
// ============================================================================

// ============================================================================
// GET /custom-fields/definitions - List all definitions
// ============================================================================

router.get(
  '/definitions',
  requirePermission(PERMISSIONS.SETTINGS_VIEW),
  asyncHandler(async (req, res) => {
    const { entityType } = req.query as any;

    const definitions = await customFieldsService.listDefinitions(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      { entityType }
    );

    sendSuccess(res, req, definitions);
  })
);

// ============================================================================
// POST /custom-fields/definitions - Create definition
// ============================================================================

router.post(
  '/definitions',
  requirePermission(PERMISSIONS.SETTINGS_EDIT),
  validate(createCustomFieldDefinitionSchema, 'body'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const definition = await customFieldsService.createDefinition(
      context,
      req.auth!.tenantId,
      {
        entity_type: req.body.entityType,
        field_key: req.body.fieldKey,
        field_name: req.body.fieldName,
        field_name_he: req.body.fieldNameHe,
        field_type: req.body.fieldType,
        description: req.body.description,
        is_required: req.body.isRequired || false,
        default_value: req.body.defaultValue,
        options: req.body.options,
        validation: req.body.validation,
        display_order: req.body.displayOrder || 0,
      }
    );

    sendSuccess(res, req, definition, 201);
  })
);

// ============================================================================
// GET /custom-fields/definitions/:id - Get definition by ID
// ============================================================================

router.get(
  '/definitions/:id',
  requirePermission(PERMISSIONS.SETTINGS_VIEW),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const definition = await customFieldsService.getDefinitionById(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, definition);
  })
);

// ============================================================================
// PATCH /custom-fields/definitions/:id - Update definition
// ============================================================================

router.patch(
  '/definitions/:id',
  requirePermission(PERMISSIONS.SETTINGS_EDIT),
  validateAll({
    params: idParamSchema,
    body: updateCustomFieldDefinitionSchema,
  }),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const definition = await customFieldsService.updateDefinition(
      context,
      req.auth!.tenantId,
      req.params.id,
      {
        field_name: req.body.fieldName,
        field_name_he: req.body.fieldNameHe,
        description: req.body.description,
        is_required: req.body.isRequired,
        default_value: req.body.defaultValue,
        options: req.body.options,
        display_order: req.body.displayOrder,
      }
    );

    sendSuccess(res, req, definition);
  })
);

// ============================================================================
// DELETE /custom-fields/definitions/:id - Delete definition
// ============================================================================

router.delete(
  '/definitions/:id',
  requirePermission(PERMISSIONS.SETTINGS_EDIT),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    await customFieldsService.deleteDefinition(
      context,
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, { message: 'Definition deleted successfully' });
  })
);

// ============================================================================
// POST /custom-fields/definitions/:id/restore - Restore definition
// ============================================================================

router.post(
  '/definitions/:id/restore',
  requirePermission(PERMISSIONS.SETTINGS_EDIT),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    await customFieldsService.restoreDefinition(
      context,
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, { message: 'Definition restored successfully' });
  })
);

// ============================================================================
// VALUES
// ============================================================================

// ============================================================================
// GET /custom-fields/:entityType/:entityId - Get values for entity
// ============================================================================

router.get(
  '/:entityType/:entityId',
  requirePermission(PERMISSIONS.CLIENTS_VIEW), // Base permission, will be checked per entity
  validate(entityParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const values = await customFieldsService.getEntityValues(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      req.params.entityType as any,
      req.params.entityId
    );

    sendSuccess(res, req, values);
  })
);

// ============================================================================
// PUT /custom-fields/:entityType/:entityId - Set values for entity
// ============================================================================

router.put(
  '/:entityType/:entityId',
  requirePermission(PERMISSIONS.CLIENTS_EDIT), // Base permission
  validate(entityParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    // req.body is a key-value map of field keys to values
    await customFieldsService.setEntityValues(
      context,
      req.auth!.tenantId,
      req.params.entityType as any,
      req.params.entityId,
      req.body
    );

    // Return updated values
    const values = await customFieldsService.getEntityValues(
      context,
      req.auth!.tenantId,
      req.params.entityType as any,
      req.params.entityId
    );

    sendSuccess(res, req, values);
  })
);

export default router;
