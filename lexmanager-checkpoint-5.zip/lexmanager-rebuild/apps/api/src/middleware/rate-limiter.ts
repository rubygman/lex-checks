// ============================================================================
// RATE LIMITER MIDDLEWARE
// apps/api/src/middleware/rate-limiter.ts
// 
// Rate limiting for auth endpoints and API protection.
// Uses in-memory store for development, designed for Redis swap in production.
// ============================================================================

import type { Request, Response, NextFunction, RequestHandler } from 'express';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Rate limit entry stored in the backend
 */
interface RateLimitEntry {
  count: number;
  resetAt: number;  // Unix timestamp in ms
}

/**
 * Options for creating a rate limiter
 */
interface RateLimitOptions {
  /** Time window in milliseconds */
  windowMs: number;
  /** Maximum requests allowed in window */
  maxRequests: number;
  /** Function to generate the rate limit key */
  keyGenerator: (req: Request) => string;
  /** Custom message for rate limit errors */
  message?: string;
  /** Whether to skip counting successful requests */
  skipSuccessful?: boolean;
}

/**
 * Interface for rate limit storage backends
 * Implement this interface for Redis, Memcached, etc.
 */
export interface RateLimitStore {
  /** Get current entry for key */
  get(key: string): RateLimitEntry | undefined | Promise<RateLimitEntry | undefined>;
  /** Increment and return updated entry */
  increment(key: string, windowMs: number): RateLimitEntry | Promise<RateLimitEntry>;
  /** Decrement count for key */
  decrement(key: string): void | Promise<void>;
  /** Clean up expired entries */
  cleanup(): void | Promise<void>;
  /** Destroy the store (cleanup intervals, connections) */
  destroy(): void | Promise<void>;
}

// ============================================================================
// IN-MEMORY STORE (Development)
// Replace with Redis store in production for distributed rate limiting
// ============================================================================

/**
 * In-memory rate limit store
 * Suitable for single-instance development/testing
 * 
 * For production, implement RateLimitStore with Redis:
 * - Use INCR with EXPIRE for atomic increment
 * - Use TTL for resetAt calculation
 */
class InMemoryRateLimitStore implements RateLimitStore {
  private store = new Map<string, RateLimitEntry>();
  private cleanupInterval: NodeJS.Timeout | null = null;

  constructor() {
    // Clean up expired entries every minute
    this.cleanupInterval = setInterval(() => this.cleanup(), 60_000);
    // Prevent interval from keeping process alive
    if (this.cleanupInterval.unref) {
      this.cleanupInterval.unref();
    }
  }

  get(key: string): RateLimitEntry | undefined {
    const entry = this.store.get(key);
    if (entry && Date.now() > entry.resetAt) {
      this.store.delete(key);
      return undefined;
    }
    return entry;
  }

  increment(key: string, windowMs: number): RateLimitEntry {
    const existing = this.get(key);
    
    if (existing) {
      existing.count++;
      return existing;
    }

    const entry: RateLimitEntry = {
      count: 1,
      resetAt: Date.now() + windowMs,
    };
    this.store.set(key, entry);
    return entry;
  }

  decrement(key: string): void {
    const entry = this.store.get(key);
    if (entry && entry.count > 0) {
      entry.count--;
    }
  }

  cleanup(): void {
    const now = Date.now();
    for (const [key, entry] of this.store.entries()) {
      if (now > entry.resetAt) {
        this.store.delete(key);
      }
    }
  }

  destroy(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
    this.store.clear();
  }

  /** For testing: get current store size */
  get size(): number {
    return this.store.size;
  }

  /** For testing: clear all entries */
  clear(): void {
    this.store.clear();
  }
}

// Shared store instance (singleton for the process)
const defaultStore = new InMemoryRateLimitStore();

// Export for testing
export { InMemoryRateLimitStore };
export const getDefaultStore = (): InMemoryRateLimitStore => defaultStore;

// ============================================================================
// HELPERS
// ============================================================================

/**
 * Extract client IP address from request
 * Handles proxied requests via X-Forwarded-For
 */
function getClientIp(req: Request): string {
  // Check X-Forwarded-For header (set by proxies/load balancers)
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) {
    const ips = Array.isArray(forwarded) ? forwarded[0] : forwarded.split(',')[0];
    return ips?.trim() || 'unknown';
  }

  // Check X-Real-IP header
  const realIp = req.headers['x-real-ip'];
  if (realIp && typeof realIp === 'string') {
    return realIp.trim();
  }

  // Fall back to direct connection
  return req.ip || req.socket?.remoteAddress || 'unknown';
}

/**
 * Get tenant ID from request context (if available)
 * Returns empty string if tenant not resolved yet
 */
function getTenantId(req: Request): string {
  return req.context?.tenant?.tenantId || '';
}

// ============================================================================
// RATE LIMITER FACTORY
// ============================================================================

/**
 * Create a rate limiter middleware
 * 
 * @param options Rate limiting configuration
 * @param store Optional custom store (defaults to in-memory)
 * @returns Express middleware
 */
export function createRateLimiter(
  options: RateLimitOptions,
  store: RateLimitStore = defaultStore
): RequestHandler {
  const {
    windowMs,
    maxRequests,
    keyGenerator,
    message = 'Too many requests',
    skipSuccessful = false,
  } = options;

  return (req: Request, res: Response, next: NextFunction): void => {
    // Generate the rate limit key
    const key = keyGenerator(req);
    
    // Increment counter
    const entryResult = store.increment(key, windowMs);
    
    // Handle both sync and async stores
    const handleEntry = (entry: RateLimitEntry): void => {
      // Set standard rate limit headers
      res.setHeader('X-RateLimit-Limit', maxRequests);
      res.setHeader('X-RateLimit-Remaining', Math.max(0, maxRequests - entry.count));
      res.setHeader('X-RateLimit-Reset', Math.ceil(entry.resetAt / 1000));

      // Check if rate limited
      if (entry.count > maxRequests) {
        const retryAfterSeconds = Math.ceil((entry.resetAt - Date.now()) / 1000);
        res.setHeader('Retry-After', retryAfterSeconds);

        // Return exact error shape as specified
        res.status(429).json({
          error: 'RATE_LIMITED',
          message,
          retryAfterSeconds,
          correlationId: req.context?.correlationId || 'unknown',
        });
        return;
      }

      // If skipSuccessful, decrement on successful response
      if (skipSuccessful) {
        const originalEnd = res.end.bind(res);
        res.end = function(this: Response, ...args: Parameters<typeof res.end>) {
          if (res.statusCode < 400) {
            store.decrement(key);
          }
          return originalEnd.apply(this, args);
        } as typeof res.end;
      }

      next();
    };

    // Support both sync and async stores
    if (entryResult instanceof Promise) {
      entryResult.then(handleEntry).catch(next);
    } else {
      handleEntry(entryResult);
    }
  };
}

// ============================================================================
// PRE-CONFIGURED RATE LIMITERS
// ============================================================================

/**
 * Global rate limiter
 * 100 requests per minute per IP
 */
export function globalRateLimiter(): RequestHandler {
  return createRateLimiter({
    windowMs: 60_000,  // 1 minute
    maxRequests: 100,
    keyGenerator: (req) => `global:${getClientIp(req)}`,
    message: 'Too many requests',
  });
}

/**
 * Login rate limiter
 * 10 requests per 15 minutes per IP + tenant
 * 
 * Security: Prevents brute force attacks on login
 * Key: tenant:IP to scope limits per tenant
 */
export function loginRateLimiter(): RequestHandler {
  return createRateLimiter({
    windowMs: 15 * 60_000,  // 15 minutes
    maxRequests: 10,
    keyGenerator: (req) => {
      const ip = getClientIp(req);
      const tenantId = getTenantId(req);
      // Include tenant if available, otherwise just IP
      return tenantId ? `login:${tenantId}:${ip}` : `login:${ip}`;
    },
    message: 'Too many login attempts, please try again later',
    skipSuccessful: true,  // Only count failed attempts
  });
}

/**
 * Registration rate limiter
 * 5 requests per hour per IP + tenant
 * 
 * Security: Prevents mass account creation
 * Key: tenant:IP to scope limits per tenant
 */
export function registrationRateLimiter(): RequestHandler {
  return createRateLimiter({
    windowMs: 60 * 60_000,  // 1 hour
    maxRequests: 5,
    keyGenerator: (req) => {
      const ip = getClientIp(req);
      const tenantId = getTenantId(req);
      // Include tenant if available, otherwise just IP
      return tenantId ? `register:${tenantId}:${ip}` : `register:${ip}`;
    },
    message: 'Too many registration attempts, please try again later',
  });
}

/**
 * Password reset rate limiter
 * 5 requests per hour per IP + tenant
 * 
 * Security: Prevents email enumeration and spam
 * Key: tenant:IP to scope limits per tenant
 */
export function passwordResetRateLimiter(): RequestHandler {
  return createRateLimiter({
    windowMs: 60 * 60_000,  // 1 hour
    maxRequests: 5,
    keyGenerator: (req) => {
      const ip = getClientIp(req);
      const tenantId = getTenantId(req);
      // Include tenant if available, otherwise just IP
      return tenantId ? `reset:${tenantId}:${ip}` : `reset:${ip}`;
    },
    message: 'Too many password reset requests, please try again later',
  });
}

/**
 * Token refresh rate limiter
 * 30 requests per 15 minutes per IP
 * 
 * Note: This route doesn't have tenant context (refresh token contains it)
 * Key: IP only
 */
export function refreshRateLimiter(): RequestHandler {
  return createRateLimiter({
    windowMs: 15 * 60_000,  // 15 minutes
    maxRequests: 30,
    keyGenerator: (req) => `refresh:${getClientIp(req)}`,
    message: 'Too many token refresh attempts, please try again later',
  });
}

/**
 * Sensitive endpoint rate limiter
 * 20 requests per minute per IP
 */
export function sensitiveRateLimiter(): RequestHandler {
  return createRateLimiter({
    windowMs: 60_000,  // 1 minute
    maxRequests: 20,
    keyGenerator: (req) => `sensitive:${getClientIp(req)}`,
    message: 'Too many requests to this endpoint',
  });
}

// ============================================================================
// COMBINED MIDDLEWARE
// ============================================================================

/**
 * Apply multiple rate limiters in sequence
 * Stops at the first limiter that rejects
 */
export function combineRateLimiters(...limiters: RequestHandler[]): RequestHandler {
  return (req: Request, res: Response, next: NextFunction): void => {
    let index = 0;

    const runNext = (err?: Error): void => {
      if (err) {
        next(err);
        return;
      }
      
      const limiter = limiters[index++];
      if (limiter) {
        limiter(req, res, runNext);
      } else {
        next();
      }
    };

    runNext();
  };
}
