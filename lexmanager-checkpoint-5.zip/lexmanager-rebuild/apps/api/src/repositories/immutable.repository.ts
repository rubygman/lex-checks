// ============================================================================
// IMMUTABLE REPOSITORY FOR APPEND-ONLY TABLES
// apps/api/src/repositories/immutable.repository.ts
// ============================================================================

import { query } from '../db/connection.js';
import {
  QueryBuilder,
  createQueryBuilder,
  buildInsert,
  SortDirection,
} from '../db/query-builder.js';
import {
  ImmutableTableError,
  TenantScopingError,
  parsePostgresError,
} from '../db/errors.js';
import type { PaginatedResult, Filter, ListOptions } from './base.repository.js';

/**
 * Base interface for immutable entities
 */
export interface ImmutableEntity {
  id: string;
  tenant_id: string;
  created_at: Date;
  // Note: No updated_at, no deleted_at
}

/**
 * Repository configuration for immutable tables
 */
export interface ImmutableRepositoryConfig {
  tableName: string;
  idColumn?: string;
}

/**
 * Abstract Immutable Repository
 * 
 * For append-only tables like trust_transactions and audit.logs
 * Only supports INSERT and SELECT operations
 * UPDATE and DELETE will throw ImmutableTableError
 */
export abstract class ImmutableRepository<T extends ImmutableEntity> {
  protected readonly tableName: string;
  protected readonly idColumn: string;

  constructor(config: ImmutableRepositoryConfig) {
    this.tableName = config.tableName;
    this.idColumn = config.idColumn || 'id';
  }

  /**
   * Validate tenant ID is provided
   */
  protected validateTenantId(tenantId: string | undefined | null, operation: string): asserts tenantId is string {
    if (!tenantId || typeof tenantId !== 'string' || tenantId.trim() === '') {
      throw new TenantScopingError(
        `${operation} on ${this.tableName} requires a valid tenantId. ` +
        `Received: ${tenantId === undefined ? 'undefined' : tenantId === null ? 'null' : `"${tenantId}"`}`
      );
    }
  }

  /**
   * Find a single record by ID (READ-ONLY)
   */
  async findById(tenantId: string, id: string): Promise<T | null> {
    this.validateTenantId(tenantId, 'findById');

    try {
      const qb = createQueryBuilder()
        .table(this.tableName)
        .tenant(tenantId)
        .whereEquals(this.idColumn, id);

      const { text, params } = qb.buildSelect();
      const result = await query<T>(text, params);

      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * List records with filtering, sorting, and pagination (READ-ONLY)
   */
  async list(
    tenantId: string,
    options: Omit<ListOptions, 'includeDeleted'> = {}
  ): Promise<PaginatedResult<T>> {
    this.validateTenantId(tenantId, 'list');

    try {
      const qb = createQueryBuilder()
        .table(this.tableName)
        .tenant(tenantId);

      // Apply filters
      if (options.filters) {
        for (const filter of options.filters) {
          if (filter.operator === 'IN') {
            qb.whereIn(filter.field, filter.value as unknown[]);
          } else if (filter.operator === 'LIKE' || filter.operator === 'ILIKE') {
            qb.where(filter.field, filter.operator, `%${filter.value}%`);
          } else {
            qb.where(filter.field, filter.operator, filter.value);
          }
        }
      }

      // Apply sorting (default to created_at DESC for audit trail)
      if (options.sort) {
        qb.orderBy(options.sort.field, options.sort.direction);
      } else {
        qb.orderBy('created_at', 'DESC');
      }

      // Get total count
      const { text: countText, params: countParams } = qb.buildCount();
      const countResult = await query<{ count: number }>(countText, countParams);
      const total = countResult.rows[0]?.count || 0;

      // Apply pagination
      const limit = options.pagination?.limit ?? 50;
      const offset = options.pagination?.offset ?? 0;
      qb.paginate(limit, offset);

      // Get data
      const { text, params } = qb.buildSelect();
      const result = await query<T>(text, params);

      return {
        data: result.rows,
        pagination: {
          total,
          limit,
          offset,
          hasMore: offset + result.rows.length < total,
        },
      };
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Count records
   */
  async count(tenantId: string, filters: Filter[] = []): Promise<number> {
    this.validateTenantId(tenantId, 'count');

    try {
      const qb = createQueryBuilder()
        .table(this.tableName)
        .tenant(tenantId);

      for (const filter of filters) {
        if (filter.operator === 'IN') {
          qb.whereIn(filter.field, filter.value as unknown[]);
        } else {
          qb.where(filter.field, filter.operator, filter.value);
        }
      }

      const { text, params } = qb.buildCount();
      const result = await query<{ count: number }>(text, params);

      return result.rows[0]?.count || 0;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Append a new record (INSERT-ONLY)
   */
  async append(
    tenantId: string,
    data: Omit<T, 'id' | 'tenant_id' | 'created_at'>
  ): Promise<T> {
    this.validateTenantId(tenantId, 'append');

    try {
      const { text, params } = buildInsert(this.tableName, tenantId, data as Record<string, unknown>);
      const result = await query<T>(text, params);

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * UPDATE - BLOCKED for immutable tables
   */
  async update(): Promise<never> {
    throw new ImmutableTableError(
      `UPDATE is not allowed on immutable table "${this.tableName}". ` +
      `This table is append-only for compliance and audit purposes.`
    );
  }

  /**
   * DELETE - BLOCKED for immutable tables
   */
  async delete(): Promise<never> {
    throw new ImmutableTableError(
      `DELETE is not allowed on immutable table "${this.tableName}". ` +
      `This table is append-only for compliance and audit purposes.`
    );
  }

  /**
   * SOFT DELETE - BLOCKED for immutable tables
   */
  async softDelete(): Promise<never> {
    throw new ImmutableTableError(
      `SOFT DELETE is not allowed on immutable table "${this.tableName}". ` +
      `This table is append-only for compliance and audit purposes.`
    );
  }
}
