// ============================================================================
// AUDIT LOG INTEGRATION TESTS
// apps/api/tests/integration/audit/audit-log.integration.test.ts
// ============================================================================

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import pg from 'pg';
import { auditService, type AuditContext } from '../../../src/services/audit.service.js';
import { auditLogRepository } from '../../../src/repositories/audit-log.repository.js';
import { rbacService } from '../../../src/services/rbac.service.js';

const { Pool } = pg;

// Skip if no database connection
const DATABASE_URL = process.env.DATABASE_URL;
const shouldRun = DATABASE_URL && DATABASE_URL.includes('localhost');

describe.skipIf(!shouldRun)('Audit Log Integration', () => {
  let pool: pg.Pool;
  let tenantId: string;
  let adminUserId: string;
  let staffUserId: string;
  let context: AuditContext;

  beforeAll(async () => {
    pool = new Pool({ connectionString: DATABASE_URL });

    // Get role IDs
    const adminRoleResult = await pool.query("SELECT id FROM roles WHERE name = 'admin' LIMIT 1");
    const staffRoleResult = await pool.query("SELECT id FROM roles WHERE name = 'staff' LIMIT 1");
    const adminRoleId = adminRoleResult.rows[0].id;
    const staffRoleId = staffRoleResult.rows[0].id;

    // Create test tenant
    const tenantResult = await pool.query(
      "INSERT INTO tenants (name, slug) VALUES ('Audit Test Tenant', $1) RETURNING id",
      [`audit-test-${Date.now()}`]
    );
    tenantId = tenantResult.rows[0].id;

    // Create admin user
    const adminResult = await pool.query(
      `INSERT INTO users (tenant_id, email, password_hash, name, role_id)
       VALUES ($1, $2, 'hash', 'Admin User', $3) RETURNING id`,
      [tenantId, `admin-${Date.now()}@test.com`, adminRoleId]
    );
    adminUserId = adminResult.rows[0].id;

    // Create staff user
    const staffResult = await pool.query(
      `INSERT INTO users (tenant_id, email, password_hash, name, role_id)
       VALUES ($1, $2, 'hash', 'Staff User', $3) RETURNING id`,
      [tenantId, `staff-${Date.now()}@test.com`, staffRoleId]
    );
    staffUserId = staffResult.rows[0].id;

    // Set up default audit context
    context = {
      tenantId,
      userId: adminUserId,
      ipAddress: '127.0.0.1',
      userAgent: 'TestAgent/1.0',
      requestId: `req-${Date.now()}`,
    };
  });

  afterAll(async () => {
    // Note: Cannot delete audit logs due to immutability
    // Delete tenant (audit logs remain orphaned by design - no FK)
    await pool.query('DELETE FROM tenants WHERE id = $1', [tenantId]);
    await pool.end();
  });

  // ============================================================================
  // IMMUTABILITY ENFORCEMENT
  // ============================================================================

  describe('Immutability Enforcement', () => {
    let auditEntryId: string;

    beforeAll(async () => {
      // Create an entry to test immutability
      const entry = await auditLogRepository.append(tenantId, {
        user_id: adminUserId,
        action: 'CREATE',
        action_category: 'data',
        entity_type: 'test_entity',
        entity_id: '00000000-0000-0000-0000-000000000001',
        description: 'Test entry for immutability',
      });
      auditEntryId = entry.id;
    });

    it('should BLOCK UPDATE on audit.logs at DB level', async () => {
      await expect(
        pool.query(
          "UPDATE audit.logs SET description = 'hacked' WHERE id = $1",
          [auditEntryId]
        )
      ).rejects.toThrow(/UPDATE not allowed|immutable/i);
    });

    it('should BLOCK DELETE on audit.logs at DB level', async () => {
      await expect(
        pool.query(
          'DELETE FROM audit.logs WHERE id = $1',
          [auditEntryId]
        )
      ).rejects.toThrow(/DELETE not allowed|immutable/i);
    });

    it('should BLOCK UPDATE even for entry_hash', async () => {
      await expect(
        pool.query(
          "UPDATE audit.logs SET entry_hash = 'tampered' WHERE id = $1",
          [auditEntryId]
        )
      ).rejects.toThrow(/UPDATE not allowed|immutable/i);
    });

    it('should BLOCK repository update method', async () => {
      await expect(
        auditLogRepository.update()
      ).rejects.toThrow(/immutable/i);
    });

    it('should BLOCK repository delete method', async () => {
      await expect(
        auditLogRepository.delete()
      ).rejects.toThrow(/immutable/i);
    });

    it('should BLOCK repository softDelete method', async () => {
      await expect(
        auditLogRepository.softDelete()
      ).rejects.toThrow(/immutable/i);
    });
  });

  // ============================================================================
  // HASH CHAIN
  // ============================================================================

  describe('Hash Chain', () => {
    let firstEntryId: string;
    let firstEntryHash: string;
    let secondEntryId: string;
    let secondEntryHash: string;

    beforeAll(async () => {
      // Create a new tenant for clean hash chain testing
      const chainTenantResult = await pool.query(
        "INSERT INTO tenants (name, slug) VALUES ('Hash Chain Test', $1) RETURNING id",
        [`hash-chain-test-${Date.now()}`]
      );
      const chainTenantId = chainTenantResult.rows[0].id;

      // Create first entry (genesis)
      const first = await auditLogRepository.append(chainTenantId, {
        user_id: adminUserId,
        action: 'CREATE',
        action_category: 'data',
        entity_type: 'test',
        description: 'First entry',
      });
      firstEntryId = first.id;
      firstEntryHash = first.entry_hash;

      // Create second entry (should link to first)
      const second = await auditLogRepository.append(chainTenantId, {
        user_id: adminUserId,
        action: 'UPDATE',
        action_category: 'data',
        entity_type: 'test',
        description: 'Second entry',
      });
      secondEntryId = second.id;
      secondEntryHash = second.entry_hash;

      // Clean up tenant
      await pool.query('DELETE FROM tenants WHERE id = $1', [chainTenantId]);
    });

    it('should generate entry_hash for each entry', async () => {
      expect(firstEntryHash).toBeDefined();
      expect(firstEntryHash).toMatch(/^[a-f0-9]{64}$/);  // SHA-256 hex
    });

    it('should set previous_hash to NULL for first entry (genesis)', async () => {
      const result = await pool.query(
        'SELECT previous_hash FROM audit.logs WHERE id = $1',
        [firstEntryId]
      );
      expect(result.rows[0].previous_hash).toBeNull();
    });

    it('should link second entry to first entry hash', async () => {
      const result = await pool.query(
        'SELECT previous_hash FROM audit.logs WHERE id = $1',
        [secondEntryId]
      );
      expect(result.rows[0].previous_hash).toBe(firstEntryHash);
    });

    it('should generate unique hashes for different entries', async () => {
      expect(firstEntryHash).not.toBe(secondEntryHash);
    });
  });

  // ============================================================================
  // HASH CHAIN VERIFICATION
  // ============================================================================

  describe('Hash Chain Verification', () => {
    let verifyTenantId: string;

    beforeAll(async () => {
      // Create tenant with clean audit chain
      const result = await pool.query(
        "INSERT INTO tenants (name, slug) VALUES ('Verify Chain Test', $1) RETURNING id",
        [`verify-chain-${Date.now()}`]
      );
      verifyTenantId = result.rows[0].id;

      // Create several audit entries
      for (let i = 0; i < 5; i++) {
        await auditLogRepository.append(verifyTenantId, {
          action: 'CREATE',
          action_category: 'data',
          entity_type: 'test',
          description: `Entry ${i + 1}`,
        });
      }
    });

    afterAll(async () => {
      await pool.query('DELETE FROM tenants WHERE id = $1', [verifyTenantId]);
    });

    it('should verify intact hash chain', async () => {
      const result = await auditLogRepository.verifyHashChain(verifyTenantId);

      expect(result.isValid).toBe(true);
      expect(result.totalEntries).toBe(5);
      expect(result.verifiedEntries).toBe(5);
      expect(result.brokenEntries).toBe(0);
      expect(result.firstBrokenId).toBeNull();
    });
  });

  // ============================================================================
  // AUDIT LOGGING
  // ============================================================================

  describe('Audit Logging', () => {
    it('should log CREATE actions', async () => {
      const entry = await auditService.logCreate(
        context,
        'clients',
        '00000000-0000-0000-0000-000000000001',
        { name: 'Test Client', email: 'test@test.com' }
      );

      expect(entry).toBeDefined();
      expect(entry.action).toBe('CREATE');
      expect(entry.entity_type).toBe('clients');
      expect(entry.entry_hash).toBeDefined();
    });

    it('should log UPDATE actions with changes', async () => {
      const oldData = { name: 'Old Name', email: 'old@test.com' };
      const newData = { name: 'New Name', email: 'old@test.com' };

      const entry = await auditService.logUpdate(
        context,
        'clients',
        '00000000-0000-0000-0000-000000000001',
        oldData,
        newData
      );

      expect(entry.action).toBe('UPDATE');
      expect(entry.old_values_json).toHaveProperty('name', 'Old Name');
      expect(entry.new_values_json).toHaveProperty('name', 'New Name');
      expect((entry.changes_json as any).fields).toContain('name');
    });

    it('should log DELETE actions', async () => {
      const entry = await auditService.logDelete(
        context,
        'clients',
        '00000000-0000-0000-0000-000000000001',
        { name: 'Deleted Client' }
      );

      expect(entry.action).toBe('DELETE');
      expect(entry.old_values_json).toHaveProperty('name', 'Deleted Client');
    });

    it('should log RESTORE actions', async () => {
      const entry = await auditService.logRestore(
        context,
        'clients',
        '00000000-0000-0000-0000-000000000001'
      );

      expect(entry.action).toBe('RESTORE');
    });

    it('should log LOGIN actions', async () => {
      const entry = await auditService.logLogin(context, true);

      expect(entry.action).toBe('LOGIN');
      expect(entry.action_category).toBe('auth');
    });

    it('should log failed LOGIN attempts', async () => {
      const entry = await auditService.logLogin(context, false, 'attacker@test.com');

      expect(entry.description).toContain('Failed');
      expect(entry.description).toContain('attacker@test.com');
    });

    it('should log EXPORT actions', async () => {
      const entry = await auditService.logExport(context, 'clients', 100, 'CSV');

      expect(entry.action).toBe('EXPORT');
      expect(entry.description).toContain('100');
      expect(entry.description).toContain('CSV');
    });

    it('should sanitize sensitive fields', async () => {
      const entry = await auditService.logCreate(
        context,
        'users',
        '00000000-0000-0000-0000-000000000002',
        { 
          name: 'Test User', 
          password_hash: 'super_secret_hash',
          api_key: 'secret_key_12345'
        }
      );

      expect(entry.new_values_json).toHaveProperty('name', 'Test User');
      expect(entry.new_values_json).toHaveProperty('password_hash', '[REDACTED]');
      expect(entry.new_values_json).toHaveProperty('api_key', '[REDACTED]');
    });

    it('should mark financial entities correctly', async () => {
      const clientEntry = await auditService.logCreate(
        context,
        'clients',
        '00000000-0000-0000-0000-000000000003',
        { name: 'Financial Client' }
      );
      expect(clientEntry.is_financial).toBe(true);

      const taskEntry = await auditService.logCreate(
        context,
        'tasks',
        '00000000-0000-0000-0000-000000000004',
        { title: 'Non-financial Task' }
      );
      expect(taskEntry.is_financial).toBe(false);
    });

    it('should set retention_date automatically', async () => {
      const entry = await auditService.logCreate(
        context,
        'invoices',
        '00000000-0000-0000-0000-000000000005',
        { invoice_number: 'INV-001' }
      );

      expect(entry.retention_date).toBeDefined();
      // Financial entities get 7 years
      const expectedYear = new Date().getFullYear() + 7;
      expect(new Date(entry.retention_date).getFullYear()).toBe(expectedYear);
    });
  });

  // ============================================================================
  // RBAC ENFORCEMENT FOR READING
  // ============================================================================

  describe('RBAC Enforcement', () => {
    beforeAll(async () => {
      // Create some audit entries
      await auditService.logCreate(context, 'test', 'test-1', { data: 'test' });
    });

    it('should allow admin to read audit logs', async () => {
      await expect(
        auditService.listAuditLogs(tenantId, adminUserId)
      ).resolves.not.toThrow();
    });

    it('should BLOCK staff from reading audit logs', async () => {
      await expect(
        auditService.listAuditLogs(tenantId, staffUserId)
      ).rejects.toThrow(/PERMISSION_DENIED/);
    });

    it('should BLOCK staff from viewing entity history', async () => {
      await expect(
        auditService.getEntityHistory(tenantId, staffUserId, 'clients', 'some-id')
      ).rejects.toThrow(/PERMISSION_DENIED/);
    });

    it('should BLOCK staff from verifying integrity', async () => {
      await expect(
        auditService.verifyIntegrity(tenantId, staffUserId)
      ).rejects.toThrow(/PERMISSION_DENIED/);
    });

    it('should BLOCK staff from viewing statistics', async () => {
      await expect(
        auditService.getStatistics(tenantId, staffUserId)
      ).rejects.toThrow(/PERMISSION_DENIED/);
    });
  });

  // ============================================================================
  // QUERYING
  // ============================================================================

  describe('Querying', () => {
    let queryTenantId: string;
    let queryUserId: string;

    beforeAll(async () => {
      // Create clean tenant for query tests
      const result = await pool.query(
        "INSERT INTO tenants (name, slug) VALUES ('Query Test', $1) RETURNING id",
        [`query-test-${Date.now()}`]
      );
      queryTenantId = result.rows[0].id;

      // Get admin role
      const roleResult = await pool.query("SELECT id FROM roles WHERE name = 'admin' LIMIT 1");
      const adminRoleId = roleResult.rows[0].id;

      // Create user
      const userResult = await pool.query(
        `INSERT INTO users (tenant_id, email, password_hash, name, role_id)
         VALUES ($1, $2, 'hash', 'Query User', $3) RETURNING id`,
        [queryTenantId, `query-${Date.now()}@test.com`, adminRoleId]
      );
      queryUserId = userResult.rows[0].id;

      // Create varied audit entries
      const ctx = { tenantId: queryTenantId, userId: queryUserId };
      
      await auditService.logCreate(ctx, 'clients', 'client-1', { name: 'Client 1' });
      await auditService.logCreate(ctx, 'clients', 'client-2', { name: 'Client 2' });
      await auditService.logUpdate(ctx, 'clients', 'client-1', { name: 'Old' }, { name: 'New' });
      await auditService.logCreate(ctx, 'cases', 'case-1', { title: 'Case 1' });
      await auditService.logDelete(ctx, 'clients', 'client-2', { name: 'Client 2' });
    });

    afterAll(async () => {
      await pool.query('DELETE FROM tenants WHERE id = $1', [queryTenantId]);
    });

    it('should filter by entity type', async () => {
      const logs = await auditService.listAuditLogs(
        queryTenantId,
        queryUserId,
        { entityType: 'clients' }
      );

      expect(logs.length).toBeGreaterThan(0);
      expect(logs.every(l => l.entity_type === 'clients')).toBe(true);
    });

    it('should filter by action', async () => {
      const logs = await auditService.listAuditLogs(
        queryTenantId,
        queryUserId,
        { action: 'CREATE' }
      );

      expect(logs.length).toBeGreaterThan(0);
      expect(logs.every(l => l.action === 'CREATE')).toBe(true);
    });

    it('should filter by entity ID', async () => {
      const logs = await auditService.listAuditLogs(
        queryTenantId,
        queryUserId,
        { entityId: 'client-1' }
      );

      expect(logs.length).toBe(2);  // CREATE and UPDATE
    });

    it('should get entity history', async () => {
      const history = await auditService.getEntityHistory(
        queryTenantId,
        queryUserId,
        'clients',
        'client-1'
      );

      expect(history.length).toBe(2);
      const actions = history.map(h => h.action);
      expect(actions).toContain('CREATE');
      expect(actions).toContain('UPDATE');
    });

    it('should count entries correctly', async () => {
      const total = await auditService.countAuditLogs(queryTenantId, queryUserId);
      expect(total).toBe(5);

      const clientsOnly = await auditService.countAuditLogs(
        queryTenantId,
        queryUserId,
        { entityType: 'clients' }
      );
      expect(clientsOnly).toBe(4);
    });
  });

  // ============================================================================
  // NO FOREIGN KEYS VERIFICATION
  // ============================================================================

  describe('No Foreign Keys (by design)', () => {
    it('should allow audit entries to reference non-existent entities', async () => {
      // This should succeed even though the entity doesn't exist
      const entry = await auditLogRepository.append(tenantId, {
        user_id: '00000000-0000-0000-0000-000000000999',  // Non-existent user
        action: 'CREATE',
        action_category: 'data',
        entity_type: 'non_existent_table',
        entity_id: '00000000-0000-0000-0000-000000000999',
        description: 'Entry referencing non-existent entities',
      });

      expect(entry.id).toBeDefined();
    });

    it('should preserve audit entries when referenced entity is deleted', async () => {
      // Create a temp client
      const clientResult = await pool.query(
        `INSERT INTO clients (tenant_id, name, client_type, status, address_country, currency, payment_terms)
         VALUES ($1, 'Temp Client', 'individual', 'active', 'Israel', 'ILS', 30) RETURNING id`,
        [tenantId]
      );
      const tempClientId = clientResult.rows[0].id;

      // Log an action for this client
      const entry = await auditService.logCreate(context, 'clients', tempClientId, { name: 'Temp Client' });

      // Hard delete the client (not soft delete)
      await pool.query('DELETE FROM clients WHERE id = $1', [tempClientId]);

      // Audit entry should still exist
      const found = await auditLogRepository.findById(tenantId, entry.id);
      expect(found).not.toBeNull();
      expect(found!.entity_id).toBe(tempClientId);
    });
  });
});
