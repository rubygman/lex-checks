# CHECKPOINT 1: Repository & Tooling

## Monorepo Folder Structure

```
lexmanager/
├── apps/
│   ├── api/                          # Express.js backend
│   │   ├── src/
│   │   │   ├── config/
│   │   │   │   ├── database.ts       # PostgreSQL connection config
│   │   │   │   ├── env.ts            # Environment validation
│   │   │   │   └── index.ts
│   │   │   ├── middleware/
│   │   │   │   ├── auth.ts           # JWT verification middleware
│   │   │   │   ├── rbac.ts           # Role-based access control
│   │   │   │   ├── rateLimiter.ts    # Rate limiting
│   │   │   │   ├── validator.ts      # Request validation (Zod)
│   │   │   │   ├── errorHandler.ts   # Global error handling
│   │   │   │   └── auditLogger.ts    # Audit log middleware
│   │   │   ├── routes/
│   │   │   │   ├── auth.routes.ts
│   │   │   │   ├── users.routes.ts
│   │   │   │   ├── clients.routes.ts
│   │   │   │   ├── cases.routes.ts
│   │   │   │   ├── documents.routes.ts
│   │   │   │   ├── tasks.routes.ts
│   │   │   │   ├── time.routes.ts
│   │   │   │   ├── invoices.routes.ts
│   │   │   │   ├── events.routes.ts
│   │   │   │   ├── settings.routes.ts
│   │   │   │   ├── audit.routes.ts
│   │   │   │   └── index.ts
│   │   │   ├── services/
│   │   │   │   ├── auth.service.ts
│   │   │   │   ├── user.service.ts
│   │   │   │   ├── client.service.ts
│   │   │   │   ├── case.service.ts
│   │   │   │   ├── document.service.ts
│   │   │   │   ├── task.service.ts
│   │   │   │   ├── time.service.ts
│   │   │   │   ├── invoice.service.ts
│   │   │   │   ├── event.service.ts
│   │   │   │   ├── audit.service.ts
│   │   │   │   └── storage.service.ts # File storage adapter
│   │   │   ├── repositories/
│   │   │   │   ├── base.repository.ts
│   │   │   │   ├── user.repository.ts
│   │   │   │   ├── client.repository.ts
│   │   │   │   ├── case.repository.ts
│   │   │   │   ├── document.repository.ts
│   │   │   │   ├── task.repository.ts
│   │   │   │   ├── time.repository.ts
│   │   │   │   ├── invoice.repository.ts
│   │   │   │   ├── event.repository.ts
│   │   │   │   └── audit.repository.ts
│   │   │   ├── db/
│   │   │   │   ├── migrations/       # SQL migration files
│   │   │   │   │   ├── 001_initial_schema.sql
│   │   │   │   │   ├── 002_rbac_tables.sql
│   │   │   │   │   ├── 003_audit_log.sql
│   │   │   │   │   └── ...
│   │   │   │   ├── seeds/            # Seed data (roles, permissions)
│   │   │   │   │   └── 001_roles_permissions.sql
│   │   │   │   └── index.ts          # Migration runner
│   │   │   ├── utils/
│   │   │   │   ├── logger.ts
│   │   │   │   ├── crypto.ts         # Argon2 password hashing
│   │   │   │   ├── jwt.ts            # JWT utilities
│   │   │   │   └── validators.ts     # Custom Zod validators
│   │   │   └── app.ts                # Express app setup
│   │   ├── tests/
│   │   │   ├── unit/
│   │   │   ├── integration/
│   │   │   └── e2e/
│   │   ├── package.json
│   │   ├── tsconfig.json
│   │   └── Dockerfile
│   │
│   └── web/                          # React frontend (Phase 2B)
│       ├── src/
│       ├── package.json
│       ├── tsconfig.json
│       └── Dockerfile
│
├── packages/
│   └── shared/                       # Shared types and utilities
│       ├── src/
│       │   ├── types/
│       │   │   ├── entities.ts       # Entity types (Client, Case, etc.)
│       │   │   ├── api.ts            # API request/response types
│       │   │   ├── auth.ts           # Auth types
│       │   │   └── index.ts
│       │   ├── constants/
│       │   │   ├── permissions.ts    # Permission constants
│       │   │   ├── roles.ts          # Role definitions
│       │   │   ├── statuses.ts       # Status enums
│       │   │   └── index.ts
│       │   ├── validators/
│       │   │   ├── client.schema.ts
│       │   │   ├── case.schema.ts
│       │   │   ├── invoice.schema.ts
│       │   │   └── index.ts
│       │   └── index.ts
│       ├── package.json
│       └── tsconfig.json
│
├── infra/
│   ├── docker/
│   │   ├── docker-compose.yml        # Local dev environment
│   │   ├── docker-compose.prod.yml   # Production stack
│   │   └── postgres/
│   │       └── init.sql              # Initial DB setup
│   ├── scripts/
│   │   ├── migrate.sh                # Run migrations
│   │   ├── seed.sh                   # Seed data
│   │   └── backup.sh                 # Backup database
│   └── k8s/                          # Kubernetes manifests (future)
│       └── ...
│
├── docs/
│   ├── api/
│   │   └── openapi.yaml              # OpenAPI 3.0 specification
│   ├── architecture/
│   │   └── README.md
│   └── deployment/
│       └── README.md
│
├── .github/
│   └── workflows/
│       ├── ci.yml                    # CI pipeline
│       └── deploy.yml                # Deployment pipeline
│
├── package.json                      # Root package.json (workspaces)
├── pnpm-workspace.yaml               # pnpm workspace config
├── tsconfig.base.json                # Base TypeScript config
├── .env.example                      # Environment variable template
├── .gitignore
└── README.md
```

## Root package.json

```json
{
  "name": "lexmanager",
  "version": "2.0.0",
  "private": true,
  "description": "Hebrew-first Legal CRM for Israeli Law Firms",
  "scripts": {
    "dev": "pnpm --filter api dev",
    "dev:all": "pnpm -r --parallel dev",
    "build": "pnpm -r build",
    "build:api": "pnpm --filter api build",
    "build:web": "pnpm --filter web build",
    "test": "pnpm -r test",
    "test:api": "pnpm --filter api test",
    "lint": "pnpm -r lint",
    "typecheck": "pnpm -r typecheck",
    "db:migrate": "pnpm --filter api db:migrate",
    "db:migrate:down": "pnpm --filter api db:migrate:down",
    "db:seed": "pnpm --filter api db:seed",
    "db:reset": "pnpm --filter api db:reset",
    "docker:up": "docker-compose -f infra/docker/docker-compose.yml up -d",
    "docker:down": "docker-compose -f infra/docker/docker-compose.yml down",
    "docker:logs": "docker-compose -f infra/docker/docker-compose.yml logs -f",
    "clean": "pnpm -r exec rm -rf node_modules dist .turbo",
    "prepare": "husky install"
  },
  "engines": {
    "node": ">=20.0.0",
    "pnpm": ">=8.0.0"
  },
  "packageManager": "pnpm@8.15.0",
  "devDependencies": {
    "@types/node": "^20.10.0",
    "husky": "^9.0.0",
    "lint-staged": "^15.2.0",
    "prettier": "^3.2.0",
    "typescript": "^5.3.0"
  }
}
```

## apps/api/package.json

```json
{
  "name": "@lexmanager/api",
  "version": "2.0.0",
  "private": true,
  "main": "dist/app.js",
  "scripts": {
    "dev": "tsx watch src/app.ts",
    "build": "tsc",
    "start": "node dist/app.js",
    "test": "vitest run",
    "test:watch": "vitest",
    "test:coverage": "vitest run --coverage",
    "lint": "eslint src --ext .ts",
    "typecheck": "tsc --noEmit",
    "db:migrate": "tsx src/db/index.ts migrate",
    "db:migrate:down": "tsx src/db/index.ts migrate:down",
    "db:seed": "tsx src/db/index.ts seed",
    "db:reset": "tsx src/db/index.ts reset"
  },
  "dependencies": {
    "@lexmanager/shared": "workspace:*",
    "express": "^4.18.2",
    "pg": "^8.11.3",
    "argon2": "^0.31.2",
    "jsonwebtoken": "^9.0.2",
    "zod": "^3.22.4",
    "helmet": "^7.1.0",
    "cors": "^2.8.5",
    "compression": "^1.7.4",
    "express-rate-limit": "^7.1.5",
    "uuid": "^9.0.1",
    "pino": "^8.17.2",
    "pino-pretty": "^10.3.1",
    "dotenv": "^16.3.1"
  },
  "devDependencies": {
    "@types/express": "^4.17.21",
    "@types/pg": "^8.10.9",
    "@types/jsonwebtoken": "^9.0.5",
    "@types/cors": "^2.8.17",
    "@types/compression": "^1.7.5",
    "@types/uuid": "^9.0.7",
    "tsx": "^4.7.0",
    "vitest": "^1.2.0",
    "@vitest/coverage-v8": "^1.2.0",
    "supertest": "^6.3.3",
    "@types/supertest": "^6.0.2",
    "eslint": "^8.56.0",
    "@typescript-eslint/eslint-plugin": "^6.19.0",
    "@typescript-eslint/parser": "^6.19.0"
  }
}
```

## packages/shared/package.json

```json
{
  "name": "@lexmanager/shared",
  "version": "2.0.0",
  "private": true,
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "scripts": {
    "build": "tsc",
    "dev": "tsc --watch",
    "lint": "eslint src --ext .ts",
    "typecheck": "tsc --noEmit"
  },
  "dependencies": {
    "zod": "^3.22.4"
  },
  "devDependencies": {
    "typescript": "^5.3.0"
  }
}
```

## Environment Variables (.env.example)

```bash
# ============================================
# LEXMANAGER ENVIRONMENT CONFIGURATION
# Copy to .env and fill in values
# ============================================

# Application
NODE_ENV=development
PORT=3000
API_PREFIX=/api/v1

# Database (PostgreSQL)
DATABASE_URL=postgresql://lexmanager:lexmanager_dev_password@localhost:5432/lexmanager
DATABASE_POOL_MIN=2
DATABASE_POOL_MAX=10

# Authentication
JWT_SECRET=CHANGE_ME_IN_PRODUCTION_USE_64_CHAR_RANDOM_STRING
JWT_ACCESS_EXPIRY=15m
JWT_REFRESH_EXPIRY=7d
JWT_ISSUER=lexmanager

# Password Hashing (Argon2)
ARGON2_MEMORY_COST=65536
ARGON2_TIME_COST=3
ARGON2_PARALLELISM=4

# Rate Limiting
RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX_REQUESTS=100
RATE_LIMIT_AUTH_MAX=10

# File Storage (Choose one)
STORAGE_PROVIDER=local
# For local storage:
STORAGE_LOCAL_PATH=./uploads
# For S3-compatible:
# STORAGE_PROVIDER=s3
# S3_BUCKET=lexmanager-documents
# S3_REGION=il-central-1
# S3_ACCESS_KEY=
# S3_SECRET_KEY=
# S3_ENDPOINT=  # Optional for non-AWS S3

# Logging
LOG_LEVEL=info
LOG_FORMAT=pretty

# CORS
CORS_ORIGIN=http://localhost:5173

# Audit Log
AUDIT_RETENTION_DAYS=2557
AUDIT_LOG_IP=true

# Israeli-specific
DEFAULT_VAT_RATE=17
DEFAULT_CURRENCY=ILS
DEFAULT_LOCALE=he-IL
DEFAULT_TIMEZONE=Asia/Jerusalem
```

## docker-compose.yml (infra/docker/docker-compose.yml)

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:16-alpine
    container_name: lexmanager-postgres
    environment:
      POSTGRES_USER: lexmanager
      POSTGRES_PASSWORD: lexmanager_dev_password
      POSTGRES_DB: lexmanager
      PGDATA: /var/lib/postgresql/data/pgdata
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./postgres/init.sql:/docker-entrypoint-initdb.d/init.sql:ro
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U lexmanager -d lexmanager"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - lexmanager-network

  postgres-test:
    image: postgres:16-alpine
    container_name: lexmanager-postgres-test
    environment:
      POSTGRES_USER: lexmanager_test
      POSTGRES_PASSWORD: lexmanager_test_password
      POSTGRES_DB: lexmanager_test
    ports:
      - "5433:5432"
    tmpfs:
      - /var/lib/postgresql/data
    networks:
      - lexmanager-network

  redis:
    image: redis:7-alpine
    container_name: lexmanager-redis
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - lexmanager-network

  adminer:
    image: adminer:latest
    container_name: lexmanager-adminer
    ports:
      - "8080:8080"
    environment:
      ADMINER_DEFAULT_SERVER: postgres
    depends_on:
      - postgres
    networks:
      - lexmanager-network

volumes:
  postgres_data:
    name: lexmanager_postgres_data
  redis_data:
    name: lexmanager_redis_data

networks:
  lexmanager-network:
    name: lexmanager-network
    driver: bridge
```

## postgres/init.sql (infra/docker/postgres/init.sql)

```sql
-- ============================================
-- LEXMANAGER PostgreSQL Initialization
-- ============================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- For fuzzy text search

-- Create schemas
CREATE SCHEMA IF NOT EXISTS audit;

-- Set default timezone for Israeli operations
SET timezone = 'Asia/Jerusalem';

-- Grant permissions
GRANT ALL PRIVILEGES ON DATABASE lexmanager TO lexmanager;
GRANT ALL PRIVILEGES ON SCHEMA public TO lexmanager;
GRANT ALL PRIVILEGES ON SCHEMA audit TO lexmanager;

-- Create trigger function for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';
```

## pnpm-workspace.yaml

```yaml
packages:
  - 'apps/*'
  - 'packages/*'
```

## tsconfig.base.json

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "lib": ["ES2022"],
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "resolveJsonModule": true,
    "noImplicitAny": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "exactOptionalPropertyTypes": true,
    "noUncheckedIndexedAccess": true
  }
}
```

## apps/api/tsconfig.json

```json
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "outDir": "./dist",
    "rootDir": "./src",
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"],
      "@lexmanager/shared": ["../../packages/shared/src"]
    }
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist", "tests"]
}
```

## packages/shared/tsconfig.json

```json
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "outDir": "./dist",
    "rootDir": "./src"
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist"]
}
```

## .gitignore

```gitignore
# Dependencies
node_modules/
.pnpm-store/

# Build outputs
dist/
build/
*.tsbuildinfo

# Environment files
.env
.env.local
.env.*.local

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Logs
logs/
*.log
npm-debug.log*
pnpm-debug.log*

# Test coverage
coverage/

# Docker volumes (local dev)
.docker-data/

# Uploads (local dev)
uploads/

# Temporary files
tmp/
temp/
*.tmp
```

---

## GAPS IDENTIFIED

1. **Multi-tenancy Approach**: The original uses `userId` on each record for single-user data isolation. Need to confirm if multi-firm (tenant) isolation is needed or if single-firm per deployment is acceptable.

2. **Soft Delete vs Hard Delete**: Original code shows hard deletes. Confirm if soft delete with `deleted_at` timestamp is required for compliance/recovery.

3. **Invoice Number Sequence**: Original uses a counter stored in DB. Confirm starting number and format (currently `INV-{counter}`). Israeli tax compliance may require specific formatting.

4. **Trust Account Transactions**: Mentioned as "append only" in Firestore rules. Confirm if separate trust accounting module is in scope.

5. **Custom Fields**: Original has custom fields system. Confirm if this needs to be ported in Phase 2A or deferred.

6. **Referral/Rewards System**: Present in original Store structure. Confirm if in scope.

7. **Communication Log**: Email/SMS integration exists. Confirm if in scope for Phase 2A or just data model.

---

**CHECKPOINT READY**
