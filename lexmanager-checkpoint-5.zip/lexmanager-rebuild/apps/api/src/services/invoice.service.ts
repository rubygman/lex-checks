// ============================================================================
// INVOICE SERVICE
// apps/api/src/services/invoice.service.ts
// 
// All methods require appropriate permissions via Authorizer
// ============================================================================

import { invoiceRepository, type Invoice } from '../repositories/index.js';
import { authorizer, PERMISSIONS, type RequestContext } from '../auth/authorizer.js';
import { auditService } from './audit.service.js';
import { softDeleteService } from './soft-delete.service.js';
import { validateClientTenant, validateCaseTenant, validateUserTenant } from '../utils/tenant-validation.js';

// ============================================================================
// TYPES
// ============================================================================

export interface CreateInvoiceInput {
  client_id: string;
  case_id?: string;
  invoice_type: 'tax_invoice' | 'proforma' | 'receipt' | 'credit_note';
  issue_date: Date;
  due_date: Date;
  currency?: string;
  subtotal?: number;
  tax_rate?: number;
  tax_amount?: number;
  discount_amount?: number;
  total_amount?: number;
  notes?: string;
  payment_terms?: string;
  original_invoice_id?: string;  // For credit notes
}

export interface UpdateInvoiceInput {
  issue_date?: Date;
  due_date?: Date;
  subtotal?: number;
  tax_rate?: number;
  tax_amount?: number;
  discount_amount?: number;
  total_amount?: number;
  notes?: string;
  payment_terms?: string;
  status?: 'draft' | 'sent' | 'paid' | 'partial' | 'overdue' | 'cancelled' | 'void';
}

export interface InvoiceListOptions {
  clientId?: string;
  caseId?: string;
  status?: string;
  invoiceType?: string;
  startDate?: Date;
  endDate?: Date;
  limit?: number;
  offset?: number;
  includeDeleted?: boolean;
}

// ============================================================================
// SERVICE
// ============================================================================

export class InvoiceService {
  // ==========================================================================
  // VIEW OPERATIONS
  // ==========================================================================

  /**
   * Get invoice by ID
   * Requires: invoices_view
   */
  async getById(
    context: RequestContext,
    tenantId: string,
    invoiceId: string
  ): Promise<Invoice | null> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.INVOICES_VIEW);
    return invoiceRepository.findById(tenantId, invoiceId);
  }

  /**
   * Get invoice by ID or throw
   * Requires: invoices_view
   */
  async getByIdOrFail(
    context: RequestContext,
    tenantId: string,
    invoiceId: string
  ): Promise<Invoice> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.INVOICES_VIEW);
    return invoiceRepository.findByIdOrFail(tenantId, invoiceId);
  }

  /**
   * List invoices
   * Requires: invoices_view
   */
  async list(
    context: RequestContext,
    tenantId: string,
    options: InvoiceListOptions = {}
  ): Promise<{ data: Invoice[]; pagination: { total: number; limit: number; offset: number; hasMore: boolean } }> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.INVOICES_VIEW);

    const filters = [];
    
    if (options.clientId) {
      filters.push({ field: 'client_id', operator: '=' as const, value: options.clientId });
    }
    if (options.caseId) {
      filters.push({ field: 'case_id', operator: '=' as const, value: options.caseId });
    }
    if (options.status) {
      filters.push({ field: 'status', operator: '=' as const, value: options.status });
    }
    if (options.invoiceType) {
      filters.push({ field: 'invoice_type', operator: '=' as const, value: options.invoiceType });
    }
    if (options.startDate) {
      filters.push({ field: 'issue_date', operator: '>=' as const, value: options.startDate });
    }
    if (options.endDate) {
      filters.push({ field: 'issue_date', operator: '<=' as const, value: options.endDate });
    }

    return invoiceRepository.list(tenantId, {
      filters,
      pagination: { 
        limit: options.limit ?? 100, 
        offset: options.offset ?? 0 
      },
      sort: { field: 'issue_date', direction: 'DESC' },
      includeDeleted: options.includeDeleted,
    });
  }

  /**
   * List invoices for a client
   * Requires: invoices_view
   */
  async listByClient(
    context: RequestContext,
    tenantId: string,
    clientId: string
  ): Promise<Invoice[]> {
    const result = await this.list(context, tenantId, { clientId });
    return result.data;
  }

  /**
   * Get overdue invoices
   * Requires: invoices_view
   */
  async getOverdue(
    context: RequestContext,
    tenantId: string
  ): Promise<Invoice[]> {
    const result = await this.list(context, tenantId, { status: 'overdue' });
    return result.data;
  }

  // ==========================================================================
  // CREATE OPERATIONS
  // ==========================================================================

  /**
   * Create a new invoice
   * Requires: invoices_create
   */
  async create(
    context: RequestContext,
    tenantId: string,
    input: CreateInvoiceInput
  ): Promise<Invoice> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.INVOICES_CREATE);

    // Validate client
    await validateClientTenant(tenantId, input.client_id);

    // Validate case if provided
    if (input.case_id) {
      await validateCaseTenant(tenantId, input.case_id);
    }

    // Validate original invoice for credit notes
    if (input.original_invoice_id) {
      const original = await invoiceRepository.findByIdOrFail(tenantId, input.original_invoice_id);
    }

    // Generate invoice number
    const invoiceNumber = await this.generateInvoiceNumber(tenantId);

    // Create invoice
    const invoice = await invoiceRepository.create(tenantId, {
      client_id: input.client_id,
      case_id: input.case_id,
      invoice_number: invoiceNumber,
      invoice_type: input.invoice_type,
      status: 'draft',
      issue_date: input.issue_date,
      due_date: input.due_date,
      currency: input.currency ?? 'ILS',
      subtotal: input.subtotal ?? 0,
      tax_rate: input.tax_rate ?? 17,  // Israel VAT
      tax_amount: input.tax_amount ?? 0,
      discount_amount: input.discount_amount ?? 0,
      total_amount: input.total_amount ?? 0,
      notes: input.notes,
      payment_terms: input.payment_terms,
      original_invoice_id: input.original_invoice_id,
      created_by: auth.userId,
    });

    // Audit log
    await auditService.logCreate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'invoices',
      invoice.id,
      invoice as unknown as Record<string, unknown>
    );

    return invoice;
  }

  /**
   * Generate unique invoice number
   */
  private async generateInvoiceNumber(tenantId: string): Promise<string> {
    const year = new Date().getFullYear();
    const prefix = `INV-${year}-`;
    
    // This would query for the max invoice number and increment
    // Simplified implementation
    const timestamp = Date.now().toString().slice(-6);
    return `${prefix}${timestamp}`;
  }

  // ==========================================================================
  // UPDATE OPERATIONS
  // ==========================================================================

  /**
   * Update an invoice
   * Requires: invoices_edit
   * Note: Only draft invoices can be edited
   */
  async update(
    context: RequestContext,
    tenantId: string,
    invoiceId: string,
    input: UpdateInvoiceInput
  ): Promise<Invoice> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.INVOICES_EDIT);

    const existing = await invoiceRepository.findByIdOrFail(tenantId, invoiceId);

    // Only draft invoices can be fully edited
    if (existing.status !== 'draft' && !['status'].every(k => Object.keys(input).includes(k))) {
      // If editing more than just status, must be draft
      const nonStatusFields = Object.keys(input).filter(k => k !== 'status');
      if (nonStatusFields.length > 0 && existing.status !== 'draft') {
        throw new Error('Only draft invoices can be edited. Create a credit note for adjustments.');
      }
    }

    const updated = await invoiceRepository.update(tenantId, invoiceId, input);

    await auditService.logUpdate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'invoices',
      invoiceId,
      existing as unknown as Record<string, unknown>,
      updated as unknown as Record<string, unknown>
    );

    return updated;
  }

  /**
   * Send invoice (change status from draft to sent)
   * Requires: invoices_edit
   */
  async send(
    context: RequestContext,
    tenantId: string,
    invoiceId: string
  ): Promise<Invoice> {
    const existing = await this.getByIdOrFail(context, tenantId, invoiceId);
    
    if (existing.status !== 'draft') {
      throw new Error('Only draft invoices can be sent');
    }

    return this.update(context, tenantId, invoiceId, { status: 'sent' });
  }

  /**
   * Mark invoice as paid
   * Requires: invoices_edit
   */
  async markPaid(
    context: RequestContext,
    tenantId: string,
    invoiceId: string
  ): Promise<Invoice> {
    return this.update(context, tenantId, invoiceId, { status: 'paid' });
  }

  /**
   * Void an invoice
   * Requires: invoices_delete
   */
  async void(
    context: RequestContext,
    tenantId: string,
    invoiceId: string
  ): Promise<Invoice> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.INVOICES_DELETE);
    return this.update(context, tenantId, invoiceId, { status: 'void' });
  }

  // ==========================================================================
  // DELETE OPERATIONS
  // ==========================================================================

  /**
   * Soft delete an invoice
   * Requires: invoices_delete
   * Note: Only draft invoices can be deleted
   */
  async delete(
    context: RequestContext,
    tenantId: string,
    invoiceId: string
  ): Promise<void> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.INVOICES_DELETE);

    const invoice = await invoiceRepository.findByIdOrFail(tenantId, invoiceId);

    if (invoice.status !== 'draft') {
      throw new Error('Only draft invoices can be deleted. Void the invoice instead.');
    }

    await softDeleteService.softDelete(tenantId, 'invoices', invoiceId, {
      deletedBy: auth.userId,
    });

    await auditService.logDelete(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'invoices',
      invoiceId,
      invoice as unknown as Record<string, unknown>
    );
  }

  // ==========================================================================
  // REPORTS
  // ==========================================================================

  /**
   * Get invoice summary report
   * Requires: finance_reports
   */
  async getSummaryReport(
    context: RequestContext,
    tenantId: string,
    startDate: Date,
    endDate: Date
  ): Promise<{
    totalInvoiced: number;
    totalPaid: number;
    totalOutstanding: number;
    invoiceCount: number;
    overdueCount: number;
  }> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.FINANCE_REPORTS);

    const invoices = await this.list(context, tenantId, {
      startDate,
      endDate,
      limit: 10000,
    });

    const totalInvoiced = invoices.data.reduce((sum, inv) => sum + (inv.total_amount || 0), 0);
    const totalPaid = invoices.data
      .filter(inv => inv.status === 'paid')
      .reduce((sum, inv) => sum + (inv.total_amount || 0), 0);
    const totalOutstanding = invoices.data
      .filter(inv => ['sent', 'partial', 'overdue'].includes(inv.status))
      .reduce((sum, inv) => sum + (inv.total_amount || 0), 0);
    const overdueCount = invoices.data.filter(inv => inv.status === 'overdue').length;

    // Audit the report generation
    const auth = authorizer.requireAuth(context);
    await auditService.log(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      {
        action: 'VIEW',
        entityType: 'finance_report',
        description: `Generated invoice summary report for ${startDate.toISOString()} to ${endDate.toISOString()}`,
      }
    );

    return {
      totalInvoiced,
      totalPaid,
      totalOutstanding,
      invoiceCount: invoices.data.length,
      overdueCount,
    };
  }
}

export const invoiceService = new InvoiceService();
