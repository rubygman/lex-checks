// ============================================================================
// INVOICE ROUTES
// apps/api/src/routes/invoice.routes.ts
// 
// Invoice CRUD + restore with RBAC and audit
// ============================================================================

import { Router } from 'express';
import { invoiceService } from '../services/invoice.service.js';
import {
  initializeContext,
  resolveTenantFromHeader,
  requireTenant,
  authParser,
  requireAuth,
  requireTenantAccess,
  requirePermission,
} from '../middleware/index.js';
import {
  validate,
  validateAll,
  createInvoiceSchema,
  updateInvoiceSchema,
  invoiceQuerySchema,
  idParamSchema,
  z,
} from '../validation/index.js';
import { asyncHandler, sendSuccess } from '../errors/index.js';
import { PERMISSIONS } from '../services/rbac.service.js';

const router = Router();

// All routes require tenant context and authentication
router.use(initializeContext());
router.use(resolveTenantFromHeader());
router.use(requireTenant());
router.use(authParser());
router.use(requireAuth());
router.use(requireTenantAccess());

// Record payment schema
const recordPaymentSchema = z.object({
  amount: z.number().positive('Amount must be positive'),
  reference: z.string().max(100).optional(),
});

// ============================================================================
// GET /invoices - List invoices
// ============================================================================

router.get(
  '/',
  requirePermission(PERMISSIONS.INVOICES_VIEW),
  validate(invoiceQuerySchema, 'query'),
  asyncHandler(async (req, res) => {
    const { page, limit, status, clientId, caseId, startDate, endDate } = req.query as any;

    const result = await invoiceService.list(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      {
        status,
        clientId,
        caseId,
        startDate,
        endDate,
        limit,
        offset: (page - 1) * limit,
      }
    );

    sendSuccess(res, req, result.data, 200, {
      page,
      limit,
      total: result.pagination.total,
      hasMore: result.pagination.hasMore,
    });
  })
);

// ============================================================================
// GET /invoices/overdue - Get overdue invoices
// ============================================================================

router.get(
  '/overdue',
  requirePermission(PERMISSIONS.INVOICES_VIEW),
  asyncHandler(async (req, res) => {
    const { limit } = req.query as any;

    const invoices = await invoiceService.getOverdue(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      { limit: limit ? parseInt(limit, 10) : undefined }
    );

    sendSuccess(res, req, invoices);
  })
);

// ============================================================================
// POST /invoices - Create invoice
// ============================================================================

router.post(
  '/',
  requirePermission(PERMISSIONS.INVOICES_CREATE),
  validate(createInvoiceSchema, 'body'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const invoice = await invoiceService.create(
      context,
      req.auth!.tenantId,
      {
        client_id: req.body.clientId,
        case_id: req.body.caseId,
        status: req.body.status || 'draft',
        issue_date: new Date(req.body.issueDate),
        due_date: new Date(req.body.dueDate),
        tax_rate: req.body.taxRate ?? 17,
        discount_amount: 0,
        notes: req.body.notes,
        terms_and_conditions: req.body.termsAndConditions,
        lines: req.body.lines.map((line: any) => ({
          description: line.description,
          quantity: line.quantity,
          unit_price: line.unitPrice,
          amount: line.amount,
          time_entry_id: line.timeEntryId,
        })),
      }
    );

    sendSuccess(res, req, invoice, 201);
  })
);

// ============================================================================
// GET /invoices/:id - Get invoice by ID
// ============================================================================

router.get(
  '/:id',
  requirePermission(PERMISSIONS.INVOICES_VIEW),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const invoice = await invoiceService.getByIdOrFail(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, invoice);
  })
);

// ============================================================================
// PATCH /invoices/:id - Update invoice
// ============================================================================

router.patch(
  '/:id',
  requirePermission(PERMISSIONS.INVOICES_EDIT),
  validateAll({
    params: idParamSchema,
    body: updateInvoiceSchema,
  }),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const invoice = await invoiceService.update(
      context,
      req.auth!.tenantId,
      req.params.id,
      {
        status: req.body.status,
        due_date: req.body.dueDate ? new Date(req.body.dueDate) : undefined,
        notes: req.body.notes,
      }
    );

    sendSuccess(res, req, invoice);
  })
);

// ============================================================================
// POST /invoices/:id/send - Mark invoice as sent
// ============================================================================

router.post(
  '/:id/send',
  requirePermission(PERMISSIONS.INVOICES_EDIT),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const invoice = await invoiceService.markSent(
      context,
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, invoice);
  })
);

// ============================================================================
// POST /invoices/:id/payment - Record payment
// ============================================================================

router.post(
  '/:id/payment',
  requirePermission(PERMISSIONS.INVOICES_EDIT),
  validateAll({
    params: idParamSchema,
    body: recordPaymentSchema,
  }),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const invoice = await invoiceService.recordPayment(
      context,
      req.auth!.tenantId,
      req.params.id,
      req.body.amount
    );

    sendSuccess(res, req, invoice);
  })
);

// ============================================================================
// DELETE /invoices/:id - Void invoice (soft delete)
// ============================================================================

router.delete(
  '/:id',
  requirePermission(PERMISSIONS.INVOICES_DELETE),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    await invoiceService.void(
      context,
      req.auth!.tenantId,
      req.params.id,
      req.body?.reason
    );

    sendSuccess(res, req, { message: 'Invoice voided successfully' });
  })
);

// ============================================================================
// POST /invoices/:id/restore - Restore soft-deleted invoice
// ============================================================================

router.post(
  '/:id/restore',
  requirePermission(PERMISSIONS.INVOICES_DELETE),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    await invoiceService.restore(
      context,
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, { message: 'Invoice restored successfully' });
  })
);

export default router;
