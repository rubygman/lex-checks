#!/bin/bash
# ============================================
# LexManager Database Migration Script
# ============================================

set -e

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '#' | xargs)
fi

DATABASE_URL="${DATABASE_URL:-postgresql://lexmanager:lexmanager_dev_password@localhost:5432/lexmanager}"

echo "🔄 Running database migrations..."

# Run migrations using the API's db:migrate script
pnpm --filter @lexmanager/api db:migrate

echo "✅ Migrations completed successfully!"
