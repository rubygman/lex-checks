// ============================================================================
// TENANT REPOSITORY
// apps/api/src/repositories/tenant.repository.ts
// ============================================================================

import { query } from '../db/connection.js';
import { parsePostgresError, NotFoundError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  domain: string | null;
  settings_json: Record<string, unknown>;
  plan: 'trial' | 'basic' | 'professional' | 'enterprise';
  max_users: number;
  max_storage_mb: number;
  is_active: boolean;
  trial_ends_at: Date | null;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

export type CreateTenantData = {
  name: string;
  slug: string;
  domain?: string;
  settings_json?: Record<string, unknown>;
  plan?: Tenant['plan'];
  max_users?: number;
  max_storage_mb?: number;
  trial_ends_at?: Date;
};

export type UpdateTenantData = Partial<Omit<CreateTenantData, 'slug'>>;

// ============================================================================
// REPOSITORY
// ============================================================================

export class TenantRepository {
  private readonly tableName = 'tenants';

  /**
   * Find tenant by ID
   */
  async findById(id: string, includeDeleted = false): Promise<Tenant | null> {
    try {
      const deletedClause = includeDeleted ? '' : 'AND deleted_at IS NULL';
      const result = await query<Tenant>(
        `SELECT * FROM ${this.tableName} WHERE id = $1 ${deletedClause}`,
        [id]
      );
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find tenant by ID, throw if not found
   */
  async findByIdOrFail(id: string, includeDeleted = false): Promise<Tenant> {
    const tenant = await this.findById(id, includeDeleted);
    if (!tenant) {
      throw new NotFoundError('Tenant', id);
    }
    return tenant;
  }

  /**
   * Find tenant by slug (unique)
   */
  async findBySlug(slug: string, includeDeleted = false): Promise<Tenant | null> {
    try {
      const deletedClause = includeDeleted ? '' : 'AND deleted_at IS NULL';
      const result = await query<Tenant>(
        `SELECT * FROM ${this.tableName} WHERE slug = $1 ${deletedClause}`,
        [slug]
      );
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find tenant by domain
   */
  async findByDomain(domain: string): Promise<Tenant | null> {
    try {
      const result = await query<Tenant>(
        `SELECT * FROM ${this.tableName} WHERE domain = $1 AND deleted_at IS NULL`,
        [domain]
      );
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Check if slug is available
   */
  async isSlugAvailable(slug: string): Promise<boolean> {
    const tenant = await this.findBySlug(slug, true); // Check including deleted
    return tenant === null;
  }

  /**
   * List all active tenants
   */
  async listActive(options?: { limit?: number; offset?: number }): Promise<Tenant[]> {
    try {
      const limit = options?.limit ?? 100;
      const offset = options?.offset ?? 0;
      
      const result = await query<Tenant>(
        `SELECT * FROM ${this.tableName} 
         WHERE deleted_at IS NULL AND is_active = TRUE
         ORDER BY created_at DESC
         LIMIT $1 OFFSET $2`,
        [limit, offset]
      );
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Create a new tenant
   */
  async create(data: CreateTenantData): Promise<Tenant> {
    try {
      const result = await query<Tenant>(
        `INSERT INTO ${this.tableName} (
          name, slug, domain, settings_json, plan, 
          max_users, max_storage_mb, trial_ends_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        RETURNING *`,
        [
          data.name,
          data.slug,
          data.domain || null,
          JSON.stringify(data.settings_json || {}),
          data.plan || 'trial',
          data.max_users || 5,
          data.max_storage_mb || 1024,
          data.trial_ends_at || null,
        ]
      );
      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Update a tenant
   */
  async update(id: string, data: UpdateTenantData): Promise<Tenant> {
    try {
      const fields: string[] = [];
      const values: unknown[] = [];
      let paramIndex = 1;

      if (data.name !== undefined) {
        fields.push(`name = $${paramIndex++}`);
        values.push(data.name);
      }
      if (data.domain !== undefined) {
        fields.push(`domain = $${paramIndex++}`);
        values.push(data.domain);
      }
      if (data.settings_json !== undefined) {
        fields.push(`settings_json = $${paramIndex++}`);
        values.push(JSON.stringify(data.settings_json));
      }
      if (data.plan !== undefined) {
        fields.push(`plan = $${paramIndex++}`);
        values.push(data.plan);
      }
      if (data.max_users !== undefined) {
        fields.push(`max_users = $${paramIndex++}`);
        values.push(data.max_users);
      }
      if (data.max_storage_mb !== undefined) {
        fields.push(`max_storage_mb = $${paramIndex++}`);
        values.push(data.max_storage_mb);
      }
      if (data.trial_ends_at !== undefined) {
        fields.push(`trial_ends_at = $${paramIndex++}`);
        values.push(data.trial_ends_at);
      }

      if (fields.length === 0) {
        return this.findByIdOrFail(id);
      }

      fields.push(`updated_at = CURRENT_TIMESTAMP`);
      values.push(id);

      const result = await query<Tenant>(
        `UPDATE ${this.tableName} 
         SET ${fields.join(', ')}
         WHERE id = $${paramIndex} AND deleted_at IS NULL
         RETURNING *`,
        values
      );

      if (result.rows.length === 0) {
        throw new NotFoundError('Tenant', id);
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Soft delete a tenant
   */
  async softDelete(id: string): Promise<Tenant> {
    try {
      const result = await query<Tenant>(
        `UPDATE ${this.tableName}
         SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
         WHERE id = $1 AND deleted_at IS NULL
         RETURNING *`,
        [id]
      );

      if (result.rows.length === 0) {
        throw new NotFoundError('Tenant', id);
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Activate/deactivate a tenant
   */
  async setActive(id: string, isActive: boolean): Promise<Tenant> {
    try {
      const result = await query<Tenant>(
        `UPDATE ${this.tableName}
         SET is_active = $1, updated_at = CURRENT_TIMESTAMP
         WHERE id = $2 AND deleted_at IS NULL
         RETURNING *`,
        [isActive, id]
      );

      if (result.rows.length === 0) {
        throw new NotFoundError('Tenant', id);
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Count users in tenant
   */
  async countUsers(tenantId: string): Promise<number> {
    try {
      const result = await query<{ count: number }>(
        `SELECT COUNT(*)::int as count FROM users 
         WHERE tenant_id = $1 AND deleted_at IS NULL`,
        [tenantId]
      );
      return result.rows[0]?.count || 0;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}

export const tenantRepository = new TenantRepository();
