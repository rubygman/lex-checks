// ============================================================================
// BASE REPOSITORY WITH STRICT TENANT SCOPING
// apps/api/src/repositories/base.repository.ts
// ============================================================================

import { query, withTransaction } from '../db/connection.js';
import {
  QueryBuilder,
  createQueryBuilder,
  buildInsert,
  buildUpdate,
  buildSoftDelete,
  buildHardDelete,
  QueryOptions,
  SortDirection,
} from '../db/query-builder.js';
import {
  DatabaseError,
  TenantScopingError,
  ImmutableTableError,
  NotFoundError,
  parsePostgresError,
} from '../db/errors.js';
import type pg from 'pg';

/**
 * Pagination result wrapper
 */
export interface PaginatedResult<T> {
  data: T[];
  pagination: {
    total: number;
    limit: number;
    offset: number;
    hasMore: boolean;
  };
}

/**
 * Filter operators for list queries
 */
export type FilterOperator = '=' | '!=' | '>' | '<' | '>=' | '<=' | 'IN' | 'LIKE' | 'ILIKE';

export interface Filter {
  field: string;
  operator: FilterOperator;
  value: unknown;
}

/**
 * List query options
 */
export interface ListOptions {
  filters?: Filter[];
  sort?: { field: string; direction: SortDirection };
  pagination?: { limit: number; offset: number };
  includeDeleted?: boolean;
}

/**
 * Base entity interface - all entities must have these fields
 */
export interface BaseEntity {
  id: string;
  tenant_id: string;
  created_at: Date;
  updated_at: Date;
}

/**
 * Soft-deletable entity interface
 */
export interface SoftDeletableEntity extends BaseEntity {
  deleted_at: Date | null;
}

/**
 * Repository configuration
 */
export interface RepositoryConfig {
  tableName: string;
  idColumn?: string;
  isImmutable?: boolean;
  supportsSoftDelete?: boolean;
}

/**
 * Abstract Base Repository
 * 
 * CRITICAL: All methods require tenantId parameter to enforce tenant isolation.
 * There is NO way to execute a query without tenant scoping for tenant-scoped tables.
 */
export abstract class BaseRepository<T extends BaseEntity> {
  protected readonly tableName: string;
  protected readonly idColumn: string;
  protected readonly isImmutable: boolean;
  protected readonly supportsSoftDelete: boolean;

  constructor(config: RepositoryConfig) {
    this.tableName = config.tableName;
    this.idColumn = config.idColumn || 'id';
    this.isImmutable = config.isImmutable ?? QueryBuilder.isImmutable(config.tableName);
    this.supportsSoftDelete = config.supportsSoftDelete ?? QueryBuilder.supportsSoftDelete(config.tableName);
  }

  /**
   * Validate tenant ID is provided
   */
  protected validateTenantId(tenantId: string | undefined | null, operation: string): asserts tenantId is string {
    if (!tenantId || typeof tenantId !== 'string' || tenantId.trim() === '') {
      throw new TenantScopingError(
        `${operation} on ${this.tableName} requires a valid tenantId. ` +
        `Received: ${tenantId === undefined ? 'undefined' : tenantId === null ? 'null' : `"${tenantId}"`}`
      );
    }
  }

  /**
   * Validate that the table is not immutable for write operations
   */
  protected validateMutable(operation: string): void {
    if (this.isImmutable) {
      throw new ImmutableTableError(
        `${operation} is not allowed on immutable table "${this.tableName}"`
      );
    }
  }

  /**
   * Find a single record by ID
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param id - The record ID
   * @param options - Query options
   */
  async findById(
    tenantId: string,
    id: string,
    options: Pick<QueryOptions, 'includeDeleted'> = {}
  ): Promise<T | null> {
    this.validateTenantId(tenantId, 'findById');

    try {
      const qb = createQueryBuilder()
        .table(this.tableName)
        .tenant(tenantId)
        .whereEquals(this.idColumn, id);

      if (options.includeDeleted) {
        qb.includeDeleted(true);
      }

      const { text, params } = qb.buildSelect();
      const result = await query<T>(text, params);

      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find a single record by ID, throw if not found
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param id - The record ID
   * @param options - Query options
   */
  async findByIdOrFail(
    tenantId: string,
    id: string,
    options: Pick<QueryOptions, 'includeDeleted'> = {}
  ): Promise<T> {
    const record = await this.findById(tenantId, id, options);
    
    if (!record) {
      throw new NotFoundError(this.tableName, id);
    }

    return record;
  }

  /**
   * Find records by multiple IDs
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param ids - Array of record IDs
   * @param options - Query options
   */
  async findByIds(
    tenantId: string,
    ids: string[],
    options: Pick<QueryOptions, 'includeDeleted'> = {}
  ): Promise<T[]> {
    this.validateTenantId(tenantId, 'findByIds');

    if (ids.length === 0) {
      return [];
    }

    try {
      const qb = createQueryBuilder()
        .table(this.tableName)
        .tenant(tenantId)
        .whereIn(this.idColumn, ids);

      if (options.includeDeleted) {
        qb.includeDeleted(true);
      }

      const { text, params } = qb.buildSelect();
      const result = await query<T>(text, params);

      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * List records with filtering, sorting, and pagination
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param options - List options
   */
  async list(
    tenantId: string,
    options: ListOptions = {}
  ): Promise<PaginatedResult<T>> {
    this.validateTenantId(tenantId, 'list');

    try {
      const qb = createQueryBuilder()
        .table(this.tableName)
        .tenant(tenantId);

      // Apply filters
      if (options.filters) {
        for (const filter of options.filters) {
          if (filter.operator === 'IN') {
            qb.whereIn(filter.field, filter.value as unknown[]);
          } else if (filter.operator === 'LIKE' || filter.operator === 'ILIKE') {
            qb.where(filter.field, filter.operator, `%${filter.value}%`);
          } else {
            qb.where(filter.field, filter.operator, filter.value);
          }
        }
      }

      // Apply soft delete filter
      if (options.includeDeleted) {
        qb.includeDeleted(true);
      }

      // Apply sorting
      if (options.sort) {
        qb.orderBy(options.sort.field, options.sort.direction);
      } else {
        qb.orderBy('created_at', 'DESC');
      }

      // Get total count first
      const { text: countText, params: countParams } = qb.buildCount();
      const countResult = await query<{ count: number }>(countText, countParams);
      const total = countResult.rows[0]?.count || 0;

      // Apply pagination
      const limit = options.pagination?.limit ?? 50;
      const offset = options.pagination?.offset ?? 0;
      qb.paginate(limit, offset);

      // Get data
      const { text, params } = qb.buildSelect();
      const result = await query<T>(text, params);

      return {
        data: result.rows,
        pagination: {
          total,
          limit,
          offset,
          hasMore: offset + result.rows.length < total,
        },
      };
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find the first record matching criteria
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param filters - Filters to apply
   * @param options - Query options
   */
  async findOne(
    tenantId: string,
    filters: Filter[],
    options: Pick<QueryOptions, 'includeDeleted'> = {}
  ): Promise<T | null> {
    this.validateTenantId(tenantId, 'findOne');

    const result = await this.list(tenantId, {
      filters,
      pagination: { limit: 1, offset: 0 },
      includeDeleted: options.includeDeleted,
    });

    return result.data[0] || null;
  }

  /**
   * Check if a record exists
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param id - The record ID
   */
  async exists(tenantId: string, id: string): Promise<boolean> {
    this.validateTenantId(tenantId, 'exists');

    const record = await this.findById(tenantId, id);
    return record !== null;
  }

  /**
   * Count records matching criteria
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param filters - Filters to apply
   * @param options - Query options
   */
  async count(
    tenantId: string,
    filters: Filter[] = [],
    options: Pick<QueryOptions, 'includeDeleted'> = {}
  ): Promise<number> {
    this.validateTenantId(tenantId, 'count');

    try {
      const qb = createQueryBuilder()
        .table(this.tableName)
        .tenant(tenantId);

      for (const filter of filters) {
        if (filter.operator === 'IN') {
          qb.whereIn(filter.field, filter.value as unknown[]);
        } else {
          qb.where(filter.field, filter.operator, filter.value);
        }
      }

      if (options.includeDeleted) {
        qb.includeDeleted(true);
      }

      const { text, params } = qb.buildCount();
      const result = await query<{ count: number }>(text, params);

      return result.rows[0]?.count || 0;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Create a new record
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param data - The data to insert (excluding id, tenant_id, timestamps)
   */
  async create(
    tenantId: string,
    data: Omit<T, 'id' | 'tenant_id' | 'created_at' | 'updated_at' | 'deleted_at'>
  ): Promise<T> {
    this.validateTenantId(tenantId, 'create');

    try {
      const { text, params } = buildInsert(this.tableName, tenantId, data as Record<string, unknown>);
      const result = await query<T>(text, params);

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Create multiple records in a transaction
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param dataArray - Array of data to insert
   */
  async createMany(
    tenantId: string,
    dataArray: Omit<T, 'id' | 'tenant_id' | 'created_at' | 'updated_at' | 'deleted_at'>[]
  ): Promise<T[]> {
    this.validateTenantId(tenantId, 'createMany');

    if (dataArray.length === 0) {
      return [];
    }

    return withTransaction(async (client) => {
      const results: T[] = [];

      for (const data of dataArray) {
        const { text, params } = buildInsert(this.tableName, tenantId, data as Record<string, unknown>);
        const result = await client.query<T>(text, params);
        results.push(result.rows[0]!);
      }

      return results;
    });
  }

  /**
   * Update a record
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param id - The record ID
   * @param data - The data to update
   */
  async update(
    tenantId: string,
    id: string,
    data: Partial<Omit<T, 'id' | 'tenant_id' | 'created_at' | 'updated_at' | 'deleted_at'>>
  ): Promise<T> {
    this.validateTenantId(tenantId, 'update');
    this.validateMutable('update');

    try {
      const { text, params } = buildUpdate(
        this.tableName,
        tenantId,
        id,
        data as Record<string, unknown>,
        this.idColumn
      );
      const result = await query<T>(text, params);

      if (result.rows.length === 0) {
        throw new NotFoundError(this.tableName, id);
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Soft delete a record
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param id - The record ID
   */
  async softDelete(tenantId: string, id: string): Promise<T> {
    this.validateTenantId(tenantId, 'softDelete');
    this.validateMutable('softDelete');

    if (!this.supportsSoftDelete) {
      throw new DatabaseError(
        `Table "${this.tableName}" does not support soft delete`,
        'SOFT_DELETE_NOT_SUPPORTED',
        400
      );
    }

    try {
      const { text, params } = buildSoftDelete(this.tableName, tenantId, id, this.idColumn);
      const result = await query<T>(text, params);

      if (result.rows.length === 0) {
        throw new NotFoundError(this.tableName, id);
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Restore a soft-deleted record
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param id - The record ID
   */
  async restore(tenantId: string, id: string): Promise<T> {
    this.validateTenantId(tenantId, 'restore');
    this.validateMutable('restore');

    if (!this.supportsSoftDelete) {
      throw new DatabaseError(
        `Table "${this.tableName}" does not support soft delete/restore`,
        'SOFT_DELETE_NOT_SUPPORTED',
        400
      );
    }

    try {
      // First, find the record including deleted
      const record = await this.findById(tenantId, id, { includeDeleted: true });
      
      if (!record) {
        throw new NotFoundError(this.tableName, id);
      }

      // Update to clear deleted_at
      const text = `
        UPDATE ${this.tableName}
        SET deleted_at = NULL, updated_at = CURRENT_TIMESTAMP
        WHERE ${this.idColumn} = $1 AND tenant_id = $2
        RETURNING *
      `;
      const result = await query<T>(text, [id, tenantId]);

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Hard delete a record (use sparingly)
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param id - The record ID
   */
  async hardDelete(tenantId: string, id: string): Promise<T> {
    this.validateTenantId(tenantId, 'hardDelete');
    this.validateMutable('hardDelete');

    try {
      const { text, params } = buildHardDelete(this.tableName, tenantId, id, this.idColumn);
      const result = await query<T>(text, params);

      if (result.rows.length === 0) {
        throw new NotFoundError(this.tableName, id);
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Execute a raw query with tenant scoping validation
   * Use sparingly and only when the query builder is insufficient
   * 
   * @param tenantId - REQUIRED: The tenant ID for scoping
   * @param text - SQL query text (must include tenant_id filter)
   * @param params - Query parameters (first must be tenantId)
   */
  async rawQuery<R = T>(
    tenantId: string,
    text: string,
    params: unknown[]
  ): Promise<R[]> {
    this.validateTenantId(tenantId, 'rawQuery');

    // Validate that the query includes tenant_id reference
    if (!text.toLowerCase().includes('tenant_id')) {
      throw new TenantScopingError(
        'Raw queries must include tenant_id filtering. ' +
        'Ensure your query has a WHERE tenant_id = $1 clause.'
      );
    }

    // Validate that tenantId is in params
    if (params[0] !== tenantId) {
      throw new TenantScopingError(
        'First parameter of raw query must be tenantId'
      );
    }

    try {
      const result = await query<R>(text, params);
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}
