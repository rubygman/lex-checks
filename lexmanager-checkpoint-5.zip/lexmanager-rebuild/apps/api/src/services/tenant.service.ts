// ============================================================================
// TENANT SERVICE
// apps/api/src/services/tenant.service.ts
// ============================================================================

import { tenantRepository, type Tenant, type CreateTenantData, type UpdateTenantData } from '../repositories/tenant.repository.js';
import { userRepository } from '../repositories/user.repository.js';
import { roleRepository } from '../repositories/rbac.repository.js';
import { DuplicateError, NotFoundError } from '../db/errors.js';
import { hashPassword } from '../utils/crypto.js';

// ============================================================================
// TYPES
// ============================================================================

export interface CreateTenantWithAdminInput {
  tenant: {
    name: string;
    slug: string;
    domain?: string;
    plan?: Tenant['plan'];
  };
  admin: {
    email: string;
    password: string;
    name: string;
    name_he?: string;
    phone?: string;
  };
}

export interface TenantWithStats extends Tenant {
  user_count: number;
}

// ============================================================================
// SERVICE
// ============================================================================

export class TenantService {
  /**
   * Create a new tenant with initial admin user
   */
  async createTenant(input: CreateTenantWithAdminInput): Promise<{ tenant: Tenant; adminUser: { id: string; email: string } }> {
    // Validate slug format
    if (!/^[a-z0-9-]+$/.test(input.tenant.slug)) {
      throw new Error('Slug must contain only lowercase letters, numbers, and hyphens');
    }

    // Check if slug is available
    const slugAvailable = await tenantRepository.isSlugAvailable(input.tenant.slug);
    if (!slugAvailable) {
      throw new DuplicateError('A tenant with this slug already exists', 'slug');
    }

    // Get admin role
    const adminRole = await roleRepository.findByName('admin');
    if (!adminRole) {
      throw new Error('Admin role not found. Please run database seeds first.');
    }

    // Calculate trial end date (14 days from now)
    const trialEndsAt = new Date();
    trialEndsAt.setDate(trialEndsAt.getDate() + 14);

    // Create tenant
    const tenant = await tenantRepository.create({
      name: input.tenant.name,
      slug: input.tenant.slug,
      domain: input.tenant.domain,
      plan: input.tenant.plan || 'trial',
      trial_ends_at: trialEndsAt,
    });

    // Hash password and create admin user
    const passwordHash = await hashPassword(input.admin.password);
    
    const adminUser = await userRepository.createUser(tenant.id, {
      email: input.admin.email,
      password_hash: passwordHash,
      name: input.admin.name,
      name_he: input.admin.name_he,
      phone: input.admin.phone,
      role_id: adminRole.id,
      is_active: true,
    });

    return {
      tenant,
      adminUser: {
        id: adminUser.id,
        email: adminUser.email,
      },
    };
  }

  /**
   * Get tenant by ID
   */
  async getById(id: string): Promise<Tenant | null> {
    return tenantRepository.findById(id);
  }

  /**
   * Get tenant by ID or throw
   */
  async getByIdOrFail(id: string): Promise<Tenant> {
    return tenantRepository.findByIdOrFail(id);
  }

  /**
   * Get tenant by slug
   */
  async getBySlug(slug: string): Promise<Tenant | null> {
    return tenantRepository.findBySlug(slug);
  }

  /**
   * Get tenant by domain
   */
  async getByDomain(domain: string): Promise<Tenant | null> {
    return tenantRepository.findByDomain(domain);
  }

  /**
   * Resolve tenant from request (by slug or domain)
   */
  async resolveTenant(slugOrDomain: string): Promise<Tenant | null> {
    // Try slug first
    let tenant = await tenantRepository.findBySlug(slugOrDomain);
    
    // Try domain if not found by slug
    if (!tenant) {
      tenant = await tenantRepository.findByDomain(slugOrDomain);
    }

    return tenant;
  }

  /**
   * Update tenant
   */
  async updateTenant(id: string, data: UpdateTenantData): Promise<Tenant> {
    return tenantRepository.update(id, data);
  }

  /**
   * Update tenant settings
   */
  async updateSettings(id: string, settings: Record<string, unknown>): Promise<Tenant> {
    const tenant = await tenantRepository.findByIdOrFail(id);
    
    const mergedSettings = {
      ...tenant.settings_json,
      ...settings,
    };

    return tenantRepository.update(id, { settings_json: mergedSettings });
  }

  /**
   * Soft delete tenant
   */
  async softDeleteTenant(id: string): Promise<Tenant> {
    // Verify tenant exists
    await tenantRepository.findByIdOrFail(id);
    
    return tenantRepository.softDelete(id);
  }

  /**
   * Activate tenant
   */
  async activateTenant(id: string): Promise<Tenant> {
    return tenantRepository.setActive(id, true);
  }

  /**
   * Deactivate tenant
   */
  async deactivateTenant(id: string): Promise<Tenant> {
    return tenantRepository.setActive(id, false);
  }

  /**
   * Check if tenant is active and not deleted
   */
  async isTenantActive(id: string): Promise<boolean> {
    const tenant = await tenantRepository.findById(id);
    return tenant !== null && tenant.is_active && tenant.deleted_at === null;
  }

  /**
   * Check if tenant has reached user limit
   */
  async canAddUser(tenantId: string): Promise<boolean> {
    const tenant = await tenantRepository.findByIdOrFail(tenantId);
    const currentCount = await tenantRepository.countUsers(tenantId);
    return currentCount < tenant.max_users;
  }

  /**
   * Get tenant with user statistics
   */
  async getWithStats(id: string): Promise<TenantWithStats | null> {
    const tenant = await tenantRepository.findById(id);
    if (!tenant) return null;

    const userCount = await tenantRepository.countUsers(id);

    return {
      ...tenant,
      user_count: userCount,
    };
  }

  /**
   * Check if tenant trial has expired
   */
  async isTrialExpired(tenantId: string): Promise<boolean> {
    const tenant = await tenantRepository.findByIdOrFail(tenantId);
    
    if (tenant.plan !== 'trial') {
      return false;
    }

    if (!tenant.trial_ends_at) {
      return false;
    }

    return new Date() > tenant.trial_ends_at;
  }

  /**
   * Upgrade tenant plan
   */
  async upgradePlan(
    tenantId: string, 
    plan: Tenant['plan'],
    options?: { max_users?: number; max_storage_mb?: number }
  ): Promise<Tenant> {
    return tenantRepository.update(tenantId, {
      plan,
      max_users: options?.max_users,
      max_storage_mb: options?.max_storage_mb,
      trial_ends_at: undefined, // Clear trial end date
    });
  }
}

export const tenantService = new TenantService();
