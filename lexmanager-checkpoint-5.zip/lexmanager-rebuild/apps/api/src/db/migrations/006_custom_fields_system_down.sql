-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 006: Custom Fields System Enhancements - DOWN
-- ============================================================================

BEGIN;

-- Drop indexes
DROP INDEX IF EXISTS idx_custom_field_values_search_number;
DROP INDEX IF EXISTS idx_custom_field_values_search_text;
DROP INDEX IF EXISTS idx_custom_field_defs_entity_type;
DROP INDEX IF EXISTS idx_custom_field_values_entity;

-- Drop functions
DROP FUNCTION IF EXISTS get_select_option_label(JSONB, TEXT, VARCHAR);
DROP FUNCTION IF EXISTS get_custom_fields_for_entity(UUID, VARCHAR, UUID);

-- Drop view
DROP VIEW IF EXISTS custom_fields_with_values;

-- Drop trigger and function
DROP TRIGGER IF EXISTS trg_custom_field_values_validate ON custom_field_values;
DROP FUNCTION IF EXISTS validate_custom_field_value();

COMMIT;
