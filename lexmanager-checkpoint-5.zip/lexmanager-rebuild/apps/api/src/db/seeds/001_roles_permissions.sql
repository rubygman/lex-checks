-- ============================================================================
-- LEXMANAGER SEED DATA
-- Seed 001: Roles and Permissions
-- ============================================================================

BEGIN;

-- ============================================================================
-- 1. ROLES
-- ============================================================================
INSERT INTO roles (id, name, name_he, description, is_system) VALUES
    ('00000000-0000-0000-0000-000000000001', 'admin', 'מנהל מערכת', 'Full system access, user management, settings', TRUE),
    ('00000000-0000-0000-0000-000000000002', 'attorney', 'עורך דין', 'Case management, client access, billing', TRUE),
    ('00000000-0000-0000-0000-000000000003', 'paralegal', 'עוזר משפטי', 'Case support, document management, scheduling', TRUE),
    ('00000000-0000-0000-0000-000000000004', 'staff', 'צוות', 'Basic access, scheduling, limited case view', TRUE);

-- ============================================================================
-- 2. PERMISSIONS
-- ============================================================================

-- Cases permissions
INSERT INTO permissions (id, code, category, description) VALUES
    ('10000000-0000-0000-0000-000000000001', 'cases_view', 'cases', 'View cases'),
    ('10000000-0000-0000-0000-000000000002', 'cases_create', 'cases', 'Create new cases'),
    ('10000000-0000-0000-0000-000000000003', 'cases_edit', 'cases', 'Edit case details'),
    ('10000000-0000-0000-0000-000000000004', 'cases_delete', 'cases', 'Delete cases'),
    ('10000000-0000-0000-0000-000000000005', 'cases_assign', 'cases', 'Assign cases to users'),
    ('10000000-0000-0000-0000-000000000006', 'cases_export', 'cases', 'Export case data');

-- Clients permissions
INSERT INTO permissions (id, code, category, description) VALUES
    ('10000000-0000-0000-0000-000000000011', 'clients_view', 'clients', 'View clients'),
    ('10000000-0000-0000-0000-000000000012', 'clients_create', 'clients', 'Create new clients'),
    ('10000000-0000-0000-0000-000000000013', 'clients_edit', 'clients', 'Edit client details'),
    ('10000000-0000-0000-0000-000000000014', 'clients_delete', 'clients', 'Delete clients'),
    ('10000000-0000-0000-0000-000000000015', 'clients_export', 'clients', 'Export client data');

-- Documents permissions
INSERT INTO permissions (id, code, category, description) VALUES
    ('10000000-0000-0000-0000-000000000021', 'docs_view', 'documents', 'View documents'),
    ('10000000-0000-0000-0000-000000000022', 'docs_upload', 'documents', 'Upload documents'),
    ('10000000-0000-0000-0000-000000000023', 'docs_edit', 'documents', 'Edit document metadata'),
    ('10000000-0000-0000-0000-000000000024', 'docs_delete', 'documents', 'Delete documents'),
    ('10000000-0000-0000-0000-000000000025', 'docs_download', 'documents', 'Download documents');

-- Calendar permissions
INSERT INTO permissions (id, code, category, description) VALUES
    ('10000000-0000-0000-0000-000000000031', 'calendar_view', 'calendar', 'View calendar events'),
    ('10000000-0000-0000-0000-000000000032', 'calendar_create', 'calendar', 'Create events'),
    ('10000000-0000-0000-0000-000000000033', 'calendar_edit', 'calendar', 'Edit events'),
    ('10000000-0000-0000-0000-000000000034', 'calendar_delete', 'calendar', 'Delete events');

-- Finance permissions
INSERT INTO permissions (id, code, category, description) VALUES
    ('10000000-0000-0000-0000-000000000041', 'finance_view', 'finance', 'View financial data'),
    ('10000000-0000-0000-0000-000000000042', 'finance_create', 'finance', 'Create financial records'),
    ('10000000-0000-0000-0000-000000000043', 'finance_edit', 'finance', 'Edit financial records'),
    ('10000000-0000-0000-0000-000000000044', 'finance_delete', 'finance', 'Delete financial records'),
    ('10000000-0000-0000-0000-000000000045', 'finance_reports', 'finance', 'View financial reports'),
    ('10000000-0000-0000-0000-000000000046', 'invoices_view', 'finance', 'View invoices'),
    ('10000000-0000-0000-0000-000000000047', 'invoices_create', 'finance', 'Create invoices'),
    ('10000000-0000-0000-0000-000000000048', 'invoices_edit', 'finance', 'Edit invoices'),
    ('10000000-0000-0000-0000-000000000049', 'invoices_delete', 'finance', 'Delete invoices');

-- Time tracking permissions
INSERT INTO permissions (id, code, category, description) VALUES
    ('10000000-0000-0000-0000-000000000051', 'time_view_own', 'time', 'View own time entries'),
    ('10000000-0000-0000-0000-000000000052', 'time_view_all', 'time', 'View all time entries'),
    ('10000000-0000-0000-0000-000000000053', 'time_create', 'time', 'Create time entries'),
    ('10000000-0000-0000-0000-000000000054', 'time_edit_own', 'time', 'Edit own time entries'),
    ('10000000-0000-0000-0000-000000000055', 'time_edit_all', 'time', 'Edit all time entries'),
    ('10000000-0000-0000-0000-000000000056', 'time_delete', 'time', 'Delete time entries'),
    ('10000000-0000-0000-0000-000000000057', 'time_approve', 'time', 'Approve time entries');

-- Trust account permissions
INSERT INTO permissions (id, code, category, description) VALUES
    ('10000000-0000-0000-0000-000000000061', 'trust_view', 'trust', 'View trust accounts'),
    ('10000000-0000-0000-0000-000000000062', 'trust_deposit', 'trust', 'Make trust deposits'),
    ('10000000-0000-0000-0000-000000000063', 'trust_withdraw', 'trust', 'Make trust withdrawals'),
    ('10000000-0000-0000-0000-000000000064', 'trust_transfer', 'trust', 'Transfer between trust accounts'),
    ('10000000-0000-0000-0000-000000000065', 'trust_reports', 'trust', 'View trust reports');

-- Communication permissions
INSERT INTO permissions (id, code, category, description) VALUES
    ('10000000-0000-0000-0000-000000000071', 'email_send', 'communication', 'Send emails'),
    ('10000000-0000-0000-0000-000000000072', 'sms_send', 'communication', 'Send SMS'),
    ('10000000-0000-0000-0000-000000000073', 'comm_log_view', 'communication', 'View communication log'),
    ('10000000-0000-0000-0000-000000000074', 'comm_log_create', 'communication', 'Create communication log entries');

-- Tasks permissions
INSERT INTO permissions (id, code, category, description) VALUES
    ('10000000-0000-0000-0000-000000000081', 'tasks_view', 'tasks', 'View tasks'),
    ('10000000-0000-0000-0000-000000000082', 'tasks_create', 'tasks', 'Create tasks'),
    ('10000000-0000-0000-0000-000000000083', 'tasks_edit', 'tasks', 'Edit tasks'),
    ('10000000-0000-0000-0000-000000000084', 'tasks_delete', 'tasks', 'Delete tasks'),
    ('10000000-0000-0000-0000-000000000085', 'tasks_assign', 'tasks', 'Assign tasks');

-- Reports permissions
INSERT INTO permissions (id, code, category, description) VALUES
    ('10000000-0000-0000-0000-000000000091', 'reports_view', 'reports', 'View reports'),
    ('10000000-0000-0000-0000-000000000092', 'reports_create', 'reports', 'Create reports'),
    ('10000000-0000-0000-0000-000000000093', 'reports_export', 'reports', 'Export reports');

-- Admin permissions
INSERT INTO permissions (id, code, category, description) VALUES
    ('10000000-0000-0000-0000-000000000101', 'settings_view', 'admin', 'View settings'),
    ('10000000-0000-0000-0000-000000000102', 'settings_edit', 'admin', 'Edit settings'),
    ('10000000-0000-0000-0000-000000000103', 'users_manage', 'admin', 'Manage users'),
    ('10000000-0000-0000-0000-000000000104', 'roles_manage', 'admin', 'Manage roles'),
    ('10000000-0000-0000-0000-000000000105', 'custom_fields_manage', 'admin', 'Manage custom fields'),
    ('10000000-0000-0000-0000-000000000106', 'templates_manage', 'admin', 'Manage templates'),
    ('10000000-0000-0000-0000-000000000107', 'backup_manage', 'admin', 'Manage backups'),
    ('10000000-0000-0000-0000-000000000108', 'audit_log_view', 'admin', 'View audit log');

-- ============================================================================
-- 3. ROLE_PERMISSIONS (Map permissions to roles)
-- ============================================================================

-- ADMIN: All permissions
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
    '00000000-0000-0000-0000-000000000001'::uuid,
    id
FROM permissions;

-- ATTORNEY: Most permissions except admin
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
    '00000000-0000-0000-0000-000000000002'::uuid,
    id
FROM permissions
WHERE code NOT IN (
    'cases_delete',
    'clients_delete',
    'docs_delete',
    'finance_delete',
    'invoices_delete',
    'time_edit_all',
    'time_delete',
    'settings_edit',
    'users_manage',
    'roles_manage',
    'custom_fields_manage',
    'backup_manage',
    'audit_log_view'
);

-- PARALEGAL: Limited permissions
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
    '00000000-0000-0000-0000-000000000003'::uuid,
    id
FROM permissions
WHERE code IN (
    'cases_view',
    'cases_edit',
    'cases_export',
    'clients_view',
    'clients_create',
    'clients_edit',
    'docs_view',
    'docs_upload',
    'docs_edit',
    'docs_download',
    'calendar_view',
    'calendar_create',
    'calendar_edit',
    'invoices_view',
    'time_view_own',
    'time_create',
    'time_edit_own',
    'trust_view',
    'email_send',
    'sms_send',
    'comm_log_view',
    'comm_log_create',
    'tasks_view',
    'tasks_create',
    'tasks_edit',
    'reports_view'
);

-- STAFF: Basic permissions
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
    '00000000-0000-0000-0000-000000000004'::uuid,
    id
FROM permissions
WHERE code IN (
    'cases_view',
    'clients_view',
    'clients_create',
    'docs_view',
    'docs_upload',
    'docs_download',
    'calendar_view',
    'calendar_create',
    'time_view_own',
    'time_create',
    'time_edit_own',
    'email_send',
    'comm_log_view',
    'comm_log_create',
    'tasks_view'
);

COMMIT;
