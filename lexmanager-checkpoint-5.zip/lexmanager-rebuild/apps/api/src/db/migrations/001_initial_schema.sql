-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 001: Initial Schema
-- Multi-tenant SaaS | Soft Delete | Trust Ledger | Custom Fields | Audit Log
-- ============================================================================

-- ============================================================================
-- UP MIGRATION
-- ============================================================================

BEGIN;

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Create audit schema for immutable logs
CREATE SCHEMA IF NOT EXISTS audit;

-- ============================================================================
-- 1. TENANTS (Root of multi-tenancy)
-- ============================================================================
CREATE TABLE tenants (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(255) NOT NULL,
    slug            VARCHAR(100) NOT NULL UNIQUE,  -- URL-friendly identifier
    domain          VARCHAR(255),                   -- Custom domain (optional)
    settings_json   JSONB DEFAULT '{}',            -- Tenant-level settings
    plan            VARCHAR(50) DEFAULT 'trial',   -- trial, basic, professional, enterprise
    max_users       INTEGER DEFAULT 5,
    max_storage_mb  INTEGER DEFAULT 1024,
    is_active       BOOLEAN DEFAULT TRUE,
    trial_ends_at   TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ                    -- Soft delete
);

CREATE INDEX idx_tenants_slug ON tenants(slug) WHERE deleted_at IS NULL;
CREATE INDEX idx_tenants_domain ON tenants(domain) WHERE domain IS NOT NULL AND deleted_at IS NULL;
CREATE INDEX idx_tenants_deleted_at ON tenants(deleted_at);

-- ============================================================================
-- 2. ROLES (Global role definitions)
-- ============================================================================
CREATE TABLE roles (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(50) NOT NULL UNIQUE,   -- admin, attorney, paralegal, staff
    name_he         VARCHAR(50) NOT NULL,          -- Hebrew name
    description     TEXT,
    is_system       BOOLEAN DEFAULT FALSE,         -- System roles cannot be deleted
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- 3. PERMISSIONS (Granular permission definitions)
-- ============================================================================
CREATE TABLE permissions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code            VARCHAR(100) NOT NULL UNIQUE,  -- e.g., 'cases_create', 'invoices_delete'
    category        VARCHAR(50) NOT NULL,          -- cases, clients, docs, finance, etc.
    description     TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_permissions_category ON permissions(category);

-- ============================================================================
-- 4. ROLE_PERMISSIONS (Many-to-many: roles <-> permissions)
-- ============================================================================
CREATE TABLE role_permissions (
    role_id         UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id   UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (role_id, permission_id)
);

CREATE INDEX idx_role_permissions_role ON role_permissions(role_id);
CREATE INDEX idx_role_permissions_permission ON role_permissions(permission_id);

-- ============================================================================
-- 5. USERS (Tenant-scoped)
-- ============================================================================
CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    email           VARCHAR(255) NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,         -- Argon2id hash
    name            VARCHAR(255) NOT NULL,
    name_he         VARCHAR(255),                  -- Hebrew name (optional)
    phone           VARCHAR(50),
    avatar_url      VARCHAR(500),
    role_id         UUID NOT NULL REFERENCES roles(id),
    is_active       BOOLEAN DEFAULT TRUE,
    email_verified  BOOLEAN DEFAULT FALSE,
    last_login_at   TIMESTAMPTZ,
    last_login_ip   INET,
    password_changed_at TIMESTAMPTZ,
    failed_login_attempts INTEGER DEFAULT 0,
    locked_until    TIMESTAMPTZ,
    settings_json   JSONB DEFAULT '{}',            -- User preferences
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ,                   -- Soft delete
    
    CONSTRAINT uq_users_tenant_email UNIQUE (tenant_id, email)
);

CREATE INDEX idx_users_tenant ON users(tenant_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_email ON users(email) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_role ON users(role_id);
CREATE INDEX idx_users_deleted_at ON users(deleted_at);

-- ============================================================================
-- 6. REFRESH_TOKENS (For JWT refresh token rotation)
-- ============================================================================
CREATE TABLE refresh_tokens (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash      VARCHAR(255) NOT NULL,         -- SHA-256 hash of token
    device_info     VARCHAR(500),                  -- User agent / device
    ip_address      INET,
    expires_at      TIMESTAMPTZ NOT NULL,
    revoked_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_refresh_tokens_user ON refresh_tokens(user_id);
CREATE INDEX idx_refresh_tokens_expires ON refresh_tokens(expires_at) WHERE revoked_at IS NULL;

-- ============================================================================
-- 7. CLIENTS (Tenant-scoped)
-- ============================================================================
CREATE TABLE clients (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    
    -- Basic info
    name            VARCHAR(255) NOT NULL,
    name_he         VARCHAR(255),
    email           VARCHAR(255),
    phone           VARCHAR(50),
    phone_secondary VARCHAR(50),
    fax             VARCHAR(50),
    
    -- Client type
    client_type     VARCHAR(20) NOT NULL DEFAULT 'individual', -- individual, company, government, non_profit
    status          VARCHAR(20) NOT NULL DEFAULT 'lead',       -- lead, prospect, active, inactive, archived
    
    -- Israeli identifiers
    israeli_id      VARCHAR(9),                    -- ת.ז. (9 digits)
    company_number  VARCHAR(9),                    -- ח.פ. (9 digits)
    vat_number      VARCHAR(20),                   -- מס' עוסק מורשה
    
    -- Address
    address_street  VARCHAR(255),
    address_city    VARCHAR(100),
    address_zip     VARCHAR(20),
    address_country VARCHAR(100) DEFAULT 'Israel',
    
    -- Additional
    website         VARCHAR(255),
    notes           TEXT,
    source          VARCHAR(100),                  -- How client was acquired
    assigned_to     UUID REFERENCES users(id),     -- Primary attorney
    
    -- Billing
    default_rate    DECIMAL(10,2),                 -- Override firm rate
    currency        VARCHAR(3) DEFAULT 'ILS',
    payment_terms   INTEGER DEFAULT 30,            -- Days
    
    -- Timestamps
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ,
    
    CONSTRAINT uq_clients_tenant_israeli_id UNIQUE (tenant_id, israeli_id),
    CONSTRAINT uq_clients_tenant_company_number UNIQUE (tenant_id, company_number)
);

CREATE INDEX idx_clients_tenant ON clients(tenant_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_clients_status ON clients(tenant_id, status) WHERE deleted_at IS NULL;
CREATE INDEX idx_clients_assigned ON clients(assigned_to) WHERE deleted_at IS NULL;
CREATE INDEX idx_clients_name_trgm ON clients USING gin(name gin_trgm_ops);
CREATE INDEX idx_clients_deleted_at ON clients(deleted_at);

-- ============================================================================
-- 8. CASES / MATTERS (Tenant-scoped)
-- ============================================================================
CREATE TABLE cases (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    client_id       UUID NOT NULL REFERENCES clients(id),
    
    -- Basic info
    title           VARCHAR(300) NOT NULL,
    case_number     VARCHAR(50),                   -- Internal reference
    court_case_number VARCHAR(100),                -- Court file number
    
    -- Classification
    case_type       VARCHAR(100) NOT NULL,         -- Real Estate, Criminal, Family, etc.
    status          VARCHAR(50) NOT NULL DEFAULT 'drafting', 
                    -- drafting, negotiation, signed, registered, active, on_hold, closed, archived
    priority        VARCHAR(20) DEFAULT 'medium',  -- low, medium, high, urgent
    
    -- Description
    description     TEXT,
    
    -- Israeli Real Estate specifics
    property_gush   INTEGER,                       -- גוש
    property_helka  INTEGER,                       -- חלקה
    property_sub_helka INTEGER,                    -- תת-חלקה
    property_address TEXT,
    
    -- Value & Billing
    case_value      DECIMAL(15,2),                 -- Transaction value
    fee_type        VARCHAR(20) DEFAULT 'hourly', -- hourly, fixed, contingency, retainer
    fee_amount      DECIMAL(10,2),
    currency        VARCHAR(3) DEFAULT 'ILS',
    
    -- Opposing party
    opposing_party_name VARCHAR(255),
    opposing_party_contact TEXT,
    opposing_counsel VARCHAR(255),
    
    -- Court info
    court_name      VARCHAR(255),
    court_branch    VARCHAR(100),
    judge_name      VARCHAR(255),
    
    -- Dates
    open_date       DATE,
    due_date        DATE,
    close_date      DATE,
    statute_of_limitations DATE,
    
    -- Tags (for filtering)
    tags            TEXT[],
    
    -- Assignment
    assigned_to     UUID REFERENCES users(id),     -- Lead attorney
    
    -- Timestamps
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ,
    
    -- Ensure client belongs to same tenant (enforced via trigger)
    CONSTRAINT uq_cases_tenant_case_number UNIQUE (tenant_id, case_number)
);

CREATE INDEX idx_cases_tenant ON cases(tenant_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_cases_client ON cases(client_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_cases_status ON cases(tenant_id, status) WHERE deleted_at IS NULL;
CREATE INDEX idx_cases_type ON cases(tenant_id, case_type) WHERE deleted_at IS NULL;
CREATE INDEX idx_cases_assigned ON cases(assigned_to) WHERE deleted_at IS NULL;
CREATE INDEX idx_cases_due_date ON cases(due_date) WHERE deleted_at IS NULL AND status NOT IN ('closed', 'archived');
CREATE INDEX idx_cases_title_trgm ON cases USING gin(title gin_trgm_ops);
CREATE INDEX idx_cases_tags ON cases USING gin(tags);
CREATE INDEX idx_cases_deleted_at ON cases(deleted_at);

-- ============================================================================
-- 9. TASKS (Tenant-scoped)
-- ============================================================================
CREATE TABLE tasks (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    case_id         UUID REFERENCES cases(id),
    client_id       UUID REFERENCES clients(id),
    
    -- Task info
    title           VARCHAR(300) NOT NULL,
    description     TEXT,
    status          VARCHAR(20) NOT NULL DEFAULT 'todo', -- todo, in_progress, done, cancelled
    priority        VARCHAR(20) DEFAULT 'medium',        -- low, medium, high, urgent
    
    -- Kanban column (for custom workflows)
    column_id       VARCHAR(50) DEFAULT 'todo',
    column_order    INTEGER DEFAULT 0,
    
    -- Dates
    due_date        DATE,
    due_time        TIME,
    completed_at    TIMESTAMPTZ,
    
    -- Recurrence (optional)
    recurrence_rule VARCHAR(255),                  -- iCal RRULE format
    parent_task_id  UUID REFERENCES tasks(id),     -- For recurring instances
    
    -- Assignment
    assigned_to     UUID REFERENCES users(id),
    assigned_by     UUID REFERENCES users(id),
    
    -- Timestamps
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ
);

CREATE INDEX idx_tasks_tenant ON tasks(tenant_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_tasks_case ON tasks(case_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_tasks_client ON tasks(client_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_tasks_assigned ON tasks(assigned_to) WHERE deleted_at IS NULL;
CREATE INDEX idx_tasks_status ON tasks(tenant_id, status) WHERE deleted_at IS NULL;
CREATE INDEX idx_tasks_due ON tasks(due_date) WHERE deleted_at IS NULL AND status NOT IN ('done', 'cancelled');
CREATE INDEX idx_tasks_deleted_at ON tasks(deleted_at);

-- ============================================================================
-- 10. DOCUMENTS (Tenant-scoped)
-- ============================================================================
CREATE TABLE documents (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    case_id         UUID REFERENCES cases(id),
    client_id       UUID REFERENCES clients(id),
    
    -- File info
    title           VARCHAR(300) NOT NULL,
    filename        VARCHAR(255) NOT NULL,
    mime_type       VARCHAR(100) NOT NULL,
    size_bytes      BIGINT NOT NULL,
    
    -- Storage
    storage_provider VARCHAR(20) NOT NULL DEFAULT 'local', -- local, s3, gcs
    storage_key     VARCHAR(500) NOT NULL,         -- Path or key in storage
    storage_bucket  VARCHAR(255),
    
    -- Classification
    category        VARCHAR(50) NOT NULL DEFAULT 'other',
                    -- pleadings, evidence, contract, correspondence, court_filing, admin, other
    
    -- Versioning
    version         INTEGER NOT NULL DEFAULT 1,
    is_latest       BOOLEAN NOT NULL DEFAULT TRUE,
    parent_id       UUID REFERENCES documents(id), -- Previous version
    
    -- Metadata
    description     TEXT,
    tags            TEXT[],
    
    -- OCR / Search
    ocr_text        TEXT,                          -- Extracted text for search
    ocr_status      VARCHAR(20) DEFAULT 'pending', -- pending, processing, completed, failed
    
    -- Timestamps
    uploaded_by     UUID NOT NULL REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ
);

CREATE INDEX idx_documents_tenant ON documents(tenant_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_documents_case ON documents(case_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_documents_client ON documents(client_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_documents_category ON documents(tenant_id, category) WHERE deleted_at IS NULL;
CREATE INDEX idx_documents_latest ON documents(parent_id) WHERE is_latest = TRUE AND deleted_at IS NULL;
CREATE INDEX idx_documents_title_trgm ON documents USING gin(title gin_trgm_ops);
CREATE INDEX idx_documents_ocr_trgm ON documents USING gin(ocr_text gin_trgm_ops) WHERE ocr_text IS NOT NULL;
CREATE INDEX idx_documents_tags ON documents USING gin(tags);
CREATE INDEX idx_documents_deleted_at ON documents(deleted_at);

-- ============================================================================
-- 11. CALENDAR_EVENTS (Tenant-scoped)
-- ============================================================================
CREATE TABLE calendar_events (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    case_id         UUID REFERENCES cases(id),
    client_id       UUID REFERENCES clients(id),
    
    -- Event info
    title           VARCHAR(300) NOT NULL,
    description     TEXT,
    event_type      VARCHAR(50) NOT NULL DEFAULT 'work',
                    -- work, court, meeting, deadline, call, block, personal, hearing
    
    -- Time
    start_at        TIMESTAMPTZ NOT NULL,
    end_at          TIMESTAMPTZ NOT NULL,
    all_day         BOOLEAN DEFAULT FALSE,
    timezone        VARCHAR(50) DEFAULT 'Asia/Jerusalem',
    
    -- Location
    location        VARCHAR(500),
    location_type   VARCHAR(20),                   -- in_person, video, phone
    video_link      VARCHAR(500),
    
    -- Reminders (stored as minutes before event)
    reminders       INTEGER[],                     -- e.g., {15, 60, 1440} = 15min, 1hr, 1day
    
    -- Recurrence
    recurrence_rule VARCHAR(255),                  -- iCal RRULE
    recurrence_end  DATE,
    parent_event_id UUID REFERENCES calendar_events(id), -- For recurring instances
    
    -- Attendees (user IDs)
    attendees       UUID[],
    
    -- External sync
    external_id     VARCHAR(255),                  -- Google Calendar ID, etc.
    external_source VARCHAR(50),
    
    -- Timestamps
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ
);

CREATE INDEX idx_events_tenant ON calendar_events(tenant_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_events_case ON calendar_events(case_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_events_client ON calendar_events(client_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_events_dates ON calendar_events(tenant_id, start_at, end_at) WHERE deleted_at IS NULL;
CREATE INDEX idx_events_type ON calendar_events(tenant_id, event_type) WHERE deleted_at IS NULL;
CREATE INDEX idx_events_deleted_at ON calendar_events(deleted_at);

-- ============================================================================
-- 12. TIME_ENTRIES (Tenant-scoped)
-- ============================================================================
CREATE TABLE time_entries (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    case_id         UUID NOT NULL REFERENCES cases(id),
    client_id       UUID NOT NULL REFERENCES clients(id),
    user_id         UUID NOT NULL REFERENCES users(id),
    
    -- Time info
    description     TEXT NOT NULL,
    work_date       DATE NOT NULL,
    duration_minutes INTEGER NOT NULL CHECK (duration_minutes > 0),
    
    -- Billing
    billable        BOOLEAN DEFAULT TRUE,
    billed          BOOLEAN DEFAULT FALSE,
    rate            DECIMAL(10,2),                 -- Rate at time of entry
    amount          DECIMAL(10,2),                 -- Calculated: (duration/60) * rate
    currency        VARCHAR(3) DEFAULT 'ILS',
    
    -- Task type for rate lookup
    task_type       VARCHAR(100),                  -- research, court, drafting, meeting, etc.
    
    -- Invoice link (when billed)
    invoice_id      UUID,                          -- Will reference invoices table
    
    -- Timestamps
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ
);

CREATE INDEX idx_time_tenant ON time_entries(tenant_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_time_case ON time_entries(case_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_time_client ON time_entries(client_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_time_user ON time_entries(user_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_time_date ON time_entries(work_date) WHERE deleted_at IS NULL;
CREATE INDEX idx_time_unbilled ON time_entries(tenant_id, client_id) WHERE billed = FALSE AND billable = TRUE AND deleted_at IS NULL;
CREATE INDEX idx_time_invoice ON time_entries(invoice_id) WHERE invoice_id IS NOT NULL;
CREATE INDEX idx_time_deleted_at ON time_entries(deleted_at);

-- ============================================================================
-- 13. INVOICES (Tenant-scoped)
-- ============================================================================
CREATE TABLE invoices (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    client_id       UUID NOT NULL REFERENCES clients(id),
    case_id         UUID REFERENCES cases(id),
    
    -- Invoice identification
    invoice_number  VARCHAR(50) NOT NULL,
    invoice_type    VARCHAR(20) NOT NULL DEFAULT 'tax_invoice',
                    -- tax_invoice, quote, receipt, credit_note
    
    -- Status (state machine)
    status          VARCHAR(20) NOT NULL DEFAULT 'draft',
                    -- draft, sent, viewed, paid, partially_paid, overdue, void, cancelled
    
    -- Dates
    issue_date      DATE NOT NULL,
    due_date        DATE NOT NULL,
    paid_date       DATE,
    void_date       DATE,
    
    -- Amounts (all in invoice currency)
    subtotal        DECIMAL(12,2) NOT NULL DEFAULT 0,
    discount_amount DECIMAL(12,2) DEFAULT 0,
    discount_percent DECIMAL(5,2) DEFAULT 0,
    vat_rate        DECIMAL(5,2) NOT NULL DEFAULT 17, -- Israeli VAT
    vat_amount      DECIMAL(12,2) NOT NULL DEFAULT 0,
    total           DECIMAL(12,2) NOT NULL DEFAULT 0,
    amount_paid     DECIMAL(12,2) DEFAULT 0,
    balance_due     DECIMAL(12,2) GENERATED ALWAYS AS (total - amount_paid) STORED,
    currency        VARCHAR(3) NOT NULL DEFAULT 'ILS',
    
    -- Reference for credit notes
    original_invoice_id UUID REFERENCES invoices(id),
    credit_note_reason TEXT,
    
    -- Payment terms
    payment_terms   INTEGER DEFAULT 30,            -- Days
    
    -- Notes
    notes           TEXT,
    internal_notes  TEXT,
    
    -- Billing details snapshot (frozen at invoice time)
    billing_name    VARCHAR(255),
    billing_address TEXT,
    billing_vat_number VARCHAR(20),
    
    -- Timestamps
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ,
    
    -- Immutability: issued invoices cannot change core fields
    issued_at       TIMESTAMPTZ,                   -- Set when status changes from draft
    
    CONSTRAINT uq_invoices_tenant_number UNIQUE (tenant_id, invoice_number),
    CONSTRAINT chk_invoice_type CHECK (invoice_type IN ('tax_invoice', 'quote', 'receipt', 'credit_note')),
    CONSTRAINT chk_invoice_status CHECK (status IN ('draft', 'sent', 'viewed', 'paid', 'partially_paid', 'overdue', 'void', 'cancelled'))
);

CREATE INDEX idx_invoices_tenant ON invoices(tenant_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_invoices_client ON invoices(client_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_invoices_case ON invoices(case_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_invoices_status ON invoices(tenant_id, status) WHERE deleted_at IS NULL;
CREATE INDEX idx_invoices_due ON invoices(due_date) WHERE status NOT IN ('paid', 'void', 'cancelled') AND deleted_at IS NULL;
CREATE INDEX idx_invoices_number ON invoices(invoice_number);
CREATE INDEX idx_invoices_deleted_at ON invoices(deleted_at);

-- ============================================================================
-- 14. INVOICE_LINES (Line items)
-- ============================================================================
CREATE TABLE invoice_lines (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    invoice_id      UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    
    -- Line item
    description     TEXT NOT NULL,
    quantity        DECIMAL(10,4) NOT NULL DEFAULT 1,
    unit_price      DECIMAL(12,2) NOT NULL,
    amount          DECIMAL(12,2) NOT NULL,        -- quantity * unit_price
    
    -- Reference to time entry (if from time tracking)
    time_entry_id   UUID REFERENCES time_entries(id),
    
    -- Order
    line_order      INTEGER NOT NULL DEFAULT 0,
    
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_invoice_lines_invoice ON invoice_lines(invoice_id);
CREATE INDEX idx_invoice_lines_tenant ON invoice_lines(tenant_id);
CREATE INDEX idx_invoice_lines_time ON invoice_lines(time_entry_id) WHERE time_entry_id IS NOT NULL;

-- ============================================================================
-- 15. PAYMENTS (Tenant-scoped)
-- ============================================================================
CREATE TABLE payments (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    invoice_id      UUID NOT NULL REFERENCES invoices(id),
    client_id       UUID NOT NULL REFERENCES clients(id),
    
    -- Payment info
    amount          DECIMAL(12,2) NOT NULL CHECK (amount > 0),
    currency        VARCHAR(3) NOT NULL DEFAULT 'ILS',
    payment_date    DATE NOT NULL,
    payment_method  VARCHAR(50) NOT NULL,          -- cash, check, bank_transfer, credit_card, other
    
    -- Reference
    reference_number VARCHAR(100),                 -- Check number, transaction ID, etc.
    notes           TEXT,
    
    -- Timestamps
    recorded_by     UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ
);

CREATE INDEX idx_payments_tenant ON payments(tenant_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_payments_invoice ON payments(invoice_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_payments_client ON payments(client_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_payments_date ON payments(payment_date) WHERE deleted_at IS NULL;
CREATE INDEX idx_payments_deleted_at ON payments(deleted_at);

-- ============================================================================
-- 16. TRUST_ACCOUNTS (Tenant-scoped, for client trust fund management)
-- ============================================================================
CREATE TABLE trust_accounts (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    client_id       UUID NOT NULL REFERENCES clients(id),
    
    -- Account info
    account_name    VARCHAR(255) NOT NULL,
    account_number  VARCHAR(100),                  -- External bank account reference
    currency        VARCHAR(3) NOT NULL DEFAULT 'ILS',
    
    -- Balance (denormalized for performance, validated by triggers)
    balance         DECIMAL(15,2) NOT NULL DEFAULT 0,
    
    -- Status
    is_active       BOOLEAN DEFAULT TRUE,
    
    -- Timestamps
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ,
    
    CONSTRAINT uq_trust_tenant_client UNIQUE (tenant_id, client_id)
);

CREATE INDEX idx_trust_accounts_tenant ON trust_accounts(tenant_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_trust_accounts_client ON trust_accounts(client_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_trust_accounts_deleted_at ON trust_accounts(deleted_at);

-- ============================================================================
-- 17. TRUST_TRANSACTIONS (APPEND-ONLY - No updates or deletes allowed)
-- Israeli Bar Association requires complete audit trail
-- ============================================================================
CREATE TABLE trust_transactions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id),
    trust_account_id UUID NOT NULL REFERENCES trust_accounts(id),
    client_id       UUID NOT NULL REFERENCES clients(id),
    case_id         UUID REFERENCES cases(id),
    
    -- Transaction type
    transaction_type VARCHAR(20) NOT NULL,
                    -- deposit, withdrawal, transfer_in, transfer_out, fee_deduction, refund
    
    -- Amount (positive for deposits, negative for withdrawals)
    amount          DECIMAL(15,2) NOT NULL,
    currency        VARCHAR(3) NOT NULL DEFAULT 'ILS',
    
    -- Running balance (calculated at insert time)
    balance_after   DECIMAL(15,2) NOT NULL,
    
    -- Description
    description     TEXT NOT NULL,
    
    -- References (for audit trail)
    invoice_id      UUID REFERENCES invoices(id),
    payment_id      UUID REFERENCES payments(id),
    
    -- For transfers between trust accounts
    related_transaction_id UUID REFERENCES trust_transactions(id),
    
    -- External reference
    reference_number VARCHAR(100),                 -- Bank reference, check number, etc.
    
    -- Metadata
    created_by      UUID NOT NULL REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- NO updated_at - transactions are immutable
    -- NO deleted_at - transactions cannot be deleted
    
    CONSTRAINT chk_trust_tx_type CHECK (transaction_type IN (
        'deposit', 'withdrawal', 'transfer_in', 'transfer_out', 'fee_deduction', 'refund'
    ))
);

-- CRITICAL: Indexes for trust transactions (no deleted_at filter - all are permanent)
CREATE INDEX idx_trust_tx_tenant ON trust_transactions(tenant_id);
CREATE INDEX idx_trust_tx_account ON trust_transactions(trust_account_id);
CREATE INDEX idx_trust_tx_client ON trust_transactions(client_id);
CREATE INDEX idx_trust_tx_case ON trust_transactions(case_id) WHERE case_id IS NOT NULL;
CREATE INDEX idx_trust_tx_date ON trust_transactions(created_at);
CREATE INDEX idx_trust_tx_invoice ON trust_transactions(invoice_id) WHERE invoice_id IS NOT NULL;

-- ============================================================================
-- 18. INVOICE_COUNTER (Per-tenant sequential numbering)
-- ============================================================================
CREATE TABLE invoice_counters (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE UNIQUE,
    prefix          VARCHAR(20) DEFAULT 'INV',
    current_number  INTEGER NOT NULL DEFAULT 1000,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_invoice_counters_tenant ON invoice_counters(tenant_id);

-- ============================================================================
-- 19. CUSTOM_FIELD_DEFINITIONS (Tenant-scoped)
-- ============================================================================
CREATE TABLE custom_field_definitions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    
    -- Which entity this field applies to
    entity_type     VARCHAR(50) NOT NULL,          -- client, case, task, document, invoice
    
    -- Field definition
    field_key       VARCHAR(100) NOT NULL,         -- Internal key (snake_case)
    label           VARCHAR(255) NOT NULL,         -- Display label (English)
    label_he        VARCHAR(255),                  -- Hebrew label
    
    -- Field type
    field_type      VARCHAR(20) NOT NULL,
                    -- text, textarea, number, decimal, date, datetime, boolean, 
                    -- select, multi_select, url, email, phone
    
    -- Options for select/multi_select (JSON array)
    options_json    JSONB,                         -- [{"value": "x", "label": "X", "label_he": "א"}]
    
    -- Validation
    is_required     BOOLEAN DEFAULT FALSE,
    min_value       DECIMAL(15,2),                 -- For number/decimal
    max_value       DECIMAL(15,2),
    min_length      INTEGER,                       -- For text
    max_length      INTEGER,
    regex_pattern   VARCHAR(500),
    
    -- Display
    display_order   INTEGER DEFAULT 0,
    is_visible      BOOLEAN DEFAULT TRUE,
    placeholder     VARCHAR(255),
    help_text       TEXT,
    
    -- Timestamps
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ,
    
    CONSTRAINT uq_custom_field_def UNIQUE (tenant_id, entity_type, field_key),
    CONSTRAINT chk_field_type CHECK (field_type IN (
        'text', 'textarea', 'number', 'decimal', 'date', 'datetime', 
        'boolean', 'select', 'multi_select', 'url', 'email', 'phone'
    )),
    CONSTRAINT chk_entity_type CHECK (entity_type IN (
        'client', 'case', 'task', 'document', 'invoice'
    ))
);

CREATE INDEX idx_custom_field_defs_tenant ON custom_field_definitions(tenant_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_custom_field_defs_entity ON custom_field_definitions(tenant_id, entity_type) WHERE deleted_at IS NULL;
CREATE INDEX idx_custom_field_defs_deleted_at ON custom_field_definitions(deleted_at);

-- ============================================================================
-- 20. CUSTOM_FIELD_VALUES (Tenant-scoped)
-- ============================================================================
CREATE TABLE custom_field_values (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    definition_id   UUID NOT NULL REFERENCES custom_field_definitions(id) ON DELETE CASCADE,
    
    -- Which entity instance this value belongs to
    entity_type     VARCHAR(50) NOT NULL,
    entity_id       UUID NOT NULL,
    
    -- Typed value storage (only one should be populated based on field_type)
    value_text      TEXT,
    value_number    DECIMAL(15,4),
    value_date      DATE,
    value_datetime  TIMESTAMPTZ,
    value_bool      BOOLEAN,
    value_json      JSONB,                         -- For multi_select and complex types
    
    -- Timestamps
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_custom_field_value UNIQUE (tenant_id, definition_id, entity_type, entity_id),
    CONSTRAINT chk_cf_entity_type CHECK (entity_type IN (
        'client', 'case', 'task', 'document', 'invoice'
    ))
);

CREATE INDEX idx_custom_field_values_tenant ON custom_field_values(tenant_id);
CREATE INDEX idx_custom_field_values_definition ON custom_field_values(definition_id);
CREATE INDEX idx_custom_field_values_entity ON custom_field_values(entity_type, entity_id);
CREATE INDEX idx_custom_field_values_lookup ON custom_field_values(tenant_id, entity_type, entity_id);

-- ============================================================================
-- 21. SETTINGS (Tenant and User level)
-- ============================================================================
CREATE TABLE settings (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id         UUID REFERENCES users(id) ON DELETE CASCADE, -- NULL = tenant-level setting
    
    -- Setting identification
    category        VARCHAR(100) NOT NULL,         -- general, billing, notifications, appearance
    key             VARCHAR(100) NOT NULL,
    
    -- Value
    value_json      JSONB NOT NULL,
    
    -- Timestamps
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- Unique per tenant+user+category+key
    CONSTRAINT uq_settings UNIQUE (tenant_id, user_id, category, key)
);

CREATE INDEX idx_settings_tenant ON settings(tenant_id);
CREATE INDEX idx_settings_user ON settings(user_id) WHERE user_id IS NOT NULL;
CREATE INDEX idx_settings_lookup ON settings(tenant_id, category, key);

-- ============================================================================
-- 22. AUDIT_LOGS (APPEND-ONLY in audit schema)
-- 7-year retention per Israeli tax law
-- ============================================================================
CREATE TABLE audit.logs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL,                 -- No FK - tenant may be deleted but logs remain
    
    -- Actor info
    user_id         UUID,
    user_email      VARCHAR(255),
    user_name       VARCHAR(255),
    ip_address      INET,
    user_agent      TEXT,
    
    -- Action
    action          VARCHAR(50) NOT NULL,
                    -- CREATE, READ, UPDATE, DELETE, LOGIN, LOGOUT, EXPORT, PRINT, ERROR
    action_category VARCHAR(50),                   -- entity, auth, system, security
    
    -- Target
    entity_type     VARCHAR(50),
    entity_id       UUID,
    
    -- Data
    description     TEXT,
    changes_json    JSONB,                         -- {field: {from: x, to: y}}
    request_json    JSONB,                         -- Sanitized request data
    
    -- Session
    session_id      VARCHAR(100),
    
    -- Integrity
    previous_hash   VARCHAR(64),                   -- SHA-256 of previous log entry
    entry_hash      VARCHAR(64) NOT NULL,          -- SHA-256 of this entry
    
    -- Retention
    retention_date  DATE NOT NULL,                 -- When this log can be deleted
    is_financial    BOOLEAN DEFAULT FALSE,         -- Financial logs have 7-year retention
    
    -- Timestamp (immutable)
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
    
    -- NO updated_at - logs are immutable
    -- NO deleted_at - logs cannot be soft-deleted
);

-- CRITICAL: Indexes for audit logs (no soft delete)
CREATE INDEX idx_audit_logs_tenant ON audit.logs(tenant_id);
CREATE INDEX idx_audit_logs_user ON audit.logs(user_id) WHERE user_id IS NOT NULL;
CREATE INDEX idx_audit_logs_action ON audit.logs(action);
CREATE INDEX idx_audit_logs_entity ON audit.logs(entity_type, entity_id) WHERE entity_id IS NOT NULL;
CREATE INDEX idx_audit_logs_created ON audit.logs(created_at);
CREATE INDEX idx_audit_logs_retention ON audit.logs(retention_date);
CREATE INDEX idx_audit_logs_hash ON audit.logs(entry_hash);

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- 1. Updated_at trigger for all tables with updated_at column
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply to all relevant tables
CREATE TRIGGER trg_tenants_updated_at BEFORE UPDATE ON tenants FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_clients_updated_at BEFORE UPDATE ON clients FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_cases_updated_at BEFORE UPDATE ON cases FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_tasks_updated_at BEFORE UPDATE ON tasks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_documents_updated_at BEFORE UPDATE ON documents FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_events_updated_at BEFORE UPDATE ON calendar_events FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_time_updated_at BEFORE UPDATE ON time_entries FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_invoices_updated_at BEFORE UPDATE ON invoices FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_trust_accounts_updated_at BEFORE UPDATE ON trust_accounts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_custom_field_defs_updated_at BEFORE UPDATE ON custom_field_definitions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_custom_field_vals_updated_at BEFORE UPDATE ON custom_field_values FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_settings_updated_at BEFORE UPDATE ON settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 2. Prevent modifications to trust_transactions (APPEND-ONLY)
CREATE OR REPLACE FUNCTION prevent_trust_tx_modification()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'Trust transactions are immutable. Updates and deletes are not allowed.';
END;
$$ language 'plpgsql';

CREATE TRIGGER trg_trust_tx_no_update BEFORE UPDATE ON trust_transactions FOR EACH ROW EXECUTE FUNCTION prevent_trust_tx_modification();
CREATE TRIGGER trg_trust_tx_no_delete BEFORE DELETE ON trust_transactions FOR EACH ROW EXECUTE FUNCTION prevent_trust_tx_modification();

-- 3. Prevent modifications to audit logs (APPEND-ONLY)
CREATE OR REPLACE FUNCTION prevent_audit_modification()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'Audit logs are immutable. Updates and deletes are not allowed.';
END;
$$ language 'plpgsql';

CREATE TRIGGER trg_audit_no_update BEFORE UPDATE ON audit.logs FOR EACH ROW EXECUTE FUNCTION prevent_audit_modification();
CREATE TRIGGER trg_audit_no_delete BEFORE DELETE ON audit.logs FOR EACH ROW EXECUTE FUNCTION prevent_audit_modification();

-- 4. Update trust account balance on transaction insert
CREATE OR REPLACE FUNCTION update_trust_account_balance()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE trust_accounts 
    SET balance = balance + NEW.amount,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = NEW.trust_account_id;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER trg_trust_tx_update_balance AFTER INSERT ON trust_transactions FOR EACH ROW EXECUTE FUNCTION update_trust_account_balance();

-- 5. Calculate trust transaction balance_after
CREATE OR REPLACE FUNCTION calculate_trust_balance_after()
RETURNS TRIGGER AS $$
DECLARE
    current_balance DECIMAL(15,2);
BEGIN
    SELECT balance INTO current_balance 
    FROM trust_accounts 
    WHERE id = NEW.trust_account_id;
    
    NEW.balance_after = COALESCE(current_balance, 0) + NEW.amount;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER trg_trust_tx_balance_before BEFORE INSERT ON trust_transactions FOR EACH ROW EXECUTE FUNCTION calculate_trust_balance_after();

-- 6. Validate tenant consistency (client must belong to same tenant as case)
CREATE OR REPLACE FUNCTION validate_case_client_tenant()
RETURNS TRIGGER AS $$
DECLARE
    client_tenant UUID;
BEGIN
    SELECT tenant_id INTO client_tenant FROM clients WHERE id = NEW.client_id;
    
    IF client_tenant IS NULL THEN
        RAISE EXCEPTION 'Client not found: %', NEW.client_id;
    END IF;
    
    IF client_tenant != NEW.tenant_id THEN
        RAISE EXCEPTION 'Cross-tenant reference not allowed: case tenant % != client tenant %', NEW.tenant_id, client_tenant;
    END IF;
    
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER trg_cases_validate_tenant BEFORE INSERT OR UPDATE ON cases FOR EACH ROW EXECUTE FUNCTION validate_case_client_tenant();

-- 7. Prevent invoice modification after issuance (except status changes)
CREATE OR REPLACE FUNCTION prevent_issued_invoice_modification()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.issued_at IS NOT NULL THEN
        -- Only allow specific field changes after issuance
        IF (NEW.subtotal != OLD.subtotal OR 
            NEW.vat_amount != OLD.vat_amount OR 
            NEW.total != OLD.total OR
            NEW.invoice_number != OLD.invoice_number OR
            NEW.invoice_type != OLD.invoice_type OR
            NEW.issue_date != OLD.issue_date OR
            NEW.client_id != OLD.client_id) THEN
            RAISE EXCEPTION 'Cannot modify issued invoice core fields. Create a credit note instead.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER trg_invoice_immutability BEFORE UPDATE ON invoices FOR EACH ROW EXECUTE FUNCTION prevent_issued_invoice_modification();

-- ============================================================================
-- VIEWS (for common soft-delete filtered queries)
-- ============================================================================

CREATE VIEW active_tenants AS SELECT * FROM tenants WHERE deleted_at IS NULL;
CREATE VIEW active_users AS SELECT * FROM users WHERE deleted_at IS NULL;
CREATE VIEW active_clients AS SELECT * FROM clients WHERE deleted_at IS NULL;
CREATE VIEW active_cases AS SELECT * FROM cases WHERE deleted_at IS NULL;
CREATE VIEW active_tasks AS SELECT * FROM tasks WHERE deleted_at IS NULL;
CREATE VIEW active_documents AS SELECT * FROM documents WHERE deleted_at IS NULL;
CREATE VIEW active_events AS SELECT * FROM calendar_events WHERE deleted_at IS NULL;
CREATE VIEW active_time_entries AS SELECT * FROM time_entries WHERE deleted_at IS NULL;
CREATE VIEW active_invoices AS SELECT * FROM invoices WHERE deleted_at IS NULL;
CREATE VIEW active_payments AS SELECT * FROM payments WHERE deleted_at IS NULL;
CREATE VIEW active_trust_accounts AS SELECT * FROM trust_accounts WHERE deleted_at IS NULL;

COMMIT;
