-- ============================================
-- LEXMANAGER PostgreSQL Initialization
-- Run automatically on first container start
-- ============================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- For fuzzy text search (Hebrew support)

-- Create schemas
CREATE SCHEMA IF NOT EXISTS audit;

-- Set default timezone for Israeli operations
SET timezone = 'Asia/Jerusalem';

-- Grant permissions
GRANT ALL PRIVILEGES ON DATABASE lexmanager TO lexmanager;
GRANT ALL PRIVILEGES ON SCHEMA public TO lexmanager;
GRANT ALL PRIVILEGES ON SCHEMA audit TO lexmanager;

-- Create trigger function for updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create function for audit log triggers (immutable append-only)
CREATE OR REPLACE FUNCTION prevent_audit_modification()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'Audit log entries cannot be modified or deleted';
END;
$$ language 'plpgsql';

-- Create function to calculate retention date (7 years for Israeli tax compliance)
CREATE OR REPLACE FUNCTION calculate_retention_date(days_to_retain INTEGER DEFAULT 2557)
RETURNS DATE AS $$
BEGIN
    RETURN CURRENT_DATE + days_to_retain;
END;
$$ language 'plpgsql';

-- Log successful initialization
DO $$
BEGIN
    RAISE NOTICE 'LexManager PostgreSQL initialized successfully at %', NOW();
END;
$$;
