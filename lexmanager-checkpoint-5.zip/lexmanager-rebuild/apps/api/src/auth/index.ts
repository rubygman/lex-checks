// ============================================================================
// AUTH MODULE INDEX
// apps/api/src/auth/index.ts
// ============================================================================

export {
  // Authorizer
  Authorizer,
  TenantAuthorizer,
  authorizer,
  
  // Error classes
  AuthenticationError,
  AuthorizationError,
  TenantAccessError,
  
  // Types
  type AuthContext,
  type RequestContext,
  
  // Re-exported permissions
  PERMISSIONS,
  type PermissionCode,
} from './authorizer.js';
