// ============================================================================
// SOFT DELETE INTEGRATION TESTS
// apps/api/tests/integration/soft-delete/soft-delete.integration.test.ts
// ============================================================================

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import pg from 'pg';
import { softDeleteService, SOFT_DELETE_TABLES } from '../../../src/services/soft-delete.service.js';
import { clientRepository } from '../../../src/repositories/index.js';
import { NotFoundError, DatabaseError } from '../../../src/db/errors.js';

const { Pool } = pg;

// Skip if no database connection
const DATABASE_URL = process.env.DATABASE_URL;
const shouldRun = DATABASE_URL && DATABASE_URL.includes('localhost');

describe.skipIf(!shouldRun)('Soft Delete Integration', () => {
  let pool: pg.Pool;
  let tenantId: string;
  let userId: string;
  let clientId: string;
  let caseId: string;
  let taskId: string;

  beforeAll(async () => {
    pool = new Pool({ connectionString: DATABASE_URL });

    // Get admin role ID
    const roleResult = await pool.query("SELECT id FROM roles WHERE name = 'admin' LIMIT 1");
    const adminRoleId = roleResult.rows[0].id;

    // Create test tenant
    const tenantResult = await pool.query(
      "INSERT INTO tenants (name, slug) VALUES ('Soft Delete Test Tenant', $1) RETURNING id",
      [`soft-delete-test-${Date.now()}`]
    );
    tenantId = tenantResult.rows[0].id;

    // Create test user
    const userResult = await pool.query(
      `INSERT INTO users (tenant_id, email, password_hash, name, role_id)
       VALUES ($1, $2, 'hash', 'Test User', $3) RETURNING id`,
      [tenantId, `test-${Date.now()}@test.com`, adminRoleId]
    );
    userId = userResult.rows[0].id;
  });

  afterAll(async () => {
    // Cleanup
    await pool.query('DELETE FROM tenants WHERE id = $1', [tenantId]);
    await pool.end();
  });

  beforeEach(async () => {
    // Create fresh test data for each test
    const clientResult = await pool.query(
      `INSERT INTO clients (tenant_id, name, client_type, status, address_country, currency, payment_terms)
       VALUES ($1, 'Test Client', 'individual', 'active', 'Israel', 'ILS', 30) RETURNING id`,
      [tenantId]
    );
    clientId = clientResult.rows[0].id;

    const caseResult = await pool.query(
      `INSERT INTO cases (tenant_id, client_id, title, case_type, status)
       VALUES ($1, $2, 'Test Case', 'Civil', 'active') RETURNING id`,
      [tenantId, clientId]
    );
    caseId = caseResult.rows[0].id;

    const taskResult = await pool.query(
      `INSERT INTO tasks (tenant_id, case_id, client_id, title, status)
       VALUES ($1, $2, $3, 'Test Task', 'todo') RETURNING id`,
      [tenantId, caseId, clientId]
    );
    taskId = taskResult.rows[0].id;
  });

  // ============================================================================
  // SOFT DELETE BEHAVIOR
  // ============================================================================

  describe('Soft Delete Behavior', () => {
    it('should soft delete a record by setting deleted_at', async () => {
      const result = await softDeleteService.softDelete(tenantId, 'tasks', taskId, {
        deletedBy: userId,
      });

      expect(result.deleted).toBe(true);
      expect(result.retentionId).toBeDefined();

      // Verify deleted_at is set
      const checkResult = await pool.query(
        'SELECT deleted_at FROM tasks WHERE id = $1',
        [taskId]
      );
      expect(checkResult.rows[0].deleted_at).not.toBeNull();
    });

    it('should track soft delete in retention table', async () => {
      await softDeleteService.softDelete(tenantId, 'tasks', taskId, {
        deletedBy: userId,
      });

      const retentionResult = await pool.query(
        "SELECT * FROM soft_delete_retention WHERE table_name = 'tasks' AND record_id = $1",
        [taskId]
      );

      expect(retentionResult.rows).toHaveLength(1);
      expect(retentionResult.rows[0].tenant_id).toBe(tenantId);
      expect(retentionResult.rows[0].deleted_by).toBe(userId);
    });

    it('should set retention period based on table configuration', async () => {
      await softDeleteService.softDelete(tenantId, 'tasks', taskId);

      const retentionResult = await pool.query(
        "SELECT retention_days FROM soft_delete_retention WHERE table_name = 'tasks' AND record_id = $1",
        [taskId]
      );

      // Tasks have 365 day retention (1 year)
      expect(retentionResult.rows[0].retention_days).toBe(365);
    });

    it('should mark financial records with is_financial flag', async () => {
      await softDeleteService.softDelete(tenantId, 'clients', clientId);

      const retentionResult = await pool.query(
        "SELECT is_financial FROM soft_delete_retention WHERE table_name = 'clients' AND record_id = $1",
        [clientId]
      );

      // Clients are marked as financial
      expect(retentionResult.rows[0].is_financial).toBe(true);
    });

    it('should throw NotFoundError for non-existent record', async () => {
      const fakeId = '00000000-0000-0000-0000-000000000000';
      
      await expect(
        softDeleteService.softDelete(tenantId, 'tasks', fakeId)
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw NotFoundError for already deleted record', async () => {
      // Delete once
      await softDeleteService.softDelete(tenantId, 'tasks', taskId);

      // Try to delete again
      await expect(
        softDeleteService.softDelete(tenantId, 'tasks', taskId)
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================================
  // DEFAULT EXCLUSION (deleted rows never show up)
  // ============================================================================

  describe('Default Exclusion of Deleted Rows', () => {
    it('should NOT return deleted records in repository queries', async () => {
      // First verify client exists
      const beforeDelete = await clientRepository.findById(tenantId, clientId);
      expect(beforeDelete).not.toBeNull();

      // Soft delete
      await softDeleteService.softDelete(tenantId, 'clients', clientId);

      // Should not find via repository
      const afterDelete = await clientRepository.findById(tenantId, clientId);
      expect(afterDelete).toBeNull();
    });

    it('should NOT return deleted records in list queries', async () => {
      // Get count before
      const beforeResult = await clientRepository.list(tenantId);
      const countBefore = beforeResult.data.length;

      // Soft delete
      await softDeleteService.softDelete(tenantId, 'clients', clientId);

      // Get count after
      const afterResult = await clientRepository.list(tenantId);
      expect(afterResult.data.length).toBe(countBefore - 1);
    });

    it('should NOT return deleted records from active_* views', async () => {
      // Soft delete
      await softDeleteService.softDelete(tenantId, 'clients', clientId);

      // Check active_clients view
      const viewResult = await pool.query(
        'SELECT * FROM active_clients WHERE id = $1',
        [clientId]
      );
      expect(viewResult.rows).toHaveLength(0);
    });

    it('should return deleted records when includeDeleted=true', async () => {
      // Soft delete
      await softDeleteService.softDelete(tenantId, 'clients', clientId);

      // Should find with includeDeleted
      const found = await clientRepository.findById(tenantId, clientId, { includeDeleted: true });
      expect(found).not.toBeNull();
      expect(found!.deleted_at).not.toBeNull();
    });
  });

  // ============================================================================
  // RESTORATION
  // ============================================================================

  describe('Record Restoration', () => {
    it('should restore a soft-deleted record', async () => {
      // Delete
      await softDeleteService.softDelete(tenantId, 'tasks', taskId);

      // Verify deleted
      const afterDelete = await pool.query(
        'SELECT deleted_at FROM tasks WHERE id = $1',
        [taskId]
      );
      expect(afterDelete.rows[0].deleted_at).not.toBeNull();

      // Restore
      const result = await softDeleteService.restore(tenantId, 'tasks', taskId);
      expect(result.restored).toBe(true);

      // Verify restored
      const afterRestore = await pool.query(
        'SELECT deleted_at FROM tasks WHERE id = $1',
        [taskId]
      );
      expect(afterRestore.rows[0].deleted_at).toBeNull();
    });

    it('should remove retention tracking on restore', async () => {
      // Delete
      await softDeleteService.softDelete(tenantId, 'tasks', taskId);

      // Verify retention entry exists
      const beforeRestore = await pool.query(
        "SELECT * FROM soft_delete_retention WHERE table_name = 'tasks' AND record_id = $1",
        [taskId]
      );
      expect(beforeRestore.rows).toHaveLength(1);

      // Restore
      await softDeleteService.restore(tenantId, 'tasks', taskId);

      // Verify retention entry removed
      const afterRestore = await pool.query(
        "SELECT * FROM soft_delete_retention WHERE table_name = 'tasks' AND record_id = $1",
        [taskId]
      );
      expect(afterRestore.rows).toHaveLength(0);
    });

    it('should throw error when restoring non-deleted record', async () => {
      await expect(
        softDeleteService.restore(tenantId, 'tasks', taskId)
      ).rejects.toThrow(/not deleted/i);
    });

    it('should throw error when parent is deleted', async () => {
      // Delete parent case
      await softDeleteService.softDelete(tenantId, 'cases', caseId);

      // Delete task
      await pool.query(
        'UPDATE tasks SET deleted_at = CURRENT_TIMESTAMP WHERE id = $1',
        [taskId]
      );

      // Try to restore task (should fail because parent case is deleted)
      await expect(
        softDeleteService.restore(tenantId, 'tasks', taskId)
      ).rejects.toThrow(/parent.*deleted/i);
    });

    it('should restore related records with restoreRelated=true', async () => {
      // Delete case (which should cascade to task)
      await softDeleteService.softDelete(tenantId, 'cases', caseId);

      // Verify task is deleted
      const taskCheck = await pool.query(
        'SELECT deleted_at FROM tasks WHERE id = $1',
        [taskId]
      );
      expect(taskCheck.rows[0].deleted_at).not.toBeNull();

      // Restore case with related
      await softDeleteService.restore(tenantId, 'cases', caseId, { restoreRelated: true });

      // Verify task is restored
      const taskAfter = await pool.query(
        'SELECT deleted_at FROM tasks WHERE id = $1',
        [taskId]
      );
      expect(taskAfter.rows[0].deleted_at).toBeNull();
    });
  });

  // ============================================================================
  // CASCADE SOFT DELETE
  // ============================================================================

  describe('Cascade Soft Delete', () => {
    it('should cascade soft delete to related records', async () => {
      // Delete client (should cascade to case and task)
      await softDeleteService.softDelete(tenantId, 'clients', clientId);

      // Verify case is deleted
      const caseCheck = await pool.query(
        'SELECT deleted_at FROM cases WHERE id = $1',
        [caseId]
      );
      expect(caseCheck.rows[0].deleted_at).not.toBeNull();

      // Verify task is deleted
      const taskCheck = await pool.query(
        'SELECT deleted_at FROM tasks WHERE id = $1',
        [taskId]
      );
      expect(taskCheck.rows[0].deleted_at).not.toBeNull();
    });

    it('should track all cascaded records in retention', async () => {
      // Delete client
      await softDeleteService.softDelete(tenantId, 'clients', clientId);

      // Check retention for all records
      const retentionResult = await pool.query(
        'SELECT table_name, record_id FROM soft_delete_retention WHERE tenant_id = $1',
        [tenantId]
      );

      const tables = retentionResult.rows.map(r => r.table_name);
      expect(tables).toContain('clients');
      expect(tables).toContain('cases');
      expect(tables).toContain('tasks');
    });
  });

  // ============================================================================
  // LISTING & STATS
  // ============================================================================

  describe('Listing Soft-Deleted Records', () => {
    it('should list all soft-deleted records for tenant', async () => {
      // Delete some records
      await softDeleteService.softDelete(tenantId, 'tasks', taskId);

      const deleted = await softDeleteService.listDeleted(tenantId);

      expect(deleted.length).toBeGreaterThan(0);
      expect(deleted[0].table_name).toBe('tasks');
      expect(deleted[0].record_id).toBe(taskId);
      expect(deleted[0].days_until_hard_delete).toBeGreaterThan(0);
    });

    it('should filter by table name', async () => {
      // Delete task and case
      await softDeleteService.softDelete(tenantId, 'tasks', taskId);
      await softDeleteService.softDelete(tenantId, 'cases', caseId);

      const tasksOnly = await softDeleteService.listDeleted(tenantId, { table: 'tasks' });

      expect(tasksOnly.every(r => r.table_name === 'tasks')).toBe(true);
    });

    it('should return soft delete statistics', async () => {
      // Delete some records
      await softDeleteService.softDelete(tenantId, 'clients', clientId);

      const stats = await softDeleteService.getStats(tenantId);

      expect(stats.length).toBeGreaterThan(0);
      const clientStats = stats.find(s => s.table_name === 'clients');
      expect(clientStats).toBeDefined();
      expect(clientStats!.deleted_count).toBeGreaterThan(0);
    });
  });

  // ============================================================================
  // HELPER METHODS
  // ============================================================================

  describe('Helper Methods', () => {
    it('should check if record is deleted', async () => {
      // Before delete
      expect(await softDeleteService.isDeleted(tenantId, 'tasks', taskId)).toBe(false);

      // After delete
      await softDeleteService.softDelete(tenantId, 'tasks', taskId);
      expect(await softDeleteService.isDeleted(tenantId, 'tasks', taskId)).toBe(true);
    });

    it('should find record including deleted', async () => {
      await softDeleteService.softDelete(tenantId, 'tasks', taskId);

      const record = await softDeleteService.findIncludingDeleted(tenantId, 'tasks', taskId);

      expect(record).not.toBeNull();
      expect((record as any).deleted_at).not.toBeNull();
    });
  });
});

describe.skipIf(!shouldRun)('Retention Cleanup Job', () => {
  // Note: Actual retention cleanup tests would require manipulating timestamps
  // These are placeholder tests for the job structure

  it('should have documented retention periods', () => {
    // Verify retention periods are documented
    expect(SOFT_DELETE_TABLES.clients.retentionDays).toBe(365 * 7); // 7 years
    expect(SOFT_DELETE_TABLES.tasks.retentionDays).toBe(365);       // 1 year
    expect(SOFT_DELETE_TABLES.invoices.retentionDays).toBe(365 * 7); // 7 years (financial)
  });

  it('should mark financial tables correctly', () => {
    expect(SOFT_DELETE_TABLES.clients.isFinancial).toBe(true);
    expect(SOFT_DELETE_TABLES.invoices.isFinancial).toBe(true);
    expect(SOFT_DELETE_TABLES.tasks.isFinancial).toBe(false);
  });
});
