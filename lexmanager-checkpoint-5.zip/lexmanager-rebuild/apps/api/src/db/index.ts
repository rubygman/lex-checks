// ============================================================================
// DATABASE LAYER INDEX
// apps/api/src/db/index.ts
// ============================================================================

// Connection & Pool
export {
  pool,
  query,
  getClient,
  withTransaction,
  healthCheck,
  closePool,
} from './connection.js';

// Query Builder
export {
  QueryBuilder,
  createQueryBuilder,
  buildInsert,
  buildUpdate,
  buildSoftDelete,
  buildHardDelete,
  IMMUTABLE_TABLES,
  GLOBAL_TABLES,
  SOFT_DELETE_TABLES,
  type QueryOptions,
  type PaginationOptions,
  type SortOptions,
  type SortDirection,
} from './query-builder.js';

// Errors
export {
  DatabaseError,
  TenantScopingError,
  ImmutableTableError,
  NotFoundError,
  DuplicateError,
  ForeignKeyError,
  CrossTenantAccessError,
  parsePostgresError,
} from './errors.js';
