// ============================================================================
// IDENTITY LAYER INTEGRATION TESTS
// apps/api/tests/integration/identity/identity.integration.test.ts
// ============================================================================

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import pg from 'pg';
import { tenantService } from '../../../src/services/tenant.service.js';
import { userService } from '../../../src/services/user.service.js';
import { rbacService, PERMISSIONS, ROLES } from '../../../src/services/rbac.service.js';
import { roleRepository } from '../../../src/repositories/rbac.repository.js';

const { Pool } = pg;

// Skip if no database connection
const DATABASE_URL = process.env.DATABASE_URL;
const shouldRun = DATABASE_URL && DATABASE_URL.includes('localhost');

describe.skipIf(!shouldRun)('Identity Layer Integration', () => {
  let pool: pg.Pool;
  let testTenantId: string;
  let adminUserId: string;
  let attorneyUserId: string;
  let staffUserId: string;

  beforeAll(async () => {
    pool = new Pool({ connectionString: DATABASE_URL });
  });

  afterAll(async () => {
    // Cleanup test tenants
    if (testTenantId) {
      await pool.query('DELETE FROM tenants WHERE id = $1', [testTenantId]);
    }
    // Clean up any test tenants created during tests
    await pool.query("DELETE FROM tenants WHERE slug LIKE 'test-%'");
    await pool.end();
  });

  describe('Full Tenant Creation Flow', () => {
    it('should create a tenant with admin user', async () => {
      const result = await tenantService.createTenant({
        tenant: {
          name: 'Test Law Firm',
          slug: `test-firm-${Date.now()}`,
        },
        admin: {
          email: `admin-${Date.now()}@test.com`,
          password: 'SecurePass123',
          name: 'Test Admin',
          name_he: 'מנהל בדיקה',
        },
      });

      testTenantId = result.tenant.id;
      adminUserId = result.adminUser.id;

      expect(result.tenant).toBeDefined();
      expect(result.tenant.id).toBeDefined();
      expect(result.tenant.name).toBe('Test Law Firm');
      expect(result.tenant.plan).toBe('trial');
      expect(result.tenant.is_active).toBe(true);

      expect(result.adminUser).toBeDefined();
      expect(result.adminUser.id).toBeDefined();
    });

    it('should retrieve tenant by slug', async () => {
      const tenant = await tenantService.getById(testTenantId);
      
      expect(tenant).not.toBeNull();
      expect(tenant!.id).toBe(testTenantId);
    });

    it('should not allow duplicate slugs', async () => {
      const slug = `test-duplicate-${Date.now()}`;
      
      // Create first tenant
      const first = await tenantService.createTenant({
        tenant: { name: 'First Tenant', slug },
        admin: {
          email: `first-${Date.now()}@test.com`,
          password: 'SecurePass123',
          name: 'First Admin',
        },
      });

      // Try to create second tenant with same slug
      await expect(
        tenantService.createTenant({
          tenant: { name: 'Second Tenant', slug },
          admin: {
            email: `second-${Date.now()}@test.com`,
            password: 'SecurePass123',
            name: 'Second Admin',
          },
        })
      ).rejects.toThrow(/slug/i);

      // Cleanup
      await pool.query('DELETE FROM tenants WHERE id = $1', [first.tenant.id]);
    });
  });

  describe('User Management', () => {
    it('should create additional users in tenant', async () => {
      const attorneyRole = await roleRepository.findByName(ROLES.ATTORNEY);
      expect(attorneyRole).toBeDefined();

      const user = await userService.createUser(testTenantId, {
        email: `attorney-${Date.now()}@test.com`,
        password: 'SecurePass123',
        name: 'Test Attorney',
        role_id: attorneyRole!.id,
      });

      attorneyUserId = user.id;

      expect(user).toBeDefined();
      expect(user.tenant_id).toBe(testTenantId);
      expect(user.role_id).toBe(attorneyRole!.id);
      expect(user.is_active).toBe(true);
    });

    it('should create staff user', async () => {
      const staffRole = await roleRepository.findByName(ROLES.STAFF);
      expect(staffRole).toBeDefined();

      const user = await userService.createUser(testTenantId, {
        email: `staff-${Date.now()}@test.com`,
        password: 'SecurePass123',
        name: 'Test Staff',
        role_id: staffRole!.id,
      });

      staffUserId = user.id;

      expect(user).toBeDefined();
      expect(user.role_id).toBe(staffRole!.id);
    });

    it('should not allow duplicate emails within tenant', async () => {
      const email = `duplicate-${Date.now()}@test.com`;
      const attorneyRole = await roleRepository.findByName(ROLES.ATTORNEY);

      // Create first user
      await userService.createUser(testTenantId, {
        email,
        password: 'SecurePass123',
        name: 'First User',
        role_id: attorneyRole!.id,
      });

      // Try to create second user with same email
      await expect(
        userService.createUser(testTenantId, {
          email,
          password: 'SecurePass123',
          name: 'Second User',
          role_id: attorneyRole!.id,
        })
      ).rejects.toThrow(/email/i);
    });

    it('should list users in tenant', async () => {
      const users = await userService.listUsers(testTenantId);

      expect(users.length).toBeGreaterThanOrEqual(3); // admin + attorney + staff
      expect(users.every(u => u.tenant_id === testTenantId)).toBe(true);
    });

    it('should deactivate and reactivate user', async () => {
      // Deactivate
      const deactivated = await userService.deactivate(testTenantId, staffUserId);
      expect(deactivated.is_active).toBe(false);

      // Reactivate
      const reactivated = await userService.activate(testTenantId, staffUserId);
      expect(reactivated.is_active).toBe(true);
    });

    it('should assign new role to user', async () => {
      const paralegalRole = await roleRepository.findByName(ROLES.PARALEGAL);
      
      const updated = await userService.assignRole(testTenantId, staffUserId, paralegalRole!.id);
      
      expect(updated.role_id).toBe(paralegalRole!.id);

      // Reset to staff for other tests
      const staffRole = await roleRepository.findByName(ROLES.STAFF);
      await userService.assignRole(testTenantId, staffUserId, staffRole!.id);
    });
  });

  describe('RBAC Permission Checks', () => {
    it('should allow admin to have all permissions', async () => {
      // Admin should have cases_delete permission
      const casesDelete = await rbacService.checkPermission(
        testTenantId, adminUserId, PERMISSIONS.CASES_DELETE
      );
      expect(casesDelete.allowed).toBe(true);

      // Admin should have users_manage permission
      const usersManage = await rbacService.checkPermission(
        testTenantId, adminUserId, PERMISSIONS.USERS_MANAGE
      );
      expect(usersManage.allowed).toBe(true);

      // Admin should have audit_log_view permission
      const auditView = await rbacService.checkPermission(
        testTenantId, adminUserId, PERMISSIONS.AUDIT_LOG_VIEW
      );
      expect(auditView.allowed).toBe(true);
    });

    it('should restrict attorney from admin permissions', async () => {
      // Attorney should NOT have cases_delete
      const casesDelete = await rbacService.checkPermission(
        testTenantId, attorneyUserId, PERMISSIONS.CASES_DELETE
      );
      expect(casesDelete.allowed).toBe(false);

      // Attorney should NOT have users_manage
      const usersManage = await rbacService.checkPermission(
        testTenantId, attorneyUserId, PERMISSIONS.USERS_MANAGE
      );
      expect(usersManage.allowed).toBe(false);

      // But attorney SHOULD have cases_view
      const casesView = await rbacService.checkPermission(
        testTenantId, attorneyUserId, PERMISSIONS.CASES_VIEW
      );
      expect(casesView.allowed).toBe(true);
    });

    it('should restrict staff to limited permissions', async () => {
      // Staff should have cases_view
      const casesView = await rbacService.checkPermission(
        testTenantId, staffUserId, PERMISSIONS.CASES_VIEW
      );
      expect(casesView.allowed).toBe(true);

      // Staff should NOT have cases_create
      const casesCreate = await rbacService.checkPermission(
        testTenantId, staffUserId, PERMISSIONS.CASES_CREATE
      );
      expect(casesCreate.allowed).toBe(false);

      // Staff should NOT have invoices_create
      const invoicesCreate = await rbacService.checkPermission(
        testTenantId, staffUserId, PERMISSIONS.INVOICES_CREATE
      );
      expect(invoicesCreate.allowed).toBe(false);
    });

    it('should get all user permissions', async () => {
      const adminPerms = await rbacService.getUserPermissions(testTenantId, adminUserId);
      
      expect(adminPerms).not.toBeNull();
      expect(adminPerms!.roleName).toBe('admin');
      expect(adminPerms!.permissions.length).toBeGreaterThan(50); // Admin has all permissions
      expect(adminPerms!.permissions).toContain(PERMISSIONS.USERS_MANAGE);
    });

    it('should check multiple permissions with checkAnyPermission', async () => {
      // Staff has cases_view but not cases_create
      const result = await rbacService.checkAnyPermission(
        testTenantId, staffUserId, 
        [PERMISSIONS.CASES_VIEW, PERMISSIONS.CASES_CREATE]
      );
      
      expect(result.allowed).toBe(true); // Has at least one
    });

    it('should check multiple permissions with checkAllPermissions', async () => {
      // Staff has cases_view but not cases_create
      const result = await rbacService.checkAllPermissions(
        testTenantId, staffUserId,
        [PERMISSIONS.CASES_VIEW, PERMISSIONS.CASES_CREATE]
      );
      
      expect(result.allowed).toBe(false); // Missing cases_create
      expect(result.reason).toContain(PERMISSIONS.CASES_CREATE);
    });

    it('should throw on requirePermission when denied', async () => {
      await expect(
        rbacService.requirePermission(testTenantId, staffUserId, PERMISSIONS.USERS_MANAGE)
      ).rejects.toThrow('PERMISSION_DENIED');
    });

    it('should not throw on requirePermission when allowed', async () => {
      await expect(
        rbacService.requirePermission(testTenantId, adminUserId, PERMISSIONS.USERS_MANAGE)
      ).resolves.not.toThrow();
    });

    it('should identify admin users correctly', async () => {
      expect(await rbacService.isAdmin(testTenantId, adminUserId)).toBe(true);
      expect(await rbacService.isAdmin(testTenantId, attorneyUserId)).toBe(false);
      expect(await rbacService.isAdmin(testTenantId, staffUserId)).toBe(false);
    });
  });

  describe('Authentication', () => {
    let authTestEmail: string;
    const authTestPassword = 'AuthTest123';

    beforeAll(async () => {
      authTestEmail = `auth-test-${Date.now()}@test.com`;
      const attorneyRole = await roleRepository.findByName(ROLES.ATTORNEY);
      
      await userService.createUser(testTenantId, {
        email: authTestEmail,
        password: authTestPassword,
        name: 'Auth Test User',
        role_id: attorneyRole!.id,
      });
    });

    it('should authenticate user with correct credentials', async () => {
      const result = await userService.authenticate(
        authTestEmail,
        authTestPassword,
        '127.0.0.1'
      );

      expect(result).not.toBeNull();
      expect(result!.user.email).toBe(authTestEmail.toLowerCase());
      expect(result!.tenantId).toBe(testTenantId);
    });

    it('should reject authentication with wrong password', async () => {
      const result = await userService.authenticate(
        authTestEmail,
        'WrongPassword123',
        '127.0.0.1'
      );

      expect(result).toBeNull();
    });

    it('should reject authentication for non-existent user', async () => {
      const result = await userService.authenticate(
        'nonexistent@test.com',
        'SomePassword123',
        '127.0.0.1'
      );

      expect(result).toBeNull();
    });

    it('should reject authentication for deactivated user', async () => {
      // Create and deactivate a user
      const deactivateEmail = `deactivate-${Date.now()}@test.com`;
      const attorneyRole = await roleRepository.findByName(ROLES.ATTORNEY);
      
      const user = await userService.createUser(testTenantId, {
        email: deactivateEmail,
        password: 'SecurePass123',
        name: 'Deactivate Test',
        role_id: attorneyRole!.id,
      });

      await userService.deactivate(testTenantId, user.id);

      await expect(
        userService.authenticate(deactivateEmail, 'SecurePass123', '127.0.0.1')
      ).rejects.toThrow(/deactivated|inactive/i);
    });
  });

  describe('Tenant Soft Delete', () => {
    it('should soft delete tenant', async () => {
      // Create a tenant to delete
      const { tenant } = await tenantService.createTenant({
        tenant: {
          name: 'Tenant to Delete',
          slug: `test-delete-${Date.now()}`,
        },
        admin: {
          email: `delete-admin-${Date.now()}@test.com`,
          password: 'SecurePass123',
          name: 'Delete Admin',
        },
      });

      // Soft delete
      const deleted = await tenantService.softDeleteTenant(tenant.id);
      
      expect(deleted.deleted_at).not.toBeNull();

      // Should not be findable by default
      const notFound = await tenantService.getById(tenant.id);
      expect(notFound).toBeNull();
    });
  });

  describe('Role-Permission Data Verification', () => {
    it('should have all 4 system roles seeded', async () => {
      const roles = await rbacService.getAllRoles();
      
      expect(roles.length).toBe(4);
      
      const roleNames = roles.map(r => r.name);
      expect(roleNames).toContain('admin');
      expect(roleNames).toContain('attorney');
      expect(roleNames).toContain('paralegal');
      expect(roleNames).toContain('staff');
    });

    it('should have permissions seeded', async () => {
      const permissions = await rbacService.getAllPermissions();
      
      expect(permissions.length).toBeGreaterThan(50);
      
      const codes = permissions.map(p => p.code);
      expect(codes).toContain(PERMISSIONS.CASES_VIEW);
      expect(codes).toContain(PERMISSIONS.USERS_MANAGE);
      expect(codes).toContain(PERMISSIONS.TRUST_VIEW);
    });

    it('should have admin role with all permissions', async () => {
      const adminRole = await roleRepository.findByName('admin');
      const roleWithPerms = await rbacService.getRoleWithPermissions(adminRole!.id);
      
      expect(roleWithPerms).not.toBeNull();
      expect(roleWithPerms!.permissions.length).toBeGreaterThan(50);
    });

    it('should have staff role with limited permissions', async () => {
      const staffRole = await roleRepository.findByName('staff');
      const roleWithPerms = await rbacService.getRoleWithPermissions(staffRole!.id);
      
      expect(roleWithPerms).not.toBeNull();
      
      // Staff should have fewer permissions than admin
      const adminRole = await roleRepository.findByName('admin');
      const adminWithPerms = await rbacService.getRoleWithPermissions(adminRole!.id);
      
      expect(roleWithPerms!.permissions.length).toBeLessThan(adminWithPerms!.permissions.length);
    });
  });
});
