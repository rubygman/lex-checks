-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 004: Trust Ledger System
-- Immutable transactions with automatic balance calculation
-- ============================================================================

BEGIN;

-- ============================================================================
-- IMMUTABILITY TRIGGERS FOR TRUST_TRANSACTIONS
-- Prevents ANY modification to trust transactions after creation
-- ============================================================================

-- Block UPDATE on trust_transactions
CREATE OR REPLACE FUNCTION block_trust_transaction_update()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'UPDATE not allowed on immutable table trust_transactions. Trust ledger entries cannot be modified for compliance and audit purposes.';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_trust_transactions_block_update ON trust_transactions;
CREATE TRIGGER trg_trust_transactions_block_update
    BEFORE UPDATE ON trust_transactions
    FOR EACH ROW
    EXECUTE FUNCTION block_trust_transaction_update();

-- Block DELETE on trust_transactions
CREATE OR REPLACE FUNCTION block_trust_transaction_delete()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'DELETE not allowed on immutable table trust_transactions. Trust ledger entries cannot be deleted for compliance and audit purposes.';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_trust_transactions_block_delete ON trust_transactions;
CREATE TRIGGER trg_trust_transactions_block_delete
    BEFORE DELETE ON trust_transactions
    FOR EACH ROW
    EXECUTE FUNCTION block_trust_transaction_delete();

-- ============================================================================
-- BALANCE CALCULATION TRIGGER
-- Automatically calculates balance_after and updates trust_accounts.balance
-- ============================================================================

CREATE OR REPLACE FUNCTION calculate_trust_transaction_balance()
RETURNS TRIGGER AS $$
DECLARE
    v_current_balance NUMERIC(15,2);
    v_new_balance NUMERIC(15,2);
    v_signed_amount NUMERIC(15,2);
BEGIN
    -- Lock the trust account row to prevent concurrent modifications
    SELECT balance INTO v_current_balance
    FROM trust_accounts
    WHERE id = NEW.trust_account_id
    FOR UPDATE;

    IF v_current_balance IS NULL THEN
        RAISE EXCEPTION 'Trust account % not found', NEW.trust_account_id;
    END IF;

    -- Calculate signed amount based on transaction type
    -- Positive: deposits, transfers in, refunds
    -- Negative: withdrawals, transfers out, fee deductions
    CASE NEW.transaction_type
        WHEN 'deposit' THEN
            v_signed_amount := ABS(NEW.amount);
        WHEN 'transfer_in' THEN
            v_signed_amount := ABS(NEW.amount);
        WHEN 'refund' THEN
            v_signed_amount := ABS(NEW.amount);
        WHEN 'withdrawal' THEN
            v_signed_amount := -ABS(NEW.amount);
        WHEN 'transfer_out' THEN
            v_signed_amount := -ABS(NEW.amount);
        WHEN 'fee_deduction' THEN
            v_signed_amount := -ABS(NEW.amount);
        ELSE
            RAISE EXCEPTION 'Unknown transaction type: %', NEW.transaction_type;
    END CASE;

    -- Store the signed amount in the amount field
    NEW.amount := v_signed_amount;

    -- Calculate new balance
    v_new_balance := v_current_balance + v_signed_amount;

    -- Prevent negative balance for withdrawals
    IF v_new_balance < 0 AND NEW.transaction_type IN ('withdrawal', 'transfer_out', 'fee_deduction') THEN
        RAISE EXCEPTION 'Insufficient funds. Current balance: %, Requested: %', 
            v_current_balance, ABS(v_signed_amount);
    END IF;

    -- Set balance_after
    NEW.balance_after := v_new_balance;

    -- Update trust_accounts.balance
    UPDATE trust_accounts
    SET balance = v_new_balance,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = NEW.trust_account_id;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_trust_transactions_calculate_balance ON trust_transactions;
CREATE TRIGGER trg_trust_transactions_calculate_balance
    BEFORE INSERT ON trust_transactions
    FOR EACH ROW
    EXECUTE FUNCTION calculate_trust_transaction_balance();

-- ============================================================================
-- TRANSACTION REFERENCE GENERATION
-- Auto-generates unique reference numbers if not provided
-- ============================================================================

CREATE OR REPLACE FUNCTION generate_trust_transaction_reference()
RETURNS TRIGGER AS $$
DECLARE
    v_year TEXT;
    v_sequence INTEGER;
BEGIN
    IF NEW.reference_number IS NULL OR NEW.reference_number = '' THEN
        v_year := TO_CHAR(CURRENT_DATE, 'YYYY');
        
        -- Get next sequence for this tenant and year
        SELECT COALESCE(MAX(
            CASE 
                WHEN reference_number ~ ('^TT-' || v_year || '-\d+$')
                THEN CAST(SPLIT_PART(reference_number, '-', 3) AS INTEGER)
                ELSE 0
            END
        ), 0) + 1
        INTO v_sequence
        FROM trust_transactions
        WHERE tenant_id = NEW.tenant_id
          AND reference_number LIKE 'TT-' || v_year || '-%';
        
        NEW.reference_number := 'TT-' || v_year || '-' || LPAD(v_sequence::TEXT, 6, '0');
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_trust_transactions_generate_reference ON trust_transactions;
CREATE TRIGGER trg_trust_transactions_generate_reference
    BEFORE INSERT ON trust_transactions
    FOR EACH ROW
    EXECUTE FUNCTION generate_trust_transaction_reference();

-- ============================================================================
-- RECONCILIATION FUNCTION
-- Compares trust_accounts.balance with last transaction balance_after
-- ============================================================================

CREATE OR REPLACE FUNCTION reconcile_trust_account(
    p_tenant_id UUID,
    p_trust_account_id UUID
) RETURNS TABLE (
    account_id UUID,
    account_name VARCHAR(255),
    stored_balance NUMERIC(15,2),
    calculated_balance NUMERIC(15,2),
    last_transaction_id UUID,
    last_transaction_date TIMESTAMPTZ,
    transaction_count BIGINT,
    is_reconciled BOOLEAN,
    discrepancy NUMERIC(15,2)
) AS $$
BEGIN
    RETURN QUERY
    WITH last_tx AS (
        SELECT 
            tt.id,
            tt.balance_after,
            tt.created_at
        FROM trust_transactions tt
        WHERE tt.trust_account_id = p_trust_account_id
          AND tt.tenant_id = p_tenant_id
        ORDER BY tt.created_at DESC, tt.id DESC
        LIMIT 1
    ),
    tx_count AS (
        SELECT COUNT(*) as cnt
        FROM trust_transactions tt
        WHERE tt.trust_account_id = p_trust_account_id
          AND tt.tenant_id = p_tenant_id
    ),
    sum_check AS (
        SELECT COALESCE(SUM(tt.amount), 0) as total
        FROM trust_transactions tt
        WHERE tt.trust_account_id = p_trust_account_id
          AND tt.tenant_id = p_tenant_id
    )
    SELECT 
        ta.id as account_id,
        ta.account_name,
        ta.balance as stored_balance,
        COALESCE(lt.balance_after, 0.00) as calculated_balance,
        lt.id as last_transaction_id,
        lt.created_at as last_transaction_date,
        tc.cnt as transaction_count,
        (ta.balance = COALESCE(lt.balance_after, 0.00) 
         AND ta.balance = sc.total) as is_reconciled,
        (ta.balance - COALESCE(lt.balance_after, 0.00)) as discrepancy
    FROM trust_accounts ta
    CROSS JOIN tx_count tc
    CROSS JOIN sum_check sc
    LEFT JOIN last_tx lt ON TRUE
    WHERE ta.id = p_trust_account_id
      AND ta.tenant_id = p_tenant_id
      AND ta.deleted_at IS NULL;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- BALANCE HISTORY VIEW
-- Shows balance progression over time
-- ============================================================================

CREATE OR REPLACE VIEW trust_balance_history AS
SELECT 
    tt.id,
    tt.tenant_id,
    tt.trust_account_id,
    ta.account_name,
    tt.client_id,
    tt.transaction_type,
    tt.amount,
    tt.balance_after,
    tt.reference_number,
    tt.description,
    tt.created_at,
    tt.created_by,
    LAG(tt.balance_after, 1, 0.00) OVER (
        PARTITION BY tt.trust_account_id 
        ORDER BY tt.created_at, tt.id
    ) as balance_before
FROM trust_transactions tt
JOIN trust_accounts ta ON tt.trust_account_id = ta.id;

-- ============================================================================
-- MONTHLY SUMMARY VIEW
-- Aggregates transactions by month for reporting
-- ============================================================================

CREATE OR REPLACE VIEW trust_monthly_summary AS
SELECT 
    tt.tenant_id,
    tt.trust_account_id,
    ta.account_name,
    DATE_TRUNC('month', tt.created_at) as month,
    COUNT(*) as transaction_count,
    SUM(CASE WHEN tt.amount > 0 THEN tt.amount ELSE 0 END) as total_deposits,
    SUM(CASE WHEN tt.amount < 0 THEN ABS(tt.amount) ELSE 0 END) as total_withdrawals,
    SUM(tt.amount) as net_change,
    MAX(tt.balance_after) as ending_balance
FROM trust_transactions tt
JOIN trust_accounts ta ON tt.trust_account_id = ta.id
GROUP BY tt.tenant_id, tt.trust_account_id, ta.account_name, DATE_TRUNC('month', tt.created_at);

-- ============================================================================
-- ACCOUNT STATEMENT FUNCTION
-- Generates statement for a date range
-- ============================================================================

CREATE OR REPLACE FUNCTION get_trust_account_statement(
    p_tenant_id UUID,
    p_trust_account_id UUID,
    p_start_date TIMESTAMPTZ,
    p_end_date TIMESTAMPTZ
) RETURNS TABLE (
    transaction_id UUID,
    transaction_date TIMESTAMPTZ,
    reference_number VARCHAR(50),
    transaction_type VARCHAR(20),
    description TEXT,
    debit NUMERIC(15,2),
    credit NUMERIC(15,2),
    balance NUMERIC(15,2),
    case_id UUID,
    created_by UUID
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        tt.id as transaction_id,
        tt.created_at as transaction_date,
        tt.reference_number,
        tt.transaction_type,
        tt.description,
        CASE WHEN tt.amount < 0 THEN ABS(tt.amount) ELSE NULL END as debit,
        CASE WHEN tt.amount > 0 THEN tt.amount ELSE NULL END as credit,
        tt.balance_after as balance,
        tt.case_id,
        tt.created_by
    FROM trust_transactions tt
    WHERE tt.tenant_id = p_tenant_id
      AND tt.trust_account_id = p_trust_account_id
      AND tt.created_at >= p_start_date
      AND tt.created_at <= p_end_date
    ORDER BY tt.created_at ASC, tt.id ASC;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================

-- Index for statement queries
CREATE INDEX IF NOT EXISTS idx_trust_tx_statement 
ON trust_transactions(tenant_id, trust_account_id, created_at);

-- Index for client transaction lookup
CREATE INDEX IF NOT EXISTS idx_trust_tx_client
ON trust_transactions(tenant_id, client_id, created_at);

-- Index for case transaction lookup
CREATE INDEX IF NOT EXISTS idx_trust_tx_case
ON trust_transactions(tenant_id, case_id) WHERE case_id IS NOT NULL;

-- Index for reference number lookup
CREATE INDEX IF NOT EXISTS idx_trust_tx_reference
ON trust_transactions(tenant_id, reference_number);

COMMIT;
