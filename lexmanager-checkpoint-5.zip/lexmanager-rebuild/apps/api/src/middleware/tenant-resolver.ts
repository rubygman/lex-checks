// ============================================================================
// TENANT RESOLVER MIDDLEWARE
// apps/api/src/middleware/tenant-resolver.ts
// 
// Resolves tenant from X-Tenant-Id header and validates against database
// SECURITY: Do not trust tenantId from JWT alone - always resolve from header
// ============================================================================

import type { Request, Response, NextFunction, RequestHandler } from 'express';
import { tenantRepository } from '../repositories/tenant.repository.js';
import type { TenantContext } from './context.js';

// Re-export TenantContext for convenience
export type { TenantContext } from './context.js';

// ============================================================================
// ERRORS
// ============================================================================

/**
 * Error thrown during tenant resolution
 */
export class TenantResolutionError extends Error {
  public readonly statusCode: number;
  public readonly code: string;

  constructor(message: string, code: string = 'TENANT_RESOLUTION_FAILED', statusCode: number = 400) {
    super(message);
    this.name = 'TenantResolutionError';
    this.code = code;
    this.statusCode = statusCode;
  }
}

// ============================================================================
// MIDDLEWARE: RESOLVE TENANT FROM HEADER
// ============================================================================

/**
 * Resolve tenant from X-Tenant-Id header
 * 
 * SECURITY NOTES:
 * - Tenant ID is provided in the "x-tenant-id" header
 * - We validate it exists and load from database
 * - We verify tenant is active
 * - We do NOT trust tenantId from JWT alone for request scoping
 * - The resolved tenant is stored in req.context.tenant
 * 
 * Usage: Include X-Tenant-Id header with valid UUID in all tenant-scoped requests
 */
export function resolveTenantFromHeader(): RequestHandler {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      // Get tenant ID from header (case-insensitive)
      const tenantId = req.headers['x-tenant-id'] as string;

      if (!tenantId) {
        throw new TenantResolutionError(
          'Missing X-Tenant-Id header',
          'TENANT_HEADER_MISSING',
          400
        );
      }

      // Validate UUID format
      if (!isValidUUID(tenantId)) {
        throw new TenantResolutionError(
          'Invalid tenant ID format',
          'INVALID_TENANT_ID',
          400
        );
      }

      // Look up tenant in database
      const tenant = await tenantRepository.findById(tenantId);

      if (!tenant) {
        throw new TenantResolutionError(
          'Tenant not found',
          'TENANT_NOT_FOUND',
          404
        );
      }

      if (!tenant.is_active) {
        throw new TenantResolutionError(
          'Tenant is deactivated',
          'TENANT_INACTIVE',
          403
        );
      }

      // Attach tenant to request context
      req.context.tenant = {
        tenantId: tenant.id,
        tenantSlug: tenant.slug,
        tenantName: tenant.name,
        isActive: tenant.is_active,
      };

      next();
    } catch (error) {
      if (error instanceof TenantResolutionError) {
        res.status(error.statusCode).json({
          error: error.code,
          message: error.message,
          correlationId: req.context?.correlationId,
        });
        return;
      }
      next(error);
    }
  };
}

// ============================================================================
// MIDDLEWARE: REQUIRE TENANT
// ============================================================================

/**
 * Guard middleware that requires tenant context to be present
 * 
 * Use after resolveTenantFromHeader() for routes that need tenant context.
 * Rejects with 400 if tenant is not resolved.
 */
export function requireTenant(): RequestHandler {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.context?.tenant) {
      res.status(400).json({
        error: 'TENANT_REQUIRED',
        message: 'Tenant context is required for this endpoint',
        correlationId: req.context?.correlationId,
      });
      return;
    }
    next();
  };
}

// ============================================================================
// HELPER: GET TENANT CONTEXT
// ============================================================================

/**
 * Helper to get tenant context from request with type safety
 * Throws if tenant is not resolved
 */
export function getTenantContext(req: Request): TenantContext {
  if (!req.context?.tenant) {
    throw new TenantResolutionError(
      'Tenant context not available',
      'TENANT_CONTEXT_MISSING',
      500
    );
  }
  return req.context.tenant;
}

// ============================================================================
// HELPERS
// ============================================================================

/**
 * Validate UUID format
 */
function isValidUUID(value: string): boolean {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return uuidRegex.test(value);
}
