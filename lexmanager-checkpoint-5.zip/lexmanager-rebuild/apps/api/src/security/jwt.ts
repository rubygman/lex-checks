// ============================================================================
// JWT AUTHENTICATION
// apps/api/src/security/jwt.ts
// 
// Short-lived access tokens + refresh token rotation
// ============================================================================

import jwt, { type JwtPayload, type SignOptions, type VerifyOptions } from 'jsonwebtoken';
import crypto from 'crypto';
import { getConfig } from '../config/index.js';

// ============================================================================
// TYPES
// ============================================================================

export interface TokenPayload {
  sub: string;       // User ID
  tid: string;       // Tenant ID
  rid: string;       // Role ID
  rn: string;        // Role name
  email: string;
  type: 'access' | 'refresh';
  jti: string;       // Unique token ID
}

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  accessExpiresAt: Date;
  refreshExpiresAt: Date;
}

export interface DecodedToken extends TokenPayload {
  iat: number;
  exp: number;
  iss: string;
  aud: string;
}

// ============================================================================
// REFRESH TOKEN STORAGE
// In production, use Redis or database for refresh tokens
// This is a simple in-memory implementation for development
// ============================================================================

interface RefreshTokenRecord {
  userId: string;
  tenantId: string;
  tokenHash: string;
  family: string;      // Token family for rotation detection
  createdAt: Date;
  expiresAt: Date;
  rotatedAt?: Date;
  revokedAt?: Date;
  revokeReason?: string;
}

// In-memory store (replace with Redis in production)
const refreshTokenStore = new Map<string, RefreshTokenRecord>();

// ============================================================================
// TOKEN GENERATION
// ============================================================================

/**
 * Generate a unique token ID
 */
function generateTokenId(): string {
  return crypto.randomUUID();
}

/**
 * Generate a token family ID (for rotation detection)
 */
function generateTokenFamily(): string {
  return crypto.randomBytes(16).toString('hex');
}

/**
 * Hash a token for storage
 */
function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

/**
 * Parse duration string to milliseconds
 */
function parseDuration(duration: string): number {
  const match = duration.match(/^(\d+)([smhd])$/);
  if (!match) throw new Error(`Invalid duration: ${duration}`);
  
  const value = parseInt(match[1], 10);
  const unit = match[2];
  
  const multipliers: Record<string, number> = {
    's': 1000,
    'm': 60 * 1000,
    'h': 60 * 60 * 1000,
    'd': 24 * 60 * 60 * 1000,
  };
  
  return value * multipliers[unit];
}

/**
 * Generate access token
 */
export function generateAccessToken(payload: Omit<TokenPayload, 'type' | 'jti'>): string {
  const config = getConfig();
  const jti = generateTokenId();
  
  const tokenPayload: TokenPayload = {
    ...payload,
    type: 'access',
    jti,
  };
  
  const options: SignOptions = {
    expiresIn: config.jwt.accessExpiresIn,
    issuer: config.jwt.issuer,
    audience: config.jwt.audience,
  };
  
  return jwt.sign(tokenPayload, config.jwt.accessSecret, options);
}

/**
 * Generate refresh token
 */
export function generateRefreshToken(
  payload: Omit<TokenPayload, 'type' | 'jti'>,
  family?: string
): string {
  const config = getConfig();
  const jti = generateTokenId();
  const tokenFamily = family || generateTokenFamily();
  
  const tokenPayload: TokenPayload & { fam: string } = {
    ...payload,
    type: 'refresh',
    jti,
    fam: tokenFamily,
  };
  
  const options: SignOptions = {
    expiresIn: config.jwt.refreshExpiresIn,
    issuer: config.jwt.issuer,
    audience: config.jwt.audience,
  };
  
  const token = jwt.sign(tokenPayload, config.jwt.refreshSecret, options);
  
  // Store refresh token record
  const expiresMs = parseDuration(config.jwt.refreshExpiresIn);
  const record: RefreshTokenRecord = {
    userId: payload.sub,
    tenantId: payload.tid,
    tokenHash: hashToken(token),
    family: tokenFamily,
    createdAt: new Date(),
    expiresAt: new Date(Date.now() + expiresMs),
  };
  
  refreshTokenStore.set(jti, record);
  
  return token;
}

/**
 * Generate token pair (access + refresh)
 */
export function generateTokenPair(
  userId: string,
  tenantId: string,
  roleId: string,
  roleName: string,
  email: string
): TokenPair {
  const config = getConfig();
  
  const payload = {
    sub: userId,
    tid: tenantId,
    rid: roleId,
    rn: roleName,
    email,
  };
  
  const accessToken = generateAccessToken(payload);
  const refreshToken = generateRefreshToken(payload);
  
  const accessExpiresMs = parseDuration(config.jwt.accessExpiresIn);
  const refreshExpiresMs = parseDuration(config.jwt.refreshExpiresIn);
  
  return {
    accessToken,
    refreshToken,
    accessExpiresAt: new Date(Date.now() + accessExpiresMs),
    refreshExpiresAt: new Date(Date.now() + refreshExpiresMs),
  };
}

// ============================================================================
// TOKEN VERIFICATION
// ============================================================================

/**
 * Verify access token
 */
export function verifyAccessToken(token: string): DecodedToken {
  const config = getConfig();
  
  const options: VerifyOptions = {
    issuer: config.jwt.issuer,
    audience: config.jwt.audience,
  };
  
  const decoded = jwt.verify(token, config.jwt.accessSecret, options) as DecodedToken;
  
  if (decoded.type !== 'access') {
    throw new Error('Invalid token type');
  }
  
  return decoded;
}

/**
 * Verify refresh token and return new token pair (rotation)
 */
export async function rotateRefreshToken(token: string): Promise<TokenPair | null> {
  const config = getConfig();
  
  // Verify the token
  let decoded: DecodedToken & { fam: string };
  try {
    decoded = jwt.verify(token, config.jwt.refreshSecret, {
      issuer: config.jwt.issuer,
      audience: config.jwt.audience,
    }) as DecodedToken & { fam: string };
  } catch {
    return null;
  }
  
  if (decoded.type !== 'refresh') {
    return null;
  }
  
  // Check if token exists in store
  const record = refreshTokenStore.get(decoded.jti);
  
  if (!record) {
    // Token not found - possible replay attack
    // Revoke all tokens in this family
    revokeTokenFamily(decoded.fam, 'Token reuse detected');
    return null;
  }
  
  if (record.revokedAt) {
    // Token was revoked - possible replay attack
    revokeTokenFamily(decoded.fam, 'Revoked token reuse');
    return null;
  }
  
  if (record.rotatedAt) {
    // Token was already rotated - replay attack!
    revokeTokenFamily(decoded.fam, 'Token replay detected');
    return null;
  }
  
  // Mark current token as rotated
  record.rotatedAt = new Date();
  
  // Generate new token pair with same family
  const payload = {
    sub: decoded.sub,
    tid: decoded.tid,
    rid: decoded.rid,
    rn: decoded.rn,
    email: decoded.email,
  };
  
  const accessToken = generateAccessToken(payload);
  const refreshToken = generateRefreshToken(payload, decoded.fam);
  
  const accessExpiresMs = parseDuration(config.jwt.accessExpiresIn);
  const refreshExpiresMs = parseDuration(config.jwt.refreshExpiresIn);
  
  return {
    accessToken,
    refreshToken,
    accessExpiresAt: new Date(Date.now() + accessExpiresMs),
    refreshExpiresAt: new Date(Date.now() + refreshExpiresMs),
  };
}

// ============================================================================
// TOKEN REVOCATION
// ============================================================================

/**
 * Revoke a specific token
 */
export function revokeToken(jti: string, reason: string = 'Manual revocation'): void {
  const record = refreshTokenStore.get(jti);
  if (record) {
    record.revokedAt = new Date();
    record.revokeReason = reason;
  }
}

/**
 * Revoke all tokens in a family (on compromise detection)
 */
export function revokeTokenFamily(family: string, reason: string = 'Family revocation'): void {
  for (const [jti, record] of refreshTokenStore.entries()) {
    if (record.family === family && !record.revokedAt) {
      record.revokedAt = new Date();
      record.revokeReason = reason;
    }
  }
}

/**
 * Revoke all tokens for a user (on password change, logout all)
 */
export function revokeAllUserTokens(userId: string, reason: string = 'User logout all'): void {
  for (const [jti, record] of refreshTokenStore.entries()) {
    if (record.userId === userId && !record.revokedAt) {
      record.revokedAt = new Date();
      record.revokeReason = reason;
    }
  }
}

/**
 * Clean up expired tokens
 */
export function cleanupExpiredTokens(): number {
  const now = new Date();
  let cleaned = 0;
  
  for (const [jti, record] of refreshTokenStore.entries()) {
    if (record.expiresAt < now) {
      refreshTokenStore.delete(jti);
      cleaned++;
    }
  }
  
  return cleaned;
}

// Run cleanup every hour
setInterval(() => {
  const cleaned = cleanupExpiredTokens();
  if (cleaned > 0) {
    console.log(`Cleaned up ${cleaned} expired refresh tokens`);
  }
}, 60 * 60 * 1000);
