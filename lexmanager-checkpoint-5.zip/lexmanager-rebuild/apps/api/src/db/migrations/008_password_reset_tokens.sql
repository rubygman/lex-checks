-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 008: Password Reset Tokens Enhancements
-- Adds missing indexes and updated_at trigger for password_reset_tokens table
-- ============================================================================

BEGIN;

-- ============================================================================
-- VERIFY TABLE EXISTS (created in 007)
-- If not, create it with the full schema
-- ============================================================================

CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Ownership (tenant-scoped)
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Token (stored hashed, NEVER plain - SHA-256)
    token_hash TEXT NOT NULL,
    
    -- Lifecycle
    expires_at TIMESTAMPTZ NOT NULL,
    used_at TIMESTAMPTZ,
    
    -- Request metadata
    ip_address TEXT,
    user_agent TEXT,
    
    -- Standard timestamps
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMPTZ,  -- Soft delete compatible
    
    -- Constraints
    CONSTRAINT uq_password_reset_token_hash UNIQUE (token_hash)
);

-- ============================================================================
-- INDEXES
-- ============================================================================

-- Primary lookup by token hash (for validation)
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_hash 
ON password_reset_tokens(token_hash);

-- User's tokens (for invalidating old tokens on new request)
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_user 
ON password_reset_tokens(tenant_id, user_id);

-- Expiry-based cleanup queries
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_expires 
ON password_reset_tokens(expires_at)
WHERE deleted_at IS NULL;

-- Find unused tokens for a user (for invalidation on new request)
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_unused 
ON password_reset_tokens(tenant_id, user_id, used_at)
WHERE used_at IS NULL AND deleted_at IS NULL;

-- ============================================================================
-- TRIGGER: Auto-update updated_at timestamp
-- ============================================================================

CREATE OR REPLACE FUNCTION update_password_reset_tokens_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_password_reset_tokens_updated_at ON password_reset_tokens;
CREATE TRIGGER trg_password_reset_tokens_updated_at
    BEFORE UPDATE ON password_reset_tokens
    FOR EACH ROW
    EXECUTE FUNCTION update_password_reset_tokens_updated_at();

-- ============================================================================
-- HELPER FUNCTION: Cleanup expired tokens
-- ============================================================================

CREATE OR REPLACE FUNCTION cleanup_expired_password_reset_tokens()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    -- Soft delete tokens that expired more than 24 hours ago
    UPDATE password_reset_tokens 
    SET deleted_at = CURRENT_TIMESTAMP
    WHERE expires_at < CURRENT_TIMESTAMP - INTERVAL '24 hours'
      AND deleted_at IS NULL;
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- COMMENTS
-- ============================================================================

COMMENT ON TABLE password_reset_tokens IS 
'Stores hashed password reset tokens. Tokens are single-use and time-limited.
SECURITY: Only token_hash is stored, never the plaintext token.';

COMMENT ON COLUMN password_reset_tokens.token_hash IS 
'SHA-256 hash of the reset token. The plaintext token is NEVER stored.';

COMMENT ON COLUMN password_reset_tokens.used_at IS 
'When the token was used to reset password. NULL means unused.';

COMMENT ON COLUMN password_reset_tokens.deleted_at IS 
'Soft delete timestamp. Expired tokens are soft-deleted for audit purposes.';

COMMIT;
