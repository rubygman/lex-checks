// ============================================================================
// AUDIT ROUTES
// apps/api/src/routes/audit.routes.ts
// 
// Read-only audit log access with RBAC
// ============================================================================

import { Router } from 'express';
import { auditService } from '../services/audit.service.js';
import {
  initializeContext,
  resolveTenantFromHeader,
  requireTenant,
  authParser,
  requireAuth,
  requireTenantAccess,
  requirePermission,
} from '../middleware/index.js';
import {
  validate,
  auditLogQuerySchema,
  idParamSchema,
  z,
} from '../validation/index.js';
import { asyncHandler, sendSuccess } from '../errors/index.js';
import { PERMISSIONS } from '../services/rbac.service.js';

const router = Router();

// All routes require tenant context and authentication
router.use(initializeContext());
router.use(resolveTenantFromHeader());
router.use(requireTenant());
router.use(authParser());
router.use(requireAuth());
router.use(requireTenantAccess());

// Entity params schema
const entityParamsSchema = z.object({
  entityType: z.string().min(1),
  entityId: z.string().uuid(),
});

// ============================================================================
// GET /audit/logs - List audit logs
// ============================================================================

router.get(
  '/logs',
  requirePermission(PERMISSIONS.AUDIT_LOG_VIEW),
  validate(auditLogQuerySchema, 'query'),
  asyncHandler(async (req, res) => {
    const { page, limit, entityType, entityId, userId, action, startDate, endDate } = req.query as any;

    const logs = await auditService.listAuditLogs(
      req.auth!.tenantId,
      req.auth!.userId,
      {
        entityType,
        entityId,
        userId,
        action,
        startDate: startDate ? new Date(startDate) : undefined,
        endDate: endDate ? new Date(endDate) : undefined,
      },
      { limit, offset: (page - 1) * limit }
    );

    const total = await auditService.countAuditLogs(
      req.auth!.tenantId,
      req.auth!.userId,
      {
        entityType,
        entityId,
        userId,
        action,
        startDate: startDate ? new Date(startDate) : undefined,
        endDate: endDate ? new Date(endDate) : undefined,
      }
    );

    sendSuccess(res, req, logs, 200, {
      page,
      limit,
      total,
      hasMore: (page * limit) < total,
    });
  })
);

// ============================================================================
// GET /audit/logs/:id - Get audit log by ID
// ============================================================================

router.get(
  '/logs/:id',
  requirePermission(PERMISSIONS.AUDIT_LOG_VIEW),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const log = await auditService.getAuditLog(
      req.auth!.tenantId,
      req.auth!.userId,
      req.params.id
    );

    if (!log) {
      sendSuccess(res, req, null, 404);
      return;
    }

    sendSuccess(res, req, log);
  })
);

// ============================================================================
// GET /audit/entity/:entityType/:entityId - Get entity history
// ============================================================================

router.get(
  '/entity/:entityType/:entityId',
  requirePermission(PERMISSIONS.AUDIT_LOG_VIEW),
  validate(entityParamsSchema, 'params'),
  asyncHandler(async (req, res) => {
    const { limit, offset } = req.query as any;

    const logs = await auditService.getEntityHistory(
      req.auth!.tenantId,
      req.auth!.userId,
      req.params.entityType,
      req.params.entityId,
      { limit: limit ? parseInt(limit, 10) : 100, offset: offset ? parseInt(offset, 10) : 0 }
    );

    sendSuccess(res, req, logs);
  })
);

// ============================================================================
// GET /audit/user/:userId - Get user activity
// ============================================================================

router.get(
  '/user/:userId',
  requirePermission(PERMISSIONS.AUDIT_LOG_VIEW),
  asyncHandler(async (req, res) => {
    const { limit, offset } = req.query as any;

    const logs = await auditService.getUserActivity(
      req.auth!.tenantId,
      req.auth!.userId,
      req.params.userId,
      { limit: limit ? parseInt(limit, 10) : 100, offset: offset ? parseInt(offset, 10) : 0 }
    );

    sendSuccess(res, req, logs);
  })
);

// ============================================================================
// GET /audit/verify - Verify hash chain integrity
// ============================================================================

router.get(
  '/verify',
  requirePermission(PERMISSIONS.AUDIT_LOG_VIEW),
  asyncHandler(async (req, res) => {
    const { startDate, endDate } = req.query as any;

    const result = await auditService.verifyIntegrity(
      req.auth!.tenantId,
      req.auth!.userId,
      startDate ? new Date(startDate) : undefined,
      endDate ? new Date(endDate) : undefined
    );

    sendSuccess(res, req, result);
  })
);

// ============================================================================
// GET /audit/statistics - Get audit log statistics
// ============================================================================

router.get(
  '/statistics',
  requirePermission(PERMISSIONS.AUDIT_LOG_VIEW),
  asyncHandler(async (req, res) => {
    const stats = await auditService.getStatistics(
      req.auth!.tenantId,
      req.auth!.userId
    );

    sendSuccess(res, req, stats);
  })
);

export default router;
