// ============================================================================
// AUDIT MUTATION HELPER
// apps/api/src/audit/mutation-logger.ts
// 
// Best-effort audit logging for all entity mutations.
// Audit failures NEVER crash business operations.
// ============================================================================

import { auditService, type AuditContext } from '../services/audit.service.js';
import { type Request } from 'express';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Mutation action types
 */
export type MutationAction = 'create' | 'update' | 'softDelete' | 'restore';

/**
 * Entity types that can be audited
 */
export type AuditableEntity = 
  | 'client'
  | 'case'
  | 'task'
  | 'document'
  | 'invoice'
  | 'invoice_line'
  | 'payment'
  | 'time_entry'
  | 'trust_account'
  | 'trust_transaction'
  | 'user'
  | 'custom_field_definition'
  | 'custom_field_value'
  | 'calendar_event';

/**
 * Mutation metadata for audit logging
 */
export interface MutationMetadata {
  /** Description override */
  description?: string;
  /** Additional data to log */
  additionalData?: Record<string, unknown>;
  /** Mark as financial (longer retention) */
  isFinancial?: boolean;
}

// ============================================================================
// CONTEXT BUILDER
// ============================================================================

/**
 * Build audit context from Express request
 */
export function buildAuditContext(req: Request): AuditContext {
  return {
    tenantId: req.context?.tenant?.tenantId || req.auth?.tenantId || '',
    userId: req.auth?.userId,
    ipAddress: req.context?.ipAddress,
    userAgent: req.context?.userAgent,
    requestId: req.context?.correlationId,
  };
}

// ============================================================================
// MUTATION LOGGER
// ============================================================================

/**
 * Log a mutation event
 * 
 * CRITICAL: This function is best-effort and will NEVER throw.
 * If audit logging fails, the error is logged to console but the
 * business operation continues normally.
 * 
 * @param context Audit context (tenant, user, request info)
 * @param action The mutation action (create/update/softDelete/restore)
 * @param entityType The type of entity being mutated
 * @param entityId The ID of the entity
 * @param metadata Optional metadata including old/new values
 */
export async function logMutation(
  context: AuditContext,
  action: MutationAction,
  entityType: AuditableEntity | string,
  entityId: string,
  metadata?: MutationMetadata & {
    oldData?: Record<string, unknown>;
    newData?: Record<string, unknown>;
  }
): Promise<void> {
  try {
    // Validate context
    if (!context.tenantId) {
      console.warn('[Audit] Missing tenantId in audit context, skipping audit log');
      return;
    }

    const { oldData, newData, description, additionalData } = metadata || {};

    switch (action) {
      case 'create':
        await auditService.logCreate(
          context,
          entityType,
          entityId,
          { ...newData, ...additionalData }
        );
        break;

      case 'update':
        await auditService.logUpdate(
          context,
          entityType,
          entityId,
          oldData || {},
          { ...newData, ...additionalData }
        );
        break;

      case 'softDelete':
        await auditService.logDelete(
          context,
          entityType,
          entityId,
          oldData
        );
        break;

      case 'restore':
        await auditService.logRestore(
          context,
          entityType,
          entityId
        );
        break;
    }
  } catch (error) {
    // CRITICAL: Never throw from audit logging
    console.error('[Audit] Failed to log mutation:', {
      action,
      entityType,
      entityId,
      tenantId: context.tenantId,
      error: error instanceof Error ? error.message : 'Unknown error',
    });
  }
}

// ============================================================================
// CONVENIENCE FUNCTIONS
// ============================================================================

/**
 * Log a create mutation
 */
export async function auditCreate(
  req: Request,
  entityType: AuditableEntity | string,
  entityId: string,
  entityData: Record<string, unknown>
): Promise<void> {
  await logMutation(
    buildAuditContext(req),
    'create',
    entityType,
    entityId,
    { newData: entityData }
  );
}

/**
 * Log an update mutation
 */
export async function auditUpdate(
  req: Request,
  entityType: AuditableEntity | string,
  entityId: string,
  oldData: Record<string, unknown>,
  newData: Record<string, unknown>
): Promise<void> {
  await logMutation(
    buildAuditContext(req),
    'update',
    entityType,
    entityId,
    { oldData, newData }
  );
}

/**
 * Log a soft delete mutation
 */
export async function auditSoftDelete(
  req: Request,
  entityType: AuditableEntity | string,
  entityId: string,
  entityData?: Record<string, unknown>
): Promise<void> {
  await logMutation(
    buildAuditContext(req),
    'softDelete',
    entityType,
    entityId,
    { oldData: entityData }
  );
}

/**
 * Log a restore mutation
 */
export async function auditRestore(
  req: Request,
  entityType: AuditableEntity | string,
  entityId: string
): Promise<void> {
  await logMutation(
    buildAuditContext(req),
    'restore',
    entityType,
    entityId
  );
}

// ============================================================================
// WRAPPER FOR SERVICE LAYER
// ============================================================================

/**
 * Create an audited wrapper for service operations
 * 
 * Usage:
 *   const audited = withAudit(req, 'client');
 *   const client = await audited.create(async () => clientService.create(...));
 */
export function withAudit(req: Request, entityType: AuditableEntity | string) {
  const context = buildAuditContext(req);

  return {
    /**
     * Wrap a create operation with automatic auditing
     */
    async create<T extends { id: string }>(
      operation: () => Promise<T>
    ): Promise<T> {
      const result = await operation();
      await logMutation(context, 'create', entityType, result.id, {
        newData: result as unknown as Record<string, unknown>,
      });
      return result;
    },

    /**
     * Wrap an update operation with automatic auditing
     */
    async update<T extends { id: string }>(
      entityId: string,
      oldData: Record<string, unknown>,
      operation: () => Promise<T>
    ): Promise<T> {
      const result = await operation();
      await logMutation(context, 'update', entityType, entityId, {
        oldData,
        newData: result as unknown as Record<string, unknown>,
      });
      return result;
    },

    /**
     * Wrap a soft delete operation with automatic auditing
     */
    async softDelete(
      entityId: string,
      entityData: Record<string, unknown>,
      operation: () => Promise<void>
    ): Promise<void> {
      await operation();
      await logMutation(context, 'softDelete', entityType, entityId, {
        oldData: entityData,
      });
    },

    /**
     * Wrap a restore operation with automatic auditing
     */
    async restore(
      entityId: string,
      operation: () => Promise<void>
    ): Promise<void> {
      await operation();
      await logMutation(context, 'restore', entityType, entityId);
    },
  };
}

// ============================================================================
// EXPORT INDEX
// ============================================================================

export { type AuditContext } from '../services/audit.service.js';
