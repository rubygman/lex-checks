// ============================================================================
// REPOSITORIES INDEX
// apps/api/src/repositories/index.ts
// ============================================================================

// Base repositories
export { 
  BaseRepository, 
  type BaseEntity, 
  type SoftDeletableEntity, 
  type Filter,
  type ListOptions,
  type PaginatedResult,
} from './base.repository.js';

export { 
  ImmutableRepository, 
  type ImmutableEntity,
} from './immutable.repository.js';

// Tenant repository
export {
  TenantRepository,
  tenantRepository,
  type Tenant,
  type CreateTenantData,
  type UpdateTenantData,
} from './tenant.repository.js';

// User repository
export {
  UserRepository,
  userRepository,
  type User,
  type UserWithRole,
  type CreateUserData,
  type UpdateUserData,
} from './user.repository.js';

// RBAC repositories
export {
  RoleRepository,
  PermissionRepository,
  RolePermissionRepository,
  roleRepository,
  permissionRepository,
  rolePermissionRepository,
  type Role,
  type Permission,
  type RolePermission,
  type RoleWithPermissions,
} from './rbac.repository.js';

// Trust Account Repository
export {
  TrustAccountRepository,
  trustAccountRepository,
  type TrustAccount,
  type TrustAccountWithClient,
  type CreateTrustAccountData,
  type UpdateTrustAccountData,
} from './trust-account.repository.js';

// Trust Transaction Repository (Immutable)
export {
  TrustTransactionRepository,
  trustTransactionRepository,
  type TrustTransaction,
  type TrustTransactionWithDetails,
  type CreateTrustTransactionData,
  type TrustTransactionType,
  type TransactionFilters,
} from './trust-transaction.repository.js';

// Audit Log Repository (Immutable, No FK)
export {
  AuditLogRepository,
  auditLogRepository,
  type AuditLogEntry,
  type AuditAction,
  type AuditCategory,
  type CreateAuditLogData,
  type AuditLogFilters,
  type HashChainVerificationResult,
} from './audit-log.repository.js';

// Custom Field Definition Repository
export {
  CustomFieldDefinitionRepository,
  customFieldDefinitionRepository,
  type CustomFieldDefinition,
  type CustomFieldType,
  type CustomFieldEntityType,
  type SelectOption,
  type FieldOptions,
  type CreateDefinitionData,
  type UpdateDefinitionData,
} from './custom-field-definition.repository.js';

// Custom Field Value Repository
export {
  CustomFieldValueRepository,
  customFieldValueRepository,
  type CustomFieldValue,
  type CustomFieldWithValue,
  type SetValueData,
} from './custom-field-value.repository.js';

// Refresh Token Repository
export {
  RefreshTokenRepository,
  refreshTokenRepository,
  type RefreshToken,
  type CreateRefreshTokenData,
} from './refresh-token.repository.js';

// Case Repository
export {
  CaseRepository,
  caseRepository,
  type Case,
  type CaseWithClient,
  type CreateCaseData,
  type UpdateCaseData,
} from './case.repository.js';

// Task Repository
export {
  TaskRepository,
  taskRepository,
  type Task,
  type TaskWithDetails,
  type CreateTaskData,
  type UpdateTaskData,
} from './task.repository.js';

// Document Repository
export {
  DocumentRepository,
  documentRepository,
  type Document,
  type DocumentWithDetails,
  type CreateDocumentData,
  type UpdateDocumentData,
} from './document.repository.js';

// Invoice Repository
export {
  InvoiceRepository,
  invoiceRepository,
  type Invoice,
  type InvoiceLine,
  type InvoiceWithDetails,
  type CreateInvoiceData,
  type UpdateInvoiceData,
  type CreateInvoiceLineData,
} from './invoice.repository.js';

// ============================================================================
// LEGACY EXPORTS (for backwards compatibility with existing code)
// ============================================================================

import { BaseRepository, type BaseEntity, type SoftDeletableEntity, type Filter } from './base.repository.js';
import { ImmutableRepository, type ImmutableEntity } from './immutable.repository.js';
import { query } from '../db/connection.js';
import { createQueryBuilder } from '../db/query-builder.js';
import { parsePostgresError } from '../db/errors.js';

// ============================================================================
// CLIENT REPOSITORY
// ============================================================================

export interface Client extends SoftDeletableEntity {
  id: string;
  tenant_id: string;
  name: string;
  name_he: string | null;
  email: string | null;
  phone: string | null;
  phone_secondary: string | null;
  fax: string | null;
  client_type: 'individual' | 'company' | 'government' | 'non_profit';
  status: 'lead' | 'prospect' | 'active' | 'inactive' | 'archived';
  israeli_id: string | null;
  company_number: string | null;
  vat_number: string | null;
  address_street: string | null;
  address_city: string | null;
  address_zip: string | null;
  address_country: string;
  website: string | null;
  notes: string | null;
  source: string | null;
  assigned_to: string | null;
  default_rate: number | null;
  currency: string;
  payment_terms: number;
  created_by: string | null;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

export type CreateClientData = Omit<Client, 'id' | 'tenant_id' | 'created_at' | 'updated_at' | 'deleted_at'>;
export type UpdateClientData = Partial<CreateClientData>;

export class ClientRepository extends BaseRepository<Client> {
  constructor() {
    super({
      tableName: 'clients',
      supportsSoftDelete: true,
    });
  }

  /**
   * Find client by Israeli ID within tenant
   */
  async findByIsraeliId(tenantId: string, israeliId: string): Promise<Client | null> {
    this.validateTenantId(tenantId, 'findByIsraeliId');

    return this.findOne(tenantId, [
      { field: 'israeli_id', operator: '=', value: israeliId }
    ]);
  }

  /**
   * Find client by company number within tenant
   */
  async findByCompanyNumber(tenantId: string, companyNumber: string): Promise<Client | null> {
    this.validateTenantId(tenantId, 'findByCompanyNumber');

    return this.findOne(tenantId, [
      { field: 'company_number', operator: '=', value: companyNumber }
    ]);
  }

  /**
   * Find client by email within tenant
   */
  async findByEmail(tenantId: string, email: string): Promise<Client | null> {
    this.validateTenantId(tenantId, 'findByEmail');

    return this.findOne(tenantId, [
      { field: 'email', operator: '=', value: email.toLowerCase() }
    ]);
  }

  /**
   * Search clients by name (fuzzy search with Hebrew support)
   */
  async searchByName(tenantId: string, searchTerm: string, limit: number = 20): Promise<Client[]> {
    this.validateTenantId(tenantId, 'searchByName');

    try {
      const text = `
        SELECT * FROM clients
        WHERE tenant_id = $1
          AND deleted_at IS NULL
          AND (
            name ILIKE $2
            OR name_he ILIKE $2
            OR name % $3  -- trigram similarity
          )
        ORDER BY similarity(name, $3) DESC
        LIMIT $4
      `;
      const result = await query<Client>(text, [
        tenantId,
        `%${searchTerm}%`,
        searchTerm,
        limit
      ]);

      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get clients by status
   */
  async findByStatus(tenantId: string, status: Client['status']): Promise<Client[]> {
    this.validateTenantId(tenantId, 'findByStatus');

    const result = await this.list(tenantId, {
      filters: [{ field: 'status', operator: '=', value: status }],
      sort: { field: 'name', direction: 'ASC' }
    });

    return result.data;
  }
}

// ============================================================================
// TRUST TRANSACTION REPOSITORY (IMMUTABLE)
// ============================================================================

export interface TrustTransaction extends ImmutableEntity {
  id: string;
  tenant_id: string;
  trust_account_id: string;
  client_id: string;
  case_id: string | null;
  transaction_type: 'deposit' | 'withdrawal' | 'transfer_in' | 'transfer_out' | 'fee_deduction' | 'refund';
  amount: number;
  currency: string;
  balance_after: number;
  description: string;
  invoice_id: string | null;
  payment_id: string | null;
  related_transaction_id: string | null;
  reference_number: string | null;
  created_by: string;
  created_at: Date;
}

export type CreateTrustTransactionData = Omit<TrustTransaction, 'id' | 'tenant_id' | 'created_at' | 'balance_after'>;

export class TrustTransactionRepository extends ImmutableRepository<TrustTransaction> {
  constructor() {
    super({
      tableName: 'trust_transactions',
    });
  }

  /**
   * Get transactions for a trust account
   */
  async findByTrustAccount(
    tenantId: string,
    trustAccountId: string,
    options?: { limit?: number; offset?: number }
  ): Promise<TrustTransaction[]> {
    this.validateTenantId(tenantId, 'findByTrustAccount');

    const result = await this.list(tenantId, {
      filters: [{ field: 'trust_account_id', operator: '=', value: trustAccountId }],
      sort: { field: 'created_at', direction: 'DESC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 }
    });

    return result.data;
  }

  /**
   * Get transactions for a client
   */
  async findByClient(
    tenantId: string,
    clientId: string,
    options?: { limit?: number; offset?: number }
  ): Promise<TrustTransaction[]> {
    this.validateTenantId(tenantId, 'findByClient');

    const result = await this.list(tenantId, {
      filters: [{ field: 'client_id', operator: '=', value: clientId }],
      sort: { field: 'created_at', direction: 'DESC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 }
    });

    return result.data;
  }

  /**
   * Get transactions for a case
   */
  async findByCase(
    tenantId: string,
    caseId: string,
    options?: { limit?: number; offset?: number }
  ): Promise<TrustTransaction[]> {
    this.validateTenantId(tenantId, 'findByCase');

    const result = await this.list(tenantId, {
      filters: [{ field: 'case_id', operator: '=', value: caseId }],
      sort: { field: 'created_at', direction: 'DESC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 }
    });

    return result.data;
  }

  /**
   * Get the current balance for a trust account
   * (from the most recent transaction)
   */
  async getCurrentBalance(tenantId: string, trustAccountId: string): Promise<number> {
    this.validateTenantId(tenantId, 'getCurrentBalance');

    try {
      const text = `
        SELECT balance_after
        FROM trust_transactions
        WHERE tenant_id = $1 AND trust_account_id = $2
        ORDER BY created_at DESC
        LIMIT 1
      `;
      const result = await query<{ balance_after: number }>(text, [tenantId, trustAccountId]);

      return result.rows[0]?.balance_after ?? 0;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Record a deposit (creates an immutable transaction)
   */
  async recordDeposit(
    tenantId: string,
    data: {
      trust_account_id: string;
      client_id: string;
      case_id?: string;
      amount: number;
      description: string;
      reference_number?: string;
      created_by: string;
    }
  ): Promise<TrustTransaction> {
    if (data.amount <= 0) {
      throw new Error('Deposit amount must be positive');
    }

    return this.append(tenantId, {
      ...data,
      case_id: data.case_id ?? null,
      transaction_type: 'deposit',
      currency: 'ILS',
      invoice_id: null,
      payment_id: null,
      related_transaction_id: null,
      reference_number: data.reference_number ?? null,
    });
  }

  /**
   * Record a withdrawal (creates an immutable transaction)
   */
  async recordWithdrawal(
    tenantId: string,
    data: {
      trust_account_id: string;
      client_id: string;
      case_id?: string;
      amount: number;
      description: string;
      invoice_id?: string;
      reference_number?: string;
      created_by: string;
    }
  ): Promise<TrustTransaction> {
    if (data.amount <= 0) {
      throw new Error('Withdrawal amount must be positive');
    }

    return this.append(tenantId, {
      ...data,
      case_id: data.case_id ?? null,
      transaction_type: 'withdrawal',
      amount: -Math.abs(data.amount), // Store as negative
      currency: 'ILS',
      invoice_id: data.invoice_id ?? null,
      payment_id: null,
      related_transaction_id: null,
      reference_number: data.reference_number ?? null,
    });
  }
}

// ============================================================================
// AUDIT LOG REPOSITORY (IMMUTABLE)
// ============================================================================

export interface AuditLog extends ImmutableEntity {
  id: string;
  tenant_id: string;
  user_id: string | null;
  user_email: string | null;
  user_name: string | null;
  ip_address: string | null;
  user_agent: string | null;
  action: 'CREATE' | 'READ' | 'UPDATE' | 'DELETE' | 'LOGIN' | 'LOGOUT' | 'EXPORT' | 'PRINT' | 'ERROR';
  action_category: string | null;
  entity_type: string | null;
  entity_id: string | null;
  description: string | null;
  changes_json: Record<string, unknown> | null;
  request_json: Record<string, unknown> | null;
  session_id: string | null;
  previous_hash: string | null;
  entry_hash: string;
  retention_date: Date;
  is_financial: boolean;
  created_at: Date;
}

export type CreateAuditLogData = Omit<AuditLog, 'id' | 'tenant_id' | 'created_at'>;

export class AuditLogRepository extends ImmutableRepository<AuditLog> {
  constructor() {
    super({
      tableName: 'audit.logs',
    });
  }

  /**
   * Find logs by user
   */
  async findByUser(
    tenantId: string,
    userId: string,
    options?: { limit?: number; offset?: number }
  ): Promise<AuditLog[]> {
    this.validateTenantId(tenantId, 'findByUser');

    const result = await this.list(tenantId, {
      filters: [{ field: 'user_id', operator: '=', value: userId }],
      sort: { field: 'created_at', direction: 'DESC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 }
    });

    return result.data;
  }

  /**
   * Find logs by entity
   */
  async findByEntity(
    tenantId: string,
    entityType: string,
    entityId: string,
    options?: { limit?: number; offset?: number }
  ): Promise<AuditLog[]> {
    this.validateTenantId(tenantId, 'findByEntity');

    const result = await this.list(tenantId, {
      filters: [
        { field: 'entity_type', operator: '=', value: entityType },
        { field: 'entity_id', operator: '=', value: entityId }
      ],
      sort: { field: 'created_at', direction: 'DESC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 }
    });

    return result.data;
  }

  /**
   * Find logs by action type
   */
  async findByAction(
    tenantId: string,
    action: AuditLog['action'],
    options?: { limit?: number; offset?: number }
  ): Promise<AuditLog[]> {
    this.validateTenantId(tenantId, 'findByAction');

    const result = await this.list(tenantId, {
      filters: [{ field: 'action', operator: '=', value: action }],
      sort: { field: 'created_at', direction: 'DESC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 }
    });

    return result.data;
  }

  /**
   * Get logs within a date range
   */
  async findByDateRange(
    tenantId: string,
    startDate: Date,
    endDate: Date,
    options?: { limit?: number; offset?: number }
  ): Promise<AuditLog[]> {
    this.validateTenantId(tenantId, 'findByDateRange');

    try {
      const text = `
        SELECT * FROM audit.logs
        WHERE tenant_id = $1
          AND created_at >= $2
          AND created_at <= $3
        ORDER BY created_at DESC
        LIMIT $4 OFFSET $5
      `;
      const result = await query<AuditLog>(text, [
        tenantId,
        startDate.toISOString(),
        endDate.toISOString(),
        options?.limit ?? 100,
        options?.offset ?? 0
      ]);

      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}

// ============================================================================
// EXPORT REPOSITORY INSTANCES
// ============================================================================

export const clientRepository = new ClientRepository();
export const trustTransactionRepository = new TrustTransactionRepository();
export const auditLogRepository = new AuditLogRepository();

// Re-export base classes and types
export { BaseRepository, ImmutableRepository };
export type { BaseEntity, SoftDeletableEntity, ImmutableEntity, Filter, ListOptions, PaginatedResult };
