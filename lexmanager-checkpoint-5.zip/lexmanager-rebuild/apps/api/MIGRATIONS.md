# Database Migration & Seed System

## Overview

LexManager uses a production-grade migration and seed system with:
- **Checksum verification** to prevent modified migrations from running
- **Transaction support** for atomic migrations
- **Status tracking** in `schema_migrations` and `schema_seeds` tables
- **Rollback support** for safe deployments

## Quick Start

```bash
# Start PostgreSQL (if using Docker)
pnpm docker:up

# Run all migrations and seeds
pnpm db:setup

# Or step by step:
pnpm db:migrate        # Run pending migrations
pnpm db:seed           # Run pending seeds
```

## CLI Commands

### Migrations

| Command | Description |
|---------|-------------|
| `pnpm db:migrate` | Run all pending migrations |
| `pnpm db:migrate:down` | Rollback the last migration |
| `pnpm db:migrate:status` | Show migration status |
| `pnpm db:migrate:reset` | Drop all and recreate (requires `--confirm`) |

### Seeds

| Command | Description |
|---------|-------------|
| `pnpm db:seed` | Run all pending seeds |
| `pnpm db:seed --force` | Re-run all seeds (even applied ones) |
| `pnpm db:seed:status` | Show seed status |
| `pnpm db:seed:reset` | Reset and re-run all seeds (requires `--confirm`) |

### Combined

| Command | Description |
|---------|-------------|
| `pnpm db:setup` | Run migrations + seeds (for fresh setup) |
| `pnpm db:reset` | Full reset: drop all, migrate, seed (requires `--confirm`) |

## Migration Files

### Naming Convention

```
{version}_{name}.sql         # UP migration
{version}_{name}_down.sql    # DOWN migration (rollback)
```

Examples:
```
001_initial_schema.sql
001_initial_schema_down.sql
002_add_notifications.sql
002_add_notifications_down.sql
```

### File Location

```
apps/api/src/db/migrations/
├── 001_initial_schema.sql
├── 001_initial_schema_down.sql
├── runner.ts
└── ...
```

### Writing Migrations

**UP Migration (001_example.sql):**
```sql
-- Always use transactions
BEGIN;

-- Your schema changes
CREATE TABLE example (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMPTZ
);

-- Add indexes
CREATE INDEX idx_example_tenant ON example(tenant_id) WHERE deleted_at IS NULL;

-- Add triggers
CREATE TRIGGER trg_example_updated_at 
    BEFORE UPDATE ON example 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

COMMIT;
```

**DOWN Migration (001_example_down.sql):**
```sql
BEGIN;

DROP TRIGGER IF EXISTS trg_example_updated_at ON example;
DROP TABLE IF EXISTS example;

COMMIT;
```

## Seed Files

### Naming Convention

```
{order}_{name}.sql
```

Examples:
```
001_roles_permissions.sql
002_default_settings.sql
003_demo_data.sql
```

### File Location

```
apps/api/src/db/seeds/
├── 001_roles_permissions.sql
├── runner.ts
└── ...
```

### Writing Seeds

Seeds should be **idempotent** - safe to run multiple times:

```sql
BEGIN;

-- Use INSERT ... ON CONFLICT for idempotency
INSERT INTO roles (id, name, name_he, description, is_system) VALUES
    ('00000000-0000-0000-0000-000000000001', 'admin', 'מנהל מערכת', 'Full access', TRUE)
ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    name_he = EXCLUDED.name_he,
    description = EXCLUDED.description;

COMMIT;
```

## Checksum Protection

### How It Works

1. Each migration file's content is hashed (SHA-256)
2. The checksum is stored in `schema_migrations` when applied
3. Before running, checksums are compared
4. **Modified migrations are blocked** to prevent data corruption

### Example Status Output

```
📋 Migration Status:
──────────────────────────────────────────────────────────────────────
Version  Name                                    Status     Applied At
──────────────────────────────────────────────────────────────────────
001      initial_schema                          ✅ applied    2024-01-15
002      add_notifications                       ⏳ pending    -
003      add_reports                             ⚠️ modified   2024-01-10
──────────────────────────────────────────────────────────────────────
Total: 3 | Applied: 1 | Pending: 1 | Modified: 1

⚠️  WARNING: Modified migrations detected. This may indicate tampering.
```

### Handling Modified Migrations

If a migration shows as "modified":

1. **In Development**: Reset and re-migrate
   ```bash
   pnpm db:reset --confirm
   ```

2. **In Production**: NEVER modify applied migrations
   - Create a new migration to make changes
   - If critical, contact your DBA for manual intervention

## Production Safety

### Blocked in Production

These commands are **disabled** when `NODE_ENV=production`:

- `pnpm db:migrate:reset`
- `pnpm db:seed:reset`
- `pnpm db:reset`

### Deployment Checklist

1. ✅ Test migrations locally
2. ✅ Test migrations in staging
3. ✅ Backup production database
4. ✅ Run `pnpm db:migrate:status` to verify
5. ✅ Run `pnpm db:migrate` 
6. ✅ Verify with `pnpm db:migrate:status`

## Database Tables

### schema_migrations

Tracks applied migrations:

```sql
CREATE TABLE schema_migrations (
    version VARCHAR(20) PRIMARY KEY,    -- e.g., "001"
    name VARCHAR(255) NOT NULL,         -- e.g., "initial_schema"
    checksum VARCHAR(64) NOT NULL,      -- SHA-256 hash
    applied_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

### schema_seeds

Tracks applied seeds:

```sql
CREATE TABLE schema_seeds (
    name VARCHAR(255) PRIMARY KEY,      -- e.g., "roles_permissions"
    checksum VARCHAR(64) NOT NULL,      -- SHA-256 hash
    applied_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

## Programmatic Usage

### Migration Runner

```typescript
import { MigrationRunner } from './db/migrations/runner.js';

const runner = new MigrationRunner(DATABASE_URL);

// Run migrations
const { applied, errors } = await runner.migrateUp();

// Rollback
const { rolledBack, error } = await runner.migrateDown();

// Check status
const statuses = await runner.status();

// Close connection
await runner.close();
```

### Seed Runner

```typescript
import { SeedRunner } from './db/seeds/runner.js';

const runner = new SeedRunner(DATABASE_URL);

// Run seeds
const { applied, skipped, errors } = await runner.run();

// Force re-run
const result = await runner.run({ force: true });

// Close connection
await runner.close();
```

## Troubleshooting

### "Modified migration detected"

A previously applied migration file has been changed.

**Solution (Development):**
```bash
pnpm db:reset --confirm
```

**Solution (Production):**
Do NOT modify applied migrations. Create a new migration instead.

### "No down migration found"

The rollback file is missing for a migration.

**Solution:**
Create the `{version}_{name}_down.sql` file with rollback SQL.

### "Foreign key constraint violation"

A migration is trying to delete data that's referenced by other tables.

**Solution:**
Use `CASCADE` in your DROP statements or delete dependent data first.

### Connection errors

Ensure `DATABASE_URL` is set correctly:

```bash
export DATABASE_URL="postgresql://user:pass@localhost:5432/lexmanager"
```
