// ============================================================================
// INVOICE REPOSITORY
// apps/api/src/repositories/invoice.repository.ts
// 
// Repository for invoices and invoice lines with tenant scoping
// ============================================================================

import { BaseRepository, type SoftDeletableEntity, type Filter, type PaginatedResult } from './base.repository.js';
import { query, withTransaction } from '../db/connection.js';
import { parsePostgresError, NotFoundError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export interface Invoice extends SoftDeletableEntity {
  id: string;
  tenant_id: string;
  client_id: string;
  case_id: string | null;
  invoice_number: string;
  status: 'draft' | 'sent' | 'paid' | 'partially_paid' | 'overdue' | 'cancelled' | 'void';
  issue_date: Date;
  due_date: Date;
  subtotal: number;
  tax_rate: number;
  tax_amount: number;
  discount_amount: number;
  total: number;
  paid_amount: number;
  balance_due: number;
  currency: string;
  notes: string | null;
  terms_and_conditions: string | null;
  payment_instructions: string | null;
  sent_at: Date | null;
  paid_at: Date | null;
  voided_at: Date | null;
  voided_reason: string | null;
  created_by: string;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

export interface InvoiceLine {
  id: string;
  tenant_id: string;
  invoice_id: string;
  description: string;
  quantity: number;
  unit_price: number;
  amount: number;
  time_entry_id: string | null;
  expense_id: string | null;
  task_id: string | null;
  sort_order: number;
  created_at: Date;
  updated_at: Date;
}

export type CreateInvoiceData = Omit<Invoice, 'id' | 'tenant_id' | 'created_at' | 'updated_at' | 'deleted_at' | 'balance_due'>;
export type UpdateInvoiceData = Partial<Pick<Invoice, 'status' | 'issue_date' | 'due_date' | 'notes' | 'terms_and_conditions' | 'payment_instructions' | 'discount_amount'>>;

export type CreateInvoiceLineData = Omit<InvoiceLine, 'id' | 'tenant_id' | 'created_at' | 'updated_at'>;

export interface InvoiceWithDetails extends Invoice {
  client_name: string;
  client_email: string | null;
  case_title: string | null;
  case_number: string | null;
  lines: InvoiceLine[];
}

// ============================================================================
// REPOSITORY
// ============================================================================

export class InvoiceRepository extends BaseRepository<Invoice> {
  constructor() {
    super({
      tableName: 'invoices',
      supportsSoftDelete: true,
    });
  }

  /**
   * Find invoice by invoice number within tenant
   */
  async findByInvoiceNumber(tenantId: string, invoiceNumber: string): Promise<Invoice | null> {
    this.validateTenantId(tenantId, 'findByInvoiceNumber');

    return this.findOne(tenantId, [
      { field: 'invoice_number', operator: '=', value: invoiceNumber }
    ]);
  }

  /**
   * Find invoices by client
   */
  async findByClient(
    tenantId: string, 
    clientId: string,
    options?: { limit?: number; offset?: number; status?: Invoice['status'] }
  ): Promise<Invoice[]> {
    this.validateTenantId(tenantId, 'findByClient');

    const filters: Filter[] = [{ field: 'client_id', operator: '=', value: clientId }];
    if (options?.status) {
      filters.push({ field: 'status', operator: '=', value: options.status });
    }

    const result = await this.list(tenantId, {
      filters,
      sort: { field: 'issue_date', direction: 'DESC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 },
    });

    return result.data;
  }

  /**
   * Find invoices by case
   */
  async findByCase(
    tenantId: string, 
    caseId: string,
    options?: { limit?: number; offset?: number }
  ): Promise<Invoice[]> {
    this.validateTenantId(tenantId, 'findByCase');

    const result = await this.list(tenantId, {
      filters: [{ field: 'case_id', operator: '=', value: caseId }],
      sort: { field: 'issue_date', direction: 'DESC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 },
    });

    return result.data;
  }

  /**
   * Get invoice with full details including lines
   */
  async findByIdWithDetails(tenantId: string, invoiceId: string): Promise<InvoiceWithDetails | null> {
    this.validateTenantId(tenantId, 'findByIdWithDetails');

    try {
      // Get invoice with client/case info
      const invoiceText = `
        SELECT 
          i.*,
          cl.name as client_name,
          cl.email as client_email,
          c.title as case_title,
          c.case_number
        FROM invoices i
        JOIN clients cl ON i.client_id = cl.id AND i.tenant_id = cl.tenant_id
        LEFT JOIN cases c ON i.case_id = c.id AND i.tenant_id = c.tenant_id
        WHERE i.tenant_id = $1 AND i.id = $2 AND i.deleted_at IS NULL
      `;
      const invoiceResult = await query<InvoiceWithDetails>(invoiceText, [tenantId, invoiceId]);
      
      if (invoiceResult.rows.length === 0) {
        return null;
      }

      // Get invoice lines
      const linesText = `
        SELECT * FROM invoice_lines
        WHERE tenant_id = $1 AND invoice_id = $2
        ORDER BY sort_order ASC
      `;
      const linesResult = await query<InvoiceLine>(linesText, [tenantId, invoiceId]);

      return {
        ...invoiceResult.rows[0]!,
        lines: linesResult.rows,
      };
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Generate next invoice number for tenant
   */
  async generateInvoiceNumber(tenantId: string): Promise<string> {
    this.validateTenantId(tenantId, 'generateInvoiceNumber');

    try {
      const year = new Date().getFullYear();
      const text = `
        SELECT COUNT(*) + 1 as next_num
        FROM invoices
        WHERE tenant_id = $1 
          AND EXTRACT(YEAR FROM created_at) = $2
      `;
      const result = await query<{ next_num: number }>(text, [tenantId, year]);
      const nextNum = result.rows[0]?.next_num || 1;
      return `INV-${year}-${String(nextNum).padStart(5, '0')}`;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Create invoice with lines in a transaction
   */
  async createWithLines(
    tenantId: string,
    invoiceData: Omit<CreateInvoiceData, 'invoice_number'>,
    lines: Omit<CreateInvoiceLineData, 'invoice_id'>[]
  ): Promise<InvoiceWithDetails> {
    this.validateTenantId(tenantId, 'createWithLines');

    return withTransaction(async (client) => {
      // Generate invoice number
      const invoiceNumber = await this.generateInvoiceNumber(tenantId);

      // Calculate totals
      const subtotal = lines.reduce((sum, line) => sum + line.amount, 0);
      const taxAmount = subtotal * (invoiceData.tax_rate / 100);
      const total = subtotal + taxAmount - (invoiceData.discount_amount || 0);

      // Create invoice
      const invoiceText = `
        INSERT INTO invoices (
          tenant_id, client_id, case_id, invoice_number, status,
          issue_date, due_date, subtotal, tax_rate, tax_amount,
          discount_amount, total, paid_amount, balance_due, currency,
          notes, terms_and_conditions, payment_instructions, created_by
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19
        ) RETURNING *
      `;
      const invoiceResult = await client.query<Invoice>(invoiceText, [
        tenantId,
        invoiceData.client_id,
        invoiceData.case_id,
        invoiceNumber,
        invoiceData.status || 'draft',
        invoiceData.issue_date,
        invoiceData.due_date,
        subtotal,
        invoiceData.tax_rate,
        taxAmount,
        invoiceData.discount_amount || 0,
        total,
        0, // paid_amount
        total, // balance_due
        invoiceData.currency,
        invoiceData.notes,
        invoiceData.terms_and_conditions,
        invoiceData.payment_instructions,
        invoiceData.created_by,
      ]);

      const invoice = invoiceResult.rows[0]!;

      // Create invoice lines
      const createdLines: InvoiceLine[] = [];
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const lineText = `
          INSERT INTO invoice_lines (
            tenant_id, invoice_id, description, quantity, unit_price,
            amount, time_entry_id, expense_id, task_id, sort_order
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
          RETURNING *
        `;
        const lineResult = await client.query<InvoiceLine>(lineText, [
          tenantId,
          invoice.id,
          line.description,
          line.quantity,
          line.unit_price,
          line.amount,
          line.time_entry_id,
          line.expense_id,
          line.task_id,
          i,
        ]);
        createdLines.push(lineResult.rows[0]!);
      }

      return {
        ...invoice,
        client_name: '',
        client_email: null,
        case_title: null,
        case_number: null,
        lines: createdLines,
      };
    });
  }

  /**
   * Add line to existing invoice
   */
  async addLine(
    tenantId: string,
    invoiceId: string,
    lineData: Omit<CreateInvoiceLineData, 'invoice_id'>
  ): Promise<InvoiceLine> {
    this.validateTenantId(tenantId, 'addLine');

    return withTransaction(async (client) => {
      // Get current max sort order
      const orderResult = await client.query<{ max_order: number }>(
        'SELECT COALESCE(MAX(sort_order), -1) + 1 as max_order FROM invoice_lines WHERE tenant_id = $1 AND invoice_id = $2',
        [tenantId, invoiceId]
      );

      // Create line
      const lineText = `
        INSERT INTO invoice_lines (
          tenant_id, invoice_id, description, quantity, unit_price,
          amount, time_entry_id, expense_id, task_id, sort_order
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        RETURNING *
      `;
      const lineResult = await client.query<InvoiceLine>(lineText, [
        tenantId,
        invoiceId,
        lineData.description,
        lineData.quantity,
        lineData.unit_price,
        lineData.amount,
        lineData.time_entry_id,
        lineData.expense_id,
        lineData.task_id,
        orderResult.rows[0]?.max_order || 0,
      ]);

      // Update invoice totals
      await this.recalculateTotals(tenantId, invoiceId, client);

      return lineResult.rows[0]!;
    });
  }

  /**
   * Recalculate invoice totals
   */
  private async recalculateTotals(tenantId: string, invoiceId: string, client?: any): Promise<void> {
    const queryFn = client ? client.query.bind(client) : query;

    const text = `
      UPDATE invoices i
      SET 
        subtotal = (
          SELECT COALESCE(SUM(amount), 0) 
          FROM invoice_lines 
          WHERE tenant_id = $1 AND invoice_id = $2
        ),
        tax_amount = (
          SELECT COALESCE(SUM(amount), 0) * i.tax_rate / 100
          FROM invoice_lines 
          WHERE tenant_id = $1 AND invoice_id = $2
        ),
        total = (
          SELECT COALESCE(SUM(amount), 0) * (1 + i.tax_rate / 100) - i.discount_amount
          FROM invoice_lines 
          WHERE tenant_id = $1 AND invoice_id = $2
        ),
        balance_due = (
          SELECT COALESCE(SUM(amount), 0) * (1 + i.tax_rate / 100) - i.discount_amount - i.paid_amount
          FROM invoice_lines 
          WHERE tenant_id = $1 AND invoice_id = $2
        ),
        updated_at = CURRENT_TIMESTAMP
      WHERE tenant_id = $1 AND id = $2
    `;
    await queryFn(text, [tenantId, invoiceId]);
  }

  /**
   * Record payment
   */
  async recordPayment(
    tenantId: string,
    invoiceId: string,
    amount: number
  ): Promise<Invoice> {
    this.validateTenantId(tenantId, 'recordPayment');

    try {
      const text = `
        UPDATE invoices
        SET 
          paid_amount = paid_amount + $3,
          balance_due = balance_due - $3,
          status = CASE
            WHEN balance_due - $3 <= 0 THEN 'paid'
            WHEN paid_amount + $3 > 0 THEN 'partially_paid'
            ELSE status
          END,
          paid_at = CASE WHEN balance_due - $3 <= 0 THEN CURRENT_TIMESTAMP ELSE paid_at END,
          updated_at = CURRENT_TIMESTAMP
        WHERE tenant_id = $1 AND id = $2 AND deleted_at IS NULL
        RETURNING *
      `;
      const result = await query<Invoice>(text, [tenantId, invoiceId, amount]);
      
      if (result.rows.length === 0) {
        throw new NotFoundError('invoices', invoiceId);
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get overdue invoices
   */
  async findOverdue(tenantId: string, options?: { limit?: number }): Promise<Invoice[]> {
    this.validateTenantId(tenantId, 'findOverdue');

    try {
      const text = `
        SELECT * FROM invoices
        WHERE tenant_id = $1
          AND deleted_at IS NULL
          AND status IN ('sent', 'partially_paid')
          AND due_date < CURRENT_DATE
        ORDER BY due_date ASC
        LIMIT $2
      `;
      const result = await query<Invoice>(text, [tenantId, options?.limit ?? 100]);
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get invoice summary for client
   */
  async getClientSummary(
    tenantId: string,
    clientId: string
  ): Promise<{ total: number; paid: number; outstanding: number; overdue: number }> {
    this.validateTenantId(tenantId, 'getClientSummary');

    try {
      const text = `
        SELECT 
          COALESCE(SUM(total), 0) as total,
          COALESCE(SUM(paid_amount), 0) as paid,
          COALESCE(SUM(balance_due), 0) as outstanding,
          COALESCE(SUM(CASE WHEN due_date < CURRENT_DATE AND status IN ('sent', 'partially_paid') THEN balance_due ELSE 0 END), 0) as overdue
        FROM invoices
        WHERE tenant_id = $1 AND client_id = $2 AND deleted_at IS NULL AND status NOT IN ('void', 'cancelled')
      `;
      const result = await query<{ total: string; paid: string; outstanding: string; overdue: string }>(text, [tenantId, clientId]);
      return {
        total: parseFloat(result.rows[0]?.total || '0'),
        paid: parseFloat(result.rows[0]?.paid || '0'),
        outstanding: parseFloat(result.rows[0]?.outstanding || '0'),
        overdue: parseFloat(result.rows[0]?.overdue || '0'),
      };
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}

// Export singleton instance
export const invoiceRepository = new InvoiceRepository();
