// ============================================================================
// DATABASE SETUP TEST
// apps/api/tests/integration/db/setup.integration.test.ts
// ============================================================================

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import pg from 'pg';
import { MigrationRunner } from '../../../src/db/migrations/runner.js';
import { SeedRunner } from '../../../src/db/seeds/runner.js';

const { Pool } = pg;

// Skip if no database connection
const DATABASE_URL = process.env.DATABASE_URL;
const shouldRun = DATABASE_URL && DATABASE_URL.includes('localhost');

describe.skipIf(!shouldRun)('Database Setup Integration', () => {
  let pool: pg.Pool;
  let migrationRunner: MigrationRunner;
  let seedRunner: SeedRunner;

  beforeAll(() => {
    pool = new Pool({ connectionString: DATABASE_URL });
    migrationRunner = new MigrationRunner(DATABASE_URL!, false); // quiet mode
    seedRunner = new SeedRunner(DATABASE_URL!, false); // quiet mode
  });

  afterAll(async () => {
    await migrationRunner.close();
    await seedRunner.close();
    await pool.end();
  });

  describe('Full Setup Flow: reset -> migrate -> seed', () => {
    it('should reset database successfully', async () => {
      const result = await migrationRunner.reset();
      expect(result.success).toBe(true);
      expect(result.error).toBeNull();
    });

    it('should run all migrations successfully', async () => {
      const result = await migrationRunner.migrateUp();
      expect(result.errors).toHaveLength(0);
      expect(result.applied.length).toBeGreaterThan(0);
    });

    it('should have schema_migrations table with records', async () => {
      const result = await pool.query('SELECT COUNT(*) as count FROM schema_migrations');
      expect(parseInt(result.rows[0].count, 10)).toBeGreaterThan(0);
    });

    it('should have all expected tables', async () => {
      const tables = [
        'tenants',
        'users',
        'roles',
        'permissions',
        'role_permissions',
        'clients',
        'cases',
        'tasks',
        'documents',
        'calendar_events',
        'time_entries',
        'invoices',
        'invoice_lines',
        'payments',
        'trust_accounts',
        'trust_transactions',
        'custom_field_definitions',
        'custom_field_values',
        'settings',
      ];

      for (const table of tables) {
        const result = await pool.query(`
          SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name = $1
          )
        `, [table]);
        expect(result.rows[0].exists, `Table ${table} should exist`).toBe(true);
      }
    });

    it('should have audit schema with logs table', async () => {
      const result = await pool.query(`
        SELECT EXISTS (
          SELECT FROM information_schema.tables 
          WHERE table_schema = 'audit' 
          AND table_name = 'logs'
        )
      `);
      expect(result.rows[0].exists).toBe(true);
    });

    it('should run all seeds successfully', async () => {
      const result = await seedRunner.run();
      expect(result.errors).toHaveLength(0);
    });

    it('should have seeded roles', async () => {
      const result = await pool.query('SELECT COUNT(*) as count FROM roles');
      expect(parseInt(result.rows[0].count, 10)).toBe(4); // admin, attorney, paralegal, staff
    });

    it('should have seeded permissions', async () => {
      const result = await pool.query('SELECT COUNT(*) as count FROM permissions');
      expect(parseInt(result.rows[0].count, 10)).toBeGreaterThan(50); // 55+ permissions
    });

    it('should have role_permissions mappings', async () => {
      const result = await pool.query('SELECT COUNT(*) as count FROM role_permissions');
      expect(parseInt(result.rows[0].count, 10)).toBeGreaterThan(0);
    });
  });

  describe('Migration Status', () => {
    it('should report all migrations as applied', async () => {
      const statuses = await migrationRunner.status();
      
      for (const status of statuses) {
        expect(status.status).toBe('applied');
      }
    });

    it('should not have modified migrations', async () => {
      const statuses = await migrationRunner.status();
      const modified = statuses.filter(s => s.status === 'modified');
      expect(modified).toHaveLength(0);
    });
  });

  describe('Migration Down (Rollback)', () => {
    it('should rollback successfully', async () => {
      const result = await migrationRunner.migrateDown();
      expect(result.error).toBeNull();
      expect(result.rolledBack).not.toBeNull();
    });

    it('should have fewer migrations applied after rollback', async () => {
      const statuses = await migrationRunner.status();
      const pending = statuses.filter(s => s.status === 'pending');
      expect(pending.length).toBeGreaterThan(0);
    });

    it('should re-migrate successfully', async () => {
      const result = await migrationRunner.migrateUp();
      expect(result.errors).toHaveLength(0);
      expect(result.applied.length).toBeGreaterThan(0);
    });
  });

  describe('Immutable Tables Protection (via triggers)', () => {
    let tenantId: string;
    let userId: string;
    let trustAccountId: string;
    let clientId: string;

    beforeAll(async () => {
      // Create a test tenant
      const tenantResult = await pool.query(`
        INSERT INTO tenants (name, slug) 
        VALUES ('Test Tenant', 'test-tenant-${Date.now()}') 
        RETURNING id
      `);
      tenantId = tenantResult.rows[0].id;

      // Create a test role reference
      const roleResult = await pool.query(`SELECT id FROM roles WHERE name = 'admin' LIMIT 1`);
      const roleId = roleResult.rows[0].id;

      // Create a test user
      const userResult = await pool.query(`
        INSERT INTO users (tenant_id, email, password_hash, name, role_id)
        VALUES ($1, 'test@test.com', 'hash', 'Test User', $2)
        RETURNING id
      `, [tenantId, roleId]);
      userId = userResult.rows[0].id;

      // Create a test client
      const clientResult = await pool.query(`
        INSERT INTO clients (tenant_id, name, client_type, status, address_country, currency, payment_terms)
        VALUES ($1, 'Test Client', 'individual', 'active', 'Israel', 'ILS', 30)
        RETURNING id
      `, [tenantId]);
      clientId = clientResult.rows[0].id;

      // Create a trust account
      const trustResult = await pool.query(`
        INSERT INTO trust_accounts (tenant_id, client_id, account_name, currency)
        VALUES ($1, $2, 'Test Trust Account', 'ILS')
        RETURNING id
      `, [tenantId, clientId]);
      trustAccountId = trustResult.rows[0].id;
    });

    it('should allow INSERT into trust_transactions', async () => {
      const result = await pool.query(`
        INSERT INTO trust_transactions (
          tenant_id, trust_account_id, client_id, 
          transaction_type, amount, currency, description, created_by
        )
        VALUES ($1, $2, $3, 'deposit', 1000.00, 'ILS', 'Test deposit', $4)
        RETURNING id
      `, [tenantId, trustAccountId, clientId, userId]);
      
      expect(result.rows[0].id).toBeDefined();
    });

    it('should BLOCK UPDATE on trust_transactions', async () => {
      await expect(
        pool.query(`
          UPDATE trust_transactions 
          SET amount = 2000.00 
          WHERE tenant_id = $1
        `, [tenantId])
      ).rejects.toThrow(/immutable/i);
    });

    it('should BLOCK DELETE on trust_transactions', async () => {
      await expect(
        pool.query(`
          DELETE FROM trust_transactions 
          WHERE tenant_id = $1
        `, [tenantId])
      ).rejects.toThrow(/immutable/i);
    });

    it('should allow INSERT into audit.logs', async () => {
      const result = await pool.query(`
        INSERT INTO audit.logs (
          tenant_id, user_id, action, entity_type, description,
          entry_hash, retention_date
        )
        VALUES ($1, $2, 'CREATE', 'client', 'Test audit log', 
                'abc123', CURRENT_DATE + INTERVAL '7 years')
        RETURNING id
      `, [tenantId, userId]);
      
      expect(result.rows[0].id).toBeDefined();
    });

    it('should BLOCK UPDATE on audit.logs', async () => {
      await expect(
        pool.query(`
          UPDATE audit.logs 
          SET description = 'Modified' 
          WHERE tenant_id = $1
        `, [tenantId])
      ).rejects.toThrow(/immutable/i);
    });

    it('should BLOCK DELETE on audit.logs', async () => {
      await expect(
        pool.query(`
          DELETE FROM audit.logs 
          WHERE tenant_id = $1
        `, [tenantId])
      ).rejects.toThrow(/immutable/i);
    });

    afterAll(async () => {
      // Cleanup (cannot delete trust_transactions/audit.logs due to triggers, but can delete parent records)
      // In a real scenario, we'd use a separate test database
    });
  });
});
