# CHECKPOINT 4 — ERROR STANDARD + OPENAPI SKELETON + AUDIT HOOKS

## Status: ✅ COMPLETE

---

## A) Global Error Standard

### Error Envelope Format
All API errors follow this JSON structure:
```json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable message",
    "details": {}
  },
  "correlationId": "uuid"
}
```

### Success Envelope Format
All successful responses follow this structure:
```json
{
  "data": { ... },
  "correlationId": "uuid",
  "meta": {
    "page": 1,
    "limit": 20,
    "total": 100
  }
}
```

### Error Codes
| Code | HTTP Status | Description |
|------|-------------|-------------|
| `VALIDATION_ERROR` | 400 | Request validation failed |
| `UNAUTHORIZED` | 401 | Authentication required |
| `INVALID_TOKEN` | 401 | Invalid/expired JWT |
| `TOKEN_REUSE` | 401 | Refresh token reuse detected |
| `FORBIDDEN` | 403 | Permission denied |
| `NOT_FOUND` | 404 | Resource not found |
| `ROUTE_NOT_FOUND` | 404 | API route not found |
| `CONFLICT` | 409 | Resource conflict |
| `DUPLICATE_ENTRY` | 409 | Unique constraint violation |
| `RATE_LIMITED` | 429 | Too many requests |
| `INTERNAL_ERROR` | 500 | Server error |

### Files Created
- `src/errors/index.ts` - Unified error handling module

---

## B) Validation Layer

### Location
- `src/validation/index.ts` - Zod schemas and middleware

### Usage
```typescript
import { validate, loginSchema } from '../validation/index.js';

router.post('/login', validate(loginSchema, 'body'), handler);
```

### Schemas Implemented
- Auth: login, register, refresh, password-reset
- Clients, Cases, Tasks, Documents, Invoices
- Trust accounts and transactions
- Custom fields
- Audit log queries
- Common: UUID, email, password, pagination

---

## C) OpenAPI Skeleton

### Location
`apps/api/openapi/lexmanager.yaml`

### Contents
- OpenAPI 3.0.3 specification
- Security: Bearer JWT + X-Tenant-Id header
- All paths use standard error envelope

### Paths
| Endpoint | Methods | Status |
|----------|---------|--------|
| `/health`, `/ready` | GET | Complete |
| `/auth/*` | POST, GET | Complete |
| `/clients`, `/clients/{id}` | CRUD | Skeleton |
| `/cases`, `/cases/{id}` | CRUD | Skeleton |
| `/tasks`, `/tasks/{id}` | CRUD | Skeleton |
| `/documents`, `/documents/{id}` | CRUD | Skeleton |
| `/invoices`, `/invoices/{id}` | CRUD | Skeleton |
| `/trust/accounts/*` | CRUD + operations | Skeleton |
| `/custom-fields/*` | CRUD | Skeleton |
| `/audit/logs`, `/audit/verify` | GET | Skeleton |

---

## D) Audit Hooks

### Location
- `src/audit/mutation-logger.ts` - Audit helper functions
- `src/audit/index.ts` - Exports

### Usage
```typescript
import { auditCreate, auditUpdate, auditSoftDelete, withAudit } from '../audit/index.js';

// Direct usage
await auditCreate(req, 'client', clientId, clientData);
await auditUpdate(req, 'client', clientId, oldData, newData);
await auditSoftDelete(req, 'client', clientId, clientData);

// Wrapper usage
const audited = withAudit(req, 'client');
const client = await audited.create(async () => clientService.create(...));
```

### Features
- Best-effort: audit failures NEVER crash business operations
- Automatic tenant/user/IP extraction from request
- Sanitizes sensitive fields (password, token, etc.)
- Marks financial entities for longer retention
- Includes correlation ID for request tracing

### Financial Entities (7-year retention)
- clients, cases, invoices, invoice_lines
- payments, time_entries
- trust_accounts, trust_transactions

### Integration Test
`tests/integration/audit/audit-mutation.integration.test.ts`

---

## E) CHECKPOINT READY — Verification Checklist

### 1. Run Migrations
```bash
cd apps/api
npm run db:migrate
# or
pnpm db:migrate
```

### 2. Start API
```bash
# Development
npm run dev
# or
pnpm dev

# Production
npm run build && npm start
```

### 3. Validate OpenAPI
```bash
# Install validator (if needed)
npm install -g @apidevtools/swagger-cli

# Validate the spec
swagger-cli validate apps/api/openapi/lexmanager.yaml

# Or use online validator:
# https://editor.swagger.io/
# Paste contents of lexmanager.yaml
```

### 4. Trigger Audited Mutation
```bash
# 1. Create a tenant (if not exists)
curl -X POST http://localhost:3000/auth/register \
  -H "Content-Type: application/json" \
  -H "X-Tenant-Id: YOUR_TENANT_UUID" \
  -d '{"email":"test@example.com","password":"Test123!@#","name":"Test User"}'

# 2. Check audit logs in database
psql $DATABASE_URL -c "SELECT action, entity_type, description, created_at FROM audit.logs ORDER BY created_at DESC LIMIT 5;"
```

### 5. Run Tests
```bash
# All tests
npm test

# Specific audit test
npm test -- tests/integration/audit/audit-mutation.integration.test.ts

# With database
DATABASE_URL=postgresql://... npm test
```

### 6. Verify Error Envelope
```bash
# Should return standard error envelope
curl http://localhost:3000/nonexistent-route

# Expected response:
# {
#   "error": {
#     "code": "ROUTE_NOT_FOUND",
#     "message": "Route GET /nonexistent-route not found"
#   },
#   "correlationId": "..."
# }
```

---

## Files Summary

| File | Purpose |
|------|---------|
| `src/errors/index.ts` | Global error handling |
| `src/validation/index.ts` | Zod validation schemas |
| `src/audit/mutation-logger.ts` | Audit helper functions |
| `src/audit/index.ts` | Audit exports |
| `src/app.ts` | Updated with error handlers |
| `src/routes/auth.routes.ts` | Refactored with validation |
| `openapi/lexmanager.yaml` | OpenAPI 3.0 specification |
| `tests/integration/audit/audit-mutation.integration.test.ts` | Audit integration test |
| `CHECKPOINT-4-ERROR-OPENAPI-AUDIT.md` | This file |

---

## STOP

Checkpoint 4 is complete. Do not proceed to Checkpoint 5.
