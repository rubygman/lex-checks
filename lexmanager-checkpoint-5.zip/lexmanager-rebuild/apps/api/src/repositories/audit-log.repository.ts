// ============================================================================
// AUDIT LOG REPOSITORY
// apps/api/src/repositories/audit-log.repository.ts
// 
// IMMUTABLE: No update or delete methods allowed
// NO FOREIGN KEYS by design
// ============================================================================

import { query } from '../db/connection.js';
import { parsePostgresError, TenantScopingError, ImmutableTableError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export type AuditAction = 'CREATE' | 'UPDATE' | 'DELETE' | 'RESTORE' | 'LOGIN' | 'LOGOUT' | 'VIEW' | 'EXPORT' | 'IMPORT';
export type AuditCategory = 'data' | 'auth' | 'system' | 'finance' | 'retention' | 'security';

export interface AuditLogEntry {
  id: string;
  tenant_id: string;
  user_id: string | null;
  action: AuditAction;
  action_category: AuditCategory;
  entity_type: string;
  entity_id: string | null;
  description: string;
  changes_json: Record<string, unknown>;
  old_values_json: Record<string, unknown>;
  new_values_json: Record<string, unknown>;
  ip_address: string | null;
  user_agent: string | null;
  request_id: string | null;
  entry_hash: string;
  previous_hash: string | null;
  retention_date: Date;
  is_financial: boolean;
  created_at: Date;
}

export interface CreateAuditLogData {
  user_id?: string;
  action: AuditAction;
  action_category: AuditCategory;
  entity_type: string;
  entity_id?: string;
  description: string;
  changes_json?: Record<string, unknown>;
  old_values_json?: Record<string, unknown>;
  new_values_json?: Record<string, unknown>;
  ip_address?: string;
  user_agent?: string;
  request_id?: string;
  is_financial?: boolean;
  retention_date?: Date;
}

export interface AuditLogFilters {
  entityType?: string;
  entityId?: string;
  userId?: string;
  action?: AuditAction;
  actionCategory?: AuditCategory;
  startDate?: Date;
  endDate?: Date;
  searchText?: string;
}

export interface HashChainVerificationResult {
  totalEntries: number;
  verifiedEntries: number;
  brokenEntries: number;
  isValid: boolean;
  firstBrokenId: string | null;
  firstBrokenAt: Date | null;
}

// ============================================================================
// REPOSITORY
// ============================================================================

export class AuditLogRepository {
  private readonly schemaTable = 'audit.logs';

  /**
   * Validate tenant ID
   */
  private validateTenantId(tenantId: string, operation: string): void {
    if (!tenantId || tenantId.trim() === '') {
      throw new TenantScopingError(
        `${operation} on audit.logs requires a valid tenantId. Received: "${tenantId}"`
      );
    }
  }

  /**
   * Append a new audit log entry
   * Note: entry_hash and previous_hash are calculated by database trigger
   */
  async append(tenantId: string, data: CreateAuditLogData): Promise<AuditLogEntry> {
    this.validateTenantId(tenantId, 'append');

    try {
      const result = await query<AuditLogEntry>(
        `INSERT INTO ${this.schemaTable} (
          tenant_id, user_id, action, action_category, entity_type, entity_id,
          description, changes_json, old_values_json, new_values_json,
          ip_address, user_agent, request_id, is_financial, retention_date
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
        RETURNING *`,
        [
          tenantId,
          data.user_id || null,
          data.action,
          data.action_category,
          data.entity_type,
          data.entity_id || null,
          data.description,
          JSON.stringify(data.changes_json || {}),
          JSON.stringify(data.old_values_json || {}),
          JSON.stringify(data.new_values_json || {}),
          data.ip_address || null,
          data.user_agent || null,
          data.request_id || null,
          data.is_financial || false,
          data.retention_date || null,  // Trigger sets default if null
        ]
      );

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find audit log entry by ID
   */
  async findById(tenantId: string, id: string): Promise<AuditLogEntry | null> {
    this.validateTenantId(tenantId, 'findById');

    try {
      const result = await query<AuditLogEntry>(
        `SELECT * FROM ${this.schemaTable} WHERE id = $1 AND tenant_id = $2`,
        [id, tenantId]
      );

      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * List audit logs with filters
   */
  async list(
    tenantId: string,
    filters: AuditLogFilters = {},
    options: { limit?: number; offset?: number } = {}
  ): Promise<AuditLogEntry[]> {
    this.validateTenantId(tenantId, 'list');

    try {
      const result = await query<AuditLogEntry>(
        `SELECT * FROM audit.search_logs($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
        [
          tenantId,
          filters.entityType || null,
          filters.entityId || null,
          filters.userId || null,
          filters.action || null,
          filters.actionCategory || null,
          filters.startDate || null,
          filters.endDate || null,
          filters.searchText || null,
          options.limit ?? 100,
          options.offset ?? 0,
        ]
      );

      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get audit logs for a specific entity
   */
  async findByEntity(
    tenantId: string,
    entityType: string,
    entityId: string,
    options: { limit?: number; offset?: number } = {}
  ): Promise<AuditLogEntry[]> {
    return this.list(tenantId, { entityType, entityId }, options);
  }

  /**
   * Get audit logs for a specific user
   */
  async findByUser(
    tenantId: string,
    userId: string,
    options: { limit?: number; offset?: number } = {}
  ): Promise<AuditLogEntry[]> {
    return this.list(tenantId, { userId }, options);
  }

  /**
   * Count audit log entries
   */
  async count(tenantId: string, filters: AuditLogFilters = {}): Promise<number> {
    this.validateTenantId(tenantId, 'count');

    const conditions: string[] = ['tenant_id = $1'];
    const params: unknown[] = [tenantId];
    let paramIndex = 2;

    if (filters.entityType) {
      conditions.push(`entity_type = $${paramIndex++}`);
      params.push(filters.entityType);
    }
    if (filters.entityId) {
      conditions.push(`entity_id = $${paramIndex++}`);
      params.push(filters.entityId);
    }
    if (filters.userId) {
      conditions.push(`user_id = $${paramIndex++}`);
      params.push(filters.userId);
    }
    if (filters.action) {
      conditions.push(`action = $${paramIndex++}`);
      params.push(filters.action);
    }
    if (filters.startDate) {
      conditions.push(`created_at >= $${paramIndex++}`);
      params.push(filters.startDate);
    }
    if (filters.endDate) {
      conditions.push(`created_at <= $${paramIndex++}`);
      params.push(filters.endDate);
    }

    try {
      const result = await query<{ count: number }>(
        `SELECT COUNT(*)::int as count FROM ${this.schemaTable}
         WHERE ${conditions.join(' AND ')}`,
        params
      );

      return result.rows[0]?.count || 0;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Verify hash chain integrity
   */
  async verifyHashChain(
    tenantId: string,
    startDate?: Date,
    endDate?: Date
  ): Promise<HashChainVerificationResult> {
    this.validateTenantId(tenantId, 'verifyHashChain');

    try {
      const result = await query<{
        total_entries: number;
        verified_entries: number;
        broken_entries: number;
        is_valid: boolean;
        first_broken_id: string | null;
        first_broken_at: Date | null;
      }>(
        `SELECT * FROM audit.verify_hash_chain($1, $2, $3)`,
        [tenantId, startDate || null, endDate || null]
      );

      const row = result.rows[0]!;
      return {
        totalEntries: row.total_entries,
        verifiedEntries: row.verified_entries,
        brokenEntries: row.broken_entries,
        isValid: row.is_valid,
        firstBrokenId: row.first_broken_id,
        firstBrokenAt: row.first_broken_at,
      };
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get the last entry for a tenant (for hash chain)
   */
  async getLastEntry(tenantId: string): Promise<AuditLogEntry | null> {
    this.validateTenantId(tenantId, 'getLastEntry');

    try {
      const result = await query<AuditLogEntry>(
        `SELECT * FROM ${this.schemaTable}
         WHERE tenant_id = $1
         ORDER BY created_at DESC, id DESC
         LIMIT 1`,
        [tenantId]
      );

      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get statistics for audit logs
   */
  async getStatistics(tenantId: string): Promise<{
    entityType: string;
    action: string;
    entryCount: number;
    firstEntry: Date;
    lastEntry: Date;
    financialCount: number;
  }[]> {
    this.validateTenantId(tenantId, 'getStatistics');

    try {
      const result = await query<{
        entity_type: string;
        action: string;
        entry_count: number;
        first_entry: Date;
        last_entry: Date;
        financial_count: number;
      }>(
        `SELECT * FROM audit.log_statistics WHERE tenant_id = $1`,
        [tenantId]
      );

      return result.rows.map(row => ({
        entityType: row.entity_type,
        action: row.action,
        entryCount: row.entry_count,
        firstEntry: row.first_entry,
        lastEntry: row.last_entry,
        financialCount: row.financial_count,
      }));
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  // ============================================================================
  // BLOCKED OPERATIONS (Immutability)
  // ============================================================================

  /**
   * UPDATE is blocked - throws immediately
   */
  async update(): Promise<never> {
    throw new ImmutableTableError(
      'audit.logs',
      'UPDATE',
      'Audit logs are immutable and cannot be modified. This is required for compliance and security.'
    );
  }

  /**
   * DELETE is blocked - throws immediately
   */
  async delete(): Promise<never> {
    throw new ImmutableTableError(
      'audit.logs',
      'DELETE',
      'Audit logs are immutable and cannot be deleted. This is required for compliance and security.'
    );
  }

  /**
   * SOFT DELETE is blocked - throws immediately
   */
  async softDelete(): Promise<never> {
    throw new ImmutableTableError(
      'audit.logs',
      'DELETE',
      'Audit logs are immutable and cannot be deleted. This is required for compliance and security.'
    );
  }
}

export const auditLogRepository = new AuditLogRepository();
