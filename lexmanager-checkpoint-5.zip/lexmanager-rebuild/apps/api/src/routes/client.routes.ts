// ============================================================================
// CLIENT ROUTES
// apps/api/src/routes/client.routes.ts
// 
// Full CRUD + restore with RBAC, validation, tenant scoping, and audit logging
// ============================================================================

import { Router } from 'express';
import { clientService } from '../services/client.service.js';
import {
  initializeContext,
  resolveTenantFromHeader,
  requireTenant,
  authParser,
  requireAuth,
  requireTenantAccess,
  requirePermission,
} from '../middleware/index.js';
import {
  validate,
  validateAll,
  createClientSchema,
  updateClientSchema,
  clientQuerySchema,
  idParamSchema,
  z,
} from '../validation/index.js';
import { asyncHandler, sendSuccess, NotFoundError } from '../errors/index.js';
import { auditCreate, auditUpdate, auditSoftDelete, auditRestore } from '../audit/index.js';
import { PERMISSIONS } from '../services/rbac.service.js';

const router = Router();

// All routes require tenant context and authentication
router.use(initializeContext());
router.use(resolveTenantFromHeader());
router.use(requireTenant());
router.use(authParser());
router.use(requireAuth());
router.use(requireTenantAccess());

// ============================================================================
// GET /clients - List clients with pagination and search
// ============================================================================

router.get(
  '/',
  requirePermission(PERMISSIONS.CLIENTS_VIEW),
  validate(clientQuerySchema, 'query'),
  asyncHandler(async (req, res) => {
    const { page, limit, sortBy, sortOrder, q, status, clientType } = req.query as any;

    const result = await clientService.list(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      {
        search: q,
        status,
        limit,
        offset: (page - 1) * limit,
      }
    );

    sendSuccess(res, req, result.data, 200, {
      page,
      limit,
      total: result.pagination.total,
      hasMore: result.pagination.hasMore,
    });
  })
);

// ============================================================================
// POST /clients - Create a new client
// ============================================================================

router.post(
  '/',
  requirePermission(PERMISSIONS.CLIENTS_CREATE),
  validate(createClientSchema, 'body'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const client = await clientService.create(
      context,
      req.auth!.tenantId,
      {
        name: req.body.name,
        client_type: req.body.clientType || 'individual',
        email: req.body.email,
        phone: req.body.phone,
        address_street: req.body.address,
        address_city: req.body.city,
        address_postal_code: req.body.postalCode,
        address_country: req.body.country || 'Israel',
        tax_id: req.body.vatNumber,
        currency: 'ILS',
        payment_terms: 30,
        notes: req.body.notes,
      }
    );

    // Audit is done in service, but we can add extra context
    sendSuccess(res, req, client, 201);
  })
);

// ============================================================================
// GET /clients/:id - Get client by ID
// ============================================================================

router.get(
  '/:id',
  requirePermission(PERMISSIONS.CLIENTS_VIEW),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const client = await clientService.getByIdOrFail(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, client);
  })
);

// ============================================================================
// PATCH /clients/:id - Update client
// ============================================================================

router.patch(
  '/:id',
  requirePermission(PERMISSIONS.CLIENTS_EDIT),
  validateAll({
    params: idParamSchema,
    body: updateClientSchema,
  }),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    // Build update data from request body
    const updateData: Record<string, unknown> = {};
    if (req.body.name !== undefined) updateData.name = req.body.name;
    if (req.body.nameHe !== undefined) updateData.name_he = req.body.nameHe;
    if (req.body.email !== undefined) updateData.email = req.body.email;
    if (req.body.phone !== undefined) updateData.phone = req.body.phone;
    if (req.body.phoneSecondary !== undefined) updateData.phone_secondary = req.body.phoneSecondary;
    if (req.body.clientType !== undefined) updateData.client_type = req.body.clientType;
    if (req.body.status !== undefined) updateData.status = req.body.status;
    if (req.body.address !== undefined) updateData.address_street = req.body.address;
    if (req.body.city !== undefined) updateData.address_city = req.body.city;
    if (req.body.postalCode !== undefined) updateData.address_zip = req.body.postalCode;
    if (req.body.country !== undefined) updateData.address_country = req.body.country;
    if (req.body.notes !== undefined) updateData.notes = req.body.notes;

    const client = await clientService.update(
      context,
      req.auth!.tenantId,
      req.params.id,
      updateData as any
    );

    sendSuccess(res, req, client);
  })
);

// ============================================================================
// DELETE /clients/:id - Soft delete client
// ============================================================================

router.delete(
  '/:id',
  requirePermission(PERMISSIONS.CLIENTS_DELETE),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    await clientService.delete(
      context,
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, { message: 'Client deleted successfully' });
  })
);

// ============================================================================
// POST /clients/:id/restore - Restore soft-deleted client
// ============================================================================

router.post(
  '/:id/restore',
  requirePermission(PERMISSIONS.CLIENTS_DELETE),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    await clientService.restore(
      context,
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, { message: 'Client restored successfully' });
  })
);

export default router;
