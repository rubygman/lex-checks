// ============================================================================
// RETENTION CLEANUP JOB
// apps/api/src/jobs/retention-cleanup.job.ts
// 
// Scheduled job for hard-deleting records after retention period
// This is a PLACEHOLDER - should be triggered by external scheduler (cron, etc.)
// 
// IMPORTANT: This job should NOT run automatically without explicit configuration
// ============================================================================

import { query, withTransaction, getClient } from '../db/connection.js';
import { logger } from '../utils/logger.js';
import type pg from 'pg';

// ============================================================================
// TYPES
// ============================================================================

export interface RetentionCleanupResult {
  success: boolean;
  processed: number;
  deleted: number;
  failed: number;
  errors: string[];
  duration_ms: number;
}

export interface RetentionCleanupOptions {
  batchSize?: number;
  dryRun?: boolean;
  tenantId?: string;  // Optional: limit to specific tenant
}

export interface EligibleRecord {
  id: string;
  tenant_id: string;
  table_name: string;
  record_id: string;
  deleted_at: Date;
  retention_days: number;
}

// ============================================================================
// JOB IMPLEMENTATION
// ============================================================================

export class RetentionCleanupJob {
  private readonly defaultBatchSize = 100;

  /**
   * Run the retention cleanup job
   * 
   * This method finds records that have passed their retention period
   * and permanently deletes them from the database.
   * 
   * SAFETY MEASURES:
   * 1. Processes in small batches to avoid long-running transactions
   * 2. Logs all deletions for audit purposes
   * 3. Supports dry-run mode for testing
   * 4. Can be limited to specific tenant
   * 5. Records failures without stopping the entire job
   */
  async run(options: RetentionCleanupOptions = {}): Promise<RetentionCleanupResult> {
    const startTime = Date.now();
    const batchSize = options.batchSize ?? this.defaultBatchSize;
    const dryRun = options.dryRun ?? false;

    const result: RetentionCleanupResult = {
      success: true,
      processed: 0,
      deleted: 0,
      failed: 0,
      errors: [],
      duration_ms: 0,
    };

    logger.info('Starting retention cleanup job', {
      batchSize,
      dryRun,
      tenantId: options.tenantId || 'all',
    });

    try {
      // Get eligible records
      const eligibleQuery = options.tenantId
        ? `SELECT * FROM get_records_for_hard_deletion($1) WHERE tenant_id = $2`
        : `SELECT * FROM get_records_for_hard_deletion($1)`;

      const eligibleParams = options.tenantId
        ? [batchSize, options.tenantId]
        : [batchSize];

      const eligibleResult = await query<EligibleRecord>(eligibleQuery, eligibleParams);
      const eligibleRecords = eligibleResult.rows;

      logger.info(`Found ${eligibleRecords.length} records eligible for hard deletion`);

      if (eligibleRecords.length === 0) {
        result.duration_ms = Date.now() - startTime;
        return result;
      }

      // Process each record
      for (const record of eligibleRecords) {
        result.processed++;

        try {
          if (dryRun) {
            logger.info('DRY RUN: Would delete', {
              table: record.table_name,
              recordId: record.record_id,
              tenantId: record.tenant_id,
              deletedAt: record.deleted_at,
            });
            result.deleted++;
          } else {
            await this.hardDeleteRecord(record);
            result.deleted++;
            
            logger.info('Hard deleted record', {
              table: record.table_name,
              recordId: record.record_id,
              tenantId: record.tenant_id,
            });
          }
        } catch (error) {
          result.failed++;
          const errorMsg = `Failed to delete ${record.table_name}:${record.record_id}: ${error instanceof Error ? error.message : 'Unknown error'}`;
          result.errors.push(errorMsg);
          
          logger.error('Failed to hard delete record', {
            table: record.table_name,
            recordId: record.record_id,
            tenantId: record.tenant_id,
            error: error instanceof Error ? error.message : 'Unknown error',
          });
        }
      }

    } catch (error) {
      result.success = false;
      const errorMsg = `Job failed: ${error instanceof Error ? error.message : 'Unknown error'}`;
      result.errors.push(errorMsg);
      
      logger.error('Retention cleanup job failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });
    }

    result.duration_ms = Date.now() - startTime;

    logger.info('Retention cleanup job completed', {
      success: result.success,
      processed: result.processed,
      deleted: result.deleted,
      failed: result.failed,
      duration_ms: result.duration_ms,
    });

    return result;
  }

  /**
   * Hard delete a single record and its retention tracking entry
   */
  private async hardDeleteRecord(record: EligibleRecord): Promise<void> {
    await withTransaction(async (client) => {
      // 1. Delete the actual record
      const deleteResult = await client.query(
        `DELETE FROM ${record.table_name} WHERE id = $1 AND tenant_id = $2 AND deleted_at IS NOT NULL`,
        [record.record_id, record.tenant_id]
      );

      if (deleteResult.rowCount === 0) {
        // Record might have been restored or already deleted
        logger.warn('Record not found for hard deletion (may have been restored)', {
          table: record.table_name,
          recordId: record.record_id,
        });
      }

      // 2. Remove the retention tracking entry
      await client.query(
        `DELETE FROM soft_delete_retention WHERE id = $1`,
        [record.id]
      );

      // 3. Log to audit (using audit.logs table)
      await this.logHardDeletion(client, record);
    });
  }

  /**
   * Log hard deletion to audit log
   */
  private async logHardDeletion(client: pg.PoolClient, record: EligibleRecord): Promise<void> {
    const entryHash = require('crypto')
      .createHash('sha256')
      .update(JSON.stringify({
        tenant_id: record.tenant_id,
        table_name: record.table_name,
        record_id: record.record_id,
        deleted_at: record.deleted_at,
        hard_deleted_at: new Date().toISOString(),
      }))
      .digest('hex');

    await client.query(`
      INSERT INTO audit.logs (
        tenant_id, action, action_category, entity_type, entity_id,
        description, changes_json, entry_hash, retention_date, is_financial
      ) VALUES (
        $1, 'DELETE', 'retention', $2, $3,
        $4, $5, $6, $7, FALSE
      )
    `, [
      record.tenant_id,
      record.table_name,
      record.record_id,
      `Hard deleted after ${record.retention_days} day retention period`,
      JSON.stringify({
        original_deleted_at: record.deleted_at,
        retention_days: record.retention_days,
        hard_deleted_at: new Date().toISOString(),
      }),
      entryHash,
      new Date(Date.now() + 7 * 365 * 24 * 60 * 60 * 1000), // 7 years from now
    ]);
  }

  /**
   * Get statistics about records eligible for deletion
   */
  async getEligibleStats(): Promise<{
    total: number;
    byTable: Record<string, number>;
    byTenant: Record<string, number>;
  }> {
    const result = await query<EligibleRecord>(
      `SELECT * FROM get_records_for_hard_deletion($1)`,
      [10000]  // Large limit to get all
    );

    const stats = {
      total: result.rows.length,
      byTable: {} as Record<string, number>,
      byTenant: {} as Record<string, number>,
    };

    for (const record of result.rows) {
      stats.byTable[record.table_name] = (stats.byTable[record.table_name] || 0) + 1;
      stats.byTenant[record.tenant_id] = (stats.byTenant[record.tenant_id] || 0) + 1;
    }

    return stats;
  }

  /**
   * Preview what would be deleted without actually deleting
   */
  async preview(options: RetentionCleanupOptions = {}): Promise<EligibleRecord[]> {
    const batchSize = options.batchSize ?? 100;

    const eligibleQuery = options.tenantId
      ? `SELECT * FROM get_records_for_hard_deletion($1) WHERE tenant_id = $2`
      : `SELECT * FROM get_records_for_hard_deletion($1)`;

    const eligibleParams = options.tenantId
      ? [batchSize, options.tenantId]
      : [batchSize];

    const result = await query<EligibleRecord>(eligibleQuery, eligibleParams);
    return result.rows;
  }
}

// ============================================================================
// CLI INTERFACE
// Run with: npx tsx src/jobs/retention-cleanup.job.ts [--dry-run] [--tenant-id=xxx]
// ============================================================================

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  const dryRun = args.includes('--dry-run');
  const tenantIdArg = args.find(a => a.startsWith('--tenant-id='));
  const tenantId = tenantIdArg ? tenantIdArg.split('=')[1] : undefined;
  const preview = args.includes('--preview');
  const stats = args.includes('--stats');

  const job = new RetentionCleanupJob();

  if (stats) {
    console.log('\n📊 Retention Cleanup Statistics:\n');
    const statistics = await job.getEligibleStats();
    console.log(`Total eligible for deletion: ${statistics.total}`);
    console.log('\nBy table:');
    Object.entries(statistics.byTable).forEach(([table, count]) => {
      console.log(`  ${table}: ${count}`);
    });
    console.log('\nBy tenant:');
    Object.entries(statistics.byTenant).forEach(([tenant, count]) => {
      console.log(`  ${tenant}: ${count}`);
    });
    return;
  }

  if (preview) {
    console.log('\n👀 Preview of records to be deleted:\n');
    const records = await job.preview({ tenantId });
    if (records.length === 0) {
      console.log('No records eligible for hard deletion.');
    } else {
      records.forEach(r => {
        console.log(`  ${r.table_name}:${r.record_id} (tenant: ${r.tenant_id}, deleted: ${r.deleted_at})`);
      });
    }
    return;
  }

  console.log('\n🗑️  Running Retention Cleanup Job\n');
  console.log(`Mode: ${dryRun ? 'DRY RUN' : 'LIVE'}`);
  console.log(`Tenant: ${tenantId || 'ALL'}\n`);

  if (!dryRun) {
    console.log('⚠️  WARNING: This will PERMANENTLY DELETE data!');
    console.log('Press Ctrl+C within 5 seconds to abort...\n');
    await new Promise(resolve => setTimeout(resolve, 5000));
  }

  const result = await job.run({ dryRun, tenantId });

  console.log('\n📋 Results:');
  console.log(`  Success: ${result.success}`);
  console.log(`  Processed: ${result.processed}`);
  console.log(`  Deleted: ${result.deleted}`);
  console.log(`  Failed: ${result.failed}`);
  console.log(`  Duration: ${result.duration_ms}ms`);

  if (result.errors.length > 0) {
    console.log('\n❌ Errors:');
    result.errors.forEach(e => console.log(`  - ${e}`));
  }

  process.exit(result.success ? 0 : 1);
}

// Export for use as module
export const retentionCleanupJob = new RetentionCleanupJob();

// Run if executed directly
if (process.argv[1]?.includes('retention-cleanup')) {
  main().catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
  });
}
