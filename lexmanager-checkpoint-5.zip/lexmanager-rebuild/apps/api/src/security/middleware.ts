// ============================================================================
// SECURITY MIDDLEWARE
// apps/api/src/security/middleware.ts
// 
// Helmet, CSP, rate limiting, secure cookies
// ============================================================================

import type { Request, Response, NextFunction, RequestHandler } from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { getConfig, isProduction } from '../config/index.js';

// ============================================================================
// HELMET CONFIGURATION
// ============================================================================

/**
 * Helmet middleware with CSP configured for SPA
 */
export function createHelmetMiddleware(): RequestHandler {
  return helmet({
    // Content Security Policy
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: [
          "'self'",
          // Add nonce-based scripts in production
          ...(isProduction() ? [] : ["'unsafe-inline'", "'unsafe-eval'"]),
        ],
        styleSrc: ["'self'", "'unsafe-inline'"],  // Required for some CSS-in-JS
        imgSrc: ["'self'", 'data:', 'blob:', 'https:'],
        fontSrc: ["'self'", 'data:'],
        connectSrc: ["'self'", 'https:'],  // API calls
        frameSrc: ["'none'"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'none'"],  // Clickjacking protection
        upgradeInsecureRequests: isProduction() ? [] : null,
      },
    },
    
    // Cross-Origin settings
    crossOriginEmbedderPolicy: false,  // May need adjustment for external resources
    crossOriginOpenerPolicy: { policy: 'same-origin' },
    crossOriginResourcePolicy: { policy: 'same-origin' },
    
    // DNS prefetch control
    dnsPrefetchControl: { allow: false },
    
    // Frameguard (X-Frame-Options)
    frameguard: { action: 'deny' },
    
    // Hide X-Powered-By
    hidePoweredBy: true,
    
    // HSTS (Strict Transport Security)
    hsts: {
      maxAge: 31536000,  // 1 year
      includeSubDomains: true,
      preload: true,
    },
    
    // IE no open
    ieNoOpen: true,
    
    // No sniff (X-Content-Type-Options)
    noSniff: true,
    
    // Origin-Agent-Cluster
    originAgentCluster: true,
    
    // Permitted Cross-Domain Policies
    permittedCrossDomainPolicies: { permittedPolicies: 'none' },
    
    // Referrer Policy
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
    
    // XSS Filter
    xssFilter: true,
  });
}

// ============================================================================
// RATE LIMITING
// ============================================================================

/**
 * Global rate limiter
 */
export function createGlobalRateLimiter(): RequestHandler {
  const config = getConfig();
  
  return rateLimit({
    windowMs: config.rateLimit.globalWindowMs,
    max: config.rateLimit.globalMaxRequests,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
      error: 'TOO_MANY_REQUESTS',
      message: 'Too many requests, please try again later',
      retryAfter: Math.ceil(config.rateLimit.globalWindowMs / 1000),
    },
    keyGenerator: (req: Request) => {
      // Use X-Forwarded-For behind proxy, fallback to IP
      return req.ip || req.socket.remoteAddress || 'unknown';
    },
    skip: (req: Request) => {
      // Skip rate limiting for health checks
      return req.path === '/health' || req.path === '/ready';
    },
  });
}

/**
 * Login rate limiter (stricter)
 */
export function createLoginRateLimiter(): RequestHandler {
  const config = getConfig();
  
  return rateLimit({
    windowMs: config.rateLimit.loginWindowMs,
    max: config.rateLimit.loginMaxAttempts,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
      error: 'TOO_MANY_LOGIN_ATTEMPTS',
      message: 'Too many login attempts, please try again later',
      retryAfter: Math.ceil(config.rateLimit.loginWindowMs / 1000),
    },
    keyGenerator: (req: Request) => {
      // Rate limit by IP + email combination for login
      const email = req.body?.email || '';
      const ip = req.ip || req.socket.remoteAddress || 'unknown';
      return `login:${ip}:${email}`;
    },
    skipSuccessfulRequests: true,  // Only count failed attempts
  });
}

/**
 * Sensitive endpoint rate limiter
 */
export function createSensitiveRateLimiter(): RequestHandler {
  const config = getConfig();
  
  return rateLimit({
    windowMs: config.rateLimit.sensitiveWindowMs,
    max: config.rateLimit.sensitiveMaxRequests,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
      error: 'TOO_MANY_REQUESTS',
      message: 'Too many requests to this endpoint, please try again later',
      retryAfter: Math.ceil(config.rateLimit.sensitiveWindowMs / 1000),
    },
  });
}

// ============================================================================
// SECURE COOKIES
// ============================================================================

export interface CookieOptions {
  httpOnly: boolean;
  secure: boolean;
  sameSite: 'strict' | 'lax' | 'none';
  maxAge: number;
  path: string;
  domain?: string;
}

/**
 * Get secure cookie options
 */
export function getSecureCookieOptions(maxAgeMs: number): CookieOptions {
  return {
    httpOnly: true,           // Not accessible via JavaScript
    secure: isProduction(),   // HTTPS only in production
    sameSite: 'strict',       // Strict CSRF protection
    maxAge: maxAgeMs,
    path: '/',
  };
}

/**
 * Set a secure cookie
 */
export function setSecureCookie(
  res: Response,
  name: string,
  value: string,
  maxAgeMs: number
): void {
  res.cookie(name, value, getSecureCookieOptions(maxAgeMs));
}

/**
 * Clear a secure cookie
 */
export function clearSecureCookie(res: Response, name: string): void {
  res.clearCookie(name, {
    httpOnly: true,
    secure: isProduction(),
    sameSite: 'strict',
    path: '/',
  });
}

// ============================================================================
// REQUEST CORRELATION
// ============================================================================

/**
 * Add correlation ID to requests
 */
export function correlationIdMiddleware(): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    // Get or generate correlation ID
    const correlationId = 
      req.headers['x-correlation-id'] as string ||
      req.headers['x-request-id'] as string ||
      generateCorrelationId();
    
    // Set on request for logging
    (req as any).correlationId = correlationId;
    
    // Set response header
    res.setHeader('X-Correlation-ID', correlationId);
    
    next();
  };
}

function generateCorrelationId(): string {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 10);
  return `${timestamp}-${random}`;
}

// ============================================================================
// HTTPS ENFORCEMENT
// ============================================================================

/**
 * Enforce HTTPS (redirect HTTP to HTTPS)
 */
export function enforceHttpsMiddleware(): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    // Check X-Forwarded-Proto header (set by reverse proxy)
    const proto = req.headers['x-forwarded-proto'];
    
    if (isProduction() && proto === 'http') {
      // Redirect to HTTPS
      const host = req.headers.host || '';
      return res.redirect(301, `https://${host}${req.url}`);
    }
    
    next();
  };
}

// ============================================================================
// COMBINED SECURITY MIDDLEWARE
// ============================================================================

/**
 * Apply all security middleware
 */
export function applySecurityMiddleware(app: any): void {
  // Correlation ID first (for logging)
  app.use(correlationIdMiddleware());
  
  // HTTPS enforcement
  app.use(enforceHttpsMiddleware());
  
  // Helmet (headers)
  app.use(createHelmetMiddleware());
  
  // Global rate limiting
  app.use(createGlobalRateLimiter());
  
  console.log('✅ Security middleware applied');
}
