-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 002: Cross-Tenant Protection Triggers
-- Prevents cross-tenant references at the database level
-- ============================================================================

BEGIN;

-- ============================================================================
-- GENERIC CROSS-TENANT VALIDATION FUNCTION
-- Reusable function that validates tenant_id matches between tables
-- ============================================================================

CREATE OR REPLACE FUNCTION validate_same_tenant(
    p_tenant_id UUID,
    p_table_name TEXT,
    p_column_name TEXT,
    p_foreign_id UUID
) RETURNS BOOLEAN AS $$
DECLARE
    v_foreign_tenant_id UUID;
    v_sql TEXT;
BEGIN
    -- If foreign_id is NULL, no validation needed
    IF p_foreign_id IS NULL THEN
        RETURN TRUE;
    END IF;

    -- Build dynamic SQL to get tenant_id from referenced table
    v_sql := format('SELECT tenant_id FROM %I WHERE id = $1', p_table_name);
    
    EXECUTE v_sql INTO v_foreign_tenant_id USING p_foreign_id;
    
    -- Check if foreign record exists
    IF v_foreign_tenant_id IS NULL THEN
        RAISE EXCEPTION 'Referenced % (id: %) not found', p_table_name, p_foreign_id;
    END IF;
    
    -- Check tenant match
    IF v_foreign_tenant_id != p_tenant_id THEN
        RAISE EXCEPTION 'Cross-tenant reference not allowed: % tenant (%) != % tenant (%)',
            'record', p_tenant_id, p_table_name, v_foreign_tenant_id;
    END IF;
    
    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- TASKS: Validate case_id and client_id belong to same tenant
-- ============================================================================

CREATE OR REPLACE FUNCTION validate_task_tenant_refs()
RETURNS TRIGGER AS $$
BEGIN
    -- Validate case_id if provided
    IF NEW.case_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'cases', 'id', NEW.case_id);
    END IF;
    
    -- Validate client_id if provided
    IF NEW.client_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'clients', 'id', NEW.client_id);
    END IF;
    
    -- Validate assigned_to if provided
    IF NEW.assigned_to IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'users', 'id', NEW.assigned_to);
    END IF;
    
    -- Validate assigned_by if provided
    IF NEW.assigned_by IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'users', 'id', NEW.assigned_by);
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_tasks_validate_tenant_refs ON tasks;
CREATE TRIGGER trg_tasks_validate_tenant_refs
    BEFORE INSERT OR UPDATE ON tasks
    FOR EACH ROW
    EXECUTE FUNCTION validate_task_tenant_refs();

-- ============================================================================
-- DOCUMENTS: Validate case_id and client_id belong to same tenant
-- ============================================================================

CREATE OR REPLACE FUNCTION validate_document_tenant_refs()
RETURNS TRIGGER AS $$
BEGIN
    -- Validate case_id if provided
    IF NEW.case_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'cases', 'id', NEW.case_id);
    END IF;
    
    -- Validate client_id if provided
    IF NEW.client_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'clients', 'id', NEW.client_id);
    END IF;
    
    -- Validate uploaded_by
    PERFORM validate_same_tenant(NEW.tenant_id, 'users', 'id', NEW.uploaded_by);
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_documents_validate_tenant_refs ON documents;
CREATE TRIGGER trg_documents_validate_tenant_refs
    BEFORE INSERT OR UPDATE ON documents
    FOR EACH ROW
    EXECUTE FUNCTION validate_document_tenant_refs();

-- ============================================================================
-- CALENDAR_EVENTS: Validate case_id and client_id belong to same tenant
-- ============================================================================

CREATE OR REPLACE FUNCTION validate_event_tenant_refs()
RETURNS TRIGGER AS $$
BEGIN
    -- Validate case_id if provided
    IF NEW.case_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'cases', 'id', NEW.case_id);
    END IF;
    
    -- Validate client_id if provided
    IF NEW.client_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'clients', 'id', NEW.client_id);
    END IF;
    
    -- Validate created_by if provided
    IF NEW.created_by IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'users', 'id', NEW.created_by);
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_events_validate_tenant_refs ON calendar_events;
CREATE TRIGGER trg_events_validate_tenant_refs
    BEFORE INSERT OR UPDATE ON calendar_events
    FOR EACH ROW
    EXECUTE FUNCTION validate_event_tenant_refs();

-- ============================================================================
-- TIME_ENTRIES: Validate case_id, client_id, user_id belong to same tenant
-- ============================================================================

CREATE OR REPLACE FUNCTION validate_time_entry_tenant_refs()
RETURNS TRIGGER AS $$
BEGIN
    -- Validate case_id (required)
    PERFORM validate_same_tenant(NEW.tenant_id, 'cases', 'id', NEW.case_id);
    
    -- Validate client_id (required)
    PERFORM validate_same_tenant(NEW.tenant_id, 'clients', 'id', NEW.client_id);
    
    -- Validate user_id (required)
    PERFORM validate_same_tenant(NEW.tenant_id, 'users', 'id', NEW.user_id);
    
    -- Validate invoice_id if provided
    IF NEW.invoice_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'invoices', 'id', NEW.invoice_id);
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_time_entries_validate_tenant_refs ON time_entries;
CREATE TRIGGER trg_time_entries_validate_tenant_refs
    BEFORE INSERT OR UPDATE ON time_entries
    FOR EACH ROW
    EXECUTE FUNCTION validate_time_entry_tenant_refs();

-- ============================================================================
-- INVOICES: Validate client_id and case_id belong to same tenant
-- ============================================================================

CREATE OR REPLACE FUNCTION validate_invoice_tenant_refs()
RETURNS TRIGGER AS $$
BEGIN
    -- Validate client_id (required)
    PERFORM validate_same_tenant(NEW.tenant_id, 'clients', 'id', NEW.client_id);
    
    -- Validate case_id if provided
    IF NEW.case_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'cases', 'id', NEW.case_id);
    END IF;
    
    -- Validate original_invoice_id if provided (for credit notes)
    IF NEW.original_invoice_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'invoices', 'id', NEW.original_invoice_id);
    END IF;
    
    -- Validate created_by if provided
    IF NEW.created_by IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'users', 'id', NEW.created_by);
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_invoices_validate_tenant_refs ON invoices;
CREATE TRIGGER trg_invoices_validate_tenant_refs
    BEFORE INSERT OR UPDATE ON invoices
    FOR EACH ROW
    EXECUTE FUNCTION validate_invoice_tenant_refs();

-- ============================================================================
-- INVOICE_LINES: Validate invoice_id and time_entry_id belong to same tenant
-- ============================================================================

CREATE OR REPLACE FUNCTION validate_invoice_line_tenant_refs()
RETURNS TRIGGER AS $$
BEGIN
    -- Validate invoice_id (required)
    PERFORM validate_same_tenant(NEW.tenant_id, 'invoices', 'id', NEW.invoice_id);
    
    -- Validate time_entry_id if provided
    IF NEW.time_entry_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'time_entries', 'id', NEW.time_entry_id);
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_invoice_lines_validate_tenant_refs ON invoice_lines;
CREATE TRIGGER trg_invoice_lines_validate_tenant_refs
    BEFORE INSERT OR UPDATE ON invoice_lines
    FOR EACH ROW
    EXECUTE FUNCTION validate_invoice_line_tenant_refs();

-- ============================================================================
-- PAYMENTS: Validate invoice_id and client_id belong to same tenant
-- ============================================================================

CREATE OR REPLACE FUNCTION validate_payment_tenant_refs()
RETURNS TRIGGER AS $$
BEGIN
    -- Validate invoice_id (required)
    PERFORM validate_same_tenant(NEW.tenant_id, 'invoices', 'id', NEW.invoice_id);
    
    -- Validate client_id (required)
    PERFORM validate_same_tenant(NEW.tenant_id, 'clients', 'id', NEW.client_id);
    
    -- Validate recorded_by if provided
    IF NEW.recorded_by IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'users', 'id', NEW.recorded_by);
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_payments_validate_tenant_refs ON payments;
CREATE TRIGGER trg_payments_validate_tenant_refs
    BEFORE INSERT OR UPDATE ON payments
    FOR EACH ROW
    EXECUTE FUNCTION validate_payment_tenant_refs();

-- ============================================================================
-- TRUST_ACCOUNTS: Validate client_id belongs to same tenant
-- ============================================================================

CREATE OR REPLACE FUNCTION validate_trust_account_tenant_refs()
RETURNS TRIGGER AS $$
BEGIN
    -- Validate client_id (required)
    PERFORM validate_same_tenant(NEW.tenant_id, 'clients', 'id', NEW.client_id);
    
    -- Validate created_by if provided
    IF NEW.created_by IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'users', 'id', NEW.created_by);
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_trust_accounts_validate_tenant_refs ON trust_accounts;
CREATE TRIGGER trg_trust_accounts_validate_tenant_refs
    BEFORE INSERT OR UPDATE ON trust_accounts
    FOR EACH ROW
    EXECUTE FUNCTION validate_trust_account_tenant_refs();

-- ============================================================================
-- TRUST_TRANSACTIONS: Validate all references belong to same tenant
-- This is CRITICAL for financial compliance
-- ============================================================================

CREATE OR REPLACE FUNCTION validate_trust_transaction_tenant_refs()
RETURNS TRIGGER AS $$
BEGIN
    -- Validate trust_account_id (required)
    PERFORM validate_same_tenant(NEW.tenant_id, 'trust_accounts', 'id', NEW.trust_account_id);
    
    -- Validate client_id (required)
    PERFORM validate_same_tenant(NEW.tenant_id, 'clients', 'id', NEW.client_id);
    
    -- Validate case_id if provided
    IF NEW.case_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'cases', 'id', NEW.case_id);
    END IF;
    
    -- Validate invoice_id if provided
    IF NEW.invoice_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'invoices', 'id', NEW.invoice_id);
    END IF;
    
    -- Validate payment_id if provided
    IF NEW.payment_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'payments', 'id', NEW.payment_id);
    END IF;
    
    -- Validate created_by (required)
    PERFORM validate_same_tenant(NEW.tenant_id, 'users', 'id', NEW.created_by);
    
    -- Validate related_transaction_id if provided (for transfers)
    IF NEW.related_transaction_id IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'trust_transactions', 'id', NEW.related_transaction_id);
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_trust_transactions_validate_tenant_refs ON trust_transactions;
CREATE TRIGGER trg_trust_transactions_validate_tenant_refs
    BEFORE INSERT ON trust_transactions
    FOR EACH ROW
    EXECUTE FUNCTION validate_trust_transaction_tenant_refs();

-- ============================================================================
-- CLIENTS: Validate assigned_to and created_by belong to same tenant
-- ============================================================================

CREATE OR REPLACE FUNCTION validate_client_tenant_refs()
RETURNS TRIGGER AS $$
BEGIN
    -- Validate assigned_to if provided
    IF NEW.assigned_to IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'users', 'id', NEW.assigned_to);
    END IF;
    
    -- Validate created_by if provided
    IF NEW.created_by IS NOT NULL THEN
        PERFORM validate_same_tenant(NEW.tenant_id, 'users', 'id', NEW.created_by);
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_clients_validate_tenant_refs ON clients;
CREATE TRIGGER trg_clients_validate_tenant_refs
    BEFORE INSERT OR UPDATE ON clients
    FOR EACH ROW
    EXECUTE FUNCTION validate_client_tenant_refs();

-- ============================================================================
-- CUSTOM_FIELD_VALUES: Validate definition_id belongs to same tenant
-- ============================================================================

CREATE OR REPLACE FUNCTION validate_custom_field_value_tenant_refs()
RETURNS TRIGGER AS $$
BEGIN
    -- Validate definition_id (required)
    PERFORM validate_same_tenant(NEW.tenant_id, 'custom_field_definitions', 'id', NEW.definition_id);
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_custom_field_values_validate_tenant_refs ON custom_field_values;
CREATE TRIGGER trg_custom_field_values_validate_tenant_refs
    BEFORE INSERT OR UPDATE ON custom_field_values
    FOR EACH ROW
    EXECUTE FUNCTION validate_custom_field_value_tenant_refs();

COMMIT;
