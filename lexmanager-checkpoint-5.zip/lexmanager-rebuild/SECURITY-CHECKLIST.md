# LexManager Security Checklist

This document maps security requirements to implemented controls and provides verification procedures.

---

## 1. Secrets Management

### Requirements
- [ ] No secrets in repository
- [ ] Environment variables for all secrets
- [ ] Structured config validation at boot

### Implementation
| Control | Location | Status |
|---------|----------|--------|
| Zod schema validation | `src/config/index.ts` | ✅ |
| Required secrets check | `validateSecrets()` | ✅ |
| Weak secret detection | `validateSecrets()` | ✅ |
| Fail-fast on missing config | `loadConfig()` | ✅ |

### Verification
```bash
# Test missing secrets (should fail)
unset JWT_ACCESS_SECRET && npm start
# Expected: "Configuration validation failed" + exit code 1

# Test weak secrets in production
NODE_ENV=production JWT_ACCESS_SECRET=password123 npm start
# Expected: "Weak secret detected" error

# Verify no secrets in git
git grep -i "password\|secret\|api_key" -- ':!*.md' ':!*.example'
# Expected: No results
```

### Required Environment Variables
```env
# Database
DB_HOST=
DB_NAME=
DB_USER=
DB_PASSWORD=        # Min: strong password

# JWT (min 32 chars each, must be different)
JWT_ACCESS_SECRET=
JWT_REFRESH_SECRET=

# Encryption
ENCRYPTION_MASTER_KEY=   # Min 32 chars
```

---

## 2. Password Hashing

### Requirements
- [ ] Argon2id algorithm
- [ ] OWASP-recommended parameters
- [ ] Safe verification (timing-safe)

### Implementation
| Control | Location | Status |
|---------|----------|--------|
| Argon2id with 64MB memory | `src/security/password.ts` | ✅ |
| 3 iterations | `ARGON2_OPTIONS.timeCost` | ✅ |
| 4 parallelism threads | `ARGON2_OPTIONS.parallelism` | ✅ |
| Timing-safe verify | `verifyPassword()` | ✅ |
| Rehash detection | `needsRehash()` | ✅ |

### Verification
```typescript
// Run password hash test
import { hashPassword, verifyPassword } from './security/password';

const hash = await hashPassword('TestPassword123!');
console.log(hash.startsWith('$argon2id$'));  // true
console.log(hash.includes('m=65536'));       // Memory: 64MB
console.log(hash.includes('t=3'));           // Iterations: 3
console.log(hash.includes('p=4'));           // Parallelism: 4

// Timing-safe verification
const valid = await verifyPassword('TestPassword123!', hash);    // true
const invalid = await verifyPassword('wrong', hash);              // false
```

---

## 3. JWT Authentication

### Requirements
- [ ] Short-lived access tokens
- [ ] Refresh token rotation
- [ ] Token family revocation on reuse

### Implementation
| Control | Location | Status |
|---------|----------|--------|
| Access token: 15min default | `JWT_ACCESS_EXPIRES_IN` | ✅ |
| Refresh token: 7 days default | `JWT_REFRESH_EXPIRES_IN` | ✅ |
| Token rotation | `rotateRefreshToken()` | ✅ |
| Family revocation | `revokeTokenFamily()` | ✅ |
| Replay detection | `rotateRefreshToken()` | ✅ |

### Verification
```typescript
// Test token expiration
const { accessToken } = generateTokenPair(userId, tenantId, roleId, roleName, email);
const decoded = verifyAccessToken(accessToken);
console.log(decoded.exp - decoded.iat);  // ~900 seconds (15 min)

// Test rotation
const newTokens = await rotateRefreshToken(refreshToken);
const replayAttempt = await rotateRefreshToken(refreshToken);  // null (replay detected)
```

---

## 4. Transport Security

### Requirements
- [ ] HTTPS enforcement
- [ ] Secure cookies
- [ ] Trust proxy configuration

### Implementation
| Control | Location | Status |
|---------|----------|--------|
| HTTPS redirect | `enforceHttpsMiddleware()` | ✅ |
| HSTS header (1 year) | Helmet config | ✅ |
| Secure cookie flag | `getSecureCookieOptions()` | ✅ |
| HttpOnly cookies | `getSecureCookieOptions()` | ✅ |
| SameSite=Strict | `getSecureCookieOptions()` | ✅ |

### Verification
```bash
# Check HSTS header
curl -I https://your-domain.com/api/health
# Expected: Strict-Transport-Security: max-age=31536000; includeSubDomains; preload

# Check cookie attributes
# In browser DevTools > Application > Cookies
# Verify: HttpOnly=true, Secure=true, SameSite=Strict
```

---

## 5. Security Headers

### Requirements
- [ ] Helmet middleware
- [ ] CSP configured for SPA
- [ ] Clickjacking protection

### Implementation
| Control | Location | Status |
|---------|----------|--------|
| Helmet middleware | `createHelmetMiddleware()` | ✅ |
| CSP policy | `contentSecurityPolicy` | ✅ |
| X-Frame-Options: DENY | `frameguard` | ✅ |
| X-Content-Type-Options | `noSniff` | ✅ |
| Referrer-Policy | `referrerPolicy` | ✅ |

### Verification
```bash
# Check security headers
curl -I https://your-domain.com/api/health

# Expected headers:
# Content-Security-Policy: default-src 'self'; ...
# X-Frame-Options: DENY
# X-Content-Type-Options: nosniff
# Referrer-Policy: strict-origin-when-cross-origin
# X-XSS-Protection: 1; mode=block
```

---

## 6. Rate Limiting

### Requirements
- [ ] Global rate limit
- [ ] Stricter login rate limit
- [ ] Sensitive endpoint protection

### Implementation
| Control | Location | Status |
|---------|----------|--------|
| Global: 100/min | `createGlobalRateLimiter()` | ✅ |
| Login: 5/15min | `createLoginRateLimiter()` | ✅ |
| Sensitive: 20/min | `createSensitiveRateLimiter()` | ✅ |
| IP-based limiting | `keyGenerator` | ✅ |
| Email+IP for login | `keyGenerator` | ✅ |

### Verification
```bash
# Test global rate limit
for i in {1..120}; do curl -s https://your-domain.com/api/health; done
# Expected: 429 Too Many Requests after 100 requests

# Test login rate limit
for i in {1..10}; do curl -X POST https://your-domain.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"wrong"}'; done
# Expected: 429 after 5 attempts
```

---

## 7. Sensitive Data Logging

### Requirements
- [ ] Never log Israeli IDs
- [ ] Never log document content
- [ ] Use correlation IDs

### Implementation
| Control | Location | Status |
|---------|----------|--------|
| Israeli ID redaction | `REDACTION_PATTERNS` | ✅ |
| Credit card redaction | `REDACTION_PATTERNS` | ✅ |
| Phone number redaction | `REDACTION_PATTERNS` | ✅ |
| JWT redaction | `REDACTION_PATTERNS` | ✅ |
| Sensitive field redaction | `SENSITIVE_FIELDS` | ✅ |
| Correlation ID middleware | `correlationIdMiddleware()` | ✅ |

### Verification
```typescript
import { logger } from './security/logger';

// Test redaction
logger.info('User 123456789 logged in');
// Output: "User [ISRAELI_ID_REDACTED] logged in"

logger.info('Processing', { tax_id: '123456789', name: 'John' });
// Output: { tax_id: '[REDACTED]', name: 'John' }

// Test correlation ID
// Check response headers for X-Correlation-ID
// Check logs for correlationId field
```

### Redacted Patterns
- `\d{9}` - Israeli ID (9 digits)
- `\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}` - Credit card
- `0[2-9]\d{7,8}` - Israeli phone
- `eyJ...` - JWT tokens
- Fields: password, token, tax_id, credit_card, etc.

---

## 8. Data Encryption

### Requirements
- [ ] Encryption at rest (DB level)
- [ ] Field-level encryption for sensitive data
- [ ] KMS-ready envelope encryption

### Implementation
| Control | Location | Status |
|---------|----------|--------|
| AES-256-GCM encryption | `src/security/encryption.ts` | ✅ |
| Envelope encryption design | `createKMSEncryptionService()` | ✅ |
| Key versioning | `EncryptedData.kid` | ✅ |
| Searchable hashing | `hashForSearch()` | ✅ |

### Fields Encrypted
- `tax_id` (Israeli ID / Teudat Zehut)
- `id_number`
- `passport_number`
- `bank_account`
- `credit_card`
- `health_info`

### Verification
```typescript
import { encryptField, decryptField, isEncrypted } from './security/encryption';

const sensitive = '123456789';
const encrypted = encryptField(sensitive);

console.log(isEncrypted(encrypted));  // true
console.log(encrypted.includes('123456789'));  // false
console.log(decryptField(encrypted));  // '123456789'

// Verify encryption format
const parsed = JSON.parse(encrypted);
console.log(parsed.v);    // 1 (version)
console.log(parsed.kid);  // Key ID
console.log(parsed.iv);   // Base64 IV
console.log(parsed.ct);   // Base64 ciphertext
console.log(parsed.tag);  // Base64 auth tag
```

### Database Encryption at Rest
```sql
-- PostgreSQL: Verify TDE (Transparent Data Encryption)
-- Check with your cloud provider:
-- - AWS RDS: Encryption enabled at instance creation
-- - Azure: TDE enabled by default
-- - GCP Cloud SQL: Encryption at rest enabled

-- Verify connection encryption
SELECT ssl_is_used();  -- Should return true
```

---

## 9. Audit Logging

### Requirements
- [ ] All mutations logged
- [ ] Hash chain for tamper detection
- [ ] Admin-only access

### Implementation
| Control | Location | Status |
|---------|----------|--------|
| Immutable audit.logs | `005_audit_log_system.sql` | ✅ |
| SHA-256 hash chain | `calculate_audit_hash()` | ✅ |
| Hash verification | `verify_hash_chain()` | ✅ |
| RBAC for viewing | `audit_log_view` permission | ✅ |

### Verification
```typescript
// Verify audit logging
await clientService.create(context, tenantId, clientData);
const logs = await auditService.listAuditLogs(tenantId, adminUserId);
console.log(logs[0].action);  // 'CREATE'
console.log(logs[0].entity_type);  // 'clients'
console.log(logs[0].entry_hash);  // SHA-256 hash

// Verify hash chain
const result = await auditService.verifyIntegrity(tenantId, adminUserId);
console.log(result.isValid);  // true

// Verify immutability
await pool.query('UPDATE audit.logs SET description = "hacked"');
// Expected: ERROR - UPDATE not allowed on immutable table
```

---

## 10. Authorization

### Requirements
- [ ] Permission checks on all endpoints
- [ ] Tenant isolation
- [ ] Admin-only for sensitive operations

### Implementation
| Control | Location | Status |
|---------|----------|--------|
| Central Authorizer | `src/auth/authorizer.ts` | ✅ |
| requirePermission() | All service methods | ✅ |
| requireTenantAccess() | All service methods | ✅ |
| 47 granular permissions | `PERMISSIONS` constant | ✅ |

### Verification
```typescript
// Test permission denied
await clientService.delete(staffContext, tenantId, clientId);
// Expected: AuthorizationError (403)

// Test cross-tenant blocked
await clientService.getById(tenant2Context, tenant1Id, clientId);
// Expected: TenantAccessError (403)

// Test admin-only
await auditService.listAuditLogs(tenantId, staffUserId);
// Expected: PERMISSION_DENIED
```

---

## Production Deployment Checklist

### Pre-Deployment
- [ ] All secrets rotated from development values
- [ ] JWT secrets are 32+ chars and unique
- [ ] Encryption master key is 32+ chars
- [ ] Database SSL enabled
- [ ] Rate limits tuned for expected traffic
- [ ] Logging level set to 'info' or 'warn'

### Infrastructure
- [ ] TLS 1.3 on load balancer
- [ ] WAF rules enabled
- [ ] DDoS protection active
- [ ] Database encryption at rest enabled
- [ ] Backup encryption enabled
- [ ] VPC/network isolation configured

### Monitoring
- [ ] Failed login alerts configured
- [ ] Rate limit alerts configured
- [ ] Audit log integrity checks scheduled
- [ ] Error rate monitoring active
- [ ] Security event logging to SIEM

---

## Security Testing Commands

```bash
# Run security test suite
npm run test:security

# Check for vulnerabilities
npm audit

# OWASP dependency check
npx audit-ci --moderate

# Test rate limiting
npm run test:rate-limit

# Test auth hardening
npm run test:auth

# Test sensitive log redaction
npm run test:logging
```

---

## Compliance Notes

### GDPR Considerations
- Personal data encrypted at field level
- Audit trail for data access
- Support for data deletion (soft delete with retention)

### Israeli Privacy Law (Protection of Privacy Law, 5741-1981)
- Israeli ID (Teudat Zehut) encrypted at rest
- Access logging for sensitive data
- Data minimization in logs

### SOC 2 Controls
- Access control (CC6.1)
- Logical access (CC6.2, CC6.3)
- System operations (CC7.1, CC7.2)
- Change management (CC8.1)

---

## Contact

For security concerns, contact: security@lexmanager.com

Last Updated: 2025-01-31
Version: 1.0.0
