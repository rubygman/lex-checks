// ============================================================================
// TENANT VALIDATION UTILITY
// apps/api/src/utils/tenant-validation.ts
// 
// Service-layer cross-tenant protection
// This provides an additional layer of protection beyond database triggers
// ============================================================================

import { query } from '../db/connection.js';
import { CrossTenantAccessError, NotFoundError, TenantScopingError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export interface EntityReference {
  table: string;
  id: string;
  label?: string;  // Human-readable label for error messages
}

export interface TenantValidationResult {
  valid: boolean;
  errors: string[];
}

// ============================================================================
// TABLE CONFIGURATIONS
// Which tables have tenant_id column
// ============================================================================

const TENANT_SCOPED_TABLES = new Set([
  'users',
  'clients',
  'cases',
  'tasks',
  'documents',
  'calendar_events',
  'time_entries',
  'invoices',
  'invoice_lines',
  'payments',
  'trust_accounts',
  'trust_transactions',
  'custom_field_definitions',
  'custom_field_values',
  'settings',
]);

// ============================================================================
// VALIDATION FUNCTIONS
// ============================================================================

/**
 * Get the tenant_id for a specific entity
 */
export async function getEntityTenantId(
  table: string,
  id: string
): Promise<string | null> {
  if (!TENANT_SCOPED_TABLES.has(table)) {
    throw new Error(`Table "${table}" is not tenant-scoped`);
  }

  const result = await query<{ tenant_id: string }>(
    `SELECT tenant_id FROM ${table} WHERE id = $1`,
    [id]
  );

  return result.rows[0]?.tenant_id || null;
}

/**
 * Validate that a single entity belongs to the specified tenant
 * 
 * @param tenantId - The tenant ID to validate against
 * @param table - The table name
 * @param id - The entity ID
 * @param label - Human-readable label for error messages
 * @throws CrossTenantAccessError if tenant doesn't match
 * @throws NotFoundError if entity doesn't exist
 */
export async function validateEntityTenant(
  tenantId: string,
  table: string,
  id: string,
  label?: string
): Promise<void> {
  if (!tenantId) {
    throw new TenantScopingError('tenantId is required for tenant validation');
  }

  if (!id) {
    return; // Null/undefined IDs are allowed (optional references)
  }

  const entityTenantId = await getEntityTenantId(table, id);

  if (!entityTenantId) {
    throw new NotFoundError(label || table, id);
  }

  if (entityTenantId !== tenantId) {
    throw new CrossTenantAccessError(
      `Cross-tenant access denied: ${label || table} (${id}) belongs to a different tenant`
    );
  }
}

/**
 * Validate multiple entity references belong to the same tenant
 * 
 * @param tenantId - The tenant ID to validate against
 * @param refs - Array of entity references to validate
 * @returns Validation result with any errors
 */
export async function validateSameTenant(
  tenantId: string,
  ...refs: (EntityReference | null | undefined)[]
): Promise<TenantValidationResult> {
  if (!tenantId) {
    return {
      valid: false,
      errors: ['tenantId is required for tenant validation'],
    };
  }

  const errors: string[] = [];
  const validRefs = refs.filter((ref): ref is EntityReference => 
    ref !== null && ref !== undefined && ref.id !== null && ref.id !== undefined
  );

  for (const ref of validRefs) {
    try {
      const entityTenantId = await getEntityTenantId(ref.table, ref.id);

      if (!entityTenantId) {
        errors.push(`${ref.label || ref.table} (${ref.id}) not found`);
      } else if (entityTenantId !== tenantId) {
        errors.push(
          `${ref.label || ref.table} (${ref.id}) belongs to a different tenant`
        );
      }
    } catch (error) {
      errors.push(
        `Error validating ${ref.label || ref.table}: ${error instanceof Error ? error.message : 'Unknown error'}`
      );
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validate multiple entity references and throw if any fail
 * This is the main function to use in services
 * 
 * @param tenantId - The tenant ID to validate against
 * @param refs - Array of entity references to validate
 * @throws CrossTenantAccessError if any reference belongs to different tenant
 * @throws NotFoundError if any reference doesn't exist
 */
export async function requireSameTenant(
  tenantId: string,
  ...refs: (EntityReference | null | undefined)[]
): Promise<void> {
  const result = await validateSameTenant(tenantId, ...refs);

  if (!result.valid) {
    throw new CrossTenantAccessError(
      `Cross-tenant validation failed: ${result.errors.join('; ')}`
    );
  }
}

/**
 * Helper to create an EntityReference
 */
export function ref(table: string, id: string | null | undefined, label?: string): EntityReference | null {
  if (!id) return null;
  return { table, id, label: label || table };
}

// ============================================================================
// CONVENIENCE FUNCTIONS FOR COMMON ENTITIES
// ============================================================================

/**
 * Validate client belongs to tenant
 */
export async function validateClientTenant(tenantId: string, clientId: string): Promise<void> {
  await validateEntityTenant(tenantId, 'clients', clientId, 'Client');
}

/**
 * Validate case belongs to tenant
 */
export async function validateCaseTenant(tenantId: string, caseId: string): Promise<void> {
  await validateEntityTenant(tenantId, 'cases', caseId, 'Case');
}

/**
 * Validate user belongs to tenant
 */
export async function validateUserTenant(tenantId: string, userId: string): Promise<void> {
  await validateEntityTenant(tenantId, 'users', userId, 'User');
}

/**
 * Validate invoice belongs to tenant
 */
export async function validateInvoiceTenant(tenantId: string, invoiceId: string): Promise<void> {
  await validateEntityTenant(tenantId, 'invoices', invoiceId, 'Invoice');
}

/**
 * Validate trust account belongs to tenant
 */
export async function validateTrustAccountTenant(tenantId: string, trustAccountId: string): Promise<void> {
  await validateEntityTenant(tenantId, 'trust_accounts', trustAccountId, 'Trust Account');
}

// ============================================================================
// BATCH VALIDATION FOR COMPLEX OPERATIONS
// ============================================================================

/**
 * Validate all references for creating a task
 */
export async function validateTaskReferences(
  tenantId: string,
  refs: {
    caseId?: string;
    clientId?: string;
    assignedTo?: string;
    assignedBy?: string;
  }
): Promise<void> {
  await requireSameTenant(
    tenantId,
    ref('cases', refs.caseId, 'Case'),
    ref('clients', refs.clientId, 'Client'),
    ref('users', refs.assignedTo, 'Assigned User'),
    ref('users', refs.assignedBy, 'Assigning User')
  );
}

/**
 * Validate all references for creating a document
 */
export async function validateDocumentReferences(
  tenantId: string,
  refs: {
    caseId?: string;
    clientId?: string;
    uploadedBy: string;
  }
): Promise<void> {
  await requireSameTenant(
    tenantId,
    ref('cases', refs.caseId, 'Case'),
    ref('clients', refs.clientId, 'Client'),
    ref('users', refs.uploadedBy, 'Uploader')
  );
}

/**
 * Validate all references for creating a calendar event
 */
export async function validateEventReferences(
  tenantId: string,
  refs: {
    caseId?: string;
    clientId?: string;
    createdBy?: string;
  }
): Promise<void> {
  await requireSameTenant(
    tenantId,
    ref('cases', refs.caseId, 'Case'),
    ref('clients', refs.clientId, 'Client'),
    ref('users', refs.createdBy, 'Creator')
  );
}

/**
 * Validate all references for creating a time entry
 */
export async function validateTimeEntryReferences(
  tenantId: string,
  refs: {
    caseId: string;
    clientId: string;
    userId: string;
    invoiceId?: string;
  }
): Promise<void> {
  await requireSameTenant(
    tenantId,
    ref('cases', refs.caseId, 'Case'),
    ref('clients', refs.clientId, 'Client'),
    ref('users', refs.userId, 'User'),
    ref('invoices', refs.invoiceId, 'Invoice')
  );
}

/**
 * Validate all references for creating an invoice
 */
export async function validateInvoiceReferences(
  tenantId: string,
  refs: {
    clientId: string;
    caseId?: string;
    originalInvoiceId?: string;
    createdBy?: string;
  }
): Promise<void> {
  await requireSameTenant(
    tenantId,
    ref('clients', refs.clientId, 'Client'),
    ref('cases', refs.caseId, 'Case'),
    ref('invoices', refs.originalInvoiceId, 'Original Invoice'),
    ref('users', refs.createdBy, 'Creator')
  );
}

/**
 * Validate all references for creating a trust transaction
 * This is CRITICAL for financial compliance
 */
export async function validateTrustTransactionReferences(
  tenantId: string,
  refs: {
    trustAccountId: string;
    clientId: string;
    caseId?: string;
    invoiceId?: string;
    paymentId?: string;
    createdBy: string;
    relatedTransactionId?: string;
  }
): Promise<void> {
  await requireSameTenant(
    tenantId,
    ref('trust_accounts', refs.trustAccountId, 'Trust Account'),
    ref('clients', refs.clientId, 'Client'),
    ref('cases', refs.caseId, 'Case'),
    ref('invoices', refs.invoiceId, 'Invoice'),
    ref('payments', refs.paymentId, 'Payment'),
    ref('users', refs.createdBy, 'Creator'),
    ref('trust_transactions', refs.relatedTransactionId, 'Related Transaction')
  );
}

/**
 * Validate all references for creating a payment
 */
export async function validatePaymentReferences(
  tenantId: string,
  refs: {
    invoiceId: string;
    clientId: string;
    recordedBy?: string;
  }
): Promise<void> {
  await requireSameTenant(
    tenantId,
    ref('invoices', refs.invoiceId, 'Invoice'),
    ref('clients', refs.clientId, 'Client'),
    ref('users', refs.recordedBy, 'Recorder')
  );
}
