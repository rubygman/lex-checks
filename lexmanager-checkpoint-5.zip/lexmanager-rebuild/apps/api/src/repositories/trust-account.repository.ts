// ============================================================================
// TRUST ACCOUNT REPOSITORY
// apps/api/src/repositories/trust-account.repository.ts
// ============================================================================

import { BaseRepository, type SoftDeletableEntity, type ListOptions } from './base.repository.js';
import { query } from '../db/connection.js';
import { parsePostgresError, NotFoundError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export interface TrustAccount extends SoftDeletableEntity {
  id: string;
  tenant_id: string;
  client_id: string;
  account_name: string;
  account_number: string | null;
  bank_name: string | null;
  bank_branch: string | null;
  currency: string;
  balance: number;
  is_active: boolean;
  last_reconciled_at: Date | null;
  reconciled_balance: number | null;
  notes: string | null;
  created_by: string | null;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

export interface TrustAccountWithClient extends TrustAccount {
  client_name: string;
}

export interface CreateTrustAccountData {
  client_id: string;
  account_name: string;
  account_number?: string;
  bank_name?: string;
  bank_branch?: string;
  currency?: string;
  notes?: string;
  created_by?: string;
}

export interface UpdateTrustAccountData {
  account_name?: string;
  account_number?: string;
  bank_name?: string;
  bank_branch?: string;
  is_active?: boolean;
  notes?: string;
}

// ============================================================================
// REPOSITORY
// ============================================================================

export class TrustAccountRepository extends BaseRepository<TrustAccount> {
  constructor() {
    super({
      tableName: 'trust_accounts',
      supportsSoftDelete: true,
    });
  }

  /**
   * Create a new trust account
   */
  async createAccount(tenantId: string, data: CreateTrustAccountData): Promise<TrustAccount> {
    this.validateTenantId(tenantId, 'createAccount');

    try {
      const result = await query<TrustAccount>(
        `INSERT INTO trust_accounts (
          tenant_id, client_id, account_name, account_number,
          bank_name, bank_branch, currency, notes, created_by
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING *`,
        [
          tenantId,
          data.client_id,
          data.account_name,
          data.account_number || null,
          data.bank_name || null,
          data.bank_branch || null,
          data.currency || 'ILS',
          data.notes || null,
          data.created_by || null,
        ]
      );

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find trust account by ID with client info
   */
  async findByIdWithClient(tenantId: string, id: string): Promise<TrustAccountWithClient | null> {
    this.validateTenantId(tenantId, 'findByIdWithClient');

    try {
      const result = await query<TrustAccountWithClient>(
        `SELECT ta.*, c.name as client_name
         FROM trust_accounts ta
         JOIN clients c ON ta.client_id = c.id
         WHERE ta.id = $1 AND ta.tenant_id = $2 AND ta.deleted_at IS NULL`,
        [id, tenantId]
      );

      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * List trust accounts for a client
   */
  async findByClient(tenantId: string, clientId: string): Promise<TrustAccount[]> {
    this.validateTenantId(tenantId, 'findByClient');

    try {
      const result = await query<TrustAccount>(
        `SELECT * FROM trust_accounts
         WHERE tenant_id = $1 AND client_id = $2 AND deleted_at IS NULL
         ORDER BY account_name ASC`,
        [tenantId, clientId]
      );

      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * List all trust accounts with client info
   */
  async listWithClients(
    tenantId: string,
    options?: ListOptions & { activeOnly?: boolean }
  ): Promise<TrustAccountWithClient[]> {
    this.validateTenantId(tenantId, 'listWithClients');

    try {
      const activeClause = options?.activeOnly ? 'AND ta.is_active = TRUE' : '';
      const limit = options?.pagination?.limit ?? 100;
      const offset = options?.pagination?.offset ?? 0;

      const result = await query<TrustAccountWithClient>(
        `SELECT ta.*, c.name as client_name
         FROM trust_accounts ta
         JOIN clients c ON ta.client_id = c.id
         WHERE ta.tenant_id = $1 AND ta.deleted_at IS NULL ${activeClause}
         ORDER BY c.name ASC, ta.account_name ASC
         LIMIT $2 OFFSET $3`,
        [tenantId, limit, offset]
      );

      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Update trust account (non-balance fields only)
   */
  async updateAccount(tenantId: string, id: string, data: UpdateTrustAccountData): Promise<TrustAccount> {
    this.validateTenantId(tenantId, 'updateAccount');

    const fields: string[] = [];
    const values: unknown[] = [];
    let paramIndex = 1;

    if (data.account_name !== undefined) {
      fields.push(`account_name = $${paramIndex++}`);
      values.push(data.account_name);
    }
    if (data.account_number !== undefined) {
      fields.push(`account_number = $${paramIndex++}`);
      values.push(data.account_number);
    }
    if (data.bank_name !== undefined) {
      fields.push(`bank_name = $${paramIndex++}`);
      values.push(data.bank_name);
    }
    if (data.bank_branch !== undefined) {
      fields.push(`bank_branch = $${paramIndex++}`);
      values.push(data.bank_branch);
    }
    if (data.is_active !== undefined) {
      fields.push(`is_active = $${paramIndex++}`);
      values.push(data.is_active);
    }
    if (data.notes !== undefined) {
      fields.push(`notes = $${paramIndex++}`);
      values.push(data.notes);
    }

    if (fields.length === 0) {
      return this.findByIdOrFail(tenantId, id);
    }

    fields.push(`updated_at = CURRENT_TIMESTAMP`);
    values.push(tenantId);
    values.push(id);

    try {
      const result = await query<TrustAccount>(
        `UPDATE trust_accounts
         SET ${fields.join(', ')}
         WHERE tenant_id = $${paramIndex++} AND id = $${paramIndex} AND deleted_at IS NULL
         RETURNING *`,
        values
      );

      if (result.rows.length === 0) {
        throw new NotFoundError('TrustAccount', id);
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Record reconciliation
   */
  async recordReconciliation(tenantId: string, id: string, balance: number): Promise<TrustAccount> {
    this.validateTenantId(tenantId, 'recordReconciliation');

    try {
      const result = await query<TrustAccount>(
        `UPDATE trust_accounts
         SET last_reconciled_at = CURRENT_TIMESTAMP,
             reconciled_balance = $1,
             updated_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $2 AND id = $3 AND deleted_at IS NULL
         RETURNING *`,
        [balance, tenantId, id]
      );

      if (result.rows.length === 0) {
        throw new NotFoundError('TrustAccount', id);
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get total balance across all accounts for tenant
   */
  async getTotalBalance(tenantId: string): Promise<number> {
    this.validateTenantId(tenantId, 'getTotalBalance');

    try {
      const result = await query<{ total: number }>(
        `SELECT COALESCE(SUM(balance), 0)::numeric as total
         FROM trust_accounts
         WHERE tenant_id = $1 AND deleted_at IS NULL AND is_active = TRUE`,
        [tenantId]
      );

      return parseFloat(result.rows[0]?.total?.toString() || '0');
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}

export const trustAccountRepository = new TrustAccountRepository();
