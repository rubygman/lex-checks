// ============================================================================
// RBAC SERVICE UNIT TESTS
// apps/api/tests/unit/services/rbac.service.test.ts
// ============================================================================

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { RBACService, PERMISSIONS, ROLES } from '../../../src/services/rbac.service.js';

// Mock repositories
vi.mock('../../../src/repositories/rbac.repository.js', () => ({
  roleRepository: {
    findByName: vi.fn(),
    findById: vi.fn(),
    findByIdWithPermissions: vi.fn(),
    listAll: vi.fn(),
  },
  permissionRepository: {
    getCodesForRole: vi.fn(),
    listAll: vi.fn(),
  },
}));

vi.mock('../../../src/repositories/user.repository.js', () => ({
  userRepository: {
    findByIdWithRole: vi.fn(),
  },
}));

import { roleRepository, permissionRepository } from '../../../src/repositories/rbac.repository.js';
import { userRepository } from '../../../src/repositories/user.repository.js';

describe('RBACService', () => {
  let service: RBACService;
  const tenantId = '550e8400-e29b-41d4-a716-446655440000';
  const userId = '660e8400-e29b-41d4-a716-446655440001';
  const adminRoleId = '00000000-0000-0000-0000-000000000001';
  const attorneyRoleId = '00000000-0000-0000-0000-000000000002';

  beforeEach(() => {
    service = new RBACService();
    vi.clearAllMocks();
  });

  afterEach(() => {
    service.clearCache();
  });

  describe('loadPermissionsForRole', () => {
    it('should load permissions from database', async () => {
      const mockPermissions = [
        PERMISSIONS.CASES_VIEW,
        PERMISSIONS.CASES_CREATE,
        PERMISSIONS.CLIENTS_VIEW,
      ];

      vi.mocked(permissionRepository.getCodesForRole).mockResolvedValue(mockPermissions);

      const permissions = await service.loadPermissionsForRole(adminRoleId);

      expect(permissions).toEqual(mockPermissions);
      expect(permissionRepository.getCodesForRole).toHaveBeenCalledWith(adminRoleId);
    });

    it('should cache permissions after first load', async () => {
      const mockPermissions = [PERMISSIONS.CASES_VIEW];
      vi.mocked(permissionRepository.getCodesForRole).mockResolvedValue(mockPermissions);

      // First call - hits database
      await service.loadPermissionsForRole(adminRoleId);
      
      // Second call - should use cache
      await service.loadPermissionsForRole(adminRoleId);

      expect(permissionRepository.getCodesForRole).toHaveBeenCalledTimes(1);
    });

    it('should reload after cache is cleared', async () => {
      const mockPermissions = [PERMISSIONS.CASES_VIEW];
      vi.mocked(permissionRepository.getCodesForRole).mockResolvedValue(mockPermissions);

      await service.loadPermissionsForRole(adminRoleId);
      service.clearRoleCache(adminRoleId);
      await service.loadPermissionsForRole(adminRoleId);

      expect(permissionRepository.getCodesForRole).toHaveBeenCalledTimes(2);
    });
  });

  describe('checkPermission', () => {
    const mockAdminUser = {
      id: userId,
      tenant_id: tenantId,
      role_id: adminRoleId,
      role_name: 'admin',
      role_name_he: 'מנהל',
      is_active: true,
    };

    const mockAttorneyUser = {
      id: userId,
      tenant_id: tenantId,
      role_id: attorneyRoleId,
      role_name: 'attorney',
      role_name_he: 'עורך דין',
      is_active: true,
    };

    it('should return allowed=true when user has permission', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue(mockAdminUser as any);
      vi.mocked(permissionRepository.getCodesForRole).mockResolvedValue([
        PERMISSIONS.CASES_VIEW,
        PERMISSIONS.CASES_CREATE,
        PERMISSIONS.CASES_DELETE,
      ]);

      const result = await service.checkPermission(tenantId, userId, PERMISSIONS.CASES_VIEW);

      expect(result.allowed).toBe(true);
      expect(result.reason).toBeUndefined();
    });

    it('should return allowed=false when user lacks permission', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue(mockAttorneyUser as any);
      vi.mocked(permissionRepository.getCodesForRole).mockResolvedValue([
        PERMISSIONS.CASES_VIEW,
        PERMISSIONS.CASES_CREATE,
        // Missing CASES_DELETE
      ]);

      const result = await service.checkPermission(tenantId, userId, PERMISSIONS.CASES_DELETE);

      expect(result.allowed).toBe(false);
      expect(result.reason).toContain('attorney');
      expect(result.reason).toContain(PERMISSIONS.CASES_DELETE);
    });

    it('should return allowed=false when user not found', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue(null);

      const result = await service.checkPermission(tenantId, userId, PERMISSIONS.CASES_VIEW);

      expect(result.allowed).toBe(false);
      expect(result.reason).toBe('User not found');
    });

    it('should return allowed=false when user is inactive', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue({
        ...mockAdminUser,
        is_active: false,
      } as any);

      const result = await service.checkPermission(tenantId, userId, PERMISSIONS.CASES_VIEW);

      expect(result.allowed).toBe(false);
      expect(result.reason).toContain('deactivated');
    });
  });

  describe('checkAnyPermission', () => {
    const mockUser = {
      id: userId,
      tenant_id: tenantId,
      role_id: attorneyRoleId,
      role_name: 'attorney',
      role_name_he: 'עורך דין',
      is_active: true,
    };

    it('should return allowed=true when user has ANY of the permissions', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue(mockUser as any);
      vi.mocked(permissionRepository.getCodesForRole).mockResolvedValue([
        PERMISSIONS.CASES_VIEW,
        // Does NOT have CASES_DELETE
      ]);

      const result = await service.checkAnyPermission(tenantId, userId, [
        PERMISSIONS.CASES_VIEW,
        PERMISSIONS.CASES_DELETE,
      ]);

      expect(result.allowed).toBe(true);
    });

    it('should return allowed=false when user has NONE of the permissions', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue(mockUser as any);
      vi.mocked(permissionRepository.getCodesForRole).mockResolvedValue([
        PERMISSIONS.CASES_VIEW,
      ]);

      const result = await service.checkAnyPermission(tenantId, userId, [
        PERMISSIONS.CASES_DELETE,
        PERMISSIONS.USERS_MANAGE,
      ]);

      expect(result.allowed).toBe(false);
    });
  });

  describe('checkAllPermissions', () => {
    const mockUser = {
      id: userId,
      tenant_id: tenantId,
      role_id: adminRoleId,
      role_name: 'admin',
      role_name_he: 'מנהל',
      is_active: true,
    };

    it('should return allowed=true when user has ALL permissions', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue(mockUser as any);
      vi.mocked(permissionRepository.getCodesForRole).mockResolvedValue([
        PERMISSIONS.CASES_VIEW,
        PERMISSIONS.CASES_CREATE,
        PERMISSIONS.CASES_DELETE,
      ]);

      const result = await service.checkAllPermissions(tenantId, userId, [
        PERMISSIONS.CASES_VIEW,
        PERMISSIONS.CASES_CREATE,
      ]);

      expect(result.allowed).toBe(true);
    });

    it('should return allowed=false when user is missing some permissions', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue(mockUser as any);
      vi.mocked(permissionRepository.getCodesForRole).mockResolvedValue([
        PERMISSIONS.CASES_VIEW,
        // Missing CASES_CREATE and CASES_DELETE
      ]);

      const result = await service.checkAllPermissions(tenantId, userId, [
        PERMISSIONS.CASES_VIEW,
        PERMISSIONS.CASES_CREATE,
        PERMISSIONS.CASES_DELETE,
      ]);

      expect(result.allowed).toBe(false);
      expect(result.reason).toContain(PERMISSIONS.CASES_CREATE);
      expect(result.reason).toContain(PERMISSIONS.CASES_DELETE);
    });
  });

  describe('requirePermission', () => {
    it('should not throw when permission is granted', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue({
        id: userId,
        tenant_id: tenantId,
        role_id: adminRoleId,
        role_name: 'admin',
        is_active: true,
      } as any);
      vi.mocked(permissionRepository.getCodesForRole).mockResolvedValue([
        PERMISSIONS.CASES_VIEW,
      ]);

      await expect(
        service.requirePermission(tenantId, userId, PERMISSIONS.CASES_VIEW)
      ).resolves.not.toThrow();
    });

    it('should throw when permission is denied', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue({
        id: userId,
        tenant_id: tenantId,
        role_id: attorneyRoleId,
        role_name: 'attorney',
        is_active: true,
      } as any);
      vi.mocked(permissionRepository.getCodesForRole).mockResolvedValue([]);

      await expect(
        service.requirePermission(tenantId, userId, PERMISSIONS.CASES_DELETE)
      ).rejects.toThrow('PERMISSION_DENIED');
    });
  });

  describe('getUserPermissions', () => {
    it('should return full user permissions object', async () => {
      const mockPermissions = [
        PERMISSIONS.CASES_VIEW,
        PERMISSIONS.CASES_CREATE,
        PERMISSIONS.CLIENTS_VIEW,
      ];

      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue({
        id: userId,
        tenant_id: tenantId,
        role_id: adminRoleId,
        role_name: 'admin',
        is_active: true,
      } as any);
      vi.mocked(permissionRepository.getCodesForRole).mockResolvedValue(mockPermissions);

      const result = await service.getUserPermissions(tenantId, userId);

      expect(result).toEqual({
        userId,
        roleId: adminRoleId,
        roleName: 'admin',
        permissions: mockPermissions,
      });
    });

    it('should return null for non-existent user', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue(null);

      const result = await service.getUserPermissions(tenantId, userId);

      expect(result).toBeNull();
    });
  });

  describe('isAdmin', () => {
    it('should return true for admin users', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue({
        id: userId,
        role_name: ROLES.ADMIN,
      } as any);

      const result = await service.isAdmin(tenantId, userId);

      expect(result).toBe(true);
    });

    it('should return false for non-admin users', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue({
        id: userId,
        role_name: ROLES.ATTORNEY,
      } as any);

      const result = await service.isAdmin(tenantId, userId);

      expect(result).toBe(false);
    });

    it('should return false for non-existent users', async () => {
      vi.mocked(userRepository.findByIdWithRole).mockResolvedValue(null);

      const result = await service.isAdmin(tenantId, userId);

      expect(result).toBe(false);
    });
  });
});

describe('Role-Permission Mapping Verification', () => {
  /**
   * These tests verify the expected permission mappings for each role
   * based on the seeded data in 001_roles_permissions.sql
   */

  const ADMIN_EXPECTED_PERMISSIONS = [
    // Admin should have ALL permissions
    PERMISSIONS.CASES_VIEW,
    PERMISSIONS.CASES_CREATE,
    PERMISSIONS.CASES_EDIT,
    PERMISSIONS.CASES_DELETE,
    PERMISSIONS.CLIENTS_DELETE,
    PERMISSIONS.USERS_MANAGE,
    PERMISSIONS.ROLES_MANAGE,
    PERMISSIONS.AUDIT_LOG_VIEW,
    PERMISSIONS.BACKUP_MANAGE,
  ];

  const ATTORNEY_FORBIDDEN_PERMISSIONS = [
    // Attorney should NOT have these
    PERMISSIONS.CASES_DELETE,
    PERMISSIONS.CLIENTS_DELETE,
    PERMISSIONS.USERS_MANAGE,
    PERMISSIONS.ROLES_MANAGE,
    PERMISSIONS.AUDIT_LOG_VIEW,
    PERMISSIONS.BACKUP_MANAGE,
  ];

  const STAFF_LIMITED_PERMISSIONS = [
    // Staff should have these
    PERMISSIONS.CASES_VIEW,
    PERMISSIONS.CLIENTS_VIEW,
    PERMISSIONS.DOCS_VIEW,
    PERMISSIONS.CALENDAR_VIEW,
  ];

  const STAFF_FORBIDDEN_PERMISSIONS = [
    // Staff should NOT have these
    PERMISSIONS.CASES_CREATE,
    PERMISSIONS.CASES_EDIT,
    PERMISSIONS.CASES_DELETE,
    PERMISSIONS.CLIENTS_CREATE,
    PERMISSIONS.CLIENTS_EDIT,
    PERMISSIONS.INVOICES_CREATE,
    PERMISSIONS.USERS_MANAGE,
  ];

  it('should define ADMIN role with comprehensive permissions', () => {
    // This is a compile-time check that the constants exist
    for (const perm of ADMIN_EXPECTED_PERMISSIONS) {
      expect(perm).toBeDefined();
      expect(typeof perm).toBe('string');
    }
  });

  it('should define expected forbidden permissions for ATTORNEY', () => {
    for (const perm of ATTORNEY_FORBIDDEN_PERMISSIONS) {
      expect(perm).toBeDefined();
    }
  });

  it('should define STAFF with limited permissions', () => {
    for (const perm of STAFF_LIMITED_PERMISSIONS) {
      expect(perm).toBeDefined();
    }
  });

  it('should have all permission codes defined', () => {
    const allPermissions = Object.values(PERMISSIONS);
    expect(allPermissions.length).toBeGreaterThan(50); // We seeded 55+ permissions
    
    // Check format
    for (const perm of allPermissions) {
      expect(perm).toMatch(/^[a-z_]+$/); // snake_case
    }
  });

  it('should have all role names defined', () => {
    expect(ROLES.ADMIN).toBe('admin');
    expect(ROLES.ATTORNEY).toBe('attorney');
    expect(ROLES.PARALEGAL).toBe('paralegal');
    expect(ROLES.STAFF).toBe('staff');
  });
});
