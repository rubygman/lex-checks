// ============================================================================
// AUTH SERVICE
// apps/api/src/services/auth.service.ts
// 
// Handles registration, login, refresh, logout, and user info
// ============================================================================

import crypto from 'crypto';
import jwt, { type SignOptions, type JwtPayload } from 'jsonwebtoken';
import { 
  userRepository, 
  type User, 
  type UserWithRole 
} from '../repositories/user.repository.js';
import { 
  refreshTokenRepository, 
  RefreshTokenRepository 
} from '../repositories/refresh-token.repository.js';
import { roleRepository } from '../repositories/rbac.repository.js';
import { tenantRepository } from '../repositories/tenant.repository.js';
import { hashPassword, verifyPassword, validatePasswordStrength } from '../security/password.js';
import { getConfig } from '../config/index.js';
import { DatabaseError, NotFoundError, DuplicateError } from '../db/errors.js';
import { query } from '../db/connection.js';
import {
  auditLoginSuccess,
  auditLoginFailed,
  auditRegistration,
  auditRefreshTokenReuse,
  auditLogout,
  auditPasswordResetRequest,
  auditPasswordResetComplete,
  type AuditMeta,
} from './security-audit.js';
import { sendPasswordResetEmail } from '../integrations/mailer.js';

// ============================================================================
// TYPES
// ============================================================================

export interface RegisterInput {
  email: string;
  password: string;
  name: string;
  phone?: string;
}

export interface LoginInput {
  email: string;
  password: string;
}

export interface LoginResult {
  user: UserPublic;
  accessToken: string;
  refreshToken: string;
  accessExpiresAt: Date;
  refreshExpiresAt: Date;
}

export interface RefreshResult {
  accessToken: string;
  refreshToken: string;
  accessExpiresAt: Date;
  refreshExpiresAt: Date;
}

export interface UserPublic {
  id: string;
  tenantId: string;
  email: string;
  name: string;
  phone: string | null;
  role: {
    id: string;
    name: string;
  };
  isActive: boolean;
  createdAt: Date;
  lastLoginAt: Date | null;
}

export interface TokenPayload {
  sub: string;       // User ID
  tid: string;       // Tenant ID
  rid: string;       // Role ID
  rn: string;        // Role name
  email: string;
  type: 'access' | 'refresh';
  jti: string;       // Unique token ID
  fam?: string;      // Family ID (refresh tokens only)
}

export interface RequestMeta {
  ipAddress?: string;
  userAgent?: string;
  deviceId?: string;
}

// ============================================================================
// CONSTANTS
// ============================================================================

const ACCESS_TOKEN_EXPIRY = '15m';
const REFRESH_TOKEN_EXPIRY_DAYS = 7;

// ============================================================================
// SERVICE
// ============================================================================

export class AuthService {
  // ==========================================================================
  // REGISTRATION
  // ==========================================================================

  /**
   * Register a new user in a tenant
   * First user in a tenant automatically becomes admin
   */
  async register(
    tenantId: string,
    input: RegisterInput,
    meta?: RequestMeta
  ): Promise<LoginResult> {
    // Validate email format
    if (!this.isValidEmail(input.email)) {
      throw new DatabaseError('Invalid email format', 'INVALID_EMAIL', 400);
    }

    // Validate password strength
    const passwordStrength = validatePasswordStrength(input.password);
    if (!passwordStrength.isValid) {
      throw new DatabaseError(
        `Password too weak: ${passwordStrength.feedback.join(', ')}`,
        'WEAK_PASSWORD',
        400
      );
    }

    // Validate tenant exists and is active
    const tenant = await tenantRepository.findById(tenantId);
    if (!tenant) {
      throw new NotFoundError('Tenant', tenantId);
    }
    if (!tenant.is_active) {
      throw new DatabaseError('Tenant is deactivated', 'TENANT_INACTIVE', 403);
    }

    // Check if email already exists in tenant
    const existingUser = await userRepository.findByEmail(tenantId, input.email);
    if (existingUser) {
      throw new DuplicateError('User with this email already exists', 'email');
    }

    // Determine role: first user becomes admin
    const isFirstUser = await this.isFirstUserInTenant(tenantId);
    const roleName = isFirstUser ? 'admin' : 'staff';  // Default to staff for subsequent users
    
    const role = await roleRepository.findByName(roleName);
    if (!role) {
      throw new DatabaseError(`Role "${roleName}" not found`, 'ROLE_NOT_FOUND', 500);
    }

    // Hash password
    const passwordHash = await hashPassword(input.password);

    // Create user
    const user = await userRepository.create(tenantId, {
      email: input.email.toLowerCase().trim(),
      password_hash: passwordHash,
      name: input.name.trim(),
      phone: input.phone?.trim(),
      role_id: role.id,
      is_active: true,
    });

    // Get user with role for response
    const userWithRole = await userRepository.findByIdWithRole(tenantId, user.id);
    if (!userWithRole) {
      throw new DatabaseError('Failed to load user after creation', 'USER_LOAD_FAILED', 500);
    }

    // Audit: Record registration (best-effort, never fails)
    await auditRegistration(
      tenantId,
      user.id,
      input.email,
      isFirstUser,
      this.toAuditMeta(meta)
    );

    // Generate tokens and return
    return this.generateLoginResult(userWithRole, meta);
  }

  /**
   * Check if this would be the first user in the tenant
   */
  private async isFirstUserInTenant(tenantId: string): Promise<boolean> {
    const result = await query<{ count: string }>(
      'SELECT COUNT(*) as count FROM users WHERE tenant_id = $1 AND deleted_at IS NULL',
      [tenantId]
    );
    return parseInt(result.rows[0]?.count || '0', 10) === 0;
  }

  // ==========================================================================
  // LOGIN
  // ==========================================================================

  /**
   * Login with email and password
   */
  async login(
    tenantId: string,
    input: LoginInput,
    meta?: RequestMeta
  ): Promise<LoginResult> {
    // Find user by email
    const user = await userRepository.findByEmail(tenantId, input.email.toLowerCase().trim());
    
    if (!user) {
      // Don't reveal whether email exists
      throw new DatabaseError('Invalid email or password', 'INVALID_CREDENTIALS', 401);
    }

    // Check if user is active
    if (!user.is_active) {
      throw new DatabaseError('Account is deactivated', 'ACCOUNT_INACTIVE', 403);
    }

    // Verify password
    const isValid = await verifyPassword(input.password, user.password_hash);
    if (!isValid) {
      // Audit: Record failed login attempt (best-effort)
      await auditLoginFailed(
        tenantId,
        user.id,
        'Invalid password',
        this.toAuditMeta(meta)
      );
      throw new DatabaseError('Invalid email or password', 'INVALID_CREDENTIALS', 401);
    }

    // Get user with role
    const userWithRole = await userRepository.findByIdWithRole(tenantId, user.id);
    if (!userWithRole) {
      throw new DatabaseError('Failed to load user', 'USER_LOAD_FAILED', 500);
    }

    // Update last login
    await userRepository.update(tenantId, user.id, {
      last_login_at: new Date(),
    });

    // Audit: Record successful login (best-effort)
    await auditLoginSuccess(tenantId, user.id, this.toAuditMeta(meta));

    // Generate tokens and return
    return this.generateLoginResult(userWithRole, meta);
  }

  /**
   * Convert RequestMeta to AuditMeta
   */
  private toAuditMeta(meta?: RequestMeta): AuditMeta | undefined {
    if (!meta) return undefined;
    return {
      ipAddress: meta.ipAddress,
      userAgent: meta.userAgent,
    };
  }

  // ==========================================================================
  // TOKEN REFRESH
  // ==========================================================================

  /**
   * Refresh access token using refresh token
   * Implements token rotation for security
   * 
   * SECURITY: Uses atomic rotation to prevent race conditions where
   * concurrent requests could both succeed with the same token.
   */
  async refresh(refreshToken: string, meta?: RequestMeta): Promise<RefreshResult> {
    const config = getConfig();
    
    // Hash the token to look it up
    const tokenHash = RefreshTokenRepository.hashToken(refreshToken);
    
    // Find the token record
    const tokenRecord = await refreshTokenRepository.findByHash(tokenHash);
    
    if (!tokenRecord) {
      throw new DatabaseError('Invalid refresh token', 'INVALID_TOKEN', 401);
    }

    // Check if token was revoked
    if (tokenRecord.revoked_at) {
      throw new DatabaseError('Refresh token has been revoked', 'TOKEN_REVOKED', 401);
    }

    // Check if token is expired
    if (new Date() > tokenRecord.expires_at) {
      throw new DatabaseError('Refresh token has expired', 'TOKEN_EXPIRED', 401);
    }

    // Check if token was already rotated (REUSE DETECTION - first check)
    // This catches obvious reuse where rotated_at is already set in DB
    if (tokenRecord.rotated_at) {
      // Token reuse detected! Revoke entire family
      await refreshTokenRepository.revokeFamily(
        tokenRecord.family_id,
        'Token reuse detected - possible theft'
      );

      // SECURITY AUDIT: Record token reuse detection (critical security event)
      await auditRefreshTokenReuse(
        tokenRecord.tenant_id,
        tokenRecord.user_id,
        tokenRecord.family_id,
        this.toAuditMeta(meta)
      );

      throw new DatabaseError(
        'Token reuse detected. All sessions have been revoked for security.',
        'TOKEN_REUSE',
        401
      );
    }

    // Get user before rotation (we'll need this info even if rotation fails)
    const user = await userRepository.findByIdWithRole(
      tokenRecord.tenant_id,
      tokenRecord.user_id
    );
    
    if (!user) {
      throw new DatabaseError('User not found', 'USER_NOT_FOUND', 401);
    }

    if (!user.is_active) {
      throw new DatabaseError('Account is deactivated', 'ACCOUNT_INACTIVE', 403);
    }

    // CRITICAL: Atomic rotation - prevents race conditions
    // Only one concurrent request can succeed; others will get false
    const rotationSucceeded = await refreshTokenRepository.markRotatedIfNotRotated(tokenRecord.id);
    
    if (!rotationSucceeded) {
      // Another request already rotated this token (race condition)
      // This is equivalent to token reuse - revoke entire family
      await refreshTokenRepository.revokeFamily(
        tokenRecord.family_id,
        'Token reuse detected - possible theft (concurrent rotation attempt)'
      );

      // SECURITY AUDIT: Record token reuse detection
      await auditRefreshTokenReuse(
        tokenRecord.tenant_id,
        tokenRecord.user_id,
        tokenRecord.family_id,
        this.toAuditMeta(meta)
      );

      throw new DatabaseError(
        'Token reuse detected. All sessions have been revoked for security.',
        'TOKEN_REUSE',
        401
      );
    }

    // Generate new tokens (same family for rotation tracking)
    const newTokens = await this.generateTokens(user, tokenRecord.family_id, meta);

    return {
      accessToken: newTokens.accessToken,
      refreshToken: newTokens.refreshToken,
      accessExpiresAt: newTokens.accessExpiresAt,
      refreshExpiresAt: newTokens.refreshExpiresAt,
    };
  }

  // ==========================================================================
  // LOGOUT
  // ==========================================================================

  /**
   * Logout - revoke the refresh token
   */
  async logout(refreshToken: string): Promise<void> {
    const tokenHash = RefreshTokenRepository.hashToken(refreshToken);
    await refreshTokenRepository.revokeByHash(tokenHash, 'User logout');
  }

  /**
   * Logout from all devices
   */
  async logoutAll(tenantId: string, userId: string, meta?: RequestMeta): Promise<number> {
    const count = await refreshTokenRepository.revokeAllForUser(tenantId, userId, 'User logout all devices');
    
    // Audit: Record logout all (best-effort)
    await auditLogout(tenantId, userId, true, count, this.toAuditMeta(meta));
    
    return count;
  }

  // ==========================================================================
  // GET CURRENT USER
  // ==========================================================================

  /**
   * Get current user info
   */
  async me(tenantId: string, userId: string): Promise<UserPublic> {
    const user = await userRepository.findByIdWithRole(tenantId, userId);
    
    if (!user) {
      throw new NotFoundError('User', userId);
    }

    return this.toPublicUser(user);
  }

  // ==========================================================================
  // PASSWORD RESET (STUB)
  // ==========================================================================

  /**
   * Request password reset
   * 
   * SECURITY:
   * - Always returns same message regardless of whether email exists (prevents enumeration)
   * - Token is stored hashed (SHA-256)
   * - Token expires in 1 hour
   * - Reset link is sent via mailer (never logged)
   */
  async requestPasswordReset(
    tenantId: string,
    email: string,
    meta?: RequestMeta
  ): Promise<{ message: string }> {
    // Find user (don't reveal if exists)
    const user = await userRepository.findByEmail(tenantId, email.toLowerCase().trim());
    
    // Always return same message (security - prevents account enumeration)
    const response = { 
      message: 'If an account with that email exists, a password reset link has been sent.' 
    };

    // Audit: Record password reset request (best-effort)
    // Note: We audit even if user not found, but don't reveal that in the response
    await auditPasswordResetRequest(
      tenantId,
      user?.id || null,
      !!user,
      this.toAuditMeta(meta)
    );

    if (!user) {
      return response;
    }

    // Get tenant for email personalization
    const tenant = await tenantRepository.findById(tenantId);

    // Generate reset token (32 random bytes = 64 hex chars)
    const resetToken = crypto.randomBytes(32).toString('hex');
    
    // Store ONLY the hash (SHA-256) - never store plaintext token
    const tokenHash = crypto.createHash('sha256').update(resetToken).digest('hex');
    
    // Token expires in 1 hour
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

    // Invalidate any existing unused tokens for this user
    await query(
      `UPDATE password_reset_tokens 
       SET used_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
       WHERE tenant_id = $1 AND user_id = $2 AND used_at IS NULL`,
      [tenantId, user.id]
    );

    // Store new token
    await query(
      `INSERT INTO password_reset_tokens (tenant_id, user_id, token_hash, expires_at, ip_address, user_agent)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [tenantId, user.id, tokenHash, expiresAt, meta?.ipAddress || null, meta?.userAgent || null]
    );

    // Build reset link
    // In production, this would come from config
    const config = getConfig();
    const baseUrl = config.server.corsOrigins[0] || 'http://localhost:3000';
    const resetLink = `${baseUrl}/reset-password?token=${resetToken}&tenant=${tenantId}`;

    // Send email via mailer (NEVER logs the token/link)
    await sendPasswordResetEmail(email, resetLink, {
      userName: user.name,
      expiresInMinutes: 60,
      tenantName: tenant?.name,
    });

    return response;
  }

  /**
   * Reset password with token
   * 
   * SECURITY:
   * - Validates token exists, not used, not expired
   * - Updates password hash (Argon2id)
   * - Marks token as used
   * - Revokes ALL refresh tokens for the user (logs out all devices)
   */
  async resetPassword(
    tenantId: string,
    token: string,
    newPassword: string,
    meta?: RequestMeta
  ): Promise<{ message: string }> {
    // Validate password strength first (before any DB operations)
    const passwordStrength = validatePasswordStrength(newPassword);
    if (!passwordStrength.isValid) {
      throw new DatabaseError(
        `Password too weak: ${passwordStrength.feedback.join(', ')}`,
        'WEAK_PASSWORD',
        400
      );
    }

    // Hash the provided token to look it up
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    
    // Find token record
    const result = await query<{
      id: string;
      user_id: string;
      used_at: Date | null;
      expires_at: Date;
    }>(
      `SELECT id, user_id, used_at, expires_at 
       FROM password_reset_tokens 
       WHERE tenant_id = $1 AND token_hash = $2 AND deleted_at IS NULL`,
      [tenantId, tokenHash]
    );

    const tokenRecord = result.rows[0];

    // Validate token exists
    if (!tokenRecord) {
      throw new DatabaseError('Invalid or expired reset token', 'INVALID_TOKEN', 400);
    }

    // Validate token not already used
    if (tokenRecord.used_at) {
      throw new DatabaseError('Reset token has already been used', 'TOKEN_USED', 400);
    }

    // Validate token not expired
    if (new Date() > new Date(tokenRecord.expires_at)) {
      throw new DatabaseError('Reset token has expired', 'TOKEN_EXPIRED', 400);
    }

    // Hash new password using Argon2id
    const passwordHash = await hashPassword(newPassword);

    // Update user password
    await userRepository.update(tenantId, tokenRecord.user_id, {
      password_hash: passwordHash,
    });

    // Mark token as used (prevents reuse)
    await query(
      `UPDATE password_reset_tokens 
       SET used_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP 
       WHERE id = $1`,
      [tokenRecord.id]
    );

    // SECURITY: Revoke ALL refresh tokens for the user
    // This logs out all devices, ensuring attacker can't maintain access
    const revokedCount = await refreshTokenRepository.revokeAllForUser(
      tenantId,
      tokenRecord.user_id,
      'Password reset - all sessions revoked for security'
    );

    // Audit: Record password reset completion (best-effort)
    await auditPasswordResetComplete(tenantId, tokenRecord.user_id, this.toAuditMeta(meta));

    return { 
      message: `Password has been reset successfully. ${revokedCount > 0 ? `${revokedCount} active sessions were logged out for security.` : ''}`.trim()
    };
  }

  // ==========================================================================
  // TOKEN GENERATION
  // ==========================================================================

  /**
   * Generate login result with tokens
   */
  private async generateLoginResult(
    user: UserWithRole,
    meta?: RequestMeta
  ): Promise<LoginResult> {
    const tokens = await this.generateTokens(user, undefined, meta);

    return {
      user: this.toPublicUser(user),
      ...tokens,
    };
  }

  /**
   * Generate access and refresh tokens
   */
  private async generateTokens(
    user: UserWithRole,
    familyId?: string,
    meta?: RequestMeta
  ): Promise<{
    accessToken: string;
    refreshToken: string;
    accessExpiresAt: Date;
    refreshExpiresAt: Date;
  }> {
    const config = getConfig();
    const jti = crypto.randomUUID();
    const family = familyId || RefreshTokenRepository.generateFamilyId();

    // Generate access token
    const accessPayload: TokenPayload = {
      sub: user.id,
      tid: user.tenant_id,
      rid: user.role_id,
      rn: user.role_name,
      email: user.email,
      type: 'access',
      jti,
    };

    const accessToken = jwt.sign(accessPayload, config.jwt.accessSecret, {
      expiresIn: config.jwt.accessExpiresIn,
      issuer: config.jwt.issuer,
      audience: config.jwt.audience,
    });

    // Calculate expiry times
    const accessExpiresAt = new Date(Date.now() + this.parseExpiry(config.jwt.accessExpiresIn));
    const refreshExpiresAt = new Date(Date.now() + REFRESH_TOKEN_EXPIRY_DAYS * 24 * 60 * 60 * 1000);

    // Generate refresh token (random, not JWT)
    const refreshTokenValue = crypto.randomBytes(32).toString('hex');
    const refreshTokenHash = RefreshTokenRepository.hashToken(refreshTokenValue);

    // Store refresh token in database
    await refreshTokenRepository.create({
      tenantId: user.tenant_id,
      userId: user.id,
      tokenHash: refreshTokenHash,
      familyId: family,
      expiresAt: refreshExpiresAt,
      deviceId: meta?.deviceId,
      userAgent: meta?.userAgent,
      ipAddress: meta?.ipAddress,
    });

    return {
      accessToken,
      refreshToken: refreshTokenValue,
      accessExpiresAt,
      refreshExpiresAt,
    };
  }

  /**
   * Parse expiry string to milliseconds
   */
  private parseExpiry(expiry: string): number {
    const match = expiry.match(/^(\d+)([smhd])$/);
    if (!match) return 15 * 60 * 1000; // Default 15 minutes

    const value = parseInt(match[1], 10);
    const unit = match[2];

    const multipliers: Record<string, number> = {
      's': 1000,
      'm': 60 * 1000,
      'h': 60 * 60 * 1000,
      'd': 24 * 60 * 60 * 1000,
    };

    return value * multipliers[unit];
  }

  // ==========================================================================
  // HELPERS
  // ==========================================================================

  /**
   * Convert user to public representation (no sensitive fields)
   */
  private toPublicUser(user: UserWithRole): UserPublic {
    return {
      id: user.id,
      tenantId: user.tenant_id,
      email: user.email,
      name: user.name,
      phone: user.phone,
      role: {
        id: user.role_id,
        name: user.role_name,
      },
      isActive: user.is_active,
      createdAt: user.created_at,
      lastLoginAt: user.last_login_at,
    };
  }

  /**
   * Validate email format
   */
  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
}

export const authService = new AuthService();
