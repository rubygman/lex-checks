// ============================================================================
// MIDDLEWARE INDEX
// apps/api/src/middleware/index.ts
// ============================================================================

// Request Context
export {
  initializeContext,
  getRequestContext,
  type TenantContext,
  type RequestContext,
} from './context.js';

// Tenant Resolution
export {
  resolveTenantFromHeader,
  requireTenant,
  getTenantContext,
  TenantResolutionError,
} from './tenant-resolver.js';

// Authentication
export {
  authParser,
  requireAuth,
  requireTenantAccess,
  requirePermission,
  requireAnyPermission,
  requireAllPermissions,
  requireAdmin,
  hasPermission,
  assertPermission,
  AuthenticationError,
  AuthorizationError,
  type AuthContext,
} from './auth.js';

// Rate Limiting
export {
  createRateLimiter,
  globalRateLimiter,
  loginRateLimiter,
  registrationRateLimiter,
  passwordResetRateLimiter,
  refreshRateLimiter,
  sensitiveRateLimiter,
  combineRateLimiters,
  InMemoryRateLimitStore,
  getDefaultStore,
  type RateLimitStore,
} from './rate-limiter.js';
