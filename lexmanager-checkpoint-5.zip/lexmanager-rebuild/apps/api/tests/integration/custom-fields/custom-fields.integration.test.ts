// ============================================================================
// CUSTOM FIELDS INTEGRATION TESTS
// apps/api/tests/integration/custom-fields/custom-fields.integration.test.ts
// ============================================================================

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import pg from 'pg';
import { customFieldsService } from '../../../src/services/custom-fields.service.js';
import { customFieldDefinitionRepository } from '../../../src/repositories/custom-field-definition.repository.js';
import { customFieldValueRepository } from '../../../src/repositories/custom-field-value.repository.js';

const { Pool } = pg;

// Skip if no database connection
const DATABASE_URL = process.env.DATABASE_URL;
const shouldRun = DATABASE_URL && DATABASE_URL.includes('localhost');

describe.skipIf(!shouldRun)('Custom Fields Integration', () => {
  let pool: pg.Pool;
  let tenantId: string;
  let adminUserId: string;
  let clientId: string;

  beforeAll(async () => {
    pool = new Pool({ connectionString: DATABASE_URL });

    // Get admin role
    const roleResult = await pool.query("SELECT id FROM roles WHERE name = 'admin' LIMIT 1");
    const adminRoleId = roleResult.rows[0].id;

    // Create test tenant
    const tenantResult = await pool.query(
      "INSERT INTO tenants (name, slug) VALUES ('Custom Fields Test', $1) RETURNING id",
      [`custom-fields-test-${Date.now()}`]
    );
    tenantId = tenantResult.rows[0].id;

    // Create admin user
    const userResult = await pool.query(
      `INSERT INTO users (tenant_id, email, password_hash, name, role_id)
       VALUES ($1, $2, 'hash', 'Admin User', $3) RETURNING id`,
      [tenantId, `admin-${Date.now()}@test.com`, adminRoleId]
    );
    adminUserId = userResult.rows[0].id;

    // Create test client
    const clientResult = await pool.query(
      `INSERT INTO clients (tenant_id, name, client_type, status, address_country, currency, payment_terms)
       VALUES ($1, 'Test Client', 'individual', 'active', 'Israel', 'ILS', 30) RETURNING id`,
      [tenantId]
    );
    clientId = clientResult.rows[0].id;
  });

  afterAll(async () => {
    await pool.query('DELETE FROM tenants WHERE id = $1', [tenantId]);
    await pool.end();
  });

  // ============================================================================
  // DEFINITION CREATION
  // ============================================================================

  describe('Definition Creation', () => {
    it('should create a text field definition', async () => {
      const definition = await customFieldsService.createDefinition(
        tenantId,
        adminUserId,
        {
          entityType: 'clients',
          fieldKey: 'nickname',
          fieldType: 'text',
          label: 'Nickname',
          labelHe: 'כינוי',
          description: 'Client nickname',
        }
      );

      expect(definition).toBeDefined();
      expect(definition.field_key).toBe('nickname');
      expect(definition.field_type).toBe('text');
      expect(definition.label).toBe('Nickname');
      expect(definition.label_he).toBe('כינוי');
    });

    it('should create a number field definition', async () => {
      const definition = await customFieldsService.createDefinition(
        tenantId,
        adminUserId,
        {
          entityType: 'clients',
          fieldKey: 'priority_score',
          fieldType: 'number',
          label: 'Priority Score',
          isRequired: false,
        }
      );

      expect(definition.field_type).toBe('number');
    });

    it('should create a boolean field definition', async () => {
      const definition = await customFieldsService.createDefinition(
        tenantId,
        adminUserId,
        {
          entityType: 'clients',
          fieldKey: 'is_vip',
          fieldType: 'boolean',
          label: 'VIP Client',
          labelHe: 'לקוח VIP',
        }
      );

      expect(definition.field_type).toBe('boolean');
    });

    it('should create a date field definition', async () => {
      const definition = await customFieldsService.createDefinition(
        tenantId,
        adminUserId,
        {
          entityType: 'clients',
          fieldKey: 'contract_date',
          fieldType: 'date',
          label: 'Contract Date',
        }
      );

      expect(definition.field_type).toBe('date');
    });

    it('should create a select field with bilingual options', async () => {
      const definition = await customFieldsService.createDefinition(
        tenantId,
        adminUserId,
        {
          entityType: 'clients',
          fieldKey: 'client_source',
          fieldType: 'select',
          label: 'Client Source',
          labelHe: 'מקור לקוח',
          options: [
            { value: 'referral', label: 'Referral', label_he: 'הפניה' },
            { value: 'website', label: 'Website', label_he: 'אתר אינטרנט' },
            { value: 'advertising', label: 'Advertising', label_he: 'פרסום' },
            { value: 'other', label: 'Other', label_he: 'אחר' },
          ],
        }
      );

      expect(definition.field_type).toBe('select');
      expect(definition.options_json).toBeDefined();
      expect((definition.options_json as any).options).toHaveLength(4);
      expect((definition.options_json as any).options[0].label_he).toBe('הפניה');
    });

    it('should create a multi_select field', async () => {
      const definition = await customFieldsService.createDefinition(
        tenantId,
        adminUserId,
        {
          entityType: 'clients',
          fieldKey: 'interests',
          fieldType: 'multi_select',
          label: 'Interests',
          labelHe: 'תחומי עניין',
          options: [
            { value: 'real_estate', label: 'Real Estate', label_he: 'נדל"ן' },
            { value: 'corporate', label: 'Corporate', label_he: 'תאגידי' },
            { value: 'litigation', label: 'Litigation', label_he: 'ליטיגציה' },
          ],
        }
      );

      expect(definition.field_type).toBe('multi_select');
    });

    it('should auto-increment display_order', async () => {
      const def1 = await customFieldsService.createDefinition(
        tenantId,
        adminUserId,
        {
          entityType: 'cases',
          fieldKey: 'field_a',
          fieldType: 'text',
          label: 'Field A',
        }
      );

      const def2 = await customFieldsService.createDefinition(
        tenantId,
        adminUserId,
        {
          entityType: 'cases',
          fieldKey: 'field_b',
          fieldType: 'text',
          label: 'Field B',
        }
      );

      expect(def2.display_order).toBeGreaterThan(def1.display_order);
    });
  });

  // ============================================================================
  // VALIDATION - INVALID TYPE/VALUE REJECTIONS
  // ============================================================================

  describe('Validation - Invalid Type/Value Rejections', () => {
    it('should reject invalid field type', async () => {
      await expect(
        customFieldsService.createDefinition(tenantId, adminUserId, {
          entityType: 'clients',
          fieldKey: 'bad_type',
          fieldType: 'invalid_type' as any,
          label: 'Bad Type',
        })
      ).rejects.toThrow(/invalid field type/i);
    });

    it('should reject invalid entity type', async () => {
      await expect(
        customFieldsService.createDefinition(tenantId, adminUserId, {
          entityType: 'invalid_entity' as any,
          fieldKey: 'some_field',
          fieldType: 'text',
          label: 'Some Field',
        })
      ).rejects.toThrow(/invalid entity type/i);
    });

    it('should reject invalid field key format', async () => {
      await expect(
        customFieldsService.createDefinition(tenantId, adminUserId, {
          entityType: 'clients',
          fieldKey: 'Invalid-Key',  // Contains uppercase and hyphen
          fieldType: 'text',
          label: 'Bad Key',
        })
      ).rejects.toThrow(/field key/i);
    });

    it('should reject select field without options', async () => {
      await expect(
        customFieldsService.createDefinition(tenantId, adminUserId, {
          entityType: 'clients',
          fieldKey: 'no_options',
          fieldType: 'select',
          label: 'No Options',
          // Missing options!
        })
      ).rejects.toThrow(/options are required/i);
    });

    it('should reject duplicate field key', async () => {
      // Create first
      await customFieldsService.createDefinition(tenantId, adminUserId, {
        entityType: 'clients',
        fieldKey: 'duplicate_key',
        fieldType: 'text',
        label: 'First',
      });

      // Try duplicate
      await expect(
        customFieldsService.createDefinition(tenantId, adminUserId, {
          entityType: 'clients',
          fieldKey: 'duplicate_key',
          fieldType: 'text',
          label: 'Second',
        })
      ).rejects.toThrow(/already exists/i);
    });

    it('should reject option with empty value', async () => {
      await expect(
        customFieldsService.createDefinition(tenantId, adminUserId, {
          entityType: 'clients',
          fieldKey: 'bad_options',
          fieldType: 'select',
          label: 'Bad Options',
          options: [
            { value: '', label: 'Empty Value' },  // Invalid
          ],
        })
      ).rejects.toThrow(/option value is required/i);
    });

    it('should reject duplicate option values', async () => {
      await expect(
        customFieldsService.createDefinition(tenantId, adminUserId, {
          entityType: 'clients',
          fieldKey: 'dup_options',
          fieldType: 'select',
          label: 'Dup Options',
          options: [
            { value: 'same', label: 'First' },
            { value: 'same', label: 'Second' },  // Duplicate value
          ],
        })
      ).rejects.toThrow(/duplicate option/i);
    });
  });

  // ============================================================================
  // SETTING VALUES
  // ============================================================================

  describe('Setting Values', () => {
    it('should set a text value', async () => {
      const value = await customFieldsService.setValue(
        tenantId,
        'clients',
        clientId,
        'nickname',
        'Johnny'
      );

      expect(value).toBeDefined();
      expect(value.value_text).toBe('Johnny');
    });

    it('should set a number value', async () => {
      const value = await customFieldsService.setValue(
        tenantId,
        'clients',
        clientId,
        'priority_score',
        85
      );

      expect(value.value_number).toBe(85);
    });

    it('should set a boolean value', async () => {
      const value = await customFieldsService.setValue(
        tenantId,
        'clients',
        clientId,
        'is_vip',
        true
      );

      expect(value.value_boolean).toBe(true);
    });

    it('should set a select value', async () => {
      const value = await customFieldsService.setValue(
        tenantId,
        'clients',
        clientId,
        'client_source',
        'referral'
      );

      expect(value.value_text).toBe('referral');
    });

    it('should set a multi_select value', async () => {
      const value = await customFieldsService.setValue(
        tenantId,
        'clients',
        clientId,
        'interests',
        ['real_estate', 'litigation']
      );

      expect(value.value_json).toEqual(['real_estate', 'litigation']);
    });

    it('should update existing value (upsert)', async () => {
      // Set initial
      await customFieldsService.setValue(tenantId, 'clients', clientId, 'nickname', 'Initial');

      // Update
      const updated = await customFieldsService.setValue(
        tenantId,
        'clients',
        clientId,
        'nickname',
        'Updated'
      );

      expect(updated.value_text).toBe('Updated');
    });

    it('should reject invalid select option', async () => {
      await expect(
        customFieldsService.setValue(
          tenantId,
          'clients',
          clientId,
          'client_source',
          'invalid_option'
        )
      ).rejects.toThrow(/invalid.*option|invalid value/i);
    });

    it('should reject invalid multi_select option', async () => {
      await expect(
        customFieldsService.setValue(
          tenantId,
          'clients',
          clientId,
          'interests',
          ['real_estate', 'invalid_option']
        )
      ).rejects.toThrow(/invalid.*option|invalid value/i);
    });

    it('should reject wrong value type', async () => {
      await expect(
        customFieldsService.setValue(
          tenantId,
          'clients',
          clientId,
          'priority_score',
          'not a number'  // Should be number
        )
      ).rejects.toThrow(/expects a number/i);
    });
  });

  // ============================================================================
  // GETTING VALUES
  // ============================================================================

  describe('Getting Values', () => {
    it('should get all values for entity with definitions', async () => {
      const results = await customFieldsService.getValuesForEntity(
        tenantId,
        'clients',
        clientId
      );

      expect(results.length).toBeGreaterThan(0);
      
      // Check structure
      const nicknameField = results.find(r => r.fieldKey === 'nickname');
      expect(nicknameField).toBeDefined();
      expect(nicknameField!.label).toBe('Nickname');
      expect(nicknameField!.labelHe).toBe('כינוי');
      expect(nicknameField!.value).toBe('Updated');  // From previous test
    });

    it('should return fields in display_order', async () => {
      const results = await customFieldsService.getValuesForEntity(
        tenantId,
        'clients',
        clientId
      );

      // Verify ordering
      for (let i = 1; i < results.length; i++) {
        expect(results[i].displayOrder).toBeGreaterThanOrEqual(results[i - 1].displayOrder);
      }
    });

    it('should return bilingual labels for select options', async () => {
      const results = await customFieldsService.getValuesForEntity(
        tenantId,
        'clients',
        clientId
      );

      const sourceField = results.find(r => r.fieldKey === 'client_source');
      expect(sourceField).toBeDefined();
      expect(sourceField!.options).toBeDefined();
      expect(sourceField!.options![0].label_he).toBeDefined();
    });

    it('should get single value', async () => {
      const value = await customFieldsService.getValue(
        tenantId,
        'clients',
        clientId,
        'nickname'
      );

      expect(value).toBe('Updated');
    });

    it('should return undefined for non-existent field', async () => {
      const value = await customFieldsService.getValue(
        tenantId,
        'clients',
        clientId,
        'non_existent_field'
      );

      expect(value).toBeUndefined();
    });

    it('should include null values for fields without values', async () => {
      const results = await customFieldsService.getValuesForEntity(
        tenantId,
        'clients',
        clientId
      );

      // contract_date was defined but never set
      const dateField = results.find(r => r.fieldKey === 'contract_date');
      expect(dateField).toBeDefined();
      expect(dateField!.value).toBeNull();
    });
  });

  // ============================================================================
  // LISTING DEFINITIONS
  // ============================================================================

  describe('Listing Definitions', () => {
    it('should list all definitions for entity type', async () => {
      const definitions = await customFieldsService.listDefinitions(tenantId, 'clients');

      expect(definitions.length).toBeGreaterThan(0);
      expect(definitions.every(d => d.entity_type === 'clients')).toBe(true);
    });

    it('should order definitions by display_order', async () => {
      const definitions = await customFieldsService.listDefinitions(tenantId, 'clients');

      for (let i = 1; i < definitions.length; i++) {
        expect(definitions[i].display_order).toBeGreaterThanOrEqual(
          definitions[i - 1].display_order
        );
      }
    });

    it('should not include deleted definitions', async () => {
      // Create and delete a definition
      const def = await customFieldsService.createDefinition(tenantId, adminUserId, {
        entityType: 'clients',
        fieldKey: 'to_delete',
        fieldType: 'text',
        label: 'To Delete',
      });

      await customFieldsService.deleteDefinition(tenantId, adminUserId, def.id);

      // List should not include it
      const definitions = await customFieldsService.listDefinitions(tenantId, 'clients');
      expect(definitions.find(d => d.field_key === 'to_delete')).toBeUndefined();
    });
  });

  // ============================================================================
  // UNIQUENESS CONSTRAINTS
  // ============================================================================

  describe('Uniqueness Constraints', () => {
    it('should enforce (tenant_id, entity_type, field_key) uniqueness', async () => {
      // Already tested via duplicate_key test above
      // This verifies at DB level

      const result = await pool.query(
        `SELECT COUNT(*) as count FROM custom_field_definitions
         WHERE tenant_id = $1 AND entity_type = 'clients' AND field_key = 'nickname'`,
        [tenantId]
      );

      expect(parseInt(result.rows[0].count)).toBe(1);
    });

    it('should enforce (tenant_id, definition_id, entity_type, entity_id) uniqueness for values', async () => {
      // Setting the same field twice should update, not create duplicate
      await customFieldsService.setValue(tenantId, 'clients', clientId, 'nickname', 'First');
      await customFieldsService.setValue(tenantId, 'clients', clientId, 'nickname', 'Second');

      const def = await customFieldDefinitionRepository.findByFieldKey(tenantId, 'clients', 'nickname');
      
      const result = await pool.query(
        `SELECT COUNT(*) as count FROM custom_field_values
         WHERE tenant_id = $1 AND definition_id = $2 AND entity_id = $3`,
        [tenantId, def!.id, clientId]
      );

      expect(parseInt(result.rows[0].count)).toBe(1);
    });
  });

  // ============================================================================
  // DB-LEVEL VALIDATION
  // ============================================================================

  describe('DB-Level Validation', () => {
    it('should reject invalid select value at DB level', async () => {
      const def = await customFieldDefinitionRepository.findByFieldKey(
        tenantId,
        'clients',
        'client_source'
      );

      await expect(
        pool.query(
          `INSERT INTO custom_field_values (tenant_id, definition_id, entity_type, entity_id, value_text)
           VALUES ($1, $2, 'clients', $3, 'totally_invalid')`,
          [tenantId, def!.id, clientId]
        )
      ).rejects.toThrow(/invalid option/i);
    });

    it('should reject entity type mismatch at DB level', async () => {
      const def = await customFieldDefinitionRepository.findByFieldKey(
        tenantId,
        'clients',
        'nickname'
      );

      await expect(
        pool.query(
          `INSERT INTO custom_field_values (tenant_id, definition_id, entity_type, entity_id, value_text)
           VALUES ($1, $2, 'cases', $3, 'test')`,  // Wrong entity_type
          [tenantId, def!.id, 'some-case-id']
        )
      ).rejects.toThrow(/entity type mismatch/i);
    });
  });

  // ============================================================================
  // REQUIRED FIELD VALIDATION
  // ============================================================================

  describe('Required Field Validation', () => {
    beforeAll(async () => {
      await customFieldsService.createDefinition(tenantId, adminUserId, {
        entityType: 'clients',
        fieldKey: 'required_field',
        fieldType: 'text',
        label: 'Required Field',
        isRequired: true,
      });
    });

    it('should reject null value for required field', async () => {
      await expect(
        customFieldsService.setValue(
          tenantId,
          'clients',
          clientId,
          'required_field',
          null
        )
      ).rejects.toThrow(/required.*cannot be null/i);
    });

    it('should accept value for required field', async () => {
      const value = await customFieldsService.setValue(
        tenantId,
        'clients',
        clientId,
        'required_field',
        'Valid Value'
      );

      expect(value.value_text).toBe('Valid Value');
    });
  });
});
