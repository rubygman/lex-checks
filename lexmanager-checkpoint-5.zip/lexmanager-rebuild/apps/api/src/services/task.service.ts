// ============================================================================
// TASK SERVICE
// apps/api/src/services/task.service.ts
// 
// Task management with Kanban support
// All methods require appropriate permissions via Authorizer
// ============================================================================

import { taskRepository, type Task } from '../repositories/task.repository.js';
import { authorizer, PERMISSIONS, type RequestContext } from '../auth/authorizer.js';
import { auditService } from './audit.service.js';
import { softDeleteService } from './soft-delete.service.js';

// ============================================================================
// TYPES
// ============================================================================

export interface CreateTaskInput {
  case_id?: string;
  client_id?: string;
  title: string;
  title_he?: string;
  description?: string;
  status?: Task['status'];
  priority?: Task['priority'];
  task_type?: string;
  assigned_to_id?: string;
  due_date?: Date;
  reminder_date?: Date;
  estimated_minutes?: number;
  is_billable?: boolean;
  tags?: string[];
}

export interface UpdateTaskInput {
  title?: string;
  title_he?: string;
  description?: string;
  status?: Task['status'];
  priority?: Task['priority'];
  task_type?: string;
  assigned_to_id?: string;
  due_date?: Date;
  reminder_date?: Date;
  estimated_minutes?: number;
  actual_minutes?: number;
  is_billable?: boolean;
  tags?: string[];
}

export interface TaskListOptions {
  caseId?: string;
  clientId?: string;
  assigneeId?: string;
  status?: Task['status'];
  priority?: Task['priority'];
  search?: string;
  limit?: number;
  offset?: number;
  includeDeleted?: boolean;
}

export interface MoveTaskInput {
  status: Task['status'];
  order?: number;
}

// ============================================================================
// SERVICE
// ============================================================================

export class TaskService {
  async getById(
    context: RequestContext,
    tenantId: string,
    taskId: string
  ): Promise<Task | null> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_VIEW);
    return taskRepository.findById(tenantId, taskId);
  }

  async getByIdOrFail(
    context: RequestContext,
    tenantId: string,
    taskId: string
  ): Promise<Task> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_VIEW);
    return taskRepository.findByIdOrFail(tenantId, taskId);
  }

  async getByIdWithDetails(
    context: RequestContext,
    tenantId: string,
    taskId: string
  ) {
    await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_VIEW);
    return taskRepository.findByIdWithDetails(tenantId, taskId);
  }

  async list(
    context: RequestContext,
    tenantId: string,
    options: TaskListOptions = {}
  ): Promise<{ data: Task[]; pagination: { total: number; limit: number; offset: number; hasMore: boolean } }> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_VIEW);

    const filters = [];
    
    if (options.caseId) {
      filters.push({ field: 'case_id', operator: '=' as const, value: options.caseId });
    }
    if (options.clientId) {
      filters.push({ field: 'client_id', operator: '=' as const, value: options.clientId });
    }
    if (options.assigneeId) {
      filters.push({ field: 'assigned_to_id', operator: '=' as const, value: options.assigneeId });
    }
    if (options.status) {
      filters.push({ field: 'status', operator: '=' as const, value: options.status });
    }
    if (options.priority) {
      filters.push({ field: 'priority', operator: '=' as const, value: options.priority });
    }
    if (options.search) {
      filters.push({ field: 'title', operator: 'ILIKE' as const, value: `%${options.search}%` });
    }

    return taskRepository.list(tenantId, {
      filters,
      pagination: { 
        limit: options.limit ?? 100, 
        offset: options.offset ?? 0 
      },
      sort: { field: 'kanban_order', direction: 'ASC' },
      includeDeleted: options.includeDeleted,
    });
  }

  async getKanbanBoard(
    context: RequestContext,
    tenantId: string,
    options?: { caseId?: string; clientId?: string; assigneeId?: string }
  ): Promise<Record<Task['status'], Task[]>> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_VIEW);

    const statuses: Task['status'][] = ['pending', 'in_progress', 'completed', 'cancelled'];
    const board: Record<Task['status'], Task[]> = {
      pending: [],
      in_progress: [],
      completed: [],
      cancelled: [],
    };

    for (const status of statuses) {
      board[status] = await taskRepository.findByStatus(tenantId, status, options);
    }

    return board;
  }

  async getStatusCounts(
    context: RequestContext,
    tenantId: string,
    options?: { caseId?: string; clientId?: string; assigneeId?: string }
  ): Promise<Record<Task['status'], number>> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_VIEW);
    return taskRepository.getCountsByStatus(tenantId, options);
  }

  async create(
    context: RequestContext,
    tenantId: string,
    input: CreateTaskInput
  ): Promise<Task> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_CREATE);

    const existingTasks = await taskRepository.findByStatus(tenantId, input.status || 'pending');
    const maxOrder = existingTasks.length > 0 
      ? Math.max(...existingTasks.map(t => t.kanban_order)) + 1 
      : 0;

    const task = await taskRepository.create(tenantId, {
      case_id: input.case_id || null,
      client_id: input.client_id || null,
      title: input.title,
      title_he: input.title_he || null,
      description: input.description || null,
      status: input.status || 'pending',
      priority: input.priority || 'medium',
      task_type: input.task_type || null,
      assigned_to_id: input.assigned_to_id || null,
      due_date: input.due_date || null,
      reminder_date: input.reminder_date || null,
      completed_at: null,
      completed_by: null,
      estimated_minutes: input.estimated_minutes || null,
      actual_minutes: null,
      is_billable: input.is_billable ?? false,
      kanban_order: maxOrder,
      tags: input.tags || null,
      created_by: auth.userId,
    });

    await auditService.logCreate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'tasks',
      task.id,
      task as unknown as Record<string, unknown>
    );

    return task;
  }

  async update(
    context: RequestContext,
    tenantId: string,
    taskId: string,
    input: UpdateTaskInput
  ): Promise<Task> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_EDIT);

    const existing = await taskRepository.findByIdOrFail(tenantId, taskId);
    const updated = await taskRepository.update(tenantId, taskId, input as any);

    await auditService.logUpdate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'tasks',
      taskId,
      existing as unknown as Record<string, unknown>,
      updated as unknown as Record<string, unknown>
    );

    return updated;
  }

  async move(
    context: RequestContext,
    tenantId: string,
    taskId: string,
    input: MoveTaskInput
  ): Promise<Task> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_EDIT);

    const existing = await taskRepository.findByIdOrFail(tenantId, taskId);
    const newOrder = input.order ?? 0;
    const task = await taskRepository.moveTask(tenantId, taskId, input.status, newOrder);

    await auditService.logUpdate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'tasks',
      taskId,
      { status: existing.status, kanban_order: existing.kanban_order },
      { status: task.status, kanban_order: task.kanban_order }
    );

    return task;
  }

  async markCompleted(
    context: RequestContext,
    tenantId: string,
    taskId: string
  ): Promise<Task> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_EDIT);

    const existing = await taskRepository.findByIdOrFail(tenantId, taskId);
    const task = await taskRepository.markCompleted(tenantId, taskId, auth.userId);

    await auditService.logUpdate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'tasks',
      taskId,
      { status: existing.status, completed_at: null },
      { status: 'completed', completed_at: task.completed_at }
    );

    return task;
  }

  async delete(
    context: RequestContext,
    tenantId: string,
    taskId: string
  ): Promise<void> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_DELETE);

    const task = await taskRepository.findByIdOrFail(tenantId, taskId);

    await softDeleteService.softDelete(tenantId, 'tasks', taskId, {
      deletedBy: auth.userId,
    });

    await auditService.logDelete(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'tasks',
      taskId,
      task as unknown as Record<string, unknown>
    );
  }

  async restore(
    context: RequestContext,
    tenantId: string,
    taskId: string
  ): Promise<void> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_DELETE);

    await softDeleteService.restore(tenantId, 'tasks', taskId);

    await auditService.logRestore(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'tasks',
      taskId
    );
  }

  async getOverdueTasks(
    context: RequestContext,
    tenantId: string,
    options?: { limit?: number; assigneeId?: string }
  ): Promise<Task[]> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_VIEW);
    return taskRepository.findOverdue(tenantId, options);
  }

  async getTasksDueSoon(
    context: RequestContext,
    tenantId: string,
    daysAhead: number = 7,
    options?: { assigneeId?: string }
  ): Promise<Task[]> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.TASKS_VIEW);
    return taskRepository.findDueSoon(tenantId, daysAhead, options);
  }
}

export const taskService = new TaskService();
