// ============================================================================
// DOCUMENT ROUTES
// apps/api/src/routes/document.routes.ts
// 
// Document metadata CRUD + restore with RBAC and audit
// Upload/download stubs included
// ============================================================================

import { Router } from 'express';
import { documentService } from '../services/document.service.js';
import {
  initializeContext,
  resolveTenantFromHeader,
  requireTenant,
  authParser,
  requireAuth,
  requireTenantAccess,
  requirePermission,
} from '../middleware/index.js';
import {
  validate,
  validateAll,
  createDocumentSchema,
  updateDocumentSchema,
  documentQuerySchema,
  idParamSchema,
} from '../validation/index.js';
import { asyncHandler, sendSuccess, NotFoundError } from '../errors/index.js';
import { PERMISSIONS } from '../services/rbac.service.js';

const router = Router();

// All routes require tenant context and authentication
router.use(initializeContext());
router.use(resolveTenantFromHeader());
router.use(requireTenant());
router.use(authParser());
router.use(requireAuth());
router.use(requireTenantAccess());

// ============================================================================
// GET /documents - List documents
// ============================================================================

router.get(
  '/',
  requirePermission(PERMISSIONS.DOCUMENTS_VIEW),
  validate(documentQuerySchema, 'query'),
  asyncHandler(async (req, res) => {
    const { page, limit, q, documentType, caseId, clientId } = req.query as any;

    const result = await documentService.list(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      {
        search: q,
        documentType,
        caseId,
        clientId,
        limit,
        offset: (page - 1) * limit,
      }
    );

    sendSuccess(res, req, result.data, 200, {
      page,
      limit,
      total: result.pagination.total,
      hasMore: result.pagination.hasMore,
    });
  })
);

// ============================================================================
// POST /documents - Create document metadata (upload stub)
// ============================================================================

router.post(
  '/',
  requirePermission(PERMISSIONS.DOCUMENTS_CREATE),
  validate(createDocumentSchema, 'body'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const document = await documentService.create(
      context,
      req.auth!.tenantId,
      {
        case_id: req.body.caseId,
        client_id: req.body.clientId,
        title: req.body.title,
        description: req.body.description,
        document_type: req.body.documentType || 'other',
        file_name: req.body.fileName,
        file_size: req.body.fileSize,
        mime_type: req.body.mimeType,
        storage_path: req.body.storagePath,
      }
    );

    sendSuccess(res, req, document, 201);
  })
);

// ============================================================================
// GET /documents/:id - Get document by ID
// ============================================================================

router.get(
  '/:id',
  requirePermission(PERMISSIONS.DOCUMENTS_VIEW),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const document = await documentService.getByIdOrFail(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, document);
  })
);

// ============================================================================
// GET /documents/:id/download - Download document (stub)
// ============================================================================

router.get(
  '/:id/download',
  requirePermission(PERMISSIONS.DOCUMENTS_VIEW),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    // Stub: In production, this would stream the file
    const document = await documentService.getByIdOrFail(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, {
      message: 'Download endpoint stub',
      document: {
        id: document.id,
        fileName: document.file_name,
        storagePath: document.storage_path,
      },
    });
  })
);

// ============================================================================
// PATCH /documents/:id - Update document metadata
// ============================================================================

router.patch(
  '/:id',
  requirePermission(PERMISSIONS.DOCUMENTS_EDIT),
  validateAll({
    params: idParamSchema,
    body: updateDocumentSchema,
  }),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const document = await documentService.update(
      context,
      req.auth!.tenantId,
      req.params.id,
      {
        title: req.body.title,
        description: req.body.description,
        document_type: req.body.documentType,
      }
    );

    sendSuccess(res, req, document);
  })
);

// ============================================================================
// DELETE /documents/:id - Soft delete document
// ============================================================================

router.delete(
  '/:id',
  requirePermission(PERMISSIONS.DOCUMENTS_DELETE),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    await documentService.delete(
      context,
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, { message: 'Document deleted successfully' });
  })
);

// ============================================================================
// POST /documents/:id/restore - Restore soft-deleted document
// ============================================================================

router.post(
  '/:id/restore',
  requirePermission(PERMISSIONS.DOCUMENTS_DELETE),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    await documentService.restore(
      context,
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, { message: 'Document restored successfully' });
  })
);

export default router;
