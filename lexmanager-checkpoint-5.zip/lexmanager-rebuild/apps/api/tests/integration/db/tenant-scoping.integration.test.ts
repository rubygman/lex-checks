// ============================================================================
// DATABASE LAYER INTEGRATION TESTS
// apps/api/tests/integration/db/tenant-scoping.integration.test.ts
// 
// These tests require a running PostgreSQL instance.
// Run with: pnpm test:integration
// ============================================================================

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import { pool, query, withTransaction } from '../../../src/db/connection.js';
import { ClientRepository } from '../../../src/repositories/index.js';
import { TenantScopingError } from '../../../src/db/errors.js';

// Skip if no database connection
const DATABASE_URL = process.env.DATABASE_URL;
const shouldRun = DATABASE_URL && DATABASE_URL.includes('localhost');

describe.skipIf(!shouldRun)('Database Integration: Tenant Scoping', () => {
  let tenantId1: string;
  let tenantId2: string;
  let clientRepo: ClientRepository;

  beforeAll(async () => {
    clientRepo = new ClientRepository();

    // Create two test tenants
    const tenant1Result = await query<{ id: string }>(
      `INSERT INTO tenants (name, slug) VALUES ($1, $2) RETURNING id`,
      ['Test Tenant 1', 'test-tenant-1-' + Date.now()]
    );
    tenantId1 = tenant1Result.rows[0]!.id;

    const tenant2Result = await query<{ id: string }>(
      `INSERT INTO tenants (name, slug) VALUES ($1, $2) RETURNING id`,
      ['Test Tenant 2', 'test-tenant-2-' + Date.now()]
    );
    tenantId2 = tenant2Result.rows[0]!.id;
  });

  afterAll(async () => {
    // Cleanup test tenants (cascade deletes related records)
    await query('DELETE FROM tenants WHERE id IN ($1, $2)', [tenantId1, tenantId2]);
    await pool.end();
  });

  beforeEach(async () => {
    // Clean up clients between tests
    await query('DELETE FROM clients WHERE tenant_id IN ($1, $2)', [tenantId1, tenantId2]);
  });

  describe('Tenant Isolation', () => {
    it('should only return records belonging to the specified tenant', async () => {
      // Create clients in both tenants
      await clientRepo.create(tenantId1, {
        name: 'Client A - Tenant 1',
        client_type: 'individual',
        status: 'active',
        address_country: 'Israel',
        currency: 'ILS',
        payment_terms: 30,
      } as any);

      await clientRepo.create(tenantId2, {
        name: 'Client B - Tenant 2',
        client_type: 'individual',
        status: 'active',
        address_country: 'Israel',
        currency: 'ILS',
        payment_terms: 30,
      } as any);

      // Query tenant 1 - should only see tenant 1's client
      const tenant1Clients = await clientRepo.list(tenantId1);
      expect(tenant1Clients.data).toHaveLength(1);
      expect(tenant1Clients.data[0]!.name).toBe('Client A - Tenant 1');

      // Query tenant 2 - should only see tenant 2's client
      const tenant2Clients = await clientRepo.list(tenantId2);
      expect(tenant2Clients.data).toHaveLength(1);
      expect(tenant2Clients.data[0]!.name).toBe('Client B - Tenant 2');
    });

    it('should not allow updating records from another tenant', async () => {
      // Create a client in tenant 1
      const client = await clientRepo.create(tenantId1, {
        name: 'Original Name',
        client_type: 'individual',
        status: 'active',
        address_country: 'Israel',
        currency: 'ILS',
        payment_terms: 30,
      } as any);

      // Try to update using tenant 2's ID - should not find the record
      await expect(
        clientRepo.update(tenantId2, client.id, { name: 'Hacked Name' })
      ).rejects.toThrow(); // NotFoundError because tenant_id doesn't match

      // Verify original is unchanged
      const original = await clientRepo.findById(tenantId1, client.id);
      expect(original!.name).toBe('Original Name');
    });

    it('should not allow deleting records from another tenant', async () => {
      // Create a client in tenant 1
      const client = await clientRepo.create(tenantId1, {
        name: 'Should Not Delete',
        client_type: 'individual',
        status: 'active',
        address_country: 'Israel',
        currency: 'ILS',
        payment_terms: 30,
      } as any);

      // Try to delete using tenant 2's ID
      await expect(
        clientRepo.softDelete(tenantId2, client.id)
      ).rejects.toThrow(); // NotFoundError

      // Verify record still exists
      const stillExists = await clientRepo.findById(tenantId1, client.id);
      expect(stillExists).not.toBeNull();
    });
  });

  describe('Soft Delete Filtering', () => {
    it('should not return soft-deleted records by default', async () => {
      // Create and soft-delete a client
      const client = await clientRepo.create(tenantId1, {
        name: 'To Be Deleted',
        client_type: 'individual',
        status: 'active',
        address_country: 'Israel',
        currency: 'ILS',
        payment_terms: 30,
      } as any);

      await clientRepo.softDelete(tenantId1, client.id);

      // Should not appear in list
      const clients = await clientRepo.list(tenantId1);
      expect(clients.data.find(c => c.id === client.id)).toBeUndefined();

      // Should not be found by ID
      const notFound = await clientRepo.findById(tenantId1, client.id);
      expect(notFound).toBeNull();
    });

    it('should return soft-deleted records when includeDeleted is true', async () => {
      // Create and soft-delete a client
      const client = await clientRepo.create(tenantId1, {
        name: 'Deleted But Visible',
        client_type: 'individual',
        status: 'active',
        address_country: 'Israel',
        currency: 'ILS',
        payment_terms: 30,
      } as any);

      await clientRepo.softDelete(tenantId1, client.id);

      // Should be found with includeDeleted
      const found = await clientRepo.findById(tenantId1, client.id, { includeDeleted: true });
      expect(found).not.toBeNull();
      expect(found!.deleted_at).not.toBeNull();
    });

    it('should be able to restore soft-deleted records', async () => {
      // Create and soft-delete a client
      const client = await clientRepo.create(tenantId1, {
        name: 'To Be Restored',
        client_type: 'individual',
        status: 'active',
        address_country: 'Israel',
        currency: 'ILS',
        payment_terms: 30,
      } as any);

      await clientRepo.softDelete(tenantId1, client.id);

      // Restore it
      const restored = await clientRepo.restore(tenantId1, client.id);
      expect(restored.deleted_at).toBeNull();

      // Should now appear in normal queries
      const found = await clientRepo.findById(tenantId1, client.id);
      expect(found).not.toBeNull();
    });
  });

  describe('Count with Tenant Scoping', () => {
    it('should count only records belonging to the tenant', async () => {
      // Create clients in both tenants
      await clientRepo.create(tenantId1, {
        name: 'T1 Client 1',
        client_type: 'individual',
        status: 'active',
        address_country: 'Israel',
        currency: 'ILS',
        payment_terms: 30,
      } as any);

      await clientRepo.create(tenantId1, {
        name: 'T1 Client 2',
        client_type: 'individual',
        status: 'active',
        address_country: 'Israel',
        currency: 'ILS',
        payment_terms: 30,
      } as any);

      await clientRepo.create(tenantId2, {
        name: 'T2 Client 1',
        client_type: 'individual',
        status: 'active',
        address_country: 'Israel',
        currency: 'ILS',
        payment_terms: 30,
      } as any);

      // Count should be tenant-specific
      const count1 = await clientRepo.count(tenantId1);
      expect(count1).toBe(2);

      const count2 = await clientRepo.count(tenantId2);
      expect(count2).toBe(1);
    });

    it('should not count soft-deleted records', async () => {
      // Create two clients
      const client1 = await clientRepo.create(tenantId1, {
        name: 'Active Client',
        client_type: 'individual',
        status: 'active',
        address_country: 'Israel',
        currency: 'ILS',
        payment_terms: 30,
      } as any);

      const client2 = await clientRepo.create(tenantId1, {
        name: 'Deleted Client',
        client_type: 'individual',
        status: 'active',
        address_country: 'Israel',
        currency: 'ILS',
        payment_terms: 30,
      } as any);

      await clientRepo.softDelete(tenantId1, client2.id);

      const count = await clientRepo.count(tenantId1);
      expect(count).toBe(1);
    });
  });
});
