-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 003: Soft Delete Enhancements - DOWN
-- ============================================================================

BEGIN;

-- Drop views
DROP VIEW IF EXISTS soft_delete_stats;
DROP VIEW IF EXISTS soft_deleted_records;

-- Drop functions
DROP FUNCTION IF EXISTS get_soft_deleted_records(UUID, TEXT, INTEGER, INTEGER);
DROP FUNCTION IF EXISTS get_records_for_hard_deletion(INTEGER);
DROP FUNCTION IF EXISTS untrack_soft_delete(TEXT, UUID);
DROP FUNCTION IF EXISTS track_soft_delete(UUID, TEXT, UUID, UUID, BOOLEAN, INTEGER, JSONB);

-- Drop table
DROP TABLE IF EXISTS soft_delete_retention;

COMMIT;
