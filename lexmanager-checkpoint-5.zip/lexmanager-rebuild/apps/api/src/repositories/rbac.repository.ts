// ============================================================================
// ROLE & PERMISSION REPOSITORIES
// apps/api/src/repositories/rbac.repository.ts
// ============================================================================

import { query } from '../db/connection.js';
import { parsePostgresError, NotFoundError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export interface Role {
  id: string;
  name: string;
  name_he: string;
  description: string | null;
  is_system: boolean;
  created_at: Date;
}

export interface Permission {
  id: string;
  code: string;
  category: string;
  description: string | null;
  created_at: Date;
}

export interface RolePermission {
  role_id: string;
  permission_id: string;
  created_at: Date;
}

export interface RoleWithPermissions extends Role {
  permissions: Permission[];
}

// ============================================================================
// ROLE REPOSITORY (Global - not tenant-scoped)
// ============================================================================

export class RoleRepository {
  private readonly tableName = 'roles';

  /**
   * Find role by ID
   */
  async findById(id: string): Promise<Role | null> {
    try {
      const result = await query<Role>(
        `SELECT * FROM ${this.tableName} WHERE id = $1`,
        [id]
      );
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find role by ID, throw if not found
   */
  async findByIdOrFail(id: string): Promise<Role> {
    const role = await this.findById(id);
    if (!role) {
      throw new NotFoundError('Role', id);
    }
    return role;
  }

  /**
   * Find role by name
   */
  async findByName(name: string): Promise<Role | null> {
    try {
      const result = await query<Role>(
        `SELECT * FROM ${this.tableName} WHERE name = $1`,
        [name]
      );
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * List all roles
   */
  async listAll(): Promise<Role[]> {
    try {
      const result = await query<Role>(
        `SELECT * FROM ${this.tableName} ORDER BY name ASC`
      );
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get role with all its permissions
   */
  async findByIdWithPermissions(id: string): Promise<RoleWithPermissions | null> {
    try {
      const roleResult = await query<Role>(
        `SELECT * FROM ${this.tableName} WHERE id = $1`,
        [id]
      );

      if (roleResult.rows.length === 0) {
        return null;
      }

      const role = roleResult.rows[0]!;

      const permissionsResult = await query<Permission>(
        `SELECT p.* FROM permissions p
         JOIN role_permissions rp ON p.id = rp.permission_id
         WHERE rp.role_id = $1
         ORDER BY p.category, p.code`,
        [id]
      );

      return {
        ...role,
        permissions: permissionsResult.rows,
      };
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get role by name with permissions
   */
  async findByNameWithPermissions(name: string): Promise<RoleWithPermissions | null> {
    const role = await this.findByName(name);
    if (!role) return null;
    return this.findByIdWithPermissions(role.id);
  }
}

// ============================================================================
// PERMISSION REPOSITORY (Global - not tenant-scoped)
// ============================================================================

export class PermissionRepository {
  private readonly tableName = 'permissions';

  /**
   * Find permission by ID
   */
  async findById(id: string): Promise<Permission | null> {
    try {
      const result = await query<Permission>(
        `SELECT * FROM ${this.tableName} WHERE id = $1`,
        [id]
      );
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find permission by code
   */
  async findByCode(code: string): Promise<Permission | null> {
    try {
      const result = await query<Permission>(
        `SELECT * FROM ${this.tableName} WHERE code = $1`,
        [code]
      );
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * List all permissions
   */
  async listAll(): Promise<Permission[]> {
    try {
      const result = await query<Permission>(
        `SELECT * FROM ${this.tableName} ORDER BY category, code`
      );
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * List permissions by category
   */
  async listByCategory(category: string): Promise<Permission[]> {
    try {
      const result = await query<Permission>(
        `SELECT * FROM ${this.tableName} WHERE category = $1 ORDER BY code`,
        [category]
      );
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get permission codes for a role
   */
  async getCodesForRole(roleId: string): Promise<string[]> {
    try {
      const result = await query<{ code: string }>(
        `SELECT p.code FROM permissions p
         JOIN role_permissions rp ON p.id = rp.permission_id
         WHERE rp.role_id = $1`,
        [roleId]
      );
      return result.rows.map(r => r.code);
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Check if role has permission
   */
  async roleHasPermission(roleId: string, permissionCode: string): Promise<boolean> {
    try {
      const result = await query<{ exists: boolean }>(
        `SELECT EXISTS (
          SELECT 1 FROM permissions p
          JOIN role_permissions rp ON p.id = rp.permission_id
          WHERE rp.role_id = $1 AND p.code = $2
        ) as exists`,
        [roleId, permissionCode]
      );
      return result.rows[0]?.exists || false;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get all categories
   */
  async listCategories(): Promise<string[]> {
    try {
      const result = await query<{ category: string }>(
        `SELECT DISTINCT category FROM ${this.tableName} ORDER BY category`
      );
      return result.rows.map(r => r.category);
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}

// ============================================================================
// ROLE_PERMISSIONS REPOSITORY
// ============================================================================

export class RolePermissionRepository {
  private readonly tableName = 'role_permissions';

  /**
   * Add permission to role
   */
  async addPermissionToRole(roleId: string, permissionId: string): Promise<void> {
    try {
      await query(
        `INSERT INTO ${this.tableName} (role_id, permission_id)
         VALUES ($1, $2)
         ON CONFLICT (role_id, permission_id) DO NOTHING`,
        [roleId, permissionId]
      );
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Remove permission from role
   */
  async removePermissionFromRole(roleId: string, permissionId: string): Promise<void> {
    try {
      await query(
        `DELETE FROM ${this.tableName}
         WHERE role_id = $1 AND permission_id = $2`,
        [roleId, permissionId]
      );
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Set permissions for role (replace all)
   */
  async setPermissionsForRole(roleId: string, permissionIds: string[]): Promise<void> {
    try {
      // Delete existing
      await query(
        `DELETE FROM ${this.tableName} WHERE role_id = $1`,
        [roleId]
      );

      // Insert new
      if (permissionIds.length > 0) {
        const values = permissionIds.map((_, i) => `($1, $${i + 2})`).join(', ');
        await query(
          `INSERT INTO ${this.tableName} (role_id, permission_id) VALUES ${values}`,
          [roleId, ...permissionIds]
        );
      }
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get all permission IDs for a role
   */
  async getPermissionIdsForRole(roleId: string): Promise<string[]> {
    try {
      const result = await query<{ permission_id: string }>(
        `SELECT permission_id FROM ${this.tableName} WHERE role_id = $1`,
        [roleId]
      );
      return result.rows.map(r => r.permission_id);
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}

// ============================================================================
// EXPORTS
// ============================================================================

export const roleRepository = new RoleRepository();
export const permissionRepository = new PermissionRepository();
export const rolePermissionRepository = new RolePermissionRepository();
