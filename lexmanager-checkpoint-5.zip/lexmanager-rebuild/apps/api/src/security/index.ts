// ============================================================================
// SECURITY MODULE INDEX
// apps/api/src/security/index.ts
// ============================================================================

// Password hashing
export {
  hashPassword,
  verifyPassword,
  needsRehash,
  validatePasswordStrength,
  type PasswordStrengthResult,
} from './password.js';

// JWT Authentication
export {
  generateAccessToken,
  generateRefreshToken,
  generateTokenPair,
  verifyAccessToken,
  rotateRefreshToken,
  revokeToken,
  revokeTokenFamily,
  revokeAllUserTokens,
  cleanupExpiredTokens,
  type TokenPayload,
  type TokenPair,
  type DecodedToken,
} from './jwt.js';

// Field-level encryption
export {
  encryptField,
  decryptField,
  isEncrypted,
  encryptSensitiveFields,
  decryptSensitiveFields,
  hashForSearch,
  SENSITIVE_FIELDS,
  type FieldEncryptionService,
} from './encryption.js';

// Security middleware
export {
  createHelmetMiddleware,
  createGlobalRateLimiter,
  createLoginRateLimiter,
  createSensitiveRateLimiter,
  correlationIdMiddleware,
  enforceHttpsMiddleware,
  applySecurityMiddleware,
  getSecureCookieOptions,
  setSecureCookie,
  clearSecureCookie,
  type CookieOptions,
} from './middleware.js';

// Secure logger
export {
  SecureLogger,
  getLogger,
  logger,
  type LogLevel,
  type LogContext,
} from './logger.js';
