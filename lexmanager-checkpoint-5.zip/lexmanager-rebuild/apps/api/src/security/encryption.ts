// ============================================================================
// FIELD-LEVEL ENCRYPTION
// apps/api/src/security/encryption.ts
// 
// Envelope encryption for sensitive fields (KMS-ready design)
// ============================================================================

import crypto from 'crypto';
import { getConfig } from '../config/index.js';

// ============================================================================
// CONSTANTS
// ============================================================================

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12;        // 96 bits for GCM
const AUTH_TAG_LENGTH = 16;  // 128 bits
const KEY_LENGTH = 32;       // 256 bits

// ============================================================================
// TYPES
// ============================================================================

interface EncryptedData {
  v: number;           // Version for future-proofing
  kid: string;         // Key ID for key rotation
  iv: string;          // Initialization vector (base64)
  ct: string;          // Ciphertext (base64)
  tag: string;         // Authentication tag (base64)
}

interface KMSProvider {
  encrypt(plaintext: Buffer): Promise<Buffer>;
  decrypt(ciphertext: Buffer): Promise<Buffer>;
  generateDataKey(): Promise<{ plaintext: Buffer; encrypted: Buffer }>;
}

// ============================================================================
// KEY DERIVATION
// In production, replace with actual KMS calls
// ============================================================================

/**
 * Derive a key-specific encryption key from master key
 * Uses HKDF for key derivation
 */
function deriveKey(masterKey: string, keyId: string, context: string): Buffer {
  const salt = crypto.createHash('sha256').update(keyId).digest();
  const info = Buffer.from(context, 'utf8');
  
  return crypto.hkdfSync(
    'sha256',
    Buffer.from(masterKey, 'utf8'),
    salt,
    info,
    KEY_LENGTH
  );
}

/**
 * Get the current data encryption key
 */
function getDataEncryptionKey(context: string = 'field-encryption'): Buffer {
  const config = getConfig();
  return deriveKey(config.encryption.masterKey, config.encryption.keyId, context);
}

// ============================================================================
// ENCRYPTION FUNCTIONS
// ============================================================================

/**
 * Encrypt a string value
 * Returns a JSON string containing all encryption metadata
 */
export function encryptField(plaintext: string): string {
  if (!plaintext) return plaintext;
  
  const config = getConfig();
  const key = getDataEncryptionKey();
  const iv = crypto.randomBytes(IV_LENGTH);
  
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv, {
    authTagLength: AUTH_TAG_LENGTH,
  });
  
  const encrypted = Buffer.concat([
    cipher.update(plaintext, 'utf8'),
    cipher.final(),
  ]);
  
  const authTag = cipher.getAuthTag();
  
  const encryptedData: EncryptedData = {
    v: 1,
    kid: config.encryption.keyId,
    iv: iv.toString('base64'),
    ct: encrypted.toString('base64'),
    tag: authTag.toString('base64'),
  };
  
  return JSON.stringify(encryptedData);
}

/**
 * Decrypt an encrypted string value
 */
export function decryptField(encrypted: string): string {
  if (!encrypted) return encrypted;
  
  // Check if it looks like encrypted data
  if (!encrypted.startsWith('{')) {
    // Not encrypted, return as-is (for backward compatibility)
    return encrypted;
  }
  
  let encryptedData: EncryptedData;
  try {
    encryptedData = JSON.parse(encrypted);
  } catch {
    // Not valid JSON, return as-is
    return encrypted;
  }
  
  // Validate version
  if (encryptedData.v !== 1) {
    throw new Error(`Unsupported encryption version: ${encryptedData.v}`);
  }
  
  // Get the appropriate key based on key ID
  // In production, this would support key rotation
  const key = getDataEncryptionKey();
  
  const iv = Buffer.from(encryptedData.iv, 'base64');
  const ciphertext = Buffer.from(encryptedData.ct, 'base64');
  const authTag = Buffer.from(encryptedData.tag, 'base64');
  
  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv, {
    authTagLength: AUTH_TAG_LENGTH,
  });
  
  decipher.setAuthTag(authTag);
  
  const decrypted = Buffer.concat([
    decipher.update(ciphertext),
    decipher.final(),
  ]);
  
  return decrypted.toString('utf8');
}

/**
 * Check if a value is encrypted
 */
export function isEncrypted(value: string): boolean {
  if (!value || !value.startsWith('{')) return false;
  
  try {
    const parsed = JSON.parse(value);
    return parsed.v && parsed.kid && parsed.iv && parsed.ct && parsed.tag;
  } catch {
    return false;
  }
}

// ============================================================================
// SENSITIVE FIELD HELPERS
// ============================================================================

/**
 * Fields that should be encrypted at rest
 */
export const SENSITIVE_FIELDS = [
  'tax_id',            // Israeli ID / Teudat Zehut
  'id_number',         // Alternative field name
  'social_security',   // SSN equivalent
  'passport_number',
  'bank_account',
  'credit_card',
  'health_info',
];

/**
 * Encrypt sensitive fields in an object
 */
export function encryptSensitiveFields<T extends Record<string, unknown>>(
  data: T,
  additionalFields: string[] = []
): T {
  const fieldsToEncrypt = [...SENSITIVE_FIELDS, ...additionalFields];
  const result = { ...data };
  
  for (const field of fieldsToEncrypt) {
    if (field in result && typeof result[field] === 'string' && result[field]) {
      (result as Record<string, unknown>)[field] = encryptField(result[field] as string);
    }
  }
  
  return result;
}

/**
 * Decrypt sensitive fields in an object
 */
export function decryptSensitiveFields<T extends Record<string, unknown>>(
  data: T,
  additionalFields: string[] = []
): T {
  const fieldsToDecrypt = [...SENSITIVE_FIELDS, ...additionalFields];
  const result = { ...data };
  
  for (const field of fieldsToDecrypt) {
    if (field in result && typeof result[field] === 'string' && result[field]) {
      (result as Record<string, unknown>)[field] = decryptField(result[field] as string);
    }
  }
  
  return result;
}

// ============================================================================
// HASHING FOR SEARCHABLE ENCRYPTED FIELDS
// ============================================================================

/**
 * Create a searchable hash of a value
 * Use this when you need to search on encrypted fields
 */
export function hashForSearch(value: string): string {
  const config = getConfig();
  const key = deriveKey(config.encryption.masterKey, config.encryption.keyId, 'search-hash');
  
  return crypto
    .createHmac('sha256', key)
    .update(value.toLowerCase().trim())
    .digest('hex');
}

// ============================================================================
// KMS INTEGRATION INTERFACE
// Implement this interface for production KMS integration
// ============================================================================

export interface FieldEncryptionService {
  encrypt(plaintext: string): Promise<string>;
  decrypt(ciphertext: string): Promise<string>;
  rotateKey(): Promise<void>;
}

/**
 * Create a KMS-backed encryption service
 * For AWS KMS, Google Cloud KMS, Azure Key Vault, etc.
 */
export function createKMSEncryptionService(kms: KMSProvider): FieldEncryptionService {
  return {
    async encrypt(plaintext: string): Promise<string> {
      // Generate a data key from KMS
      const { plaintext: dataKey, encrypted: encryptedDataKey } = await kms.generateDataKey();
      
      // Encrypt the data with the data key
      const iv = crypto.randomBytes(IV_LENGTH);
      const cipher = crypto.createCipheriv(ALGORITHM, dataKey, iv, {
        authTagLength: AUTH_TAG_LENGTH,
      });
      
      const encrypted = Buffer.concat([
        cipher.update(plaintext, 'utf8'),
        cipher.final(),
      ]);
      
      const authTag = cipher.getAuthTag();
      
      // Return envelope-encrypted data
      const envelope = {
        v: 2,  // Version 2 = KMS envelope encryption
        edk: encryptedDataKey.toString('base64'),  // Encrypted data key
        iv: iv.toString('base64'),
        ct: encrypted.toString('base64'),
        tag: authTag.toString('base64'),
      };
      
      return JSON.stringify(envelope);
    },
    
    async decrypt(ciphertext: string): Promise<string> {
      const envelope = JSON.parse(ciphertext);
      
      if (envelope.v !== 2) {
        throw new Error('Invalid envelope version');
      }
      
      // Decrypt the data key using KMS
      const encryptedDataKey = Buffer.from(envelope.edk, 'base64');
      const dataKey = await kms.decrypt(encryptedDataKey);
      
      // Decrypt the data
      const iv = Buffer.from(envelope.iv, 'base64');
      const ct = Buffer.from(envelope.ct, 'base64');
      const tag = Buffer.from(envelope.tag, 'base64');
      
      const decipher = crypto.createDecipheriv(ALGORITHM, dataKey, iv, {
        authTagLength: AUTH_TAG_LENGTH,
      });
      
      decipher.setAuthTag(tag);
      
      const decrypted = Buffer.concat([
        decipher.update(ct),
        decipher.final(),
      ]);
      
      return decrypted.toString('utf8');
    },
    
    async rotateKey(): Promise<void> {
      // KMS handles key rotation automatically
      // This method triggers re-encryption of data with new key
      throw new Error('Key rotation should be implemented based on your KMS provider');
    },
  };
}
