// ============================================================================
// DOCUMENT SERVICE
// apps/api/src/services/document.service.ts
// 
// All methods require appropriate permissions via Authorizer
// ============================================================================

import { documentRepository, type Document } from '../repositories/index.js';
import { authorizer, PERMISSIONS, type RequestContext } from '../auth/authorizer.js';
import { auditService } from './audit.service.js';
import { softDeleteService } from './soft-delete.service.js';
import { validateCaseTenant, validateClientTenant, validateUserTenant } from '../utils/tenant-validation.js';

// ============================================================================
// TYPES
// ============================================================================

export interface UploadDocumentInput {
  title: string;
  filename: string;
  mime_type: string;
  size_bytes: number;
  storage_key: string;
  case_id?: string;
  client_id?: string;
  category?: string;
  description?: string;
  tags?: string[];
}

export interface UpdateDocumentInput {
  title?: string;
  category?: string;
  description?: string;
  tags?: string[];
  is_privileged?: boolean;
  is_confidential?: boolean;
}

export interface DocumentListOptions {
  caseId?: string;
  clientId?: string;
  category?: string;
  mimeType?: string;
  search?: string;
  limit?: number;
  offset?: number;
  includeDeleted?: boolean;
}

// ============================================================================
// SERVICE
// ============================================================================

export class DocumentService {
  // ==========================================================================
  // VIEW OPERATIONS
  // ==========================================================================

  /**
   * Get document by ID
   * Requires: docs_view
   */
  async getById(
    context: RequestContext,
    tenantId: string,
    documentId: string
  ): Promise<Document | null> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.DOCS_VIEW);
    return documentRepository.findById(tenantId, documentId);
  }

  /**
   * Get document by ID or throw
   * Requires: docs_view
   */
  async getByIdOrFail(
    context: RequestContext,
    tenantId: string,
    documentId: string
  ): Promise<Document> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.DOCS_VIEW);
    return documentRepository.findByIdOrFail(tenantId, documentId);
  }

  /**
   * List documents
   * Requires: docs_view
   */
  async list(
    context: RequestContext,
    tenantId: string,
    options: DocumentListOptions = {}
  ): Promise<{ data: Document[]; pagination: { total: number; limit: number; offset: number; hasMore: boolean } }> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.DOCS_VIEW);

    const filters = [];
    
    if (options.caseId) {
      filters.push({ field: 'case_id', operator: '=' as const, value: options.caseId });
    }
    if (options.clientId) {
      filters.push({ field: 'client_id', operator: '=' as const, value: options.clientId });
    }
    if (options.category) {
      filters.push({ field: 'category', operator: '=' as const, value: options.category });
    }
    if (options.mimeType) {
      filters.push({ field: 'mime_type', operator: '=' as const, value: options.mimeType });
    }
    if (options.search) {
      filters.push({ field: 'title', operator: 'ILIKE' as const, value: `%${options.search}%` });
    }

    return documentRepository.list(tenantId, {
      filters,
      pagination: { 
        limit: options.limit ?? 100, 
        offset: options.offset ?? 0 
      },
      includeDeleted: options.includeDeleted,
    });
  }

  /**
   * List documents for a case
   * Requires: docs_view
   */
  async listByCase(
    context: RequestContext,
    tenantId: string,
    caseId: string,
    options: { limit?: number; offset?: number } = {}
  ): Promise<Document[]> {
    const result = await this.list(context, tenantId, {
      caseId,
      ...options,
    });
    return result.data;
  }

  /**
   * List documents for a client
   * Requires: docs_view
   */
  async listByClient(
    context: RequestContext,
    tenantId: string,
    clientId: string,
    options: { limit?: number; offset?: number } = {}
  ): Promise<Document[]> {
    const result = await this.list(context, tenantId, {
      clientId,
      ...options,
    });
    return result.data;
  }

  // ==========================================================================
  // UPLOAD OPERATIONS
  // ==========================================================================

  /**
   * Upload/create a new document
   * Requires: docs_upload
   */
  async upload(
    context: RequestContext,
    tenantId: string,
    input: UploadDocumentInput
  ): Promise<Document> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.DOCS_UPLOAD);

    // Validate case if provided
    if (input.case_id) {
      await validateCaseTenant(tenantId, input.case_id);
    }

    // Validate client if provided
    if (input.client_id) {
      await validateClientTenant(tenantId, input.client_id);
    }

    // Create document record
    const document = await documentRepository.create(tenantId, {
      title: input.title,
      filename: input.filename,
      mime_type: input.mime_type,
      size_bytes: input.size_bytes,
      storage_key: input.storage_key,
      case_id: input.case_id,
      client_id: input.client_id,
      category: input.category,
      description: input.description,
      tags: input.tags,
      uploaded_by: auth.userId,
    });

    // Audit log
    await auditService.logCreate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'documents',
      document.id,
      document as unknown as Record<string, unknown>
    );

    return document;
  }

  // ==========================================================================
  // UPDATE OPERATIONS
  // ==========================================================================

  /**
   * Update document metadata
   * Requires: docs_edit
   */
  async update(
    context: RequestContext,
    tenantId: string,
    documentId: string,
    input: UpdateDocumentInput
  ): Promise<Document> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.DOCS_EDIT);

    const existing = await documentRepository.findByIdOrFail(tenantId, documentId);
    const updated = await documentRepository.update(tenantId, documentId, input);

    await auditService.logUpdate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'documents',
      documentId,
      existing as unknown as Record<string, unknown>,
      updated as unknown as Record<string, unknown>
    );

    return updated;
  }

  // ==========================================================================
  // DELETE OPERATIONS
  // ==========================================================================

  /**
   * Soft delete a document
   * Requires: docs_delete
   */
  async delete(
    context: RequestContext,
    tenantId: string,
    documentId: string
  ): Promise<void> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.DOCS_DELETE);

    const document = await documentRepository.findByIdOrFail(tenantId, documentId);

    await softDeleteService.softDelete(tenantId, 'documents', documentId, {
      deletedBy: auth.userId,
    });

    await auditService.logDelete(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'documents',
      documentId,
      document as unknown as Record<string, unknown>
    );
  }

  /**
   * Restore a soft-deleted document
   * Requires: docs_delete
   */
  async restore(
    context: RequestContext,
    tenantId: string,
    documentId: string
  ): Promise<void> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.DOCS_DELETE);

    await softDeleteService.restore(tenantId, 'documents', documentId);

    await auditService.logRestore(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'documents',
      documentId
    );
  }

  // ==========================================================================
  // DOWNLOAD OPERATIONS
  // ==========================================================================

  /**
   * Get document for download (returns storage key)
   * Requires: docs_download
   */
  async getForDownload(
    context: RequestContext,
    tenantId: string,
    documentId: string
  ): Promise<{ document: Document; storageKey: string }> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.DOCS_DOWNLOAD);

    const document = await documentRepository.findByIdOrFail(tenantId, documentId);

    // Increment download count
    await documentRepository.update(tenantId, documentId, {
      // download_count would be incremented here
    });

    // Audit download
    await auditService.log(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      {
        action: 'VIEW',
        entityType: 'documents',
        entityId: documentId,
        description: `Downloaded document: ${document.title}`,
      }
    );

    return {
      document,
      storageKey: document.storage_key,
    };
  }

  // ==========================================================================
  // VERSION MANAGEMENT
  // ==========================================================================

  /**
   * Upload a new version of a document
   * Requires: docs_upload
   */
  async uploadVersion(
    context: RequestContext,
    tenantId: string,
    documentId: string,
    versionInput: {
      filename: string;
      mime_type: string;
      size_bytes: number;
      storage_key: string;
      change_notes?: string;
    }
  ): Promise<Document> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.DOCS_UPLOAD);

    const existing = await documentRepository.findByIdOrFail(tenantId, documentId);

    // Update document with new version info
    const updated = await documentRepository.update(tenantId, documentId, {
      filename: versionInput.filename,
      mime_type: versionInput.mime_type,
      size_bytes: versionInput.size_bytes,
      storage_key: versionInput.storage_key,
      // version: existing.version + 1,  // Would increment version
    });

    await auditService.logUpdate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'documents',
      documentId,
      existing as unknown as Record<string, unknown>,
      { ...updated as unknown as Record<string, unknown>, change_notes: versionInput.change_notes }
    );

    return updated;
  }
}

export const documentService = new DocumentService();
