// ============================================================================
// SEED RUNNER
// apps/api/src/db/seeds/runner.ts
// ============================================================================

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import pg from 'pg';

const { Pool } = pg;

// ============================================================================
// TYPES
// ============================================================================

interface SeedFile {
  order: number;
  name: string;
  filename: string;
  filepath: string;
  checksum: string;
  sql: string;
}

interface AppliedSeed {
  name: string;
  checksum: string;
  applied_at: Date;
}

// ============================================================================
// CONFIGURATION
// ============================================================================

const SEEDS_DIR = path.join(import.meta.dirname, '.');
const SEEDS_TABLE = 'schema_seeds';

// ============================================================================
// UTILITIES
// ============================================================================

/**
 * Calculate SHA-256 checksum of file content
 */
function calculateChecksum(content: string): string {
  return crypto.createHash('sha256').update(content, 'utf8').digest('hex');
}

/**
 * Parse seed filename to extract order and name
 * Expected format: 001_roles_permissions.sql
 */
function parseSeedFilename(filename: string): { order: number; name: string } | null {
  const match = filename.match(/^(\d+)_(.+)\.sql$/);
  if (!match) return null;
  
  return {
    order: parseInt(match[1]!, 10),
    name: match[2]!,
  };
}

/**
 * Load all seed files from the seeds directory
 */
function loadSeedFiles(): SeedFile[] {
  const files = fs.readdirSync(SEEDS_DIR)
    .filter(f => f.endsWith('.sql') && !f.includes('runner'))
    .sort();
  
  const seeds: SeedFile[] = [];
  
  for (const filename of files) {
    const parsed = parseSeedFilename(filename);
    if (!parsed) continue;
    
    const filepath = path.join(SEEDS_DIR, filename);
    const sql = fs.readFileSync(filepath, 'utf8');
    const checksum = calculateChecksum(sql);
    
    seeds.push({
      order: parsed.order,
      name: parsed.name,
      filename,
      filepath,
      checksum,
      sql,
    });
  }
  
  return seeds.sort((a, b) => a.order - b.order);
}

// ============================================================================
// SEED RUNNER CLASS
// ============================================================================

export class SeedRunner {
  private pool: pg.Pool;
  private verbose: boolean;
  
  constructor(connectionString: string, verbose: boolean = true) {
    this.pool = new Pool({ connectionString });
    this.verbose = verbose;
  }
  
  private log(message: string): void {
    if (this.verbose) {
      console.log(message);
    }
  }
  
  private logError(message: string): void {
    console.error(`❌ ${message}`);
  }
  
  private logSuccess(message: string): void {
    if (this.verbose) {
      console.log(`✅ ${message}`);
    }
  }
  
  private logWarning(message: string): void {
    if (this.verbose) {
      console.log(`⚠️  ${message}`);
    }
  }
  
  /**
   * Ensure the schema_seeds table exists
   */
  async ensureSeedsTable(): Promise<void> {
    await this.pool.query(`
      CREATE TABLE IF NOT EXISTS ${SEEDS_TABLE} (
        name VARCHAR(255) PRIMARY KEY,
        checksum VARCHAR(64) NOT NULL,
        applied_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
      )
    `);
  }
  
  /**
   * Get all applied seeds from the database
   */
  async getAppliedSeeds(): Promise<AppliedSeed[]> {
    await this.ensureSeedsTable();
    
    const result = await this.pool.query<AppliedSeed>(`
      SELECT name, checksum, applied_at
      FROM ${SEEDS_TABLE}
      ORDER BY applied_at ASC
    `);
    
    return result.rows;
  }
  
  /**
   * Check if a specific seed has been applied
   */
  async isSeedApplied(name: string): Promise<boolean> {
    await this.ensureSeedsTable();
    
    const result = await this.pool.query(`
      SELECT 1 FROM ${SEEDS_TABLE} WHERE name = $1
    `, [name]);
    
    return result.rows.length > 0;
  }
  
  /**
   * Run all seeds
   * By default, skips already applied seeds unless force=true
   */
  async run(options: { force?: boolean } = {}): Promise<{ applied: string[]; skipped: string[]; errors: string[] }> {
    const seeds = loadSeedFiles();
    const applied = await this.getAppliedSeeds();
    const appliedMap = new Map(applied.map(s => [s.name, s]));
    
    const results = { 
      applied: [] as string[], 
      skipped: [] as string[], 
      errors: [] as string[] 
    };
    
    for (const seed of seeds) {
      const appliedSeed = appliedMap.get(seed.name);
      
      // Check if already applied
      if (appliedSeed && !options.force) {
        // Check for checksum mismatch
        if (appliedSeed.checksum !== seed.checksum) {
          this.logWarning(`Seed ${seed.name} has been modified. Use --force to re-apply.`);
        }
        results.skipped.push(seed.name);
        continue;
      }
      
      // Apply the seed
      this.log(`Applying seed ${seed.name}...`);
      
      const client = await this.pool.connect();
      try {
        await client.query('BEGIN');
        
        // If forcing, remove old seed record first
        if (appliedSeed && options.force) {
          await client.query(`DELETE FROM ${SEEDS_TABLE} WHERE name = $1`, [seed.name]);
        }
        
        await client.query(seed.sql);
        
        // Record the seed (upsert)
        await client.query(`
          INSERT INTO ${SEEDS_TABLE} (name, checksum)
          VALUES ($1, $2)
          ON CONFLICT (name) DO UPDATE SET checksum = $2, applied_at = CURRENT_TIMESTAMP
        `, [seed.name, seed.checksum]);
        
        await client.query('COMMIT');
        
        results.applied.push(seed.name);
        this.logSuccess(`Applied ${seed.name}`);
      } catch (error) {
        await client.query('ROLLBACK');
        const errorMsg = `Failed to apply ${seed.name}: ${error instanceof Error ? error.message : error}`;
        this.logError(errorMsg);
        results.errors.push(errorMsg);
        // Continue with other seeds on error (seeds should be idempotent)
      } finally {
        client.release();
      }
    }
    
    return results;
  }
  
  /**
   * Reset seeds (remove all seed records and re-run)
   */
  async reset(): Promise<{ applied: string[]; errors: string[] }> {
    this.logWarning('Resetting seeds - will re-apply all seeds');
    
    // Clear seed records
    await this.pool.query(`DELETE FROM ${SEEDS_TABLE}`);
    
    // Run all seeds
    const result = await this.run({ force: true });
    
    return {
      applied: result.applied,
      errors: result.errors,
    };
  }
  
  /**
   * Show seed status
   */
  async status(): Promise<void> {
    const seeds = loadSeedFiles();
    const applied = await this.getAppliedSeeds();
    const appliedMap = new Map(applied.map(s => [s.name, s]));
    
    console.log('\n🌱 Seed Status:');
    console.log('─'.repeat(60));
    console.log('Order  Name                                 Status     Applied At');
    console.log('─'.repeat(60));
    
    for (const seed of seeds) {
      const appliedSeed = appliedMap.get(seed.name);
      let status = 'pending';
      let statusIcon = '⏳';
      
      if (appliedSeed) {
        if (appliedSeed.checksum === seed.checksum) {
          status = 'applied';
          statusIcon = '✅';
        } else {
          status = 'modified';
          statusIcon = '⚠️';
        }
      }
      
      const appliedAt = appliedSeed?.applied_at 
        ? appliedSeed.applied_at.toISOString().split('T')[0] 
        : '-';
      
      console.log(
        `${String(seed.order).padStart(5)}  ${seed.name.padEnd(37).substring(0, 37)} ${statusIcon} ${status.padEnd(10)} ${appliedAt}`
      );
    }
    
    console.log('─'.repeat(60));
  }
  
  /**
   * Close the database connection pool
   */
  async close(): Promise<void> {
    await this.pool.end();
  }
}

// ============================================================================
// CLI INTERFACE
// ============================================================================

async function main(): Promise<void> {
  const command = process.argv[2];
  const DATABASE_URL = process.env.DATABASE_URL;
  
  if (!DATABASE_URL) {
    console.error('❌ DATABASE_URL environment variable is required');
    process.exit(1);
  }
  
  const runner = new SeedRunner(DATABASE_URL);
  
  try {
    switch (command) {
      case 'run':
      case undefined: {
        console.log('\n🌱 Running seeds...\n');
        const force = process.argv.includes('--force');
        const result = await runner.run({ force });
        
        console.log('\n📊 Summary:');
        console.log(`   Applied: ${result.applied.length}`);
        console.log(`   Skipped: ${result.skipped.length}`);
        console.log(`   Errors:  ${result.errors.length}`);
        
        if (result.errors.length > 0) {
          process.exit(1);
        }
        
        await runner.status();
        break;
      }
      
      case 'status': {
        await runner.status();
        break;
      }
      
      case 'reset': {
        // Require confirmation in production
        if (process.env.NODE_ENV === 'production') {
          console.error('❌ db:seed:reset is not allowed in production');
          process.exit(1);
        }
        
        const confirm = process.argv[3];
        if (confirm !== '--confirm') {
          console.log('\n⚠️  This will reset and re-apply all seeds!');
          console.log('   Run with --confirm to proceed: db:seed reset --confirm\n');
          process.exit(1);
        }
        
        console.log('\n🔄 Resetting seeds...\n');
        const result = await runner.reset();
        
        console.log('\n📊 Summary:');
        console.log(`   Applied: ${result.applied.length}`);
        console.log(`   Errors:  ${result.errors.length}`);
        
        if (result.errors.length > 0) {
          process.exit(1);
        }
        break;
      }
      
      default:
        console.log(`
Usage: db:seed [command] [options]

Commands:
  run (default)  Run all pending seeds
  status         Show seed status
  reset          Reset and re-apply all seeds (requires --confirm)

Options:
  --force        Force re-apply even if already applied

Examples:
  pnpm db:seed
  pnpm db:seed --force
  pnpm db:seed status
  pnpm db:seed reset --confirm
`);
        process.exit(1);
    }
  } finally {
    await runner.close();
  }
}

// Run if executed directly
main().catch((error) => {
  console.error('Seed runner error:', error);
  process.exit(1);
});

export { SeedRunner };
