// ============================================================================
// TRUST TRANSACTION REPOSITORY
// apps/api/src/repositories/trust-transaction.repository.ts
// 
// IMMUTABLE: No update or delete methods allowed
// ============================================================================

import { ImmutableRepository, type ImmutableEntity } from './immutable.repository.js';
import { query } from '../db/connection.js';
import { parsePostgresError, TenantScopingError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export type TrustTransactionType = 
  | 'deposit' 
  | 'withdrawal' 
  | 'transfer_in' 
  | 'transfer_out' 
  | 'fee_deduction' 
  | 'refund';

export interface TrustTransaction extends ImmutableEntity {
  id: string;
  tenant_id: string;
  trust_account_id: string;
  client_id: string;
  case_id: string | null;
  transaction_type: TrustTransactionType;
  amount: number;  // Signed: positive for deposits, negative for withdrawals
  balance_after: number;
  currency: string;
  reference_number: string;
  description: string;
  external_reference: string | null;
  payment_method: string | null;
  check_number: string | null;
  bank_reference: string | null;
  invoice_id: string | null;
  payment_id: string | null;
  related_transaction_id: string | null;
  metadata_json: Record<string, unknown>;
  created_by: string;
  created_at: Date;
}

export interface TrustTransactionWithDetails extends TrustTransaction {
  trust_account_name: string;
  client_name: string;
  case_title: string | null;
  created_by_name: string;
}

export interface CreateTrustTransactionData {
  trust_account_id: string;
  client_id: string;
  case_id?: string;
  transaction_type: TrustTransactionType;
  amount: number;  // Always positive, sign determined by type
  currency?: string;
  description: string;
  external_reference?: string;
  payment_method?: string;
  check_number?: string;
  bank_reference?: string;
  invoice_id?: string;
  payment_id?: string;
  related_transaction_id?: string;
  metadata_json?: Record<string, unknown>;
  created_by: string;
}

export interface TransactionFilters {
  trustAccountId?: string;
  clientId?: string;
  caseId?: string;
  transactionType?: TrustTransactionType;
  startDate?: Date;
  endDate?: Date;
  minAmount?: number;
  maxAmount?: number;
}

// ============================================================================
// REPOSITORY
// ============================================================================

export class TrustTransactionRepository extends ImmutableRepository<TrustTransaction> {
  constructor() {
    super({
      tableName: 'trust_transactions',
    });
  }

  /**
   * Record a new transaction (INSERT only)
   * Note: balance_after is calculated by database trigger
   */
  async recordTransaction(tenantId: string, data: CreateTrustTransactionData): Promise<TrustTransaction> {
    this.validateTenantId(tenantId, 'recordTransaction');

    try {
      const result = await query<TrustTransaction>(
        `INSERT INTO trust_transactions (
          tenant_id, trust_account_id, client_id, case_id,
          transaction_type, amount, currency, description,
          external_reference, payment_method, check_number, bank_reference,
          invoice_id, payment_id, related_transaction_id, metadata_json,
          created_by
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
        RETURNING *`,
        [
          tenantId,
          data.trust_account_id,
          data.client_id,
          data.case_id || null,
          data.transaction_type,
          Math.abs(data.amount),  // Always store absolute value, trigger handles sign
          data.currency || 'ILS',
          data.description,
          data.external_reference || null,
          data.payment_method || null,
          data.check_number || null,
          data.bank_reference || null,
          data.invoice_id || null,
          data.payment_id || null,
          data.related_transaction_id || null,
          JSON.stringify(data.metadata_json || {}),
          data.created_by,
        ]
      );

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find transaction by ID with full details
   */
  async findByIdWithDetails(tenantId: string, id: string): Promise<TrustTransactionWithDetails | null> {
    this.validateTenantId(tenantId, 'findByIdWithDetails');

    try {
      const result = await query<TrustTransactionWithDetails>(
        `SELECT 
          tt.*,
          ta.account_name as trust_account_name,
          cl.name as client_name,
          cs.title as case_title,
          u.name as created_by_name
         FROM trust_transactions tt
         JOIN trust_accounts ta ON tt.trust_account_id = ta.id
         JOIN clients cl ON tt.client_id = cl.id
         LEFT JOIN cases cs ON tt.case_id = cs.id
         JOIN users u ON tt.created_by = u.id
         WHERE tt.id = $1 AND tt.tenant_id = $2`,
        [id, tenantId]
      );

      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * List transactions with filters
   */
  async listTransactions(
    tenantId: string,
    filters: TransactionFilters = {},
    options: { limit?: number; offset?: number } = {}
  ): Promise<TrustTransactionWithDetails[]> {
    this.validateTenantId(tenantId, 'listTransactions');

    const conditions: string[] = ['tt.tenant_id = $1'];
    const params: unknown[] = [tenantId];
    let paramIndex = 2;

    if (filters.trustAccountId) {
      conditions.push(`tt.trust_account_id = $${paramIndex++}`);
      params.push(filters.trustAccountId);
    }

    if (filters.clientId) {
      conditions.push(`tt.client_id = $${paramIndex++}`);
      params.push(filters.clientId);
    }

    if (filters.caseId) {
      conditions.push(`tt.case_id = $${paramIndex++}`);
      params.push(filters.caseId);
    }

    if (filters.transactionType) {
      conditions.push(`tt.transaction_type = $${paramIndex++}`);
      params.push(filters.transactionType);
    }

    if (filters.startDate) {
      conditions.push(`tt.created_at >= $${paramIndex++}`);
      params.push(filters.startDate);
    }

    if (filters.endDate) {
      conditions.push(`tt.created_at <= $${paramIndex++}`);
      params.push(filters.endDate);
    }

    if (filters.minAmount !== undefined) {
      conditions.push(`ABS(tt.amount) >= $${paramIndex++}`);
      params.push(filters.minAmount);
    }

    if (filters.maxAmount !== undefined) {
      conditions.push(`ABS(tt.amount) <= $${paramIndex++}`);
      params.push(filters.maxAmount);
    }

    const limit = options.limit ?? 100;
    const offset = options.offset ?? 0;
    params.push(limit);
    params.push(offset);

    try {
      const result = await query<TrustTransactionWithDetails>(
        `SELECT 
          tt.*,
          ta.account_name as trust_account_name,
          cl.name as client_name,
          cs.title as case_title,
          u.name as created_by_name
         FROM trust_transactions tt
         JOIN trust_accounts ta ON tt.trust_account_id = ta.id
         JOIN clients cl ON tt.client_id = cl.id
         LEFT JOIN cases cs ON tt.case_id = cs.id
         JOIN users u ON tt.created_by = u.id
         WHERE ${conditions.join(' AND ')}
         ORDER BY tt.created_at DESC, tt.id DESC
         LIMIT $${paramIndex++} OFFSET $${paramIndex}`,
        params
      );

      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get account statement for date range
   */
  async getStatement(
    tenantId: string,
    trustAccountId: string,
    startDate: Date,
    endDate: Date
  ): Promise<{
    transaction_id: string;
    transaction_date: Date;
    reference_number: string;
    transaction_type: TrustTransactionType;
    description: string;
    debit: number | null;
    credit: number | null;
    balance: number;
  }[]> {
    this.validateTenantId(tenantId, 'getStatement');

    try {
      const result = await query(
        `SELECT * FROM get_trust_account_statement($1, $2, $3, $4)`,
        [tenantId, trustAccountId, startDate, endDate]
      );

      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get last transaction for account
   */
  async getLastTransaction(tenantId: string, trustAccountId: string): Promise<TrustTransaction | null> {
    this.validateTenantId(tenantId, 'getLastTransaction');

    try {
      const result = await query<TrustTransaction>(
        `SELECT * FROM trust_transactions
         WHERE tenant_id = $1 AND trust_account_id = $2
         ORDER BY created_at DESC, id DESC
         LIMIT 1`,
        [tenantId, trustAccountId]
      );

      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Count transactions for account
   */
  async countByAccount(tenantId: string, trustAccountId: string): Promise<number> {
    this.validateTenantId(tenantId, 'countByAccount');

    try {
      const result = await query<{ count: number }>(
        `SELECT COUNT(*)::int as count FROM trust_transactions
         WHERE tenant_id = $1 AND trust_account_id = $2`,
        [tenantId, trustAccountId]
      );

      return result.rows[0]?.count || 0;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Calculate balance from transactions (for reconciliation)
   */
  async calculateBalanceFromTransactions(tenantId: string, trustAccountId: string): Promise<number> {
    this.validateTenantId(tenantId, 'calculateBalanceFromTransactions');

    try {
      const result = await query<{ total: number }>(
        `SELECT COALESCE(SUM(amount), 0)::numeric as total
         FROM trust_transactions
         WHERE tenant_id = $1 AND trust_account_id = $2`,
        [tenantId, trustAccountId]
      );

      return parseFloat(result.rows[0]?.total?.toString() || '0');
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find transactions by reference number
   */
  async findByReference(tenantId: string, referenceNumber: string): Promise<TrustTransaction | null> {
    this.validateTenantId(tenantId, 'findByReference');

    try {
      const result = await query<TrustTransaction>(
        `SELECT * FROM trust_transactions
         WHERE tenant_id = $1 AND reference_number = $2`,
        [tenantId, referenceNumber]
      );

      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get balance history (for charts/graphs)
   */
  async getBalanceHistory(
    tenantId: string,
    trustAccountId: string,
    limit: number = 100
  ): Promise<{ date: Date; balance: number }[]> {
    this.validateTenantId(tenantId, 'getBalanceHistory');

    try {
      const result = await query<{ date: Date; balance: number }>(
        `SELECT 
          created_at as date,
          balance_after as balance
         FROM trust_transactions
         WHERE tenant_id = $1 AND trust_account_id = $2
         ORDER BY created_at ASC
         LIMIT $3`,
        [tenantId, trustAccountId, limit]
      );

      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}

export const trustTransactionRepository = new TrustTransactionRepository();
