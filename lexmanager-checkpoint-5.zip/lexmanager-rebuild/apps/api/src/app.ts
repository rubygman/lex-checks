// ============================================================================
// EXPRESS APP SETUP
// apps/api/src/app.ts
// 
// Main application setup with middleware and routes
// ============================================================================

import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { getConfig, isProduction } from './config/index.js';
import authRoutes from './routes/auth.routes.js';
import clientRoutes from './routes/client.routes.js';
import caseRoutes from './routes/case.routes.js';
import taskRoutes from './routes/task.routes.js';
import documentRoutes from './routes/document.routes.js';
import invoiceRoutes from './routes/invoice.routes.js';
import trustRoutes from './routes/trust.routes.js';
import customFieldRoutes from './routes/custom-field.routes.js';
import auditRoutes from './routes/audit.routes.js';
import { globalRateLimiter, initializeContext } from './middleware/index.js';
import { errorHandler, notFoundHandler, sendSuccess } from './errors/index.js';

// ============================================================================
// CREATE APP
// ============================================================================

export function createApp(): Express {
  const app = express();
  const config = getConfig();

  // ==========================================================================
  // SECURITY MIDDLEWARE
  // ==========================================================================

  if (config.server.trustProxy) {
    app.set('trust proxy', 1);
  }

  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", ...(isProduction() ? [] : ["'unsafe-inline'", "'unsafe-eval'"])],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'blob:', 'https:'],
        fontSrc: ["'self'", 'data:'],
        connectSrc: ["'self'", 'https:'],
        frameSrc: ["'none'"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
      },
    },
    hsts: {
      maxAge: 31536000,
      includeSubDomains: true,
      preload: true,
    },
  }));

  app.use(cors({
    origin: config.server.corsOrigins.length > 0 ? config.server.corsOrigins : true,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Tenant-Id', 'X-Correlation-ID'],
  }));

  // ==========================================================================
  // BODY PARSING
  // ==========================================================================

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // ==========================================================================
  // GLOBAL MIDDLEWARE
  // ==========================================================================

  app.use(initializeContext());
  app.use(globalRateLimiter());

  // ==========================================================================
  // HEALTH CHECKS (before auth)
  // ==========================================================================

  app.get('/health', (req: Request, res: Response) => {
    sendSuccess(res, req, {
      status: 'ok',
      timestamp: new Date().toISOString(),
    });
  });

  app.get('/ready', async (req: Request, res: Response) => {
    sendSuccess(res, req, {
      status: 'ready',
      timestamp: new Date().toISOString(),
    });
  });

  // ==========================================================================
  // API ROUTES
  // ==========================================================================

  app.use('/auth', authRoutes);
  app.use('/clients', clientRoutes);
  app.use('/cases', caseRoutes);
  app.use('/tasks', taskRoutes);
  app.use('/documents', documentRoutes);
  app.use('/invoices', invoiceRoutes);
  app.use('/trust', trustRoutes);
  app.use('/custom-fields', customFieldRoutes);
  app.use('/audit', auditRoutes);

  // ==========================================================================
  // 404 HANDLER
  // ==========================================================================

  app.use(notFoundHandler);

  // ==========================================================================
  // GLOBAL ERROR HANDLER
  // ==========================================================================

  app.use(errorHandler);

  return app;
}

export default createApp;
