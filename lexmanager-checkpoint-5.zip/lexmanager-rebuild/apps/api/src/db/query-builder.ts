// ============================================================================
// QUERY BUILDER WITH STRICT TENANT SCOPING
// apps/api/src/db/query-builder.ts
// ============================================================================

import { TenantScopingError, ImmutableTableError } from './errors.js';

/**
 * Tables that are immutable (append-only, no UPDATE/DELETE)
 */
export const IMMUTABLE_TABLES = ['trust_transactions', 'audit.logs'] as const;

/**
 * Tables that don't require tenant scoping (global tables)
 */
export const GLOBAL_TABLES = ['roles', 'permissions', 'role_permissions'] as const;

/**
 * Tables with soft delete support
 */
export const SOFT_DELETE_TABLES = [
  'tenants',
  'users',
  'clients',
  'cases',
  'tasks',
  'documents',
  'calendar_events',
  'time_entries',
  'invoices',
  'payments',
  'trust_accounts',
  'custom_field_definitions',
] as const;

export type SortDirection = 'ASC' | 'DESC';

export interface PaginationOptions {
  limit: number;
  offset: number;
}

export interface SortOptions {
  column: string;
  direction: SortDirection;
}

export interface QueryOptions {
  includeDeleted?: boolean;
  pagination?: PaginationOptions;
  sort?: SortOptions;
}

interface WhereClause {
  column: string;
  operator: '=' | '!=' | '>' | '<' | '>=' | '<=' | 'IN' | 'NOT IN' | 'LIKE' | 'ILIKE' | 'IS NULL' | 'IS NOT NULL';
  value?: unknown;
  paramIndex?: number;
}

/**
 * Type-safe query builder that enforces tenant scoping
 */
export class QueryBuilder {
  private _table: string = '';
  private _tenantId: string | null = null;
  private _columns: string[] = ['*'];
  private _whereClauses: WhereClause[] = [];
  private _params: unknown[] = [];
  private _paramCounter: number = 1;
  private _includeDeleted: boolean = false;
  private _pagination: PaginationOptions | null = null;
  private _sort: SortOptions | null = null;
  private _joins: string[] = [];
  private _groupBy: string[] = [];
  private _having: string | null = null;

  /**
   * Check if a table requires tenant scoping
   */
  static requiresTenantScoping(table: string): boolean {
    return !GLOBAL_TABLES.includes(table as typeof GLOBAL_TABLES[number]);
  }

  /**
   * Check if a table is immutable
   */
  static isImmutable(table: string): boolean {
    return IMMUTABLE_TABLES.includes(table as typeof IMMUTABLE_TABLES[number]);
  }

  /**
   * Check if a table supports soft delete
   */
  static supportsSoftDelete(table: string): boolean {
    return SOFT_DELETE_TABLES.includes(table as typeof SOFT_DELETE_TABLES[number]);
  }

  /**
   * Set the table for the query
   */
  table(tableName: string): this {
    this._table = tableName;
    return this;
  }

  /**
   * Set tenant ID (REQUIRED for tenant-scoped tables)
   */
  tenant(tenantId: string): this {
    if (!tenantId || typeof tenantId !== 'string' || tenantId.trim() === '') {
      throw new TenantScopingError('tenant() called with invalid tenantId');
    }
    this._tenantId = tenantId;
    return this;
  }

  /**
   * Select specific columns
   */
  select(...columns: string[]): this {
    this._columns = columns.length > 0 ? columns : ['*'];
    return this;
  }

  /**
   * Add a WHERE clause
   */
  where(column: string, operator: WhereClause['operator'], value?: unknown): this {
    if (operator === 'IS NULL' || operator === 'IS NOT NULL') {
      this._whereClauses.push({ column, operator });
    } else {
      this._whereClauses.push({
        column,
        operator,
        value,
        paramIndex: this._paramCounter++,
      });
      this._params.push(value);
    }
    return this;
  }

  /**
   * Add a WHERE equals clause (shorthand)
   */
  whereEquals(column: string, value: unknown): this {
    return this.where(column, '=', value);
  }

  /**
   * Add a WHERE IN clause
   */
  whereIn(column: string, values: unknown[]): this {
    return this.where(column, 'IN', values);
  }

  /**
   * Include soft-deleted records
   */
  includeDeleted(include: boolean = true): this {
    this._includeDeleted = include;
    return this;
  }

  /**
   * Add pagination
   */
  paginate(limit: number, offset: number = 0): this {
    this._pagination = { limit, offset };
    return this;
  }

  /**
   * Add sorting
   */
  orderBy(column: string, direction: SortDirection = 'ASC'): this {
    this._sort = { column, direction };
    return this;
  }

  /**
   * Add a JOIN clause
   */
  join(type: 'INNER' | 'LEFT' | 'RIGHT', table: string, condition: string): this {
    this._joins.push(`${type} JOIN ${table} ON ${condition}`);
    return this;
  }

  /**
   * Add GROUP BY clause
   */
  groupBy(...columns: string[]): this {
    this._groupBy = columns;
    return this;
  }

  /**
   * Add HAVING clause
   */
  having(condition: string): this {
    this._having = condition;
    return this;
  }

  /**
   * Validate that tenant scoping is properly applied
   */
  private validateTenantScoping(): void {
    if (QueryBuilder.requiresTenantScoping(this._table) && !this._tenantId) {
      throw new TenantScopingError(
        `Query on table "${this._table}" requires tenant scoping. ` +
        `Call .tenant(tenantId) before building the query.`
      );
    }
  }

  /**
   * Build a SELECT query
   */
  buildSelect(): { text: string; params: unknown[] } {
    if (!this._table) {
      throw new Error('Table not specified. Call .table() first.');
    }

    this.validateTenantScoping();

    const params = [...this._params];
    const conditions: string[] = [];

    // Add tenant scoping
    if (this._tenantId && QueryBuilder.requiresTenantScoping(this._table)) {
      conditions.push(`${this._table}.tenant_id = $${params.length + 1}`);
      params.push(this._tenantId);
    }

    // Add soft delete filter
    if (QueryBuilder.supportsSoftDelete(this._table) && !this._includeDeleted) {
      conditions.push(`${this._table}.deleted_at IS NULL`);
    }

    // Add user-defined WHERE clauses
    for (const clause of this._whereClauses) {
      if (clause.operator === 'IS NULL') {
        conditions.push(`${clause.column} IS NULL`);
      } else if (clause.operator === 'IS NOT NULL') {
        conditions.push(`${clause.column} IS NOT NULL`);
      } else if (clause.operator === 'IN' || clause.operator === 'NOT IN') {
        const values = clause.value as unknown[];
        const placeholders = values.map((_, i) => `$${params.length + i + 1}`).join(', ');
        conditions.push(`${clause.column} ${clause.operator} (${placeholders})`);
        params.push(...values);
      } else {
        // Find the correct param index for this clause
        const paramIdx = params.indexOf(clause.value) + 1 || clause.paramIndex;
        conditions.push(`${clause.column} ${clause.operator} $${paramIdx}`);
      }
    }

    // Build query
    let query = `SELECT ${this._columns.join(', ')} FROM ${this._table}`;

    // Add joins
    if (this._joins.length > 0) {
      query += ' ' + this._joins.join(' ');
    }

    // Add WHERE
    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(' AND ')}`;
    }

    // Add GROUP BY
    if (this._groupBy.length > 0) {
      query += ` GROUP BY ${this._groupBy.join(', ')}`;
    }

    // Add HAVING
    if (this._having) {
      query += ` HAVING ${this._having}`;
    }

    // Add ORDER BY
    if (this._sort) {
      query += ` ORDER BY ${this._sort.column} ${this._sort.direction}`;
    }

    // Add LIMIT/OFFSET
    if (this._pagination) {
      query += ` LIMIT ${this._pagination.limit} OFFSET ${this._pagination.offset}`;
    }

    return { text: query, params };
  }

  /**
   * Build a COUNT query
   */
  buildCount(): { text: string; params: unknown[] } {
    const originalColumns = this._columns;
    this._columns = ['COUNT(*) as count'];
    
    const originalPagination = this._pagination;
    this._pagination = null;
    
    const originalSort = this._sort;
    this._sort = null;

    const result = this.buildSelect();

    // Restore original state
    this._columns = originalColumns;
    this._pagination = originalPagination;
    this._sort = originalSort;

    return result;
  }

  /**
   * Reset the builder for reuse
   */
  reset(): this {
    this._table = '';
    this._tenantId = null;
    this._columns = ['*'];
    this._whereClauses = [];
    this._params = [];
    this._paramCounter = 1;
    this._includeDeleted = false;
    this._pagination = null;
    this._sort = null;
    this._joins = [];
    this._groupBy = [];
    this._having = null;
    return this;
  }
}

/**
 * Build an INSERT query with tenant scoping
 */
export function buildInsert(
  table: string,
  tenantId: string | null,
  data: Record<string, unknown>
): { text: string; params: unknown[] } {
  if (QueryBuilder.requiresTenantScoping(table) && !tenantId) {
    throw new TenantScopingError(
      `INSERT into table "${table}" requires tenant scoping.`
    );
  }

  const dataWithTenant = QueryBuilder.requiresTenantScoping(table)
    ? { tenant_id: tenantId, ...data }
    : data;

  const columns = Object.keys(dataWithTenant);
  const values = Object.values(dataWithTenant);
  const placeholders = columns.map((_, i) => `$${i + 1}`).join(', ');

  const text = `INSERT INTO ${table} (${columns.join(', ')}) VALUES (${placeholders}) RETURNING *`;

  return { text, params: values };
}

/**
 * Build an UPDATE query with strict tenant scoping
 */
export function buildUpdate(
  table: string,
  tenantId: string,
  id: string,
  data: Record<string, unknown>,
  idColumn: string = 'id'
): { text: string; params: unknown[] } {
  // Check for immutable tables
  if (QueryBuilder.isImmutable(table)) {
    throw new ImmutableTableError(
      `Table "${table}" is immutable. UPDATE operations are not allowed.`
    );
  }

  if (QueryBuilder.requiresTenantScoping(table) && !tenantId) {
    throw new TenantScopingError(
      `UPDATE on table "${table}" requires tenant scoping.`
    );
  }

  // Add updated_at timestamp
  const dataWithTimestamp = {
    ...data,
    updated_at: new Date().toISOString(),
  };

  const columns = Object.keys(dataWithTimestamp);
  const values = Object.values(dataWithTimestamp);
  
  const setClause = columns.map((col, i) => `${col} = $${i + 1}`).join(', ');
  
  let paramIndex = values.length + 1;
  const conditions: string[] = [`${idColumn} = $${paramIndex++}`];
  values.push(id);

  if (QueryBuilder.requiresTenantScoping(table)) {
    conditions.push(`tenant_id = $${paramIndex++}`);
    values.push(tenantId);
  }

  // Ensure we're not updating a soft-deleted record
  if (QueryBuilder.supportsSoftDelete(table)) {
    conditions.push('deleted_at IS NULL');
  }

  const text = `UPDATE ${table} SET ${setClause} WHERE ${conditions.join(' AND ')} RETURNING *`;

  return { text, params: values };
}

/**
 * Build a soft DELETE query with strict tenant scoping
 */
export function buildSoftDelete(
  table: string,
  tenantId: string,
  id: string,
  idColumn: string = 'id'
): { text: string; params: unknown[] } {
  // Check for immutable tables
  if (QueryBuilder.isImmutable(table)) {
    throw new ImmutableTableError(
      `Table "${table}" is immutable. DELETE operations are not allowed.`
    );
  }

  if (!QueryBuilder.supportsSoftDelete(table)) {
    throw new Error(
      `Table "${table}" does not support soft delete. Use hard delete or add soft delete support.`
    );
  }

  if (QueryBuilder.requiresTenantScoping(table) && !tenantId) {
    throw new TenantScopingError(
      `DELETE on table "${table}" requires tenant scoping.`
    );
  }

  const conditions: string[] = [`${idColumn} = $1`, 'deleted_at IS NULL'];
  const params: unknown[] = [id];

  if (QueryBuilder.requiresTenantScoping(table)) {
    conditions.push(`tenant_id = $2`);
    params.push(tenantId);
  }

  const text = `UPDATE ${table} SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE ${conditions.join(' AND ')} RETURNING *`;

  return { text, params };
}

/**
 * Build a hard DELETE query (use sparingly, mainly for cleanup)
 */
export function buildHardDelete(
  table: string,
  tenantId: string,
  id: string,
  idColumn: string = 'id'
): { text: string; params: unknown[] } {
  // Check for immutable tables
  if (QueryBuilder.isImmutable(table)) {
    throw new ImmutableTableError(
      `Table "${table}" is immutable. DELETE operations are not allowed.`
    );
  }

  if (QueryBuilder.requiresTenantScoping(table) && !tenantId) {
    throw new TenantScopingError(
      `DELETE on table "${table}" requires tenant scoping.`
    );
  }

  const conditions: string[] = [`${idColumn} = $1`];
  const params: unknown[] = [id];

  if (QueryBuilder.requiresTenantScoping(table)) {
    conditions.push(`tenant_id = $2`);
    params.push(tenantId);
  }

  const text = `DELETE FROM ${table} WHERE ${conditions.join(' AND ')} RETURNING *`;

  return { text, params };
}

/**
 * Create a new QueryBuilder instance
 */
export function createQueryBuilder(): QueryBuilder {
  return new QueryBuilder();
}
