// ============================================================================
// CLIENT SERVICE
// apps/api/src/services/client.service.ts
// 
// All methods require appropriate permissions via Authorizer
// ============================================================================

import { clientRepository, type Client } from '../repositories/index.js';
import { authorizer, PERMISSIONS, type RequestContext, AuthorizationError } from '../auth/authorizer.js';
import { auditService } from './audit.service.js';
import { softDeleteService } from './soft-delete.service.js';
import { validateClientTenant, validateUserTenant } from '../utils/tenant-validation.js';
import { NotFoundError, TenantScopingError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export interface CreateClientInput {
  name: string;
  client_type: 'individual' | 'company';
  email?: string;
  phone?: string;
  address_street?: string;
  address_city?: string;
  address_state?: string;
  address_postal_code?: string;
  address_country: string;
  tax_id?: string;
  currency: string;
  payment_terms: number;
  credit_limit?: number;
  notes?: string;
  assigned_to?: string;
}

export interface UpdateClientInput {
  name?: string;
  email?: string;
  phone?: string;
  address_street?: string;
  address_city?: string;
  address_state?: string;
  address_postal_code?: string;
  address_country?: string;
  tax_id?: string;
  currency?: string;
  payment_terms?: number;
  credit_limit?: number;
  notes?: string;
  assigned_to?: string;
  status?: 'active' | 'inactive' | 'archived';
}

export interface ClientListOptions {
  status?: 'active' | 'inactive' | 'archived';
  assignedTo?: string;
  search?: string;
  limit?: number;
  offset?: number;
  includeDeleted?: boolean;
}

// ============================================================================
// SERVICE
// ============================================================================

export class ClientService {
  // ==========================================================================
  // VIEW OPERATIONS
  // ==========================================================================

  /**
   * Get client by ID
   * Requires: clients_view
   */
  async getById(
    context: RequestContext,
    tenantId: string,
    clientId: string
  ): Promise<Client | null> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CLIENTS_VIEW);
    
    return clientRepository.findById(tenantId, clientId);
  }

  /**
   * Get client by ID or throw
   * Requires: clients_view
   */
  async getByIdOrFail(
    context: RequestContext,
    tenantId: string,
    clientId: string
  ): Promise<Client> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CLIENTS_VIEW);
    
    return clientRepository.findByIdOrFail(tenantId, clientId);
  }

  /**
   * List clients
   * Requires: clients_view
   */
  async list(
    context: RequestContext,
    tenantId: string,
    options: ClientListOptions = {}
  ): Promise<{ data: Client[]; pagination: { total: number; limit: number; offset: number; hasMore: boolean } }> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CLIENTS_VIEW);

    const filters = [];
    
    if (options.status) {
      filters.push({ field: 'status', operator: '=' as const, value: options.status });
    }
    if (options.assignedTo) {
      filters.push({ field: 'assigned_to', operator: '=' as const, value: options.assignedTo });
    }
    if (options.search) {
      filters.push({ field: 'name', operator: 'ILIKE' as const, value: `%${options.search}%` });
    }

    return clientRepository.list(tenantId, {
      filters,
      pagination: { 
        limit: options.limit ?? 100, 
        offset: options.offset ?? 0 
      },
      includeDeleted: options.includeDeleted,
    });
  }

  /**
   * Count clients
   * Requires: clients_view
   */
  async count(
    context: RequestContext,
    tenantId: string,
    options: { status?: string } = {}
  ): Promise<number> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CLIENTS_VIEW);

    const filters = [];
    if (options.status) {
      filters.push({ field: 'status', operator: '=' as const, value: options.status });
    }

    return clientRepository.count(tenantId, { filters });
  }

  // ==========================================================================
  // CREATE OPERATIONS
  // ==========================================================================

  /**
   * Create a new client
   * Requires: clients_create
   */
  async create(
    context: RequestContext,
    tenantId: string,
    input: CreateClientInput
  ): Promise<Client> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CLIENTS_CREATE);

    // Validate assigned_to if provided
    if (input.assigned_to) {
      await validateUserTenant(tenantId, input.assigned_to);
    }

    // Create client
    const client = await clientRepository.create(tenantId, {
      name: input.name,
      client_type: input.client_type,
      status: 'active',
      email: input.email,
      phone: input.phone,
      address_street: input.address_street,
      address_city: input.address_city,
      address_state: input.address_state,
      address_postal_code: input.address_postal_code,
      address_country: input.address_country,
      tax_id: input.tax_id,
      currency: input.currency,
      payment_terms: input.payment_terms,
      credit_limit: input.credit_limit,
      notes: input.notes,
      assigned_to: input.assigned_to,
      created_by: auth.userId,
    });

    // Audit log
    await auditService.logCreate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'clients',
      client.id,
      client as unknown as Record<string, unknown>
    );

    return client;
  }

  // ==========================================================================
  // UPDATE OPERATIONS
  // ==========================================================================

  /**
   * Update a client
   * Requires: clients_edit
   */
  async update(
    context: RequestContext,
    tenantId: string,
    clientId: string,
    input: UpdateClientInput
  ): Promise<Client> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CLIENTS_EDIT);

    // Get existing client for audit
    const existing = await clientRepository.findByIdOrFail(tenantId, clientId);

    // Validate assigned_to if provided
    if (input.assigned_to) {
      await validateUserTenant(tenantId, input.assigned_to);
    }

    // Update client
    const updated = await clientRepository.update(tenantId, clientId, input);

    // Audit log
    await auditService.logUpdate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'clients',
      clientId,
      existing as unknown as Record<string, unknown>,
      updated as unknown as Record<string, unknown>
    );

    return updated;
  }

  // ==========================================================================
  // DELETE OPERATIONS
  // ==========================================================================

  /**
   * Soft delete a client
   * Requires: clients_delete
   */
  async delete(
    context: RequestContext,
    tenantId: string,
    clientId: string
  ): Promise<void> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CLIENTS_DELETE);

    // Get client for audit
    const client = await clientRepository.findByIdOrFail(tenantId, clientId);

    // Soft delete with cascade
    await softDeleteService.softDelete(tenantId, 'clients', clientId, {
      deletedBy: auth.userId,
    });

    // Audit log
    await auditService.logDelete(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'clients',
      clientId,
      client as unknown as Record<string, unknown>
    );
  }

  /**
   * Restore a soft-deleted client
   * Requires: clients_delete (same permission as delete)
   */
  async restore(
    context: RequestContext,
    tenantId: string,
    clientId: string
  ): Promise<void> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CLIENTS_DELETE);

    await softDeleteService.restore(tenantId, 'clients', clientId, {
      restoreRelated: true,
    });

    // Audit log
    await auditService.logRestore(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'clients',
      clientId
    );
  }

  // ==========================================================================
  // EXPORT OPERATIONS
  // ==========================================================================

  /**
   * Export clients data
   * Requires: clients_export
   */
  async export(
    context: RequestContext,
    tenantId: string,
    options: { format: 'csv' | 'xlsx'; filters?: ClientListOptions }
  ): Promise<{ data: Client[]; format: string }> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CLIENTS_EXPORT);

    // Get all clients matching filters (no pagination for export)
    const result = await this.list(context, tenantId, {
      ...options.filters,
      limit: 10000,  // Max export limit
      offset: 0,
    });

    // Audit log
    await auditService.logExport(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'clients',
      result.data.length,
      options.format
    );

    return {
      data: result.data,
      format: options.format,
    };
  }

  // ==========================================================================
  // ASSIGNMENT OPERATIONS
  // ==========================================================================

  /**
   * Assign client to user
   * Requires: clients_edit
   */
  async assignTo(
    context: RequestContext,
    tenantId: string,
    clientId: string,
    assigneeId: string | null
  ): Promise<Client> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CLIENTS_EDIT);

    if (assigneeId) {
      await validateUserTenant(tenantId, assigneeId);
    }

    return this.update(context, tenantId, clientId, { assigned_to: assigneeId || undefined });
  }
}

export const clientService = new ClientService();
