// ============================================================================
// USER REPOSITORY
// apps/api/src/repositories/user.repository.ts
// ============================================================================

import { BaseRepository, type SoftDeletableEntity, type Filter } from './base.repository.js';
import { query } from '../db/connection.js';
import { parsePostgresError, TenantScopingError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export interface User extends SoftDeletableEntity {
  id: string;
  tenant_id: string;
  email: string;
  password_hash: string;
  name: string;
  name_he: string | null;
  phone: string | null;
  avatar_url: string | null;
  role_id: string;
  is_active: boolean;
  email_verified: boolean;
  last_login_at: Date | null;
  last_login_ip: string | null;
  password_changed_at: Date | null;
  failed_login_attempts: number;
  locked_until: Date | null;
  settings_json: Record<string, unknown>;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

export interface UserWithRole extends User {
  role_name: string;
  role_name_he: string;
}

export type CreateUserData = {
  email: string;
  password_hash: string;
  name: string;
  name_he?: string;
  phone?: string;
  avatar_url?: string;
  role_id: string;
  is_active?: boolean;
  settings_json?: Record<string, unknown>;
};

export type UpdateUserData = Partial<Omit<CreateUserData, 'email' | 'password_hash'>>;

// ============================================================================
// REPOSITORY
// ============================================================================

export class UserRepository extends BaseRepository<User> {
  constructor() {
    super({
      tableName: 'users',
      supportsSoftDelete: true,
    });
  }

  /**
   * Find user by email within tenant
   */
  async findByEmail(tenantId: string, email: string): Promise<User | null> {
    this.validateTenantId(tenantId, 'findByEmail');

    try {
      const result = await query<User>(
        `SELECT * FROM users 
         WHERE tenant_id = $1 AND LOWER(email) = LOWER($2) AND deleted_at IS NULL`,
        [tenantId, email]
      );
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find user by email across ALL tenants (for login)
   * This is a special case that bypasses tenant scoping
   */
  async findByEmailGlobal(email: string): Promise<UserWithRole | null> {
    try {
      const result = await query<UserWithRole>(
        `SELECT u.*, r.name as role_name, r.name_he as role_name_he
         FROM users u
         JOIN roles r ON u.role_id = r.id
         WHERE LOWER(u.email) = LOWER($1) AND u.deleted_at IS NULL`,
        [email]
      );
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get user with role information
   */
  async findByIdWithRole(tenantId: string, id: string): Promise<UserWithRole | null> {
    this.validateTenantId(tenantId, 'findByIdWithRole');

    try {
      const result = await query<UserWithRole>(
        `SELECT u.*, r.name as role_name, r.name_he as role_name_he
         FROM users u
         JOIN roles r ON u.role_id = r.id
         WHERE u.tenant_id = $1 AND u.id = $2 AND u.deleted_at IS NULL`,
        [tenantId, id]
      );
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * List users with role information
   */
  async listWithRoles(
    tenantId: string,
    options?: { 
      limit?: number; 
      offset?: number;
      includeInactive?: boolean;
    }
  ): Promise<UserWithRole[]> {
    this.validateTenantId(tenantId, 'listWithRoles');

    try {
      const limit = options?.limit ?? 100;
      const offset = options?.offset ?? 0;
      const activeClause = options?.includeInactive ? '' : 'AND u.is_active = TRUE';

      const result = await query<UserWithRole>(
        `SELECT u.*, r.name as role_name, r.name_he as role_name_he
         FROM users u
         JOIN roles r ON u.role_id = r.id
         WHERE u.tenant_id = $1 AND u.deleted_at IS NULL ${activeClause}
         ORDER BY u.name ASC
         LIMIT $2 OFFSET $3`,
        [tenantId, limit, offset]
      );
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Create a new user
   */
  async createUser(tenantId: string, data: CreateUserData): Promise<User> {
    this.validateTenantId(tenantId, 'createUser');

    try {
      const result = await query<User>(
        `INSERT INTO users (
          tenant_id, email, password_hash, name, name_he,
          phone, avatar_url, role_id, is_active, settings_json
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        RETURNING *`,
        [
          tenantId,
          data.email.toLowerCase(),
          data.password_hash,
          data.name,
          data.name_he || null,
          data.phone || null,
          data.avatar_url || null,
          data.role_id,
          data.is_active ?? true,
          JSON.stringify(data.settings_json || {}),
        ]
      );
      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Update user's role
   */
  async updateRole(tenantId: string, userId: string, roleId: string): Promise<User> {
    this.validateTenantId(tenantId, 'updateRole');

    try {
      const result = await query<User>(
        `UPDATE users
         SET role_id = $1, updated_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $2 AND id = $3 AND deleted_at IS NULL
         RETURNING *`,
        [roleId, tenantId, userId]
      );

      if (result.rows.length === 0) {
        throw new Error(`User ${userId} not found in tenant ${tenantId}`);
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Update password hash
   */
  async updatePassword(tenantId: string, userId: string, passwordHash: string): Promise<void> {
    this.validateTenantId(tenantId, 'updatePassword');

    try {
      await query(
        `UPDATE users
         SET password_hash = $1, 
             password_changed_at = CURRENT_TIMESTAMP,
             updated_at = CURRENT_TIMESTAMP,
             failed_login_attempts = 0,
             locked_until = NULL
         WHERE tenant_id = $2 AND id = $3 AND deleted_at IS NULL`,
        [passwordHash, tenantId, userId]
      );
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Record successful login
   */
  async recordLogin(tenantId: string, userId: string, ipAddress: string): Promise<void> {
    this.validateTenantId(tenantId, 'recordLogin');

    try {
      await query(
        `UPDATE users
         SET last_login_at = CURRENT_TIMESTAMP,
             last_login_ip = $1,
             failed_login_attempts = 0,
             locked_until = NULL,
             updated_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $2 AND id = $3`,
        [ipAddress, tenantId, userId]
      );
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Record failed login attempt
   */
  async recordFailedLogin(tenantId: string, userId: string): Promise<number> {
    this.validateTenantId(tenantId, 'recordFailedLogin');

    try {
      const result = await query<{ failed_login_attempts: number }>(
        `UPDATE users
         SET failed_login_attempts = failed_login_attempts + 1,
             updated_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $1 AND id = $2
         RETURNING failed_login_attempts`,
        [tenantId, userId]
      );
      return result.rows[0]?.failed_login_attempts || 0;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Lock user account
   */
  async lockAccount(tenantId: string, userId: string, untilDate: Date): Promise<void> {
    this.validateTenantId(tenantId, 'lockAccount');

    try {
      await query(
        `UPDATE users
         SET locked_until = $1, updated_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $2 AND id = $3`,
        [untilDate, tenantId, userId]
      );
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Activate/deactivate user
   */
  async setActive(tenantId: string, userId: string, isActive: boolean): Promise<User> {
    this.validateTenantId(tenantId, 'setActive');

    try {
      const result = await query<User>(
        `UPDATE users
         SET is_active = $1, updated_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $2 AND id = $3 AND deleted_at IS NULL
         RETURNING *`,
        [isActive, tenantId, userId]
      );

      if (result.rows.length === 0) {
        throw new Error(`User ${userId} not found in tenant ${tenantId}`);
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Verify email
   */
  async verifyEmail(tenantId: string, userId: string): Promise<void> {
    this.validateTenantId(tenantId, 'verifyEmail');

    try {
      await query(
        `UPDATE users
         SET email_verified = TRUE, updated_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $1 AND id = $2`,
        [tenantId, userId]
      );
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Count active users in tenant
   */
  async countActive(tenantId: string): Promise<number> {
    this.validateTenantId(tenantId, 'countActive');

    try {
      const result = await query<{ count: number }>(
        `SELECT COUNT(*)::int as count FROM users
         WHERE tenant_id = $1 AND deleted_at IS NULL AND is_active = TRUE`,
        [tenantId]
      );
      return result.rows[0]?.count || 0;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Check if email is available within tenant
   */
  async isEmailAvailable(tenantId: string, email: string, excludeUserId?: string): Promise<boolean> {
    this.validateTenantId(tenantId, 'isEmailAvailable');

    try {
      const excludeClause = excludeUserId ? 'AND id != $3' : '';
      const params = excludeUserId 
        ? [tenantId, email.toLowerCase(), excludeUserId]
        : [tenantId, email.toLowerCase()];

      const result = await query<{ exists: boolean }>(
        `SELECT EXISTS (
          SELECT 1 FROM users 
          WHERE tenant_id = $1 AND LOWER(email) = $2 AND deleted_at IS NULL ${excludeClause}
        ) as exists`,
        params
      );
      return !result.rows[0]?.exists;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}

export const userRepository = new UserRepository();
