// ============================================================================
// DOCUMENT REPOSITORY
// apps/api/src/repositories/document.repository.ts
// 
// Repository for document metadata with tenant scoping
// ============================================================================

import { BaseRepository, type SoftDeletableEntity, type Filter } from './base.repository.js';
import { query } from '../db/connection.js';
import { parsePostgresError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export interface Document extends SoftDeletableEntity {
  id: string;
  tenant_id: string;
  case_id: string | null;
  client_id: string | null;
  title: string;
  title_he: string | null;
  description: string | null;
  document_type: 'contract' | 'pleading' | 'correspondence' | 'evidence' | 'court_filing' | 'invoice' | 'receipt' | 'other';
  file_name: string;
  file_size: number;
  mime_type: string;
  storage_path: string;
  storage_provider: 'local' | 's3' | 'azure' | 'gcs';
  version: number;
  parent_document_id: string | null;
  is_template: boolean;
  is_confidential: boolean;
  tags: string[] | null;
  ocr_text: string | null;
  checksum: string | null;
  uploaded_by: string;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

export type CreateDocumentData = Omit<Document, 'id' | 'tenant_id' | 'created_at' | 'updated_at' | 'deleted_at'>;
export type UpdateDocumentData = Partial<Pick<Document, 'title' | 'title_he' | 'description' | 'document_type' | 'tags' | 'is_confidential'>>;

export interface DocumentWithDetails extends Document {
  case_title: string | null;
  case_number: string | null;
  client_name: string | null;
  uploaded_by_name: string | null;
}

// ============================================================================
// REPOSITORY
// ============================================================================

export class DocumentRepository extends BaseRepository<Document> {
  constructor() {
    super({
      tableName: 'documents',
      supportsSoftDelete: true,
    });
  }

  /**
   * Find documents by case
   */
  async findByCase(
    tenantId: string, 
    caseId: string,
    options?: { limit?: number; offset?: number; documentType?: Document['document_type'] }
  ): Promise<Document[]> {
    this.validateTenantId(tenantId, 'findByCase');

    const filters: Filter[] = [{ field: 'case_id', operator: '=', value: caseId }];
    if (options?.documentType) {
      filters.push({ field: 'document_type', operator: '=', value: options.documentType });
    }

    const result = await this.list(tenantId, {
      filters,
      sort: { field: 'created_at', direction: 'DESC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 },
    });

    return result.data;
  }

  /**
   * Find documents by client
   */
  async findByClient(
    tenantId: string, 
    clientId: string,
    options?: { limit?: number; offset?: number; documentType?: Document['document_type'] }
  ): Promise<Document[]> {
    this.validateTenantId(tenantId, 'findByClient');

    const filters: Filter[] = [{ field: 'client_id', operator: '=', value: clientId }];
    if (options?.documentType) {
      filters.push({ field: 'document_type', operator: '=', value: options.documentType });
    }

    const result = await this.list(tenantId, {
      filters,
      sort: { field: 'created_at', direction: 'DESC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 },
    });

    return result.data;
  }

  /**
   * Get document with full details
   */
  async findByIdWithDetails(tenantId: string, documentId: string): Promise<DocumentWithDetails | null> {
    this.validateTenantId(tenantId, 'findByIdWithDetails');

    try {
      const text = `
        SELECT 
          d.*,
          c.title as case_title,
          c.case_number,
          cl.name as client_name,
          u.name as uploaded_by_name
        FROM documents d
        LEFT JOIN cases c ON d.case_id = c.id AND d.tenant_id = c.tenant_id
        LEFT JOIN clients cl ON d.client_id = cl.id AND d.tenant_id = cl.tenant_id
        LEFT JOIN users u ON d.uploaded_by = u.id AND d.tenant_id = u.tenant_id
        WHERE d.tenant_id = $1 AND d.id = $2 AND d.deleted_at IS NULL
      `;
      const result = await query<DocumentWithDetails>(text, [tenantId, documentId]);
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Search documents by title or OCR text
   */
  async search(
    tenantId: string, 
    searchTerm: string,
    options?: { limit?: number; caseId?: string; clientId?: string }
  ): Promise<Document[]> {
    this.validateTenantId(tenantId, 'search');

    try {
      let text = `
        SELECT * FROM documents
        WHERE tenant_id = $1
          AND deleted_at IS NULL
          AND (
            title ILIKE $2
            OR title_he ILIKE $2
            OR description ILIKE $2
            OR file_name ILIKE $2
            OR ocr_text ILIKE $2
          )
      `;
      const params: unknown[] = [tenantId, `%${searchTerm}%`];

      if (options?.caseId) {
        text += ` AND case_id = $${params.length + 1}`;
        params.push(options.caseId);
      }
      if (options?.clientId) {
        text += ` AND client_id = $${params.length + 1}`;
        params.push(options.clientId);
      }

      text += ` ORDER BY created_at DESC LIMIT $${params.length + 1}`;
      params.push(options?.limit ?? 50);

      const result = await query<Document>(text, params);
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find document versions (all versions of a document)
   */
  async findVersions(tenantId: string, parentDocumentId: string): Promise<Document[]> {
    this.validateTenantId(tenantId, 'findVersions');

    try {
      const text = `
        SELECT * FROM documents
        WHERE tenant_id = $1
          AND deleted_at IS NULL
          AND (id = $2 OR parent_document_id = $2)
        ORDER BY version ASC
      `;
      const result = await query<Document>(text, [tenantId, parentDocumentId]);
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get templates
   */
  async findTemplates(
    tenantId: string,
    options?: { documentType?: Document['document_type']; limit?: number }
  ): Promise<Document[]> {
    this.validateTenantId(tenantId, 'findTemplates');

    const filters: Filter[] = [{ field: 'is_template', operator: '=', value: true }];
    if (options?.documentType) {
      filters.push({ field: 'document_type', operator: '=', value: options.documentType });
    }

    const result = await this.list(tenantId, {
      filters,
      sort: { field: 'title', direction: 'ASC' },
      pagination: { limit: options?.limit ?? 100, offset: 0 },
    });

    return result.data;
  }

  /**
   * Get storage usage for tenant
   */
  async getStorageUsage(tenantId: string): Promise<{ totalFiles: number; totalBytes: number }> {
    this.validateTenantId(tenantId, 'getStorageUsage');

    try {
      const text = `
        SELECT 
          COUNT(*) as total_files,
          COALESCE(SUM(file_size), 0) as total_bytes
        FROM documents
        WHERE tenant_id = $1 AND deleted_at IS NULL
      `;
      const result = await query<{ total_files: string; total_bytes: string }>(text, [tenantId]);
      return {
        totalFiles: parseInt(result.rows[0]?.total_files || '0', 10),
        totalBytes: parseInt(result.rows[0]?.total_bytes || '0', 10),
      };
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find by checksum (for deduplication)
   */
  async findByChecksum(tenantId: string, checksum: string): Promise<Document | null> {
    this.validateTenantId(tenantId, 'findByChecksum');

    return this.findOne(tenantId, [
      { field: 'checksum', operator: '=', value: checksum }
    ]);
  }

  /**
   * Get recent documents
   */
  async findRecent(
    tenantId: string,
    options?: { limit?: number; userId?: string }
  ): Promise<Document[]> {
    this.validateTenantId(tenantId, 'findRecent');

    const filters: Filter[] = [];
    if (options?.userId) {
      filters.push({ field: 'uploaded_by', operator: '=', value: options.userId });
    }

    const result = await this.list(tenantId, {
      filters,
      sort: { field: 'created_at', direction: 'DESC' },
      pagination: { limit: options?.limit ?? 20, offset: 0 },
    });

    return result.data;
  }
}

// Export singleton instance
export const documentRepository = new DocumentRepository();
