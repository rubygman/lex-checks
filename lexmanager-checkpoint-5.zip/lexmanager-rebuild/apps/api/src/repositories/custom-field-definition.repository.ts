// ============================================================================
// CUSTOM FIELD DEFINITION REPOSITORY
// apps/api/src/repositories/custom-field-definition.repository.ts
// ============================================================================

import { BaseRepository, type SoftDeletableEntity } from './base.repository.js';
import { query } from '../db/connection.js';
import { parsePostgresError, NotFoundError, DuplicateError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export type CustomFieldType = 
  | 'text' 
  | 'number' 
  | 'boolean' 
  | 'date' 
  | 'datetime' 
  | 'select' 
  | 'multi_select' 
  | 'json';

export type CustomFieldEntityType = 
  | 'clients' 
  | 'cases' 
  | 'tasks' 
  | 'documents' 
  | 'invoices' 
  | 'users';

export interface SelectOption {
  value: string;
  label: string;
  label_he?: string;
  color?: string;
  icon?: string;
}

export interface FieldOptions {
  options?: SelectOption[];
  min?: number;
  max?: number;
  step?: number;
  pattern?: string;
  placeholder?: string;
  placeholder_he?: string;
  helpText?: string;
  helpText_he?: string;
}

export interface CustomFieldDefinition extends SoftDeletableEntity {
  id: string;
  tenant_id: string;
  entity_type: CustomFieldEntityType;
  field_key: string;
  field_type: CustomFieldType;
  label: string;
  label_he: string | null;
  description: string | null;
  is_required: boolean;
  is_searchable: boolean;
  display_order: number;
  default_value_json: Record<string, unknown> | null;
  options_json: FieldOptions | null;
  validation_json: Record<string, unknown> | null;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

export interface CreateDefinitionData {
  entity_type: CustomFieldEntityType;
  field_key: string;
  field_type: CustomFieldType;
  label: string;
  label_he?: string;
  description?: string;
  is_required?: boolean;
  is_searchable?: boolean;
  display_order?: number;
  default_value_json?: Record<string, unknown>;
  options_json?: FieldOptions;
  validation_json?: Record<string, unknown>;
}

export interface UpdateDefinitionData {
  label?: string;
  label_he?: string;
  description?: string;
  is_required?: boolean;
  is_searchable?: boolean;
  display_order?: number;
  default_value_json?: Record<string, unknown>;
  options_json?: FieldOptions;
  validation_json?: Record<string, unknown>;
}

// ============================================================================
// REPOSITORY
// ============================================================================

export class CustomFieldDefinitionRepository extends BaseRepository<CustomFieldDefinition> {
  constructor() {
    super({
      tableName: 'custom_field_definitions',
      supportsSoftDelete: true,
    });
  }

  /**
   * Create a new field definition
   */
  async createDefinition(tenantId: string, data: CreateDefinitionData): Promise<CustomFieldDefinition> {
    this.validateTenantId(tenantId, 'createDefinition');

    try {
      // Get next display order if not specified
      let displayOrder = data.display_order;
      if (displayOrder === undefined) {
        const maxResult = await query<{ max: number }>(
          `SELECT COALESCE(MAX(display_order), 0) + 1 as max
           FROM custom_field_definitions
           WHERE tenant_id = $1 AND entity_type = $2 AND deleted_at IS NULL`,
          [tenantId, data.entity_type]
        );
        displayOrder = maxResult.rows[0]?.max || 1;
      }

      const result = await query<CustomFieldDefinition>(
        `INSERT INTO custom_field_definitions (
          tenant_id, entity_type, field_key, field_type, label, label_he,
          description, is_required, is_searchable, display_order,
          default_value_json, options_json, validation_json
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        RETURNING *`,
        [
          tenantId,
          data.entity_type,
          data.field_key,
          data.field_type,
          data.label,
          data.label_he || null,
          data.description || null,
          data.is_required ?? false,
          data.is_searchable ?? false,
          displayOrder,
          data.default_value_json ? JSON.stringify(data.default_value_json) : null,
          data.options_json ? JSON.stringify(data.options_json) : null,
          data.validation_json ? JSON.stringify(data.validation_json) : null,
        ]
      );

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find definition by field key
   */
  async findByFieldKey(
    tenantId: string,
    entityType: CustomFieldEntityType,
    fieldKey: string
  ): Promise<CustomFieldDefinition | null> {
    this.validateTenantId(tenantId, 'findByFieldKey');

    try {
      const result = await query<CustomFieldDefinition>(
        `SELECT * FROM custom_field_definitions
         WHERE tenant_id = $1 AND entity_type = $2 AND field_key = $3 AND deleted_at IS NULL`,
        [tenantId, entityType, fieldKey]
      );

      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find definition by field key, throw if not found
   */
  async findByFieldKeyOrFail(
    tenantId: string,
    entityType: CustomFieldEntityType,
    fieldKey: string
  ): Promise<CustomFieldDefinition> {
    const definition = await this.findByFieldKey(tenantId, entityType, fieldKey);
    if (!definition) {
      throw new NotFoundError('CustomFieldDefinition', fieldKey);
    }
    return definition;
  }

  /**
   * List definitions for an entity type
   */
  async listByEntityType(
    tenantId: string,
    entityType: CustomFieldEntityType,
    options?: { includeDeleted?: boolean }
  ): Promise<CustomFieldDefinition[]> {
    this.validateTenantId(tenantId, 'listByEntityType');

    try {
      const deletedClause = options?.includeDeleted ? '' : 'AND deleted_at IS NULL';
      
      const result = await query<CustomFieldDefinition>(
        `SELECT * FROM custom_field_definitions
         WHERE tenant_id = $1 AND entity_type = $2 ${deletedClause}
         ORDER BY display_order ASC, field_key ASC`,
        [tenantId, entityType]
      );

      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Update definition
   */
  async updateDefinition(
    tenantId: string,
    id: string,
    data: UpdateDefinitionData
  ): Promise<CustomFieldDefinition> {
    this.validateTenantId(tenantId, 'updateDefinition');

    const fields: string[] = [];
    const values: unknown[] = [];
    let paramIndex = 1;

    if (data.label !== undefined) {
      fields.push(`label = $${paramIndex++}`);
      values.push(data.label);
    }
    if (data.label_he !== undefined) {
      fields.push(`label_he = $${paramIndex++}`);
      values.push(data.label_he);
    }
    if (data.description !== undefined) {
      fields.push(`description = $${paramIndex++}`);
      values.push(data.description);
    }
    if (data.is_required !== undefined) {
      fields.push(`is_required = $${paramIndex++}`);
      values.push(data.is_required);
    }
    if (data.is_searchable !== undefined) {
      fields.push(`is_searchable = $${paramIndex++}`);
      values.push(data.is_searchable);
    }
    if (data.display_order !== undefined) {
      fields.push(`display_order = $${paramIndex++}`);
      values.push(data.display_order);
    }
    if (data.default_value_json !== undefined) {
      fields.push(`default_value_json = $${paramIndex++}`);
      values.push(JSON.stringify(data.default_value_json));
    }
    if (data.options_json !== undefined) {
      fields.push(`options_json = $${paramIndex++}`);
      values.push(JSON.stringify(data.options_json));
    }
    if (data.validation_json !== undefined) {
      fields.push(`validation_json = $${paramIndex++}`);
      values.push(JSON.stringify(data.validation_json));
    }

    if (fields.length === 0) {
      return this.findByIdOrFail(tenantId, id);
    }

    fields.push(`updated_at = CURRENT_TIMESTAMP`);
    values.push(tenantId);
    values.push(id);

    try {
      const result = await query<CustomFieldDefinition>(
        `UPDATE custom_field_definitions
         SET ${fields.join(', ')}
         WHERE tenant_id = $${paramIndex++} AND id = $${paramIndex} AND deleted_at IS NULL
         RETURNING *`,
        values
      );

      if (result.rows.length === 0) {
        throw new NotFoundError('CustomFieldDefinition', id);
      }

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Reorder definitions
   */
  async reorder(
    tenantId: string,
    entityType: CustomFieldEntityType,
    orderedIds: string[]
  ): Promise<void> {
    this.validateTenantId(tenantId, 'reorder');

    try {
      for (let i = 0; i < orderedIds.length; i++) {
        await query(
          `UPDATE custom_field_definitions
           SET display_order = $1, updated_at = CURRENT_TIMESTAMP
           WHERE tenant_id = $2 AND entity_type = $3 AND id = $4`,
          [i + 1, tenantId, entityType, orderedIds[i]]
        );
      }
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Check if field key is available
   */
  async isFieldKeyAvailable(
    tenantId: string,
    entityType: CustomFieldEntityType,
    fieldKey: string,
    excludeId?: string
  ): Promise<boolean> {
    this.validateTenantId(tenantId, 'isFieldKeyAvailable');

    try {
      const excludeClause = excludeId ? 'AND id != $4' : '';
      const params = excludeId 
        ? [tenantId, entityType, fieldKey, excludeId]
        : [tenantId, entityType, fieldKey];

      const result = await query<{ exists: boolean }>(
        `SELECT EXISTS (
          SELECT 1 FROM custom_field_definitions
          WHERE tenant_id = $1 AND entity_type = $2 AND field_key = $3 AND deleted_at IS NULL ${excludeClause}
        ) as exists`,
        params
      );

      return !result.rows[0]?.exists;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}

export const customFieldDefinitionRepository = new CustomFieldDefinitionRepository();
