#!/bin/bash
# ============================================
# LexManager Database Seed Script
# ============================================

set -e

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '#' | xargs)
fi

echo "🌱 Seeding database with initial data..."

# Run seed using the API's db:seed script
pnpm --filter @lexmanager/api db:seed

echo "✅ Database seeded successfully!"
