// ============================================================================
// TRUST ROUTES
// apps/api/src/routes/trust.routes.ts
// 
// Trust accounts and transactions with RBAC and audit
// NOTE: trust_transactions is INSERT-ONLY (immutable)
// ============================================================================

import { Router } from 'express';
import { trustService } from '../services/trust.service.js';
import {
  initializeContext,
  resolveTenantFromHeader,
  requireTenant,
  authParser,
  requireAuth,
  requireTenantAccess,
  requirePermission,
} from '../middleware/index.js';
import {
  validate,
  validateAll,
  createTrustAccountSchema,
  trustDepositSchema,
  trustWithdrawalSchema,
  trustTransferSchema,
  idParamSchema,
  paginationSchema,
  z,
} from '../validation/index.js';
import { asyncHandler, sendSuccess } from '../errors/index.js';
import { PERMISSIONS } from '../services/rbac.service.js';

const router = Router();

// All routes require tenant context and authentication
router.use(initializeContext());
router.use(resolveTenantFromHeader());
router.use(requireTenant());
router.use(authParser());
router.use(requireAuth());
router.use(requireTenantAccess());

// ============================================================================
// GET /trust/accounts - List trust accounts
// ============================================================================

router.get(
  '/accounts',
  requirePermission(PERMISSIONS.TRUST_VIEW),
  asyncHandler(async (req, res) => {
    const { clientId } = req.query as any;

    const accounts = await trustService.listAccounts(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      { clientId }
    );

    sendSuccess(res, req, accounts);
  })
);

// ============================================================================
// POST /trust/accounts - Create trust account
// ============================================================================

router.post(
  '/accounts',
  requirePermission(PERMISSIONS.TRUST_CREATE),
  validate(createTrustAccountSchema, 'body'),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const account = await trustService.createAccount(
      context,
      req.auth!.tenantId,
      {
        client_id: req.body.clientId,
        account_name: req.body.accountName,
        account_number: req.body.accountNumber,
        bank_name: req.body.bankName,
        currency: req.body.currency || 'ILS',
      }
    );

    sendSuccess(res, req, account, 201);
  })
);

// ============================================================================
// GET /trust/accounts/:id - Get trust account by ID
// ============================================================================

router.get(
  '/accounts/:id',
  requirePermission(PERMISSIONS.TRUST_VIEW),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const account = await trustService.getAccountById(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      req.params.id
    );

    sendSuccess(res, req, account);
  })
);

// ============================================================================
// POST /trust/accounts/:id/deposit - Deposit to trust account
// ============================================================================

router.post(
  '/accounts/:id/deposit',
  requirePermission(PERMISSIONS.TRUST_DEPOSIT),
  validateAll({
    params: idParamSchema,
    body: trustDepositSchema,
  }),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const transaction = await trustService.deposit(
      context,
      req.auth!.tenantId,
      req.params.id,
      {
        amount: req.body.amount,
        description: req.body.description,
        reference: req.body.reference,
        case_id: req.body.caseId,
      }
    );

    sendSuccess(res, req, transaction, 201);
  })
);

// ============================================================================
// POST /trust/accounts/:id/withdraw - Withdraw from trust account
// ============================================================================

router.post(
  '/accounts/:id/withdraw',
  requirePermission(PERMISSIONS.TRUST_WITHDRAW),
  validateAll({
    params: idParamSchema,
    body: trustWithdrawalSchema,
  }),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    const transaction = await trustService.withdraw(
      context,
      req.auth!.tenantId,
      req.params.id,
      {
        amount: req.body.amount,
        description: req.body.description,
        reference: req.body.reference,
        case_id: req.body.caseId,
      }
    );

    sendSuccess(res, req, transaction, 201);
  })
);

// ============================================================================
// GET /trust/accounts/:id/transactions - Get transactions for account
// ============================================================================

router.get(
  '/accounts/:id/transactions',
  requirePermission(PERMISSIONS.TRUST_VIEW),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const { limit, offset } = req.query as any;

    const transactions = await trustService.getAccountTransactions(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      req.params.id,
      { limit: limit ? parseInt(limit, 10) : 100, offset: offset ? parseInt(offset, 10) : 0 }
    );

    sendSuccess(res, req, transactions);
  })
);

// ============================================================================
// GET /trust/accounts/:id/reconcile - Get reconciliation report
// ============================================================================

router.get(
  '/accounts/:id/reconcile',
  requirePermission(PERMISSIONS.TRUST_VIEW),
  validate(idParamSchema, 'params'),
  asyncHandler(async (req, res) => {
    const { startDate, endDate } = req.query as any;

    const report = await trustService.reconcile(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      req.params.id,
      {
        startDate: startDate ? new Date(startDate) : undefined,
        endDate: endDate ? new Date(endDate) : undefined,
      }
    );

    sendSuccess(res, req, report);
  })
);

// ============================================================================
// GET /trust/transactions - List all trust transactions
// ============================================================================

router.get(
  '/transactions',
  requirePermission(PERMISSIONS.TRUST_VIEW),
  asyncHandler(async (req, res) => {
    const { accountId, clientId, caseId, limit, offset } = req.query as any;

    const transactions = await trustService.listTransactions(
      {
        userId: req.auth!.userId,
        tenantId: req.auth!.tenantId,
        ipAddress: req.context.ipAddress,
        userAgent: req.context.userAgent,
      },
      req.auth!.tenantId,
      {
        accountId,
        clientId,
        caseId,
        limit: limit ? parseInt(limit, 10) : 100,
        offset: offset ? parseInt(offset, 10) : 0,
      }
    );

    sendSuccess(res, req, transactions);
  })
);

// ============================================================================
// POST /trust/transactions - Create a trust transaction (INSERT-ONLY)
// ============================================================================

router.post(
  '/transactions',
  requirePermission(PERMISSIONS.TRUST_DEPOSIT),
  asyncHandler(async (req, res) => {
    const context = {
      userId: req.auth!.userId,
      tenantId: req.auth!.tenantId,
      ipAddress: req.context.ipAddress,
      userAgent: req.context.userAgent,
    };

    // Route to deposit or withdraw based on transaction type
    if (req.body.transactionType === 'deposit') {
      const transaction = await trustService.deposit(
        context,
        req.auth!.tenantId,
        req.body.accountId,
        {
          amount: req.body.amount,
          description: req.body.description,
          reference: req.body.reference,
          case_id: req.body.caseId,
        }
      );
      sendSuccess(res, req, transaction, 201);
    } else if (req.body.transactionType === 'withdrawal') {
      const transaction = await trustService.withdraw(
        context,
        req.auth!.tenantId,
        req.body.accountId,
        {
          amount: req.body.amount,
          description: req.body.description,
          reference: req.body.reference,
          case_id: req.body.caseId,
        }
      );
      sendSuccess(res, req, transaction, 201);
    } else {
      sendSuccess(res, req, { message: 'Invalid transaction type' }, 400);
    }
  })
);

export default router;
