// ============================================================================
// AUTHORIZER MODULE
// apps/api/src/auth/authorizer.ts
// 
// Central authorization module for server-side permission enforcement
// All services MUST use this module to verify access
// ============================================================================

import { rbacService, PERMISSIONS, type PermissionCode } from '../services/rbac.service.js';
import { userRepository, type User, type UserWithRole } from '../repositories/user.repository.js';
import { tenantRepository } from '../repositories/tenant.repository.js';
import { query } from '../db/connection.js';

// ============================================================================
// ERROR CLASSES
// ============================================================================

/**
 * Thrown when user is not authenticated
 */
export class AuthenticationError extends Error {
  public readonly statusCode = 401;
  public readonly code = 'AUTHENTICATION_REQUIRED';

  constructor(message: string = 'Authentication required') {
    super(message);
    this.name = 'AuthenticationError';
  }
}

/**
 * Thrown when user is authenticated but lacks permission
 */
export class AuthorizationError extends Error {
  public readonly statusCode = 403;
  public readonly code = 'PERMISSION_DENIED';
  public readonly requiredPermission?: string;

  constructor(message: string, requiredPermission?: string) {
    super(message);
    this.name = 'AuthorizationError';
    this.requiredPermission = requiredPermission;
  }
}

/**
 * Thrown when user tries to access another tenant's data
 */
export class TenantAccessError extends Error {
  public readonly statusCode = 403;
  public readonly code = 'TENANT_ACCESS_DENIED';

  constructor(message: string = 'Access to this tenant is denied') {
    super(message);
    this.name = 'TenantAccessError';
  }
}

// ============================================================================
// TYPES
// ============================================================================

/**
 * Authenticated user context passed to all service methods
 */
export interface AuthContext {
  userId: string;
  tenantId: string;
  roleId: string;
  roleName: string;
  email: string;
  isActive: boolean;
  permissions?: Set<string>;  // Cached permissions
}

/**
 * Request context with optional auth (for public endpoints)
 */
export interface RequestContext {
  auth?: AuthContext;
  ipAddress?: string;
  userAgent?: string;
  requestId?: string;
}

// ============================================================================
// AUTHORIZER CLASS
// ============================================================================

export class Authorizer {
  // Permission cache per user session
  private userPermissionsCache = new Map<string, Set<string>>();
  private cacheExpiry = new Map<string, number>();
  private readonly CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

  // ==========================================================================
  // AUTHENTICATION
  // ==========================================================================

  /**
   * Require user to be authenticated
   * Throws AuthenticationError if not authenticated
   */
  requireAuth(context: RequestContext): AuthContext {
    if (!context.auth) {
      throw new AuthenticationError('Authentication required');
    }

    if (!context.auth.isActive) {
      throw new AuthenticationError('User account is deactivated');
    }

    return context.auth;
  }

  /**
   * Build auth context from user data
   */
  async buildAuthContext(user: UserWithRole): Promise<AuthContext> {
    const permissions = await this.loadUserPermissions(user.tenant_id, user.id, user.role_id);

    return {
      userId: user.id,
      tenantId: user.tenant_id,
      roleId: user.role_id,
      roleName: user.role_name,
      email: user.email,
      isActive: user.is_active,
      permissions,
    };
  }

  /**
   * Load and cache user permissions
   */
  private async loadUserPermissions(
    tenantId: string,
    userId: string,
    roleId: string
  ): Promise<Set<string>> {
    const cacheKey = `${tenantId}:${userId}`;

    // Check cache
    const cached = this.userPermissionsCache.get(cacheKey);
    const expiry = this.cacheExpiry.get(cacheKey);

    if (cached && expiry && Date.now() < expiry) {
      return cached;
    }

    // Load from RBAC service
    const permissions = await rbacService.loadPermissionsForRole(roleId);
    const permissionSet = new Set(permissions);

    // Cache
    this.userPermissionsCache.set(cacheKey, permissionSet);
    this.cacheExpiry.set(cacheKey, Date.now() + this.CACHE_TTL_MS);

    return permissionSet;
  }

  /**
   * Clear permission cache for a user (call after role change)
   */
  clearUserCache(tenantId: string, userId: string): void {
    const cacheKey = `${tenantId}:${userId}`;
    this.userPermissionsCache.delete(cacheKey);
    this.cacheExpiry.delete(cacheKey);
  }

  /**
   * Clear all caches (call after role permission changes)
   */
  clearAllCaches(): void {
    this.userPermissionsCache.clear();
    this.cacheExpiry.clear();
  }

  // ==========================================================================
  // AUTHORIZATION
  // ==========================================================================

  /**
   * Require user has a specific permission
   * Throws AuthorizationError if permission is denied
   */
  async requirePermission(
    context: RequestContext,
    permissionCode: PermissionCode | string
  ): Promise<AuthContext> {
    const auth = this.requireAuth(context);

    // Use cached permissions if available
    let permissions = auth.permissions;
    if (!permissions) {
      permissions = await this.loadUserPermissions(auth.tenantId, auth.userId, auth.roleId);
      auth.permissions = permissions;
    }

    if (!permissions.has(permissionCode)) {
      throw new AuthorizationError(
        `Permission denied: ${permissionCode} is required for this action`,
        permissionCode
      );
    }

    return auth;
  }

  /**
   * Require user has any of the specified permissions
   */
  async requireAnyPermission(
    context: RequestContext,
    permissionCodes: (PermissionCode | string)[]
  ): Promise<AuthContext> {
    const auth = this.requireAuth(context);

    let permissions = auth.permissions;
    if (!permissions) {
      permissions = await this.loadUserPermissions(auth.tenantId, auth.userId, auth.roleId);
      auth.permissions = permissions;
    }

    const hasAny = permissionCodes.some(code => permissions!.has(code));
    if (!hasAny) {
      throw new AuthorizationError(
        `Permission denied: one of [${permissionCodes.join(', ')}] is required`,
        permissionCodes[0]
      );
    }

    return auth;
  }

  /**
   * Require user has all of the specified permissions
   */
  async requireAllPermissions(
    context: RequestContext,
    permissionCodes: (PermissionCode | string)[]
  ): Promise<AuthContext> {
    const auth = this.requireAuth(context);

    let permissions = auth.permissions;
    if (!permissions) {
      permissions = await this.loadUserPermissions(auth.tenantId, auth.userId, auth.roleId);
      auth.permissions = permissions;
    }

    const missing = permissionCodes.filter(code => !permissions!.has(code));
    if (missing.length > 0) {
      throw new AuthorizationError(
        `Permission denied: missing required permissions [${missing.join(', ')}]`,
        missing[0]
      );
    }

    return auth;
  }

  /**
   * Check if user has a permission (non-throwing)
   */
  async hasPermission(
    context: RequestContext,
    permissionCode: PermissionCode | string
  ): Promise<boolean> {
    if (!context.auth) return false;

    let permissions = context.auth.permissions;
    if (!permissions) {
      permissions = await this.loadUserPermissions(
        context.auth.tenantId,
        context.auth.userId,
        context.auth.roleId
      );
      context.auth.permissions = permissions;
    }

    return permissions.has(permissionCode);
  }

  // ==========================================================================
  // TENANT ACCESS
  // ==========================================================================

  /**
   * Require user has access to the specified tenant
   */
  requireTenantAccess(context: RequestContext, tenantId: string): AuthContext {
    const auth = this.requireAuth(context);

    if (auth.tenantId !== tenantId) {
      throw new TenantAccessError(
        `User does not have access to tenant ${tenantId}`
      );
    }

    return auth;
  }

  /**
   * Validate tenant access and return auth context with verified tenant
   */
  async requireTenantAccessWithValidation(
    context: RequestContext,
    tenantId: string
  ): Promise<AuthContext> {
    const auth = this.requireTenantAccess(context, tenantId);

    // Verify tenant exists and is active
    const tenant = await tenantRepository.findById(tenantId);
    if (!tenant) {
      throw new TenantAccessError('Tenant not found');
    }
    if (!tenant.is_active) {
      throw new TenantAccessError('Tenant is deactivated');
    }

    return auth;
  }

  // ==========================================================================
  // RESOURCE OWNERSHIP
  // ==========================================================================

  /**
   * Require user owns the resource OR has override permission
   * Useful for "edit own" vs "edit all" scenarios
   */
  async requireOwnershipOrPermission(
    context: RequestContext,
    resourceOwnerId: string,
    overridePermission: PermissionCode | string
  ): Promise<AuthContext> {
    const auth = this.requireAuth(context);

    // Owner can always access
    if (auth.userId === resourceOwnerId) {
      return auth;
    }

    // Otherwise, need override permission
    return this.requirePermission(context, overridePermission);
  }

  /**
   * Check if user can edit resource (owns it or has edit_all permission)
   */
  async canEdit(
    context: RequestContext,
    resourceOwnerId: string,
    editOwnPermission: PermissionCode | string,
    editAllPermission: PermissionCode | string
  ): Promise<boolean> {
    if (!context.auth) return false;

    // Check if owner and has edit_own
    if (context.auth.userId === resourceOwnerId) {
      return this.hasPermission(context, editOwnPermission);
    }

    // Check if has edit_all
    return this.hasPermission(context, editAllPermission);
  }

  // ==========================================================================
  // ADMIN CHECKS
  // ==========================================================================

  /**
   * Require user is an admin
   */
  requireAdmin(context: RequestContext): AuthContext {
    const auth = this.requireAuth(context);

    if (auth.roleName !== 'admin') {
      throw new AuthorizationError('Admin access required');
    }

    return auth;
  }

  /**
   * Check if user is admin (non-throwing)
   */
  isAdmin(context: RequestContext): boolean {
    return context.auth?.roleName === 'admin';
  }

  // ==========================================================================
  // COMBINED CHECKS
  // ==========================================================================

  /**
   * Full authorization check: auth + tenant + permission
   */
  async authorize(
    context: RequestContext,
    tenantId: string,
    permissionCode: PermissionCode | string
  ): Promise<AuthContext> {
    this.requireTenantAccess(context, tenantId);
    return this.requirePermission(context, permissionCode);
  }

  /**
   * Create a scoped authorizer for a specific tenant
   * Useful for service methods that operate on a known tenant
   */
  forTenant(context: RequestContext, tenantId: string): TenantAuthorizer {
    this.requireTenantAccess(context, tenantId);
    return new TenantAuthorizer(this, context, tenantId);
  }
}

// ============================================================================
// TENANT-SCOPED AUTHORIZER
// ============================================================================

/**
 * Authorizer scoped to a specific tenant
 * Provides cleaner API for service methods
 */
export class TenantAuthorizer {
  constructor(
    private authorizer: Authorizer,
    private context: RequestContext,
    public readonly tenantId: string
  ) {}

  get auth(): AuthContext {
    return this.authorizer.requireAuth(this.context);
  }

  get userId(): string {
    return this.auth.userId;
  }

  async require(permission: PermissionCode | string): Promise<void> {
    await this.authorizer.requirePermission(this.context, permission);
  }

  async requireAny(permissions: (PermissionCode | string)[]): Promise<void> {
    await this.authorizer.requireAnyPermission(this.context, permissions);
  }

  async requireAll(permissions: (PermissionCode | string)[]): Promise<void> {
    await this.authorizer.requireAllPermissions(this.context, permissions);
  }

  async has(permission: PermissionCode | string): Promise<boolean> {
    return this.authorizer.hasPermission(this.context, permission);
  }

  async requireOwnerOrPermission(ownerId: string, permission: PermissionCode | string): Promise<void> {
    await this.authorizer.requireOwnershipOrPermission(this.context, ownerId, permission);
  }

  requireAdmin(): void {
    this.authorizer.requireAdmin(this.context);
  }

  isAdmin(): boolean {
    return this.authorizer.isAdmin(this.context);
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const authorizer = new Authorizer();

// ============================================================================
// RE-EXPORT PERMISSIONS FOR CONVENIENCE
// ============================================================================

export { PERMISSIONS, type PermissionCode } from '../services/rbac.service.js';
