-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 008 DOWN: Password Reset Tokens Enhancements Rollback
-- ============================================================================

BEGIN;

-- Drop trigger
DROP TRIGGER IF EXISTS trg_password_reset_tokens_updated_at ON password_reset_tokens;

-- Drop trigger function
DROP FUNCTION IF EXISTS update_password_reset_tokens_updated_at();

-- Drop cleanup function
DROP FUNCTION IF EXISTS cleanup_expired_password_reset_tokens();

-- Drop new indexes (keep the ones from 007)
DROP INDEX IF EXISTS idx_password_reset_tokens_expires;
DROP INDEX IF EXISTS idx_password_reset_tokens_unused;

-- Note: We do NOT drop the table here as it was created in 007
-- The table and its base indexes (hash, user) are managed by 007

COMMIT;
