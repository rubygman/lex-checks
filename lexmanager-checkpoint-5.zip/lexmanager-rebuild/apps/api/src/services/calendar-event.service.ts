// ============================================================================
// CALENDAR EVENT SERVICE
// apps/api/src/services/calendar-event.service.ts
// 
// All methods require appropriate permissions via Authorizer
// ============================================================================

import { calendarEventRepository, type CalendarEvent } from '../repositories/index.js';
import { authorizer, PERMISSIONS, type RequestContext } from '../auth/authorizer.js';
import { auditService } from './audit.service.js';
import { softDeleteService } from './soft-delete.service.js';
import { validateCaseTenant, validateClientTenant, validateUserTenant } from '../utils/tenant-validation.js';

// ============================================================================
// TYPES
// ============================================================================

export interface CreateEventInput {
  title: string;
  event_type: 'meeting' | 'hearing' | 'deadline' | 'reminder' | 'task' | 'other';
  start_at: Date;
  end_at: Date;
  all_day?: boolean;
  location?: string;
  description?: string;
  case_id?: string;
  client_id?: string;
  is_private?: boolean;
  reminder_minutes?: number;
  recurrence_rule?: string;
  attendees?: string[];  // User IDs
}

export interface UpdateEventInput {
  title?: string;
  event_type?: 'meeting' | 'hearing' | 'deadline' | 'reminder' | 'task' | 'other';
  start_at?: Date;
  end_at?: Date;
  all_day?: boolean;
  location?: string;
  description?: string;
  is_private?: boolean;
  reminder_minutes?: number;
  recurrence_rule?: string;
  status?: 'scheduled' | 'completed' | 'cancelled';
  attendees?: string[];
}

export interface EventListOptions {
  caseId?: string;
  clientId?: string;
  eventType?: string;
  startDate?: Date;
  endDate?: Date;
  createdBy?: string;
  limit?: number;
  offset?: number;
  includeDeleted?: boolean;
}

// ============================================================================
// SERVICE
// ============================================================================

export class CalendarEventService {
  // ==========================================================================
  // VIEW OPERATIONS
  // ==========================================================================

  /**
   * Get event by ID
   * Requires: calendar_view
   */
  async getById(
    context: RequestContext,
    tenantId: string,
    eventId: string
  ): Promise<CalendarEvent | null> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.CALENDAR_VIEW);
    return calendarEventRepository.findById(tenantId, eventId);
  }

  /**
   * Get event by ID or throw
   * Requires: calendar_view
   */
  async getByIdOrFail(
    context: RequestContext,
    tenantId: string,
    eventId: string
  ): Promise<CalendarEvent> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.CALENDAR_VIEW);
    return calendarEventRepository.findByIdOrFail(tenantId, eventId);
  }

  /**
   * List events
   * Requires: calendar_view
   */
  async list(
    context: RequestContext,
    tenantId: string,
    options: EventListOptions = {}
  ): Promise<{ data: CalendarEvent[]; pagination: { total: number; limit: number; offset: number; hasMore: boolean } }> {
    await authorizer.authorize(context, tenantId, PERMISSIONS.CALENDAR_VIEW);

    const filters = [];
    
    if (options.caseId) {
      filters.push({ field: 'case_id', operator: '=' as const, value: options.caseId });
    }
    if (options.clientId) {
      filters.push({ field: 'client_id', operator: '=' as const, value: options.clientId });
    }
    if (options.eventType) {
      filters.push({ field: 'event_type', operator: '=' as const, value: options.eventType });
    }
    if (options.createdBy) {
      filters.push({ field: 'created_by', operator: '=' as const, value: options.createdBy });
    }
    if (options.startDate) {
      filters.push({ field: 'start_at', operator: '>=' as const, value: options.startDate });
    }
    if (options.endDate) {
      filters.push({ field: 'end_at', operator: '<=' as const, value: options.endDate });
    }

    return calendarEventRepository.list(tenantId, {
      filters,
      pagination: { 
        limit: options.limit ?? 100, 
        offset: options.offset ?? 0 
      },
      sort: { field: 'start_at', direction: 'ASC' },
      includeDeleted: options.includeDeleted,
    });
  }

  /**
   * Get events for a date range
   * Requires: calendar_view
   */
  async getForDateRange(
    context: RequestContext,
    tenantId: string,
    startDate: Date,
    endDate: Date
  ): Promise<CalendarEvent[]> {
    const result = await this.list(context, tenantId, {
      startDate,
      endDate,
      limit: 1000,
    });
    return result.data;
  }

  /**
   * Get upcoming events
   * Requires: calendar_view
   */
  async getUpcoming(
    context: RequestContext,
    tenantId: string,
    days: number = 7
  ): Promise<CalendarEvent[]> {
    const now = new Date();
    const future = new Date(now.getTime() + days * 24 * 60 * 60 * 1000);

    return this.getForDateRange(context, tenantId, now, future);
  }

  /**
   * Get events for a case
   * Requires: calendar_view
   */
  async listByCase(
    context: RequestContext,
    tenantId: string,
    caseId: string
  ): Promise<CalendarEvent[]> {
    const result = await this.list(context, tenantId, { caseId });
    return result.data;
  }

  // ==========================================================================
  // CREATE OPERATIONS
  // ==========================================================================

  /**
   * Create a new event
   * Requires: calendar_create
   */
  async create(
    context: RequestContext,
    tenantId: string,
    input: CreateEventInput
  ): Promise<CalendarEvent> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CALENDAR_CREATE);

    // Validate case if provided
    if (input.case_id) {
      await validateCaseTenant(tenantId, input.case_id);
    }

    // Validate client if provided
    if (input.client_id) {
      await validateClientTenant(tenantId, input.client_id);
    }

    // Validate attendees if provided
    if (input.attendees) {
      for (const attendeeId of input.attendees) {
        await validateUserTenant(tenantId, attendeeId);
      }
    }

    // Create event
    const event = await calendarEventRepository.create(tenantId, {
      title: input.title,
      event_type: input.event_type,
      start_at: input.start_at,
      end_at: input.end_at,
      all_day: input.all_day ?? false,
      location: input.location,
      description: input.description,
      case_id: input.case_id,
      client_id: input.client_id,
      is_private: input.is_private ?? false,
      reminder_minutes: input.reminder_minutes,
      recurrence_rule: input.recurrence_rule,
      created_by: auth.userId,
      status: 'scheduled',
    });

    // Audit log
    await auditService.logCreate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'calendar_events',
      event.id,
      event as unknown as Record<string, unknown>
    );

    return event;
  }

  // ==========================================================================
  // UPDATE OPERATIONS
  // ==========================================================================

  /**
   * Update an event
   * Requires: calendar_edit
   */
  async update(
    context: RequestContext,
    tenantId: string,
    eventId: string,
    input: UpdateEventInput
  ): Promise<CalendarEvent> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CALENDAR_EDIT);

    const existing = await calendarEventRepository.findByIdOrFail(tenantId, eventId);

    // Validate attendees if provided
    if (input.attendees) {
      for (const attendeeId of input.attendees) {
        await validateUserTenant(tenantId, attendeeId);
      }
    }

    const updated = await calendarEventRepository.update(tenantId, eventId, input);

    await auditService.logUpdate(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'calendar_events',
      eventId,
      existing as unknown as Record<string, unknown>,
      updated as unknown as Record<string, unknown>
    );

    return updated;
  }

  /**
   * Mark event as completed
   * Requires: calendar_edit
   */
  async complete(
    context: RequestContext,
    tenantId: string,
    eventId: string
  ): Promise<CalendarEvent> {
    return this.update(context, tenantId, eventId, { status: 'completed' });
  }

  /**
   * Cancel event
   * Requires: calendar_edit
   */
  async cancel(
    context: RequestContext,
    tenantId: string,
    eventId: string
  ): Promise<CalendarEvent> {
    return this.update(context, tenantId, eventId, { status: 'cancelled' });
  }

  // ==========================================================================
  // DELETE OPERATIONS
  // ==========================================================================

  /**
   * Soft delete an event
   * Requires: calendar_delete
   */
  async delete(
    context: RequestContext,
    tenantId: string,
    eventId: string
  ): Promise<void> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CALENDAR_DELETE);

    const event = await calendarEventRepository.findByIdOrFail(tenantId, eventId);

    await softDeleteService.softDelete(tenantId, 'calendar_events', eventId, {
      deletedBy: auth.userId,
    });

    await auditService.logDelete(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'calendar_events',
      eventId,
      event as unknown as Record<string, unknown>
    );
  }

  /**
   * Restore a soft-deleted event
   * Requires: calendar_delete
   */
  async restore(
    context: RequestContext,
    tenantId: string,
    eventId: string
  ): Promise<void> {
    const auth = await authorizer.authorize(context, tenantId, PERMISSIONS.CALENDAR_DELETE);

    await softDeleteService.restore(tenantId, 'calendar_events', eventId);

    await auditService.logRestore(
      { tenantId, userId: auth.userId, ipAddress: context.ipAddress, userAgent: context.userAgent },
      'calendar_events',
      eventId
    );
  }
}

export const calendarEventService = new CalendarEventService();
