# LexManager v2.0

**Hebrew-first Legal CRM for Israeli Law Firms**

A production-grade legal practice management system built specifically for Israeli law firms, featuring full RTL support, Israeli tax compliance, and comprehensive case management.

## 🚀 Quick Start

### Prerequisites

- Node.js >= 20.0.0
- pnpm >= 8.0.0
- Docker & Docker Compose

### Development Setup

```bash
# Clone the repository
git clone <repository-url>
cd lexmanager

# Install dependencies
pnpm install

# Start database
pnpm docker:up

# Run migrations
pnpm db:migrate

# Seed initial data (roles, permissions)
pnpm db:seed

# Start development server
pnpm dev
```

API will be available at `http://localhost:3000/api/v1`

### Database Management

```bash
# View database (Adminer UI)
open http://localhost:8080

# Run migrations
pnpm db:migrate

# Rollback last migration
pnpm db:migrate:down

# Reset database (drop all, re-migrate, re-seed)
pnpm db:reset

# Create backup
./infra/scripts/backup.sh
```

## 📁 Project Structure

```
lexmanager/
├── apps/
│   ├── api/          # Express.js backend
│   └── web/          # React frontend (Phase 2B)
├── packages/
│   └── shared/       # Shared types, constants, validators
├── infra/
│   ├── docker/       # Docker configurations
│   └── scripts/      # Utility scripts
└── docs/             # Documentation
```

## 🔐 Security Features

- JWT-based authentication with refresh tokens
- Argon2id password hashing
- Role-based access control (RBAC)
- Immutable audit logs (7-year retention for Israeli tax compliance)
- Rate limiting
- Request validation (Zod)
- SQL injection protection (parameterized queries)
- XSS protection (Helmet.js)

## 👥 Roles & Permissions

| Role      | Description                                    |
|-----------|------------------------------------------------|
| admin     | Full system access, user management            |
| attorney  | Case management, client access, billing        |
| paralegal | Case support, document management              |
| staff     | Basic access, scheduling, limited case view    |

## 🇮🇱 Israeli Compliance

- VAT calculation (17% default)
- Sequential invoice numbering
- 7-year audit log retention
- Hebrew RTL support
- Israeli ID (ת.ז.) and company number (ח.פ.) validation
- Court deadline calculations (מועדים משפטיים)

## 📊 Environment Variables

Copy `.env.example` to `.env` and configure:

```bash
cp .env.example .env
```

Key variables:
- `DATABASE_URL` - PostgreSQL connection string
- `JWT_SECRET` - Secret for JWT signing (change in production!)
- `STORAGE_PROVIDER` - `local` or `s3`

## 🧪 Testing

```bash
# Run all tests
pnpm test

# Run API tests with coverage
pnpm test:api -- --coverage

# Run tests in watch mode
pnpm --filter @lexmanager/api test:watch
```

## 📖 API Documentation

OpenAPI specification available at `docs/api/openapi.yaml`

When running in development, Swagger UI available at:
`http://localhost:3000/api/v1/docs`

## 🚢 Production Deployment

See `docs/deployment/README.md` for production deployment guides.

## 📄 License

Proprietary - All rights reserved

---

Built with ❤️ for Israeli law firms
