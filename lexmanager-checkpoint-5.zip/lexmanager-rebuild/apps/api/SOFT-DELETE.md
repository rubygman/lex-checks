# Soft Delete System

## Overview

LexManager implements a comprehensive soft delete system that:
- Marks records as deleted without physically removing them
- Maintains data integrity and audit trails
- Supports restoration of accidentally deleted records
- Enforces retention periods before permanent deletion
- Cascades deletes to related records

## How It Works

### 1. Soft Delete Flow

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  User Deletes   │────►│  deleted_at =   │────►│  Retention      │
│  Record         │     │  CURRENT_TIME   │     │  Tracking       │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                                                        │
                                                        ▼
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Hard Delete    │◄────│  Retention      │◄────│  Retention      │
│  (Permanent)    │     │  Cleanup Job    │     │  Period Expires │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

### 2. Tables with Soft Delete

| Table | Retention Period | Is Financial |
|-------|------------------|--------------|
| `tenants` | 7 years | No |
| `users` | 7 years | No |
| `clients` | 7 years | Yes |
| `cases` | 7 years | Yes |
| `tasks` | 1 year | No |
| `documents` | 7 years | No |
| `calendar_events` | 1 year | No |
| `time_entries` | 7 years | Yes |
| `invoices` | 7 years | Yes |
| `payments` | 7 years | Yes |
| `trust_accounts` | 7 years | Yes |
| `custom_field_definitions` | 1 year | No |

**Note:** `trust_transactions` and `audit.logs` are **IMMUTABLE** and never deleted.

### 3. Database Views

Active record views automatically filter out soft-deleted records:

```sql
-- These views exclude deleted_at IS NOT NULL
SELECT * FROM active_tenants;
SELECT * FROM active_users;
SELECT * FROM active_clients;
SELECT * FROM active_cases;
SELECT * FROM active_tasks;
SELECT * FROM active_documents;
SELECT * FROM active_events;
SELECT * FROM active_time_entries;
SELECT * FROM active_invoices;
SELECT * FROM active_payments;
SELECT * FROM active_trust_accounts;
```

## Usage

### Soft Delete a Record

```typescript
import { softDeleteService } from './services/soft-delete.service.js';

// Basic soft delete
await softDeleteService.softDelete(tenantId, 'clients', clientId);

// With options
await softDeleteService.softDelete(tenantId, 'cases', caseId, {
  deletedBy: userId,           // Track who deleted
  isFinancial: true,           // Override financial flag
  retentionDays: 365 * 10,     // Custom retention (10 years)
  metadata: { reason: 'Duplicate record' },
});
```

### Restore a Deleted Record

```typescript
// Basic restore
await softDeleteService.restore(tenantId, 'clients', clientId);

// Restore with related records
await softDeleteService.restore(tenantId, 'clients', clientId, {
  restoreRelated: true  // Also restores cases, tasks, etc.
});
```

### Check if Record is Deleted

```typescript
const isDeleted = await softDeleteService.isDeleted(tenantId, 'clients', clientId);
// true or false
```

### Find Record Including Deleted

```typescript
// For admin/recovery purposes
const record = await softDeleteService.findIncludingDeleted(
  tenantId, 
  'clients', 
  clientId
);

if (record.deleted_at) {
  console.log('Record was deleted at:', record.deleted_at);
}
```

### List Soft-Deleted Records

```typescript
// All deleted records for tenant
const deleted = await softDeleteService.listDeleted(tenantId);

// Filter by table
const deletedClients = await softDeleteService.listDeleted(tenantId, {
  table: 'clients',
  limit: 50,
  offset: 0,
});

// Each record includes:
// - table_name
// - record_id
// - deleted_at
// - deleted_by
// - hard_delete_after
// - days_until_hard_delete
```

### Get Soft Delete Statistics

```typescript
const stats = await softDeleteService.getStats(tenantId);

// Returns array of:
// {
//   table_name: 'clients',
//   deleted_count: 5,
//   oldest_deletion: Date,
//   newest_deletion: Date,
//   eligible_for_hard_delete: 0
// }
```

## Repository Pattern

All repositories automatically exclude soft-deleted records:

```typescript
// This will NOT return deleted clients
const clients = await clientRepository.list(tenantId);

// This will NOT find a deleted client
const client = await clientRepository.findById(tenantId, clientId);

// To include deleted records, use includeDeleted option
const allClients = await clientRepository.list(tenantId, { 
  includeDeleted: true 
});

const clientMaybeDeleted = await clientRepository.findById(
  tenantId, 
  clientId, 
  { includeDeleted: true }
);
```

## Cascade Soft Delete

When a parent record is soft-deleted, related records are also soft-deleted:

```
Client (deleted)
├── Case 1 (deleted)
│   ├── Task 1 (deleted)
│   ├── Task 2 (deleted)
│   ├── Document 1 (deleted)
│   └── Time Entry 1 (deleted)
├── Case 2 (deleted)
│   └── ...
└── Trust Account (deleted)
```

**Cascade Configuration:**

| Parent | Cascades To |
|--------|-------------|
| `tenants` | `users`, `clients` |
| `clients` | `cases`, `trust_accounts` |
| `cases` | `tasks`, `documents`, `calendar_events`, `time_entries` |
| `invoices` | `invoice_lines`, `payments` |

## Retention Cleanup Job

The retention cleanup job permanently deletes records after their retention period:

```bash
# Preview what would be deleted
npx tsx src/jobs/retention-cleanup.job.ts --preview

# Dry run (logs but doesn't delete)
npx tsx src/jobs/retention-cleanup.job.ts --dry-run

# Actually run (with 5-second warning)
npx tsx src/jobs/retention-cleanup.job.ts

# Limit to specific tenant
npx tsx src/jobs/retention-cleanup.job.ts --tenant-id=xxx

# Get statistics
npx tsx src/jobs/retention-cleanup.job.ts --stats
```

**Important:** The job is NOT automated. It must be triggered manually or by an external scheduler (cron, etc.).

### Recommended Cron Schedule

```bash
# Run daily at 2 AM (during low-traffic period)
0 2 * * * cd /app && npx tsx src/jobs/retention-cleanup.job.ts >> /var/log/retention-cleanup.log 2>&1
```

## Database Schema

### Retention Tracking Table

```sql
CREATE TABLE soft_delete_retention (
    id                  UUID PRIMARY KEY,
    tenant_id           UUID NOT NULL,
    table_name          VARCHAR(100) NOT NULL,
    record_id           UUID NOT NULL,
    deleted_at          TIMESTAMPTZ NOT NULL,
    deleted_by          UUID,
    retention_days      INTEGER NOT NULL DEFAULT 2557,
    hard_delete_after   TIMESTAMPTZ NOT NULL,
    is_financial        BOOLEAN DEFAULT FALSE,
    metadata_json       JSONB DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL,
    
    UNIQUE (table_name, record_id)
);
```

### Useful Functions

```sql
-- Track a soft delete
SELECT track_soft_delete(
    tenant_id, 
    'clients', 
    record_id, 
    deleted_by_user_id, 
    true,  -- is_financial
    2557,  -- retention_days (7 years)
    '{"reason": "duplicate"}'::jsonb
);

-- Remove tracking (for restore)
SELECT untrack_soft_delete('clients', record_id);

-- Get records eligible for hard deletion
SELECT * FROM get_records_for_hard_deletion(100);

-- Get soft-deleted records for tenant
SELECT * FROM get_soft_deleted_records(tenant_id, 'clients', 100, 0);
```

### Useful Views

```sql
-- All soft-deleted records with remaining time
SELECT * FROM soft_deleted_records WHERE tenant_id = $1;

-- Statistics by tenant and table
SELECT * FROM soft_delete_stats WHERE tenant_id = $1;
```

## Restoration Rules

1. **Record must be soft-deleted**: Cannot restore an active record
2. **Parent must exist and be active**: Cannot restore a case if its client is deleted
3. **Cascade restore optional**: Use `restoreRelated: true` to also restore children

### Restoration Errors

```typescript
// Error: Record is not deleted
await softDeleteService.restore(tenantId, 'clients', activeClientId);
// Throws: DatabaseError('Record is not deleted')

// Error: Parent is deleted
await softDeleteService.restore(tenantId, 'cases', caseId);
// Throws: DatabaseError('Cannot restore: parent clients (xxx) is deleted')
```

## Best Practices

1. **Always use the service**: Don't manually UPDATE `deleted_at`
2. **Track deletion context**: Pass `deletedBy` and `metadata` when possible
3. **Test restoration**: Verify restoration works before relying on soft delete
4. **Monitor retention**: Review `soft_delete_stats` regularly
5. **Backup before hard delete**: Consider backing up before running cleanup job

## Compliance Notes

- **Israeli Tax Law**: Financial records retained 7 years
- **GDPR**: Soft delete allows data to be truly deleted after retention
- **Audit Trail**: All deletions tracked with timestamp and user
- **Immutable Records**: `trust_transactions` and `audit.logs` are never deleted
