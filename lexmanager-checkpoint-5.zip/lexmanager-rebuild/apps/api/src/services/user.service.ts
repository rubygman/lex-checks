// ============================================================================
// USER SERVICE
// apps/api/src/services/user.service.ts
// ============================================================================

import { userRepository, type User, type UserWithRole, type CreateUserData, type UpdateUserData } from '../repositories/user.repository.js';
import { tenantRepository } from '../repositories/tenant.repository.js';
import { roleRepository } from '../repositories/rbac.repository.js';
import { DuplicateError, NotFoundError, DatabaseError } from '../db/errors.js';
import { hashPassword, verifyPassword } from '../utils/crypto.js';

// ============================================================================
// TYPES
// ============================================================================

export interface CreateUserInput {
  email: string;
  password: string;
  name: string;
  name_he?: string;
  phone?: string;
  role_id: string;
  is_active?: boolean;
}

export interface UpdateUserInput {
  name?: string;
  name_he?: string;
  phone?: string;
  avatar_url?: string;
  settings_json?: Record<string, unknown>;
}

export interface ChangePasswordInput {
  currentPassword: string;
  newPassword: string;
}

// ============================================================================
// CONSTANTS
// ============================================================================

const MAX_FAILED_LOGIN_ATTEMPTS = 5;
const LOCKOUT_DURATION_MINUTES = 15;

// ============================================================================
// SERVICE
// ============================================================================

export class UserService {
  /**
   * Create a new user in a tenant
   */
  async createUser(tenantId: string, input: CreateUserInput): Promise<User> {
    // Verify tenant exists and is active
    const tenant = await tenantRepository.findById(tenantId);
    if (!tenant || !tenant.is_active || tenant.deleted_at) {
      throw new Error('Tenant not found or inactive');
    }

    // Check user limit
    const currentCount = await userRepository.countActive(tenantId);
    if (currentCount >= tenant.max_users) {
      throw new DatabaseError(
        `Tenant has reached maximum user limit (${tenant.max_users})`,
        'USER_LIMIT_REACHED',
        400
      );
    }

    // Check email availability
    const emailAvailable = await userRepository.isEmailAvailable(tenantId, input.email);
    if (!emailAvailable) {
      throw new DuplicateError('A user with this email already exists', 'email');
    }

    // Verify role exists
    const role = await roleRepository.findById(input.role_id);
    if (!role) {
      throw new NotFoundError('Role', input.role_id);
    }

    // Validate password strength
    this.validatePasswordStrength(input.password);

    // Hash password
    const passwordHash = await hashPassword(input.password);

    // Create user
    return userRepository.createUser(tenantId, {
      email: input.email,
      password_hash: passwordHash,
      name: input.name,
      name_he: input.name_he,
      phone: input.phone,
      role_id: input.role_id,
      is_active: input.is_active ?? true,
    });
  }

  /**
   * Get user by ID
   */
  async getById(tenantId: string, userId: string): Promise<User | null> {
    return userRepository.findById(tenantId, userId);
  }

  /**
   * Get user by ID or throw
   */
  async getByIdOrFail(tenantId: string, userId: string): Promise<User> {
    return userRepository.findByIdOrFail(tenantId, userId);
  }

  /**
   * Get user with role information
   */
  async getWithRole(tenantId: string, userId: string): Promise<UserWithRole | null> {
    return userRepository.findByIdWithRole(tenantId, userId);
  }

  /**
   * Get user by email within tenant
   */
  async getByEmail(tenantId: string, email: string): Promise<User | null> {
    return userRepository.findByEmail(tenantId, email);
  }

  /**
   * List users in tenant
   */
  async listUsers(
    tenantId: string,
    options?: { 
      limit?: number; 
      offset?: number;
      includeInactive?: boolean;
    }
  ): Promise<UserWithRole[]> {
    return userRepository.listWithRoles(tenantId, options);
  }

  /**
   * Update user
   */
  async updateUser(tenantId: string, userId: string, input: UpdateUserInput): Promise<User> {
    // Verify user exists
    await userRepository.findByIdOrFail(tenantId, userId);

    return userRepository.update(tenantId, userId, input);
  }

  /**
   * Assign role to user
   */
  async assignRole(tenantId: string, userId: string, roleId: string): Promise<User> {
    // Verify role exists
    const role = await roleRepository.findById(roleId);
    if (!role) {
      throw new NotFoundError('Role', roleId);
    }

    return userRepository.updateRole(tenantId, userId, roleId);
  }

  /**
   * Deactivate user (soft disable)
   */
  async deactivate(tenantId: string, userId: string): Promise<User> {
    return userRepository.setActive(tenantId, userId, false);
  }

  /**
   * Activate user
   */
  async activate(tenantId: string, userId: string): Promise<User> {
    return userRepository.setActive(tenantId, userId, true);
  }

  /**
   * Soft delete user
   */
  async softDelete(tenantId: string, userId: string): Promise<User> {
    return userRepository.softDelete(tenantId, userId);
  }

  /**
   * Change user password
   */
  async changePassword(
    tenantId: string, 
    userId: string, 
    input: ChangePasswordInput
  ): Promise<void> {
    const user = await userRepository.findByIdOrFail(tenantId, userId);

    // Verify current password
    const isValid = await verifyPassword(input.currentPassword, user.password_hash);
    if (!isValid) {
      throw new DatabaseError('Current password is incorrect', 'INVALID_PASSWORD', 400);
    }

    // Validate new password
    this.validatePasswordStrength(input.newPassword);

    // Hash and update
    const newPasswordHash = await hashPassword(input.newPassword);
    await userRepository.updatePassword(tenantId, userId, newPasswordHash);
  }

  /**
   * Admin reset password (no current password required)
   */
  async resetPassword(tenantId: string, userId: string, newPassword: string): Promise<void> {
    // Verify user exists
    await userRepository.findByIdOrFail(tenantId, userId);

    // Validate new password
    this.validatePasswordStrength(newPassword);

    // Hash and update
    const newPasswordHash = await hashPassword(newPassword);
    await userRepository.updatePassword(tenantId, userId, newPasswordHash);
  }

  /**
   * Authenticate user (for login)
   */
  async authenticate(
    email: string, 
    password: string,
    ipAddress: string
  ): Promise<{ user: UserWithRole; tenantId: string } | null> {
    // Find user globally by email
    const user = await userRepository.findByEmailGlobal(email);
    
    if (!user) {
      return null;
    }

    // Check if account is locked
    if (user.locked_until && new Date() < user.locked_until) {
      throw new DatabaseError(
        'Account is temporarily locked. Please try again later.',
        'ACCOUNT_LOCKED',
        403
      );
    }

    // Check if user is active
    if (!user.is_active) {
      throw new DatabaseError('Account is deactivated', 'ACCOUNT_INACTIVE', 403);
    }

    // Check if tenant is active
    const tenant = await tenantRepository.findById(user.tenant_id);
    if (!tenant || !tenant.is_active || tenant.deleted_at) {
      throw new DatabaseError('Tenant is inactive or deleted', 'TENANT_INACTIVE', 403);
    }

    // Verify password
    const isValid = await verifyPassword(password, user.password_hash);
    
    if (!isValid) {
      // Record failed attempt
      const failedAttempts = await userRepository.recordFailedLogin(user.tenant_id, user.id);
      
      // Lock account if too many failures
      if (failedAttempts >= MAX_FAILED_LOGIN_ATTEMPTS) {
        const lockUntil = new Date();
        lockUntil.setMinutes(lockUntil.getMinutes() + LOCKOUT_DURATION_MINUTES);
        await userRepository.lockAccount(user.tenant_id, user.id, lockUntil);
        
        throw new DatabaseError(
          `Account locked due to too many failed login attempts. Try again in ${LOCKOUT_DURATION_MINUTES} minutes.`,
          'ACCOUNT_LOCKED',
          403
        );
      }

      return null;
    }

    // Record successful login
    await userRepository.recordLogin(user.tenant_id, user.id, ipAddress);

    return {
      user,
      tenantId: user.tenant_id,
    };
  }

  /**
   * Verify user's email
   */
  async verifyEmail(tenantId: string, userId: string): Promise<void> {
    await userRepository.verifyEmail(tenantId, userId);
  }

  /**
   * Count active users in tenant
   */
  async countActiveUsers(tenantId: string): Promise<number> {
    return userRepository.countActive(tenantId);
  }

  /**
   * Check if email is available
   */
  async isEmailAvailable(tenantId: string, email: string, excludeUserId?: string): Promise<boolean> {
    return userRepository.isEmailAvailable(tenantId, email, excludeUserId);
  }

  /**
   * Validate password strength
   */
  private validatePasswordStrength(password: string): void {
    const minLength = 8;
    const hasUppercase = /[A-Z]/.test(password);
    const hasLowercase = /[a-z]/.test(password);
    const hasNumber = /[0-9]/.test(password);

    const errors: string[] = [];

    if (password.length < minLength) {
      errors.push(`at least ${minLength} characters`);
    }
    if (!hasUppercase) {
      errors.push('an uppercase letter');
    }
    if (!hasLowercase) {
      errors.push('a lowercase letter');
    }
    if (!hasNumber) {
      errors.push('a number');
    }

    if (errors.length > 0) {
      throw new DatabaseError(
        `Password must contain ${errors.join(', ')}`,
        'WEAK_PASSWORD',
        400
      );
    }
  }
}

export const userService = new UserService();
