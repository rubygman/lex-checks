// ============================================================================
// CASE REPOSITORY
// apps/api/src/repositories/case.repository.ts
// 
// Repository for legal cases with tenant scoping
// ============================================================================

import { BaseRepository, type SoftDeletableEntity, type Filter, type ListOptions } from './base.repository.js';
import { query } from '../db/connection.js';
import { parsePostgresError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export interface Case extends SoftDeletableEntity {
  id: string;
  tenant_id: string;
  client_id: string;
  case_number: string;
  title: string;
  title_he: string | null;
  description: string | null;
  case_type: 'litigation' | 'contract' | 'consultation' | 'regulatory' | 'corporate' | 'real_estate' | 'family' | 'criminal' | 'intellectual_property' | 'other';
  status: 'intake' | 'active' | 'pending' | 'closed' | 'archived';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  court_name: string | null;
  court_case_number: string | null;
  court_branch: string | null;
  judge_name: string | null;
  opposing_party: string | null;
  opposing_counsel: string | null;
  assigned_attorney_id: string | null;
  assigned_paralegal_id: string | null;
  open_date: Date;
  close_date: Date | null;
  statute_of_limitations: Date | null;
  billing_type: 'hourly' | 'fixed' | 'contingency' | 'pro_bono';
  hourly_rate: number | null;
  fixed_fee: number | null;
  retainer_amount: number | null;
  contingency_percent: number | null;
  estimated_value: number | null;
  notes: string | null;
  created_by: string | null;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

export type CreateCaseData = Omit<Case, 'id' | 'tenant_id' | 'created_at' | 'updated_at' | 'deleted_at'>;
export type UpdateCaseData = Partial<Omit<CreateCaseData, 'client_id' | 'case_number'>>;

export interface CaseWithClient extends Case {
  client_name: string;
  client_email: string | null;
}

// ============================================================================
// REPOSITORY
// ============================================================================

export class CaseRepository extends BaseRepository<Case> {
  constructor() {
    super({
      tableName: 'cases',
      supportsSoftDelete: true,
    });
  }

  /**
   * Find case by case number within tenant
   */
  async findByCaseNumber(tenantId: string, caseNumber: string): Promise<Case | null> {
    this.validateTenantId(tenantId, 'findByCaseNumber');

    return this.findOne(tenantId, [
      { field: 'case_number', operator: '=', value: caseNumber }
    ]);
  }

  /**
   * Find cases by client
   */
  async findByClient(
    tenantId: string, 
    clientId: string,
    options?: { limit?: number; offset?: number; includeDeleted?: boolean }
  ): Promise<Case[]> {
    this.validateTenantId(tenantId, 'findByClient');

    const result = await this.list(tenantId, {
      filters: [{ field: 'client_id', operator: '=', value: clientId }],
      sort: { field: 'created_at', direction: 'DESC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 },
      includeDeleted: options?.includeDeleted,
    });

    return result.data;
  }

  /**
   * Find cases by assigned attorney
   */
  async findByAttorney(
    tenantId: string, 
    attorneyId: string,
    options?: { limit?: number; offset?: number }
  ): Promise<Case[]> {
    this.validateTenantId(tenantId, 'findByAttorney');

    const result = await this.list(tenantId, {
      filters: [{ field: 'assigned_attorney_id', operator: '=', value: attorneyId }],
      sort: { field: 'updated_at', direction: 'DESC' },
      pagination: { limit: options?.limit ?? 100, offset: options?.offset ?? 0 },
    });

    return result.data;
  }

  /**
   * Find cases by status
   */
  async findByStatus(tenantId: string, status: Case['status']): Promise<Case[]> {
    this.validateTenantId(tenantId, 'findByStatus');

    const result = await this.list(tenantId, {
      filters: [{ field: 'status', operator: '=', value: status }],
      sort: { field: 'updated_at', direction: 'DESC' },
    });

    return result.data;
  }

  /**
   * Get case with client info
   */
  async findByIdWithClient(tenantId: string, caseId: string): Promise<CaseWithClient | null> {
    this.validateTenantId(tenantId, 'findByIdWithClient');

    try {
      const text = `
        SELECT 
          c.*,
          cl.name as client_name,
          cl.email as client_email
        FROM cases c
        JOIN clients cl ON c.client_id = cl.id AND c.tenant_id = cl.tenant_id
        WHERE c.tenant_id = $1 AND c.id = $2 AND c.deleted_at IS NULL
      `;
      const result = await query<CaseWithClient>(text, [tenantId, caseId]);
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Generate next case number for tenant
   */
  async generateCaseNumber(tenantId: string): Promise<string> {
    this.validateTenantId(tenantId, 'generateCaseNumber');

    try {
      const year = new Date().getFullYear();
      const text = `
        SELECT COUNT(*) + 1 as next_num
        FROM cases
        WHERE tenant_id = $1 
          AND EXTRACT(YEAR FROM created_at) = $2
      `;
      const result = await query<{ next_num: number }>(text, [tenantId, year]);
      const nextNum = result.rows[0]?.next_num || 1;
      return `${year}-${String(nextNum).padStart(5, '0')}`;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Search cases by title
   */
  async searchByTitle(tenantId: string, searchTerm: string, limit: number = 20): Promise<Case[]> {
    this.validateTenantId(tenantId, 'searchByTitle');

    try {
      const text = `
        SELECT * FROM cases
        WHERE tenant_id = $1
          AND deleted_at IS NULL
          AND (
            title ILIKE $2
            OR title_he ILIKE $2
            OR case_number ILIKE $2
          )
        ORDER BY updated_at DESC
        LIMIT $3
      `;
      const result = await query<Case>(text, [tenantId, `%${searchTerm}%`, limit]);
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get cases with upcoming statute of limitations
   */
  async findWithUpcomingDeadline(
    tenantId: string, 
    daysAhead: number = 30
  ): Promise<Case[]> {
    this.validateTenantId(tenantId, 'findWithUpcomingDeadline');

    try {
      const text = `
        SELECT * FROM cases
        WHERE tenant_id = $1
          AND deleted_at IS NULL
          AND status IN ('intake', 'active', 'pending')
          AND statute_of_limitations IS NOT NULL
          AND statute_of_limitations <= CURRENT_DATE + INTERVAL '1 day' * $2
          AND statute_of_limitations >= CURRENT_DATE
        ORDER BY statute_of_limitations ASC
      `;
      const result = await query<Case>(text, [tenantId, daysAhead]);
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}

// Export singleton instance
export const caseRepository = new CaseRepository();
