// ============================================================================
// RATE LIMITER UNIT TESTS
// apps/api/tests/unit/middleware/rate-limiter.test.ts
// 
// Tests for rate limiting middleware behavior
// ============================================================================

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import type { Request, Response, NextFunction } from 'express';

// ============================================================================
// MOCK REQUEST/RESPONSE FACTORY
// ============================================================================

function createMockRequest(overrides: Partial<Request> = {}): Request {
  return {
    headers: {},
    ip: '192.168.1.1',
    socket: { remoteAddress: '192.168.1.1' },
    context: {
      correlationId: 'test-correlation-id',
      ipAddress: '192.168.1.1',
      userAgent: 'test-agent',
      tenant: undefined,
    },
    body: {},
    ...overrides,
  } as unknown as Request;
}

function createMockResponse(): Response & { 
  _status: number; 
  _json: unknown; 
  _headers: Map<string, string | number>;
  _ended: boolean;
} {
  const headers = new Map<string, string | number>();
  const res = {
    _status: 200,
    _json: null,
    _headers: headers,
    _ended: false,
    status(code: number) {
      this._status = code;
      return this;
    },
    json(data: unknown) {
      this._json = data;
      this._ended = true;
      return this;
    },
    setHeader(name: string, value: string | number) {
      headers.set(name, value);
      return this;
    },
    end() {
      this._ended = true;
      return this;
    },
    statusCode: 200,
  };
  return res as unknown as Response & typeof res;
}

// ============================================================================
// TESTS: InMemoryRateLimitStore
// ============================================================================

describe('InMemoryRateLimitStore', () => {
  let store: InstanceType<typeof import('../../../src/middleware/rate-limiter.js').InMemoryRateLimitStore>;

  beforeEach(async () => {
    const { InMemoryRateLimitStore } = await import('../../../src/middleware/rate-limiter.js');
    store = new InMemoryRateLimitStore();
  });

  afterEach(() => {
    store.destroy();
  });

  it('should increment count for new key', () => {
    const entry = store.increment('test-key', 60000);
    expect(entry.count).toBe(1);
    expect(entry.resetAt).toBeGreaterThan(Date.now());
  });

  it('should increment count for existing key', () => {
    store.increment('test-key', 60000);
    const entry = store.increment('test-key', 60000);
    expect(entry.count).toBe(2);
  });

  it('should reset count after window expires', async () => {
    const entry1 = store.increment('test-key', 10);  // 10ms window
    expect(entry1.count).toBe(1);

    // Wait for window to expire
    await new Promise(resolve => setTimeout(resolve, 20));

    const entry2 = store.increment('test-key', 10);
    expect(entry2.count).toBe(1);  // Reset to 1
  });

  it('should decrement count', () => {
    store.increment('test-key', 60000);
    store.increment('test-key', 60000);
    store.decrement('test-key');
    
    const entry = store.get('test-key');
    expect(entry?.count).toBe(1);
  });

  it('should not decrement below 0', () => {
    store.increment('test-key', 60000);
    store.decrement('test-key');
    store.decrement('test-key');
    
    const entry = store.get('test-key');
    expect(entry?.count).toBe(0);
  });

  it('should clear all entries', () => {
    store.increment('key1', 60000);
    store.increment('key2', 60000);
    store.clear();
    
    expect(store.size).toBe(0);
  });
});

// ============================================================================
// TESTS: createRateLimiter
// ============================================================================

describe('createRateLimiter', () => {
  let store: InstanceType<typeof import('../../../src/middleware/rate-limiter.js').InMemoryRateLimitStore>;

  beforeEach(async () => {
    const { InMemoryRateLimitStore } = await import('../../../src/middleware/rate-limiter.js');
    store = new InMemoryRateLimitStore();
  });

  afterEach(() => {
    store.destroy();
  });

  it('should allow requests within limit', async () => {
    const { createRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
    
    const limiter = createRateLimiter({
      windowMs: 60000,
      maxRequests: 5,
      keyGenerator: () => 'test-key',
    }, store);

    const req = createMockRequest();
    const res = createMockResponse();
    const next = vi.fn();

    limiter(req, res, next);

    expect(next).toHaveBeenCalled();
    expect(res._status).toBe(200);  // Not changed
    expect(res._headers.get('X-RateLimit-Limit')).toBe(5);
    expect(res._headers.get('X-RateLimit-Remaining')).toBe(4);
  });

  it('should block requests over limit with correct error shape', async () => {
    const { createRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
    
    const limiter = createRateLimiter({
      windowMs: 60000,
      maxRequests: 2,
      keyGenerator: () => 'test-key',
      message: 'Rate limited!',
    }, store);

    const req = createMockRequest();
    const next = vi.fn();

    // Make 3 requests (limit is 2)
    for (let i = 0; i < 3; i++) {
      const res = createMockResponse();
      limiter(req, res, next);
      
      if (i < 2) {
        expect(next).toHaveBeenCalled();
        next.mockClear();
      } else {
        // Third request should be blocked
        expect(res._status).toBe(429);
        expect(res._json).toEqual({
          error: 'RATE_LIMITED',
          message: 'Rate limited!',
          retryAfterSeconds: expect.any(Number),
          correlationId: 'test-correlation-id',
        });
        expect(res._headers.get('Retry-After')).toBeGreaterThan(0);
      }
    }
  });

  it('should include correlationId from context', async () => {
    const { createRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
    
    const limiter = createRateLimiter({
      windowMs: 60000,
      maxRequests: 1,
      keyGenerator: () => 'test-key',
    }, store);

    const req = createMockRequest({
      context: {
        correlationId: 'my-custom-correlation-id',
        ipAddress: '192.168.1.1',
        userAgent: 'test',
      },
    } as any);

    // First request passes
    limiter(req, createMockResponse(), vi.fn());

    // Second request is blocked
    const res = createMockResponse();
    limiter(req, res, vi.fn());

    expect(res._json).toMatchObject({
      correlationId: 'my-custom-correlation-id',
    });
  });

  it('should handle missing context gracefully', async () => {
    const { createRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
    
    const limiter = createRateLimiter({
      windowMs: 60000,
      maxRequests: 1,
      keyGenerator: () => 'test-key',
    }, store);

    const req = createMockRequest();
    delete (req as any).context;

    // First request passes
    limiter(req, createMockResponse(), vi.fn());

    // Second request is blocked
    const res = createMockResponse();
    limiter(req, res, vi.fn());

    expect(res._json).toMatchObject({
      error: 'RATE_LIMITED',
      correlationId: 'unknown',
    });
  });

  it('should use different keys for different IPs', async () => {
    const { createRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
    
    const limiter = createRateLimiter({
      windowMs: 60000,
      maxRequests: 1,
      keyGenerator: (req) => `test:${req.ip}`,
    }, store);

    const req1 = createMockRequest({ ip: '1.1.1.1' } as any);
    const req2 = createMockRequest({ ip: '2.2.2.2' } as any);
    const next = vi.fn();

    limiter(req1, createMockResponse(), next);
    expect(next).toHaveBeenCalled();
    next.mockClear();

    limiter(req2, createMockResponse(), next);
    expect(next).toHaveBeenCalled();  // Different IP, should pass
  });

  it('should decrement on successful response when skipSuccessful is true', async () => {
    const { createRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
    
    const limiter = createRateLimiter({
      windowMs: 60000,
      maxRequests: 2,
      keyGenerator: () => 'test-key',
      skipSuccessful: true,
    }, store);

    const req = createMockRequest();
    
    // First request - success (should be decremented)
    const res1 = createMockResponse();
    res1.statusCode = 200;
    limiter(req, res1 as any, vi.fn());
    (res1 as any).end();  // Trigger the end hook

    // Second request - success
    const res2 = createMockResponse();
    res2.statusCode = 200;
    limiter(req, res2 as any, vi.fn());
    (res2 as any).end();

    // Third request - should still pass because successful ones were decremented
    const res3 = createMockResponse();
    const next = vi.fn();
    limiter(req, res3 as any, next);
    
    // This test verifies the logic exists; actual decrement behavior
    // depends on response ending, which is tricky to test fully
    expect(next).toHaveBeenCalled();
  });
});

// ============================================================================
// TESTS: Pre-configured limiters
// ============================================================================

describe('Pre-configured rate limiters', () => {
  let getDefaultStore: typeof import('../../../src/middleware/rate-limiter.js').getDefaultStore;

  beforeEach(async () => {
    const module = await import('../../../src/middleware/rate-limiter.js');
    getDefaultStore = module.getDefaultStore;
    // Clear the default store between tests
    getDefaultStore().clear();
  });

  describe('loginRateLimiter', () => {
    it('should key by tenant + IP when tenant is available', async () => {
      const { loginRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
      
      const limiter = loginRateLimiter();
      const req = createMockRequest({
        ip: '1.2.3.4',
        context: {
          correlationId: 'test',
          ipAddress: '1.2.3.4',
          userAgent: 'test',
          tenant: {
            tenantId: 'tenant-123',
            tenantSlug: 'test',
            tenantName: 'Test',
            isActive: true,
          },
        },
      } as any);

      const res = createMockResponse();
      const next = vi.fn();

      limiter(req, res, next);

      // Should set rate limit headers
      expect(res._headers.get('X-RateLimit-Limit')).toBe(10);
      expect(next).toHaveBeenCalled();
    });

    it('should key by IP only when tenant is missing', async () => {
      const { loginRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
      
      const limiter = loginRateLimiter();
      const req = createMockRequest({
        ip: '1.2.3.4',
        context: {
          correlationId: 'test',
          ipAddress: '1.2.3.4',
          userAgent: 'test',
          tenant: undefined,
        },
      } as any);

      const res = createMockResponse();
      const next = vi.fn();

      limiter(req, res, next);

      expect(next).toHaveBeenCalled();  // Should not crash
    });

    it('should have 10 requests per 15 minutes limit', async () => {
      const { loginRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
      
      const limiter = loginRateLimiter();
      const req = createMockRequest();
      const res = createMockResponse();

      limiter(req, res, vi.fn());

      expect(res._headers.get('X-RateLimit-Limit')).toBe(10);
    });
  });

  describe('registrationRateLimiter', () => {
    it('should have 5 requests per hour limit', async () => {
      const { registrationRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
      
      const limiter = registrationRateLimiter();
      const req = createMockRequest();
      const res = createMockResponse();

      limiter(req, res, vi.fn());

      expect(res._headers.get('X-RateLimit-Limit')).toBe(5);
    });

    it('should not crash when tenant is missing', async () => {
      const { registrationRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
      
      const limiter = registrationRateLimiter();
      const req = createMockRequest({
        context: {
          correlationId: 'test',
          ipAddress: '1.2.3.4',
          userAgent: 'test',
        },
      } as any);

      const res = createMockResponse();
      const next = vi.fn();

      expect(() => limiter(req, res, next)).not.toThrow();
      expect(next).toHaveBeenCalled();
    });
  });

  describe('passwordResetRateLimiter', () => {
    it('should have 5 requests per hour limit', async () => {
      const { passwordResetRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
      
      const limiter = passwordResetRateLimiter();
      const req = createMockRequest();
      const res = createMockResponse();

      limiter(req, res, vi.fn());

      expect(res._headers.get('X-RateLimit-Limit')).toBe(5);
    });
  });

  describe('refreshRateLimiter', () => {
    it('should have 30 requests per 15 minutes limit', async () => {
      const { refreshRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
      
      const limiter = refreshRateLimiter();
      const req = createMockRequest();
      const res = createMockResponse();

      limiter(req, res, vi.fn());

      expect(res._headers.get('X-RateLimit-Limit')).toBe(30);
    });

    it('should key by IP only (no tenant)', async () => {
      const { refreshRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
      
      const limiter = refreshRateLimiter();
      
      // Request without tenant context
      const req = createMockRequest({
        ip: '5.6.7.8',
        context: {
          correlationId: 'test',
          ipAddress: '5.6.7.8',
          userAgent: 'test',
        },
      } as any);

      const res = createMockResponse();
      const next = vi.fn();

      expect(() => limiter(req, res, next)).not.toThrow();
      expect(next).toHaveBeenCalled();
    });
  });
});

// ============================================================================
// TESTS: Error response format
// ============================================================================

describe('Rate limit error response format', () => {
  let store: InstanceType<typeof import('../../../src/middleware/rate-limiter.js').InMemoryRateLimitStore>;

  beforeEach(async () => {
    const { InMemoryRateLimitStore } = await import('../../../src/middleware/rate-limiter.js');
    store = new InMemoryRateLimitStore();
  });

  afterEach(() => {
    store.destroy();
  });

  it('should return exact error shape as specified', async () => {
    const { createRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
    
    const limiter = createRateLimiter({
      windowMs: 60000,
      maxRequests: 1,
      keyGenerator: () => 'test-key',
      message: 'Too many requests',
    }, store);

    const req = createMockRequest();

    // First request passes
    limiter(req, createMockResponse(), vi.fn());

    // Second request is rate limited
    const res = createMockResponse();
    limiter(req, res, vi.fn());

    expect(res._status).toBe(429);
    expect(res._json).toEqual({
      error: 'RATE_LIMITED',
      message: 'Too many requests',
      retryAfterSeconds: expect.any(Number),
      correlationId: 'test-correlation-id',
    });

    // Verify retryAfterSeconds is positive
    expect((res._json as any).retryAfterSeconds).toBeGreaterThan(0);
  });

  it('should set Retry-After header', async () => {
    const { createRateLimiter } = await import('../../../src/middleware/rate-limiter.js');
    
    const limiter = createRateLimiter({
      windowMs: 60000,
      maxRequests: 1,
      keyGenerator: () => 'test-key',
    }, store);

    const req = createMockRequest();

    limiter(req, createMockResponse(), vi.fn());

    const res = createMockResponse();
    limiter(req, res, vi.fn());

    expect(res._headers.get('Retry-After')).toBeGreaterThan(0);
  });
});
