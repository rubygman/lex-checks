# CHECKPOINT 5 — CORE MODULES API WITH RBAC + TENANT + SOFT DELETE + AUDIT

## Status: ✅ COMPLETE

---

## Modules Implemented

### A) Clients
| Endpoint | Method | Permission | Description |
|----------|--------|------------|-------------|
| `/clients` | GET | clients_view | List with pagination + search |
| `/clients` | POST | clients_create | Create client |
| `/clients/:id` | GET | clients_view | Get by ID |
| `/clients/:id` | PATCH | clients_edit | Update client |
| `/clients/:id` | DELETE | clients_delete | Soft delete |
| `/clients/:id/restore` | POST | clients_delete | Restore |

### B) Cases
| Endpoint | Method | Permission | Description |
|----------|--------|------------|-------------|
| `/cases` | GET | cases_view | List with filters |
| `/cases` | POST | cases_create | Create case (linked to client) |
| `/cases/:id` | GET | cases_view | Get by ID |
| `/cases/:id` | PATCH | cases_edit | Update case |
| `/cases/:id` | DELETE | cases_delete | Soft delete |
| `/cases/:id/restore` | POST | cases_delete | Restore |

### C) Tasks + Kanban
| Endpoint | Method | Permission | Description |
|----------|--------|------------|-------------|
| `/tasks` | GET | tasks_view | List with filters |
| `/tasks/kanban` | GET | tasks_view | Get Kanban board |
| `/tasks/counts` | GET | tasks_view | Get status counts |
| `/tasks/overdue` | GET | tasks_view | Get overdue tasks |
| `/tasks/due-soon` | GET | tasks_view | Get tasks due soon |
| `/tasks` | POST | tasks_create | Create task |
| `/tasks/:id` | GET | tasks_view | Get with details |
| `/tasks/:id` | PATCH | tasks_edit | Update task |
| `/tasks/:id/move` | PATCH | tasks_edit | Move in Kanban |
| `/tasks/:id/complete` | POST | tasks_edit | Mark completed |
| `/tasks/:id` | DELETE | tasks_delete | Soft delete |
| `/tasks/:id/restore` | POST | tasks_delete | Restore |

### D) Documents (Metadata)
| Endpoint | Method | Permission | Description |
|----------|--------|------------|-------------|
| `/documents` | GET | documents_view | List documents |
| `/documents` | POST | documents_create | Create metadata |
| `/documents/:id` | GET | documents_view | Get by ID |
| `/documents/:id/download` | GET | documents_view | Download (stub) |
| `/documents/:id` | PATCH | documents_edit | Update metadata |
| `/documents/:id` | DELETE | documents_delete | Soft delete |
| `/documents/:id/restore` | POST | documents_delete | Restore |

### E) Invoices
| Endpoint | Method | Permission | Description |
|----------|--------|------------|-------------|
| `/invoices` | GET | invoices_view | List invoices |
| `/invoices/overdue` | GET | invoices_view | Get overdue |
| `/invoices` | POST | invoices_create | Create with lines |
| `/invoices/:id` | GET | invoices_view | Get with details |
| `/invoices/:id` | PATCH | invoices_edit | Update |
| `/invoices/:id/send` | POST | invoices_edit | Mark as sent |
| `/invoices/:id/payment` | POST | invoices_edit | Record payment |
| `/invoices/:id` | DELETE | invoices_delete | Void (soft delete) |
| `/invoices/:id/restore` | POST | invoices_delete | Restore |

### F) Trust (Immutable Transactions)
| Endpoint | Method | Permission | Description |
|----------|--------|------------|-------------|
| `/trust/accounts` | GET | trust_view | List accounts |
| `/trust/accounts` | POST | trust_create | Create account |
| `/trust/accounts/:id` | GET | trust_view | Get account |
| `/trust/accounts/:id/deposit` | POST | trust_deposit | Deposit (INSERT-ONLY) |
| `/trust/accounts/:id/withdraw` | POST | trust_withdraw | Withdraw (INSERT-ONLY) |
| `/trust/accounts/:id/transactions` | GET | trust_view | Get transactions |
| `/trust/accounts/:id/reconcile` | GET | trust_view | Reconciliation report |
| `/trust/transactions` | GET | trust_view | List all transactions |
| `/trust/transactions` | POST | trust_deposit | Create transaction |

**NOTE**: trust_transactions is INSERT-ONLY (immutable). No updates or deletes allowed.

### G) Custom Fields
| Endpoint | Method | Permission | Description |
|----------|--------|------------|-------------|
| `/custom-fields/definitions` | GET | settings_view | List definitions |
| `/custom-fields/definitions` | POST | settings_edit | Create definition |
| `/custom-fields/definitions/:id` | GET | settings_view | Get definition |
| `/custom-fields/definitions/:id` | PATCH | settings_edit | Update definition |
| `/custom-fields/definitions/:id` | DELETE | settings_edit | Delete definition |
| `/custom-fields/definitions/:id/restore` | POST | settings_edit | Restore |
| `/custom-fields/:entityType/:entityId` | GET | * | Get values for entity |
| `/custom-fields/:entityType/:entityId` | PUT | * | Set values for entity |

---

## Files Created/Modified

### Routes
- `src/routes/client.routes.ts`
- `src/routes/case.routes.ts`
- `src/routes/task.routes.ts`
- `src/routes/document.routes.ts`
- `src/routes/invoice.routes.ts`
- `src/routes/trust.routes.ts`
- `src/routes/custom-field.routes.ts`
- `src/routes/audit.routes.ts`
- `src/routes/index.ts`

### Repositories
- `src/repositories/case.repository.ts`
- `src/repositories/task.repository.ts`
- `src/repositories/document.repository.ts`
- `src/repositories/invoice.repository.ts`
- `src/repositories/index.ts` (updated)

### Services
- `src/services/task.service.ts`
- `src/services/index.ts` (updated)

### App
- `src/app.ts` (updated with all routes)

### Tests
- `tests/integration/modules/core-modules.integration.test.ts`

---

## Non-Negotiables Verified

| Requirement | Status |
|-------------|--------|
| Tenant context required (X-Tenant-Id) | ✅ All routes use `requireTenant()` |
| Tenant-scoped DB operations | ✅ All repos require `tenantId` parameter |
| Soft deletes | ✅ All entities except trust_transactions |
| Audit on mutations | ✅ All create/update/delete log audit entries |
| RBAC server-side | ✅ `requirePermission()` middleware + service checks |
| Input validation (Zod) | ✅ All routes use `validate()` |

---

## CHECKPOINT READY — Verification Commands

### 1. Start the API
```bash
cd apps/api
npm run dev
# or
pnpm dev
```

### 2. Health Check
```bash
curl http://localhost:3000/health
```

### 3. Create Test Data

```bash
# Set your tenant ID and auth token
TENANT_ID="your-tenant-uuid"
TOKEN="your-jwt-token"

# Create a client
curl -X POST http://localhost:3000/clients \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: $TENANT_ID" \
  -d '{"name":"Test Client","clientType":"individual"}'

# List clients
curl http://localhost:3000/clients \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: $TENANT_ID"

# Create a case (use client ID from above)
curl -X POST http://localhost:3000/cases \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: $TENANT_ID" \
  -d '{"clientId":"<CLIENT_ID>","title":"Test Case","caseType":"litigation"}'

# Create a task
curl -X POST http://localhost:3000/tasks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: $TENANT_ID" \
  -d '{"title":"Test Task","priority":"high"}'

# Get Kanban board
curl http://localhost:3000/tasks/kanban \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: $TENANT_ID"

# Move task
curl -X PATCH http://localhost:3000/tasks/<TASK_ID>/move \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: $TENANT_ID" \
  -d '{"status":"in_progress","order":0}'
```

### 4. Soft Delete and Restore

```bash
# Soft delete a client
curl -X DELETE http://localhost:3000/clients/<CLIENT_ID> \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: $TENANT_ID"

# Restore the client
curl -X POST http://localhost:3000/clients/<CLIENT_ID>/restore \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: $TENANT_ID"
```

### 5. Check Audit Logs

```bash
# List audit logs
curl "http://localhost:3000/audit/logs?page=1&limit=10" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: $TENANT_ID"

# Get entity history
curl "http://localhost:3000/audit/entity/clients/<CLIENT_ID>" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: $TENANT_ID"
```

### 6. Trust Operations (Immutable)

```bash
# Create trust account
curl -X POST http://localhost:3000/trust/accounts \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: $TENANT_ID" \
  -d '{"clientId":"<CLIENT_ID>","accountName":"Client Trust"}'

# Deposit (creates immutable transaction)
curl -X POST http://localhost:3000/trust/accounts/<ACCOUNT_ID>/deposit \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: $TENANT_ID" \
  -d '{"amount":5000,"description":"Initial deposit"}'

# Get transactions
curl http://localhost:3000/trust/accounts/<ACCOUNT_ID>/transactions \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: $TENANT_ID"
```

### 7. Run Integration Tests

```bash
# With database connection
DATABASE_URL=postgresql://... npm test -- tests/integration/modules/core-modules.integration.test.ts
```

### 8. Verify Tenant Isolation

```bash
# Try accessing with wrong tenant ID - should fail
curl http://localhost:3000/clients \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-Id: wrong-tenant-uuid"
# Expected: 403 Forbidden
```

---

## STOP

Checkpoint 5 is complete. Do not start frontend work.
