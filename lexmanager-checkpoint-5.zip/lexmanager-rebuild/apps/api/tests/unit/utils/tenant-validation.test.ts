// ============================================================================
// TENANT VALIDATION UNIT TESTS
// apps/api/tests/unit/utils/tenant-validation.test.ts
// ============================================================================

import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  ref,
  validateSameTenant,
  requireSameTenant,
} from '../../../src/utils/tenant-validation.js';
import { CrossTenantAccessError, TenantScopingError } from '../../../src/db/errors.js';

// Mock the database connection
vi.mock('../../../src/db/connection.js', () => ({
  query: vi.fn(),
}));

import { query } from '../../../src/db/connection.js';

describe('Tenant Validation Utility', () => {
  const tenantId = '550e8400-e29b-41d4-a716-446655440000';
  const otherTenantId = '660e8400-e29b-41d4-a716-446655440001';
  const entityId = '770e8400-e29b-41d4-a716-446655440002';

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('ref helper', () => {
    it('should create EntityReference with all fields', () => {
      const result = ref('clients', entityId, 'My Client');
      
      expect(result).toEqual({
        table: 'clients',
        id: entityId,
        label: 'My Client',
      });
    });

    it('should create EntityReference with default label', () => {
      const result = ref('clients', entityId);
      
      expect(result).toEqual({
        table: 'clients',
        id: entityId,
        label: 'clients',
      });
    });

    it('should return null for null id', () => {
      expect(ref('clients', null)).toBeNull();
    });

    it('should return null for undefined id', () => {
      expect(ref('clients', undefined)).toBeNull();
    });
  });

  describe('validateSameTenant', () => {
    it('should return valid=true when all references match tenant', async () => {
      vi.mocked(query).mockImplementation(async (sql: string, params?: unknown[]) => {
        // All entities return the same tenant
        return { rows: [{ tenant_id: tenantId }], rowCount: 1 } as any;
      });

      const result = await validateSameTenant(
        tenantId,
        ref('clients', 'id1'),
        ref('cases', 'id2')
      );

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should return valid=false when reference belongs to different tenant', async () => {
      vi.mocked(query).mockImplementation(async (sql: string, params?: unknown[]) => {
        const id = (params as string[])?.[0];
        if (id === 'cross-tenant-id') {
          return { rows: [{ tenant_id: otherTenantId }], rowCount: 1 } as any;
        }
        return { rows: [{ tenant_id: tenantId }], rowCount: 1 } as any;
      });

      const result = await validateSameTenant(
        tenantId,
        ref('clients', 'same-tenant-id'),
        ref('cases', 'cross-tenant-id', 'Bad Case')
      );

      expect(result.valid).toBe(false);
      expect(result.errors).toHaveLength(1);
      expect(result.errors[0]).toContain('Bad Case');
      expect(result.errors[0]).toContain('different tenant');
    });

    it('should return valid=false when reference not found', async () => {
      vi.mocked(query).mockResolvedValue({ rows: [], rowCount: 0 } as any);

      const result = await validateSameTenant(
        tenantId,
        ref('clients', 'non-existent', 'Missing Client')
      );

      expect(result.valid).toBe(false);
      expect(result.errors).toHaveLength(1);
      expect(result.errors[0]).toContain('not found');
    });

    it('should return valid=false for empty tenantId', async () => {
      const result = await validateSameTenant(
        '',
        ref('clients', entityId)
      );

      expect(result.valid).toBe(false);
      expect(result.errors[0]).toContain('tenantId is required');
    });

    it('should skip null and undefined references', async () => {
      vi.mocked(query).mockResolvedValue({ rows: [{ tenant_id: tenantId }], rowCount: 1 } as any);

      const result = await validateSameTenant(
        tenantId,
        ref('clients', entityId),
        null,
        undefined,
        ref('cases', null)
      );

      expect(result.valid).toBe(true);
      // Should only query for the one valid reference
      expect(query).toHaveBeenCalledTimes(1);
    });

    it('should collect all errors for multiple invalid references', async () => {
      vi.mocked(query).mockResolvedValue({ rows: [{ tenant_id: otherTenantId }], rowCount: 1 } as any);

      const result = await validateSameTenant(
        tenantId,
        ref('clients', 'bad1', 'Client 1'),
        ref('cases', 'bad2', 'Case 1'),
        ref('users', 'bad3', 'User 1')
      );

      expect(result.valid).toBe(false);
      expect(result.errors).toHaveLength(3);
    });

    it('should handle database errors gracefully', async () => {
      vi.mocked(query).mockRejectedValue(new Error('Database connection failed'));

      const result = await validateSameTenant(
        tenantId,
        ref('clients', entityId, 'Problem Client')
      );

      expect(result.valid).toBe(false);
      expect(result.errors[0]).toContain('Error validating');
    });
  });

  describe('requireSameTenant', () => {
    it('should not throw when all references are valid', async () => {
      vi.mocked(query).mockResolvedValue({ rows: [{ tenant_id: tenantId }], rowCount: 1 } as any);

      await expect(
        requireSameTenant(
          tenantId,
          ref('clients', entityId)
        )
      ).resolves.not.toThrow();
    });

    it('should throw CrossTenantAccessError when reference belongs to different tenant', async () => {
      vi.mocked(query).mockResolvedValue({ rows: [{ tenant_id: otherTenantId }], rowCount: 1 } as any);

      await expect(
        requireSameTenant(
          tenantId,
          ref('clients', entityId, 'Cross-tenant Client')
        )
      ).rejects.toThrow(CrossTenantAccessError);
    });

    it('should throw CrossTenantAccessError when reference not found', async () => {
      vi.mocked(query).mockResolvedValue({ rows: [], rowCount: 0 } as any);

      await expect(
        requireSameTenant(
          tenantId,
          ref('clients', entityId)
        )
      ).rejects.toThrow(CrossTenantAccessError);
    });

    it('should include all errors in exception message', async () => {
      vi.mocked(query).mockResolvedValue({ rows: [{ tenant_id: otherTenantId }], rowCount: 1 } as any);

      try {
        await requireSameTenant(
          tenantId,
          ref('clients', 'bad1', 'Client'),
          ref('cases', 'bad2', 'Case')
        );
        expect.fail('Should have thrown');
      } catch (error) {
        expect(error).toBeInstanceOf(CrossTenantAccessError);
        expect((error as Error).message).toContain('Client');
        expect((error as Error).message).toContain('Case');
      }
    });
  });

  describe('EntityReference filtering', () => {
    it('should handle all null references without querying', async () => {
      const result = await validateSameTenant(
        tenantId,
        null,
        undefined,
        ref('clients', null),
        ref('cases', undefined)
      );

      expect(result.valid).toBe(true);
      expect(query).not.toHaveBeenCalled();
    });

    it('should validate only non-null references', async () => {
      vi.mocked(query).mockResolvedValue({ rows: [{ tenant_id: tenantId }], rowCount: 1 } as any);

      const result = await validateSameTenant(
        tenantId,
        ref('clients', 'valid-id'),
        null,
        ref('cases', null),  // Will be filtered out
        ref('users', 'another-valid-id')
      );

      expect(result.valid).toBe(true);
      expect(query).toHaveBeenCalledTimes(2);
    });
  });
});
