// ============================================================================
// DATABASE LAYER CUSTOM ERRORS
// apps/api/src/db/errors.ts
// ============================================================================

/**
 * Base error for database operations
 */
export class DatabaseError extends Error {
  public readonly code: string;
  public readonly statusCode: number;

  constructor(message: string, code: string = 'DATABASE_ERROR', statusCode: number = 500) {
    super(message);
    this.name = 'DatabaseError';
    this.code = code;
    this.statusCode = statusCode;
    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * Error thrown when a query lacks required tenant scoping
 */
export class TenantScopingError extends DatabaseError {
  constructor(message: string) {
    super(message, 'TENANT_SCOPING_REQUIRED', 400);
    this.name = 'TenantScopingError';
  }
}

/**
 * Error thrown when attempting to modify an immutable table
 */
export class ImmutableTableError extends DatabaseError {
  constructor(message: string) {
    super(message, 'IMMUTABLE_TABLE', 403);
    this.name = 'ImmutableTableError';
  }
}

/**
 * Error thrown when a record is not found
 */
export class NotFoundError extends DatabaseError {
  constructor(entity: string, id: string) {
    super(`${entity} with id "${id}" not found`, 'NOT_FOUND', 404);
    this.name = 'NotFoundError';
  }
}

/**
 * Error thrown when a unique constraint is violated
 */
export class DuplicateError extends DatabaseError {
  public readonly field: string;

  constructor(message: string, field: string) {
    super(message, 'DUPLICATE_ENTRY', 409);
    this.name = 'DuplicateError';
    this.field = field;
  }
}

/**
 * Error thrown when a foreign key constraint is violated
 */
export class ForeignKeyError extends DatabaseError {
  public readonly constraint: string;

  constructor(message: string, constraint: string) {
    super(message, 'FOREIGN_KEY_VIOLATION', 400);
    this.name = 'ForeignKeyError';
    this.constraint = constraint;
  }
}

/**
 * Error thrown when cross-tenant access is attempted
 */
export class CrossTenantAccessError extends DatabaseError {
  constructor(message: string = 'Cross-tenant access is not allowed') {
    super(message, 'CROSS_TENANT_ACCESS', 403);
    this.name = 'CrossTenantAccessError';
  }
}

/**
 * Parse PostgreSQL error and return appropriate custom error
 */
export function parsePostgresError(error: unknown): DatabaseError {
  if (error instanceof DatabaseError) {
    return error;
  }

  const pgError = error as { code?: string; constraint?: string; detail?: string; message?: string };

  // Unique violation
  if (pgError.code === '23505') {
    const match = pgError.detail?.match(/Key \((.+)\)=/);
    const field = match ? match[1] : 'unknown';
    return new DuplicateError(
      `A record with this ${field} already exists`,
      field
    );
  }

  // Foreign key violation
  if (pgError.code === '23503') {
    return new ForeignKeyError(
      pgError.detail || 'Foreign key constraint violation',
      pgError.constraint || 'unknown'
    );
  }

  // Not null violation
  if (pgError.code === '23502') {
    return new DatabaseError(
      pgError.message || 'Required field is missing',
      'NOT_NULL_VIOLATION',
      400
    );
  }

  // Check constraint violation
  if (pgError.code === '23514') {
    return new DatabaseError(
      pgError.message || 'Check constraint violation',
      'CHECK_VIOLATION',
      400
    );
  }

  // Cross-tenant trigger error
  if (pgError.message?.includes('Cross-tenant reference not allowed')) {
    return new CrossTenantAccessError(pgError.message);
  }

  // Immutable table trigger error
  if (pgError.message?.includes('immutable') || pgError.message?.includes('not allowed')) {
    return new ImmutableTableError(pgError.message || 'Operation not allowed on immutable table');
  }

  // Generic database error
  return new DatabaseError(
    pgError.message || 'An unexpected database error occurred',
    pgError.code || 'UNKNOWN_ERROR',
    500
  );
}
