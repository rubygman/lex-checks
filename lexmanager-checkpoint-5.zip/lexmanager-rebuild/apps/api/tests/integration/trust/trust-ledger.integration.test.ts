// ============================================================================
// TRUST LEDGER INTEGRATION TESTS
// apps/api/tests/integration/trust/trust-ledger.integration.test.ts
// ============================================================================

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import pg from 'pg';
import { trustService } from '../../../src/services/trust.service.js';
import { trustAccountRepository } from '../../../src/repositories/trust-account.repository.js';
import { trustTransactionRepository } from '../../../src/repositories/trust-transaction.repository.js';
import { rbacService, PERMISSIONS } from '../../../src/services/rbac.service.js';

const { Pool } = pg;

// Skip if no database connection
const DATABASE_URL = process.env.DATABASE_URL;
const shouldRun = DATABASE_URL && DATABASE_URL.includes('localhost');

describe.skipIf(!shouldRun)('Trust Ledger Integration', () => {
  let pool: pg.Pool;
  let tenantId: string;
  let adminUserId: string;
  let staffUserId: string;
  let clientId: string;
  let client2Id: string;
  let trustAccountId: string;
  let trustAccount2Id: string;

  beforeAll(async () => {
    pool = new Pool({ connectionString: DATABASE_URL });

    // Get role IDs
    const adminRoleResult = await pool.query("SELECT id FROM roles WHERE name = 'admin' LIMIT 1");
    const staffRoleResult = await pool.query("SELECT id FROM roles WHERE name = 'staff' LIMIT 1");
    const adminRoleId = adminRoleResult.rows[0].id;
    const staffRoleId = staffRoleResult.rows[0].id;

    // Create test tenant
    const tenantResult = await pool.query(
      "INSERT INTO tenants (name, slug) VALUES ('Trust Test Tenant', $1) RETURNING id",
      [`trust-test-${Date.now()}`]
    );
    tenantId = tenantResult.rows[0].id;

    // Create admin user (full permissions)
    const adminResult = await pool.query(
      `INSERT INTO users (tenant_id, email, password_hash, name, role_id)
       VALUES ($1, $2, 'hash', 'Admin User', $3) RETURNING id`,
      [tenantId, `admin-${Date.now()}@test.com`, adminRoleId]
    );
    adminUserId = adminResult.rows[0].id;

    // Create staff user (limited permissions)
    const staffResult = await pool.query(
      `INSERT INTO users (tenant_id, email, password_hash, name, role_id)
       VALUES ($1, $2, 'hash', 'Staff User', $3) RETURNING id`,
      [tenantId, `staff-${Date.now()}@test.com`, staffRoleId]
    );
    staffUserId = staffResult.rows[0].id;

    // Create test clients
    const clientResult = await pool.query(
      `INSERT INTO clients (tenant_id, name, client_type, status, address_country, currency, payment_terms)
       VALUES ($1, 'Trust Client 1', 'individual', 'active', 'Israel', 'ILS', 30) RETURNING id`,
      [tenantId]
    );
    clientId = clientResult.rows[0].id;

    const client2Result = await pool.query(
      `INSERT INTO clients (tenant_id, name, client_type, status, address_country, currency, payment_terms)
       VALUES ($1, 'Trust Client 2', 'individual', 'active', 'Israel', 'ILS', 30) RETURNING id`,
      [tenantId]
    );
    client2Id = client2Result.rows[0].id;
  });

  afterAll(async () => {
    await pool.query('DELETE FROM tenants WHERE id = $1', [tenantId]);
    await pool.end();
  });

  // ============================================================================
  // TRUST ACCOUNT CREATION
  // ============================================================================

  describe('Trust Account Creation', () => {
    it('should create a trust account', async () => {
      const account = await trustService.createTrustAccount(tenantId, adminUserId, {
        clientId: clientId,
        accountName: 'Test Trust Account',
        bankName: 'Bank Leumi',
        currency: 'ILS',
      });

      trustAccountId = account.id;

      expect(account).toBeDefined();
      expect(account.id).toBeDefined();
      expect(account.client_id).toBe(clientId);
      expect(account.account_name).toBe('Test Trust Account');
      expect(account.balance).toBe(0);
      expect(account.is_active).toBe(true);
    });

    it('should create second trust account for transfers', async () => {
      const account = await trustService.createTrustAccount(tenantId, adminUserId, {
        clientId: client2Id,
        accountName: 'Second Trust Account',
        currency: 'ILS',
      });

      trustAccount2Id = account.id;
      expect(account.id).toBeDefined();
    });
  });

  // ============================================================================
  // IMMUTABILITY ENFORCEMENT (DB LEVEL)
  // ============================================================================

  describe('Immutability Enforcement', () => {
    let transactionId: string;

    beforeAll(async () => {
      // Create a transaction to test immutability
      const tx = await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: trustAccountId,
        client_id: clientId,
        transaction_type: 'deposit',
        amount: 100,
        description: 'Initial deposit for immutability test',
        created_by: adminUserId,
      });
      transactionId = tx.id;
    });

    it('should BLOCK UPDATE on trust_transactions at DB level', async () => {
      await expect(
        pool.query(
          'UPDATE trust_transactions SET amount = 999 WHERE id = $1',
          [transactionId]
        )
      ).rejects.toThrow(/UPDATE not allowed|immutable/i);
    });

    it('should BLOCK DELETE on trust_transactions at DB level', async () => {
      await expect(
        pool.query(
          'DELETE FROM trust_transactions WHERE id = $1',
          [transactionId]
        )
      ).rejects.toThrow(/DELETE not allowed|immutable/i);
    });

    it('should BLOCK UPDATE even for balance_after', async () => {
      await expect(
        pool.query(
          'UPDATE trust_transactions SET balance_after = 0 WHERE id = $1',
          [transactionId]
        )
      ).rejects.toThrow(/UPDATE not allowed|immutable/i);
    });

    it('should BLOCK UPDATE even for description', async () => {
      await expect(
        pool.query(
          "UPDATE trust_transactions SET description = 'hacked' WHERE id = $1",
          [transactionId]
        )
      ).rejects.toThrow(/UPDATE not allowed|immutable/i);
    });
  });

  // ============================================================================
  // BALANCE CALCULATION
  // ============================================================================

  describe('Balance Calculation', () => {
    let testAccountId: string;

    beforeEach(async () => {
      // Create fresh account for balance tests
      const account = await trustAccountRepository.createAccount(tenantId, {
        client_id: clientId,
        account_name: `Balance Test ${Date.now()}`,
      });
      testAccountId = account.id;
    });

    it('should calculate balance_after for deposits', async () => {
      // Deposit 1000
      const tx = await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: testAccountId,
        client_id: clientId,
        transaction_type: 'deposit',
        amount: 1000,
        description: 'Deposit test',
        created_by: adminUserId,
      });

      expect(tx.balance_after).toBe(1000);
      expect(tx.amount).toBe(1000);  // Positive for deposit
    });

    it('should calculate balance_after for withdrawals', async () => {
      // Deposit first
      await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: testAccountId,
        client_id: clientId,
        transaction_type: 'deposit',
        amount: 500,
        description: 'Initial deposit',
        created_by: adminUserId,
      });

      // Withdraw
      const tx = await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: testAccountId,
        client_id: clientId,
        transaction_type: 'withdrawal',
        amount: 200,
        description: 'Withdrawal test',
        created_by: adminUserId,
      });

      expect(tx.balance_after).toBe(300);  // 500 - 200
      expect(tx.amount).toBe(-200);  // Negative for withdrawal
    });

    it('should update trust_accounts.balance after each transaction', async () => {
      // Multiple transactions
      await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: testAccountId,
        client_id: clientId,
        transaction_type: 'deposit',
        amount: 1000,
        description: 'Deposit 1',
        created_by: adminUserId,
      });

      await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: testAccountId,
        client_id: clientId,
        transaction_type: 'deposit',
        amount: 500,
        description: 'Deposit 2',
        created_by: adminUserId,
      });

      await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: testAccountId,
        client_id: clientId,
        transaction_type: 'withdrawal',
        amount: 300,
        description: 'Withdrawal 1',
        created_by: adminUserId,
      });

      // Check account balance
      const account = await trustAccountRepository.findById(tenantId, testAccountId);
      expect(account?.balance).toBe(1200);  // 1000 + 500 - 300
    });

    it('should prevent negative balance on withdrawal', async () => {
      // Deposit 100
      await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: testAccountId,
        client_id: clientId,
        transaction_type: 'deposit',
        amount: 100,
        description: 'Small deposit',
        created_by: adminUserId,
      });

      // Try to withdraw 200 (more than balance)
      await expect(
        trustTransactionRepository.recordTransaction(tenantId, {
          trust_account_id: testAccountId,
          client_id: clientId,
          transaction_type: 'withdrawal',
          amount: 200,
          description: 'Overdraft attempt',
          created_by: adminUserId,
        })
      ).rejects.toThrow(/insufficient funds/i);
    });

    it('should handle all transaction types correctly', async () => {
      // Deposit
      const deposit = await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: testAccountId,
        client_id: clientId,
        transaction_type: 'deposit',
        amount: 1000,
        description: 'Initial',
        created_by: adminUserId,
      });
      expect(deposit.amount).toBeGreaterThan(0);

      // Refund (also positive)
      const refund = await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: testAccountId,
        client_id: clientId,
        transaction_type: 'refund',
        amount: 100,
        description: 'Refund',
        created_by: adminUserId,
      });
      expect(refund.amount).toBeGreaterThan(0);
      expect(refund.balance_after).toBe(1100);

      // Withdrawal (negative)
      const withdrawal = await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: testAccountId,
        client_id: clientId,
        transaction_type: 'withdrawal',
        amount: 200,
        description: 'Withdrawal',
        created_by: adminUserId,
      });
      expect(withdrawal.amount).toBeLessThan(0);
      expect(withdrawal.balance_after).toBe(900);

      // Fee deduction (negative)
      const fee = await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: testAccountId,
        client_id: clientId,
        transaction_type: 'fee_deduction',
        amount: 50,
        description: 'Service fee',
        created_by: adminUserId,
      });
      expect(fee.amount).toBeLessThan(0);
      expect(fee.balance_after).toBe(850);
    });
  });

  // ============================================================================
  // RECONCILIATION
  // ============================================================================

  describe('Reconciliation', () => {
    let reconcileAccountId: string;

    beforeEach(async () => {
      // Create account with known transactions
      const account = await trustAccountRepository.createAccount(tenantId, {
        client_id: clientId,
        account_name: `Reconcile Test ${Date.now()}`,
      });
      reconcileAccountId = account.id;

      // Add transactions
      await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: reconcileAccountId,
        client_id: clientId,
        transaction_type: 'deposit',
        amount: 1000,
        description: 'Deposit 1',
        created_by: adminUserId,
      });

      await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: reconcileAccountId,
        client_id: clientId,
        transaction_type: 'withdrawal',
        amount: 250,
        description: 'Withdrawal 1',
        created_by: adminUserId,
      });
    });

    it('should return clean match in happy path', async () => {
      const result = await trustService.reconcileBalance(tenantId, adminUserId, reconcileAccountId);

      expect(result.isReconciled).toBe(true);
      expect(result.discrepancy).toBe(0);
      expect(result.storedBalance).toBe(750);  // 1000 - 250
      expect(result.calculatedBalance).toBe(750);
      expect(result.transactionCount).toBe(2);
    });

    it('should return correct reconciliation data', async () => {
      const result = await trustService.reconcileBalance(tenantId, adminUserId, reconcileAccountId);

      expect(result.accountId).toBe(reconcileAccountId);
      expect(result.accountName).toBeDefined();
      expect(result.lastTransactionId).toBeDefined();
      expect(result.lastTransactionDate).toBeInstanceOf(Date);
    });

    it('should detect discrepancy if balance is manually corrupted', async () => {
      // Manually corrupt balance (this would never happen in practice due to triggers)
      // But we test the reconciliation logic by checking stored vs calculated
      
      const result = await trustService.reconcileBalance(tenantId, adminUserId, reconcileAccountId);
      
      // In normal operation, these should always match
      expect(result.storedBalance).toBe(result.calculatedBalance);
    });
  });

  // ============================================================================
  // TRANSFERS
  // ============================================================================

  describe('Transfers', () => {
    let fromAccountId: string;
    let toAccountId: string;

    beforeEach(async () => {
      // Create source account with funds
      const fromAccount = await trustAccountRepository.createAccount(tenantId, {
        client_id: clientId,
        account_name: `Transfer From ${Date.now()}`,
      });
      fromAccountId = fromAccount.id;

      // Fund the source account
      await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: fromAccountId,
        client_id: clientId,
        transaction_type: 'deposit',
        amount: 5000,
        description: 'Initial funding',
        created_by: adminUserId,
      });

      // Create destination account
      const toAccount = await trustAccountRepository.createAccount(tenantId, {
        client_id: client2Id,
        account_name: `Transfer To ${Date.now()}`,
      });
      toAccountId = toAccount.id;
    });

    it('should transfer funds between accounts', async () => {
      const { outTransaction, inTransaction } = await trustService.recordTransfer(
        tenantId,
        adminUserId,
        {
          fromAccountId,
          toAccountId,
          amount: 1000,
          description: 'Test transfer',
          createdBy: adminUserId,
        }
      );

      // Check outgoing transaction
      expect(outTransaction.transaction_type).toBe('transfer_out');
      expect(outTransaction.amount).toBe(-1000);  // Negative
      expect(outTransaction.balance_after).toBe(4000);  // 5000 - 1000

      // Check incoming transaction
      expect(inTransaction.transaction_type).toBe('transfer_in');
      expect(inTransaction.amount).toBe(1000);  // Positive
      expect(inTransaction.balance_after).toBe(1000);  // 0 + 1000

      // Verify related_transaction_id
      expect(inTransaction.related_transaction_id).toBe(outTransaction.id);
    });

    it('should prevent transfer with insufficient funds', async () => {
      await expect(
        trustService.recordTransfer(tenantId, adminUserId, {
          fromAccountId,
          toAccountId,
          amount: 10000,  // More than available
          description: 'Too much',
          createdBy: adminUserId,
        })
      ).rejects.toThrow(/insufficient funds/i);
    });
  });

  // ============================================================================
  // RBAC ENFORCEMENT
  // ============================================================================

  describe('RBAC Enforcement', () => {
    it('should allow admin to access trust ledger', async () => {
      await expect(
        trustService.listAccounts(tenantId, adminUserId)
      ).resolves.not.toThrow();
    });

    it('should block staff from accessing trust ledger', async () => {
      // Staff role doesn't have trust_view permission
      await expect(
        trustService.listAccounts(tenantId, staffUserId)
      ).rejects.toThrow(/PERMISSION_DENIED/);
    });

    it('should block staff from making deposits', async () => {
      await expect(
        trustService.recordDeposit(tenantId, staffUserId, {
          trustAccountId: trustAccountId,
          clientId: clientId,
          amount: 100,
          description: 'Unauthorized deposit',
        })
      ).rejects.toThrow(/PERMISSION_DENIED/);
    });

    it('should block staff from viewing reconciliation', async () => {
      await expect(
        trustService.reconcileBalance(tenantId, staffUserId, trustAccountId)
      ).rejects.toThrow(/PERMISSION_DENIED/);
    });
  });

  // ============================================================================
  // REFERENCE NUMBER GENERATION
  // ============================================================================

  describe('Reference Number Generation', () => {
    it('should auto-generate reference number', async () => {
      const account = await trustAccountRepository.createAccount(tenantId, {
        client_id: clientId,
        account_name: `RefNum Test ${Date.now()}`,
      });

      const tx = await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: account.id,
        client_id: clientId,
        transaction_type: 'deposit',
        amount: 100,
        description: 'Reference test',
        created_by: adminUserId,
      });

      expect(tx.reference_number).toMatch(/^TT-\d{4}-\d{6}$/);  // TT-YYYY-NNNNNN
    });

    it('should generate sequential reference numbers', async () => {
      const account = await trustAccountRepository.createAccount(tenantId, {
        client_id: clientId,
        account_name: `Sequential Test ${Date.now()}`,
      });

      const tx1 = await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: account.id,
        client_id: clientId,
        transaction_type: 'deposit',
        amount: 100,
        description: 'Seq 1',
        created_by: adminUserId,
      });

      const tx2 = await trustTransactionRepository.recordTransaction(tenantId, {
        trust_account_id: account.id,
        client_id: clientId,
        transaction_type: 'deposit',
        amount: 100,
        description: 'Seq 2',
        created_by: adminUserId,
      });

      // Extract sequence numbers
      const seq1 = parseInt(tx1.reference_number.split('-')[2]!);
      const seq2 = parseInt(tx2.reference_number.split('-')[2]!);
      
      expect(seq2).toBeGreaterThan(seq1);
    });
  });
});
