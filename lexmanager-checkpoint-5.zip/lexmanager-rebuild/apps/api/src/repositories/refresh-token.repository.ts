// ============================================================================
// REFRESH TOKEN REPOSITORY
// apps/api/src/repositories/refresh-token.repository.ts
// 
// Persistence layer for refresh tokens with rotation and reuse detection.
// SECURITY: Only token hashes are stored - never plaintext tokens.
// ============================================================================

import crypto from 'crypto';
import { query } from '../db/connection.js';
import { parsePostgresError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Refresh token record as stored in database
 */
export interface RefreshToken {
  id: string;
  tenant_id: string;
  user_id: string;
  token_hash: string;
  family_id: string;
  device_id: string | null;
  user_agent: string | null;
  ip_address: string | null;
  issued_at: Date;
  expires_at: Date;
  rotated_at: Date | null;
  revoked_at: Date | null;
  revoke_reason: string | null;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

/**
 * Data required to create a new refresh token
 */
export interface CreateRefreshTokenData {
  tenantId: string;
  userId: string;
  tokenHash: string;
  familyId: string;
  expiresAt: Date;
  deviceId?: string;
  userAgent?: string;
  ipAddress?: string;
}

// ============================================================================
// REPOSITORY CLASS
// ============================================================================

/**
 * Repository for refresh token persistence
 * 
 * Implements token rotation with family-based reuse detection:
 * - Each login creates a new token family
 * - On refresh, old token is marked rotated, new token inherits family
 * - If a rotated token is reused, entire family is revoked (security breach)
 */
export class RefreshTokenRepository {
  // ==========================================================================
  // STATIC UTILITIES
  // ==========================================================================

  /**
   * Hash a token for storage
   * Uses SHA-256 to create a one-way hash of the token
   * SECURITY: Never store plaintext tokens
   */
  static hashToken(token: string): string {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  /**
   * Generate a new token family ID
   * Used to group related tokens for rotation tracking
   */
  static generateFamilyId(): string {
    return crypto.randomUUID();
  }

  // ==========================================================================
  // CREATE
  // ==========================================================================

  /**
   * Create a new refresh token record
   * 
   * @param data Token data including hash (NOT plaintext)
   * @returns Created token record
   */
  async create(data: CreateRefreshTokenData): Promise<RefreshToken> {
    try {
      const result = await query<RefreshToken>(
        `INSERT INTO refresh_tokens (
          tenant_id, user_id, token_hash, family_id, expires_at,
          device_id, user_agent, ip_address
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        RETURNING *`,
        [
          data.tenantId,
          data.userId,
          data.tokenHash,
          data.familyId,
          data.expiresAt,
          data.deviceId || null,
          data.userAgent || null,
          data.ipAddress || null,
        ]
      );
      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  // ==========================================================================
  // READ
  // ==========================================================================

  /**
   * Find a token by its hash
   * Returns full record including tenant_id for service-level tenant validation
   * 
   * @param tokenHash SHA-256 hash of the token
   * @returns Token record or null if not found
   */
  async findByHash(tokenHash: string): Promise<RefreshToken | null> {
    try {
      const result = await query<RefreshToken>(
        `SELECT * FROM refresh_tokens 
         WHERE token_hash = $1 
           AND deleted_at IS NULL`,
        [tokenHash]
      );
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Find a valid (non-revoked, non-expired, non-rotated) token by hash
   * 
   * @param tokenHash SHA-256 hash of the token
   * @returns Valid token record or null
   */
  async findValidByHash(tokenHash: string): Promise<RefreshToken | null> {
    try {
      const result = await query<RefreshToken>(
        `SELECT * FROM refresh_tokens 
         WHERE token_hash = $1 
           AND revoked_at IS NULL 
           AND rotated_at IS NULL
           AND expires_at > CURRENT_TIMESTAMP
           AND deleted_at IS NULL`,
        [tokenHash]
      );
      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get all active tokens for a user (tenant-scoped)
   * 
   * @param tenantId Tenant ID for scoping
   * @param userId User ID
   * @returns Array of active token records
   */
  async getActiveForUser(tenantId: string, userId: string): Promise<RefreshToken[]> {
    try {
      const result = await query<RefreshToken>(
        `SELECT * FROM refresh_tokens 
         WHERE tenant_id = $1 
           AND user_id = $2 
           AND revoked_at IS NULL 
           AND rotated_at IS NULL
           AND expires_at > CURRENT_TIMESTAMP
           AND deleted_at IS NULL
         ORDER BY issued_at DESC`,
        [tenantId, userId]
      );
      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  // ==========================================================================
  // UPDATE - ROTATION
  // ==========================================================================

  /**
   * Atomically mark a token as rotated IF it hasn't been rotated yet.
   * 
   * CRITICAL SECURITY: This prevents race conditions where two concurrent
   * refresh requests could both succeed with the same token.
   * 
   * The SQL uses "AND rotated_at IS NULL" to ensure only the first caller wins.
   * Subsequent callers get false, indicating the token was already rotated
   * (which means token reuse/theft).
   * 
   * @param tokenId Token record ID
   * @returns true if this call rotated the token, false if already rotated
   */
  async markRotatedIfNotRotated(tokenId: string): Promise<boolean> {
    try {
      const result = await query<{ id: string }>(
        `UPDATE refresh_tokens 
         SET rotated_at = CURRENT_TIMESTAMP 
         WHERE id = $1 
           AND rotated_at IS NULL 
           AND deleted_at IS NULL
         RETURNING id`,
        [tokenId]
      );
      // If RETURNING gives us a row, we successfully rotated it
      // If no rows returned, it was already rotated (race condition lost)
      return (result.rowCount || 0) > 0;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * @deprecated Use markRotatedIfNotRotated for atomic rotation
   * Kept for backwards compatibility but should not be used in auth flows
   */
  async markRotated(tokenId: string): Promise<void> {
    await this.markRotatedIfNotRotated(tokenId);
  }

  // ==========================================================================
  // UPDATE - REVOCATION
  // ==========================================================================

  /**
   * Revoke a specific token by ID
   * 
   * @param tokenId Token record ID
   * @param reason Reason for revocation
   */
  async revoke(tokenId: string, reason: string = 'Manual revocation'): Promise<void> {
    try {
      await query(
        `UPDATE refresh_tokens 
         SET revoked_at = CURRENT_TIMESTAMP, revoke_reason = $2 
         WHERE id = $1 AND deleted_at IS NULL`,
        [tokenId, reason]
      );
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Revoke a token by its hash
   * Used for logout operations
   * 
   * @param tokenHash SHA-256 hash of the token
   * @param reason Reason for revocation
   * @returns true if a token was revoked, false if not found
   */
  async revokeByHash(tokenHash: string, reason: string = 'Manual revocation'): Promise<boolean> {
    try {
      const result = await query(
        `UPDATE refresh_tokens 
         SET revoked_at = CURRENT_TIMESTAMP, revoke_reason = $2 
         WHERE token_hash = $1 
           AND revoked_at IS NULL 
           AND deleted_at IS NULL`,
        [tokenHash, reason]
      );
      return (result.rowCount || 0) > 0;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Revoke all tokens in a family
   * SECURITY: Called when token reuse is detected - entire family is compromised
   * 
   * @param familyId Token family ID
   * @param reason Reason for revocation
   * @returns Number of tokens revoked
   */
  async revokeFamily(familyId: string, reason: string = 'Token reuse detected'): Promise<number> {
    try {
      // Use the database function for atomic operation
      const result = await query<{ revoke_token_family: number }>(
        `SELECT revoke_token_family($1, $2)`,
        [familyId, reason]
      );
      return result.rows[0]?.revoke_token_family || 0;
    } catch (error) {
      // Fallback to direct query if function doesn't exist
      try {
        const directResult = await query(
          `UPDATE refresh_tokens 
           SET revoked_at = CURRENT_TIMESTAMP, revoke_reason = $2 
           WHERE family_id = $1 
             AND revoked_at IS NULL 
             AND deleted_at IS NULL`,
          [familyId, reason]
        );
        return directResult.rowCount || 0;
      } catch {
        throw parsePostgresError(error);
      }
    }
  }

  /**
   * Revoke all tokens for a user (logout all devices)
   * Tenant-scoped for multi-tenant isolation
   * 
   * @param tenantId Tenant ID for scoping
   * @param userId User ID
   * @param reason Reason for revocation
   * @returns Number of tokens revoked
   */
  async revokeAllForUser(
    tenantId: string, 
    userId: string, 
    reason: string = 'User logout all'
  ): Promise<number> {
    try {
      // Use the database function for atomic operation
      const result = await query<{ revoke_all_user_tokens: number }>(
        `SELECT revoke_all_user_tokens($1, $2, $3)`,
        [tenantId, userId, reason]
      );
      return result.rows[0]?.revoke_all_user_tokens || 0;
    } catch (error) {
      // Fallback to direct query if function doesn't exist
      try {
        const directResult = await query(
          `UPDATE refresh_tokens 
           SET revoked_at = CURRENT_TIMESTAMP, revoke_reason = $3 
           WHERE tenant_id = $1 
             AND user_id = $2 
             AND revoked_at IS NULL 
             AND deleted_at IS NULL`,
          [tenantId, userId, reason]
        );
        return directResult.rowCount || 0;
      } catch {
        throw parsePostgresError(error);
      }
    }
  }

  // ==========================================================================
  // UTILITY
  // ==========================================================================

  /**
   * Check if a token was already rotated (reuse detection helper)
   * 
   * @param tokenHash SHA-256 hash of the token
   * @returns true if token was rotated
   */
  async wasRotated(tokenHash: string): Promise<boolean> {
    try {
      const result = await query<{ rotated_at: Date | null }>(
        `SELECT rotated_at FROM refresh_tokens 
         WHERE token_hash = $1 AND deleted_at IS NULL`,
        [tokenHash]
      );
      return result.rows[0]?.rotated_at !== null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Clean up expired tokens (soft delete)
   * Should be called periodically by a background job
   * 
   * @returns Number of tokens cleaned up
   */
  async cleanup(): Promise<number> {
    try {
      const result = await query<{ cleanup_expired_tokens: number }>(
        `SELECT cleanup_expired_tokens()`
      );
      return result.rows[0]?.cleanup_expired_tokens || 0;
    } catch (error) {
      // Fallback to direct query if function doesn't exist
      try {
        const directResult = await query(
          `UPDATE refresh_tokens 
           SET deleted_at = CURRENT_TIMESTAMP 
           WHERE expires_at < CURRENT_TIMESTAMP - INTERVAL '30 days' 
             AND deleted_at IS NULL`
        );
        return directResult.rowCount || 0;
      } catch {
        throw parsePostgresError(error);
      }
    }
  }

  /**
   * Count active sessions for a user
   * Useful for session management UI
   * 
   * @param tenantId Tenant ID for scoping
   * @param userId User ID
   * @returns Number of active sessions
   */
  async countActiveForUser(tenantId: string, userId: string): Promise<number> {
    try {
      const result = await query<{ count: string }>(
        `SELECT COUNT(*) as count FROM refresh_tokens 
         WHERE tenant_id = $1 
           AND user_id = $2 
           AND revoked_at IS NULL 
           AND rotated_at IS NULL
           AND expires_at > CURRENT_TIMESTAMP
           AND deleted_at IS NULL`,
        [tenantId, userId]
      );
      return parseInt(result.rows[0]?.count || '0', 10);
    } catch (error) {
      throw parsePostgresError(error);
    }
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const refreshTokenRepository = new RefreshTokenRepository();
