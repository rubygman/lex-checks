// ============================================================================
// PASSWORD HASHING
// apps/api/src/security/password.ts
// 
// Argon2id with OWASP-recommended parameters for legal/financial applications
// ============================================================================

import * as argon2 from 'argon2';

// ============================================================================
// ARGON2 CONFIGURATION
// Based on OWASP recommendations for high-value targets
// https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html
// ============================================================================

const ARGON2_OPTIONS: argon2.Options = {
  // Use Argon2id (hybrid of Argon2i and Argon2d)
  type: argon2.argon2id,
  
  // Memory cost: 64 MiB (OWASP recommends 47104 KiB minimum for Argon2id)
  memoryCost: 65536,  // 64 * 1024 KiB
  
  // Time cost: 3 iterations (OWASP minimum)
  timeCost: 3,
  
  // Parallelism: 4 threads
  parallelism: 4,
  
  // Hash length: 32 bytes (256 bits)
  hashLength: 32,
};

// ============================================================================
// PASSWORD HASHING FUNCTIONS
// ============================================================================

/**
 * Hash a password using Argon2id
 * Returns the full encoded hash string including parameters
 */
export async function hashPassword(plainPassword: string): Promise<string> {
  // Validate password length
  if (!plainPassword || plainPassword.length < 8) {
    throw new Error('Password must be at least 8 characters');
  }

  if (plainPassword.length > 128) {
    throw new Error('Password must be at most 128 characters');
  }

  return argon2.hash(plainPassword, ARGON2_OPTIONS);
}

/**
 * Verify a password against a stored hash
 * Returns true if password matches, false otherwise
 * Never throws on invalid password - timing-safe comparison
 */
export async function verifyPassword(
  plainPassword: string,
  hashedPassword: string
): Promise<boolean> {
  // Validate inputs
  if (!plainPassword || !hashedPassword) {
    return false;
  }

  try {
    return await argon2.verify(hashedPassword, plainPassword);
  } catch {
    // Invalid hash format or other error - return false, don't throw
    return false;
  }
}

/**
 * Check if a password hash needs to be rehashed
 * (e.g., if parameters have been upgraded)
 */
export async function needsRehash(hashedPassword: string): Promise<boolean> {
  try {
    return argon2.needsRehash(hashedPassword, ARGON2_OPTIONS);
  } catch {
    // Invalid hash format - needs rehash
    return true;
  }
}

// ============================================================================
// PASSWORD STRENGTH VALIDATION
// ============================================================================

export interface PasswordStrengthResult {
  isValid: boolean;
  score: number;  // 0-4
  feedback: string[];
}

/**
 * Validate password strength
 * Requirements for legal CRM:
 * - Minimum 12 characters (NIST recommendation)
 * - At least one uppercase, lowercase, number
 * - Not in common password list
 */
export function validatePasswordStrength(password: string): PasswordStrengthResult {
  const feedback: string[] = [];
  let score = 0;

  // Length check
  if (password.length >= 12) {
    score++;
  } else {
    feedback.push('Password should be at least 12 characters');
  }

  if (password.length >= 16) {
    score++;
  }

  // Character class checks
  if (/[a-z]/.test(password)) {
    score += 0.25;
  } else {
    feedback.push('Password should contain lowercase letters');
  }

  if (/[A-Z]/.test(password)) {
    score += 0.25;
  } else {
    feedback.push('Password should contain uppercase letters');
  }

  if (/[0-9]/.test(password)) {
    score += 0.25;
  } else {
    feedback.push('Password should contain numbers');
  }

  if (/[^a-zA-Z0-9]/.test(password)) {
    score += 0.25;
  }

  // Common password check (subset)
  const commonPasswords = [
    'password', '123456', 'qwerty', 'admin', 'letmein',
    'welcome', 'monkey', 'dragon', 'master', 'login',
    'password1', 'password123', 'abc123', '111111', '123123',
  ];

  if (commonPasswords.some(p => password.toLowerCase().includes(p))) {
    score = Math.max(0, score - 1);
    feedback.push('Password contains common patterns');
  }

  // Sequential characters check
  if (/(.)\1{2,}/.test(password)) {
    score = Math.max(0, score - 0.5);
    feedback.push('Password contains repeated characters');
  }

  return {
    isValid: score >= 2 && password.length >= 12,
    score: Math.min(4, Math.floor(score)),
    feedback,
  };
}
