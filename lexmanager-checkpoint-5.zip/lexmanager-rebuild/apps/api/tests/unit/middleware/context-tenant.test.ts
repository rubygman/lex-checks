// ============================================================================
// MIDDLEWARE UNIT TESTS
// apps/api/tests/unit/middleware/context-tenant.test.ts
// 
// Tests for initializeContext and resolveTenantFromHeader middleware
// ============================================================================

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import type { Request, Response, NextFunction } from 'express';

// ============================================================================
// MOCK SETUP
// ============================================================================

// Mock tenantRepository
vi.mock('../../../src/repositories/tenant.repository.js', () => ({
  tenantRepository: {
    findById: vi.fn(),
  },
}));

// ============================================================================
// TESTS: initializeContext
// ============================================================================

describe('initializeContext middleware', () => {
  let mockReq: Partial<Request>;
  let mockRes: Partial<Response>;
  let mockNext: NextFunction;

  beforeEach(async () => {
    mockReq = {
      headers: {},
      ip: '192.168.1.1',
      socket: { remoteAddress: '192.168.1.1' } as any,
    };
    mockRes = {
      setHeader: vi.fn(),
    };
    mockNext = vi.fn();
  });

  it('should initialize context with generated correlationId', async () => {
    const { initializeContext } = await import('../../../src/middleware/context.js');
    const middleware = initializeContext();

    middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockReq.context).toBeDefined();
    expect(mockReq.context?.correlationId).toBeDefined();
    expect(typeof mockReq.context?.correlationId).toBe('string');
    expect(mockReq.context?.correlationId.length).toBeGreaterThan(0);
  });

  it('should use existing X-Correlation-ID header', async () => {
    const { initializeContext } = await import('../../../src/middleware/context.js');
    const middleware = initializeContext();
    mockReq.headers = { 'x-correlation-id': 'existing-correlation-id' };

    middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockReq.context?.correlationId).toBe('existing-correlation-id');
  });

  it('should use X-Request-ID as fallback for correlation ID', async () => {
    const { initializeContext } = await import('../../../src/middleware/context.js');
    const middleware = initializeContext();
    mockReq.headers = { 'x-request-id': 'request-id-123' };

    middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockReq.context?.correlationId).toBe('request-id-123');
  });

  it('should extract ipAddress from request', async () => {
    const { initializeContext } = await import('../../../src/middleware/context.js');
    const middleware = initializeContext();

    middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockReq.context?.ipAddress).toBe('192.168.1.1');
  });

  it('should extract ipAddress from X-Forwarded-For header', async () => {
    const { initializeContext } = await import('../../../src/middleware/context.js');
    const middleware = initializeContext();
    mockReq.headers = { 'x-forwarded-for': '10.0.0.1, 10.0.0.2' };

    middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockReq.context?.ipAddress).toBe('10.0.0.1');
  });

  it('should extract userAgent from headers', async () => {
    const { initializeContext } = await import('../../../src/middleware/context.js');
    const middleware = initializeContext();
    mockReq.headers = { 'user-agent': 'Mozilla/5.0 Test Browser' };

    middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockReq.context?.userAgent).toBe('Mozilla/5.0 Test Browser');
  });

  it('should set X-Correlation-ID response header', async () => {
    const { initializeContext } = await import('../../../src/middleware/context.js');
    const middleware = initializeContext();

    middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockRes.setHeader).toHaveBeenCalledWith('X-Correlation-ID', expect.any(String));
  });

  it('should call next()', async () => {
    const { initializeContext } = await import('../../../src/middleware/context.js');
    const middleware = initializeContext();

    middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockNext).toHaveBeenCalled();
  });

  it('should initialize tenant as undefined', async () => {
    const { initializeContext } = await import('../../../src/middleware/context.js');
    const middleware = initializeContext();

    middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockReq.context?.tenant).toBeUndefined();
  });
});

// ============================================================================
// TESTS: resolveTenantFromHeader
// ============================================================================

describe('resolveTenantFromHeader middleware', () => {
  let mockReq: Partial<Request>;
  let mockRes: Partial<Response>;
  let mockNext: NextFunction;
  let mockJson: ReturnType<typeof vi.fn>;
  let mockStatus: ReturnType<typeof vi.fn>;

  beforeEach(async () => {
    mockJson = vi.fn();
    mockStatus = vi.fn().mockReturnValue({ json: mockJson });
    mockReq = {
      headers: {},
      context: {
        correlationId: 'test-correlation-id',
        ipAddress: '192.168.1.1',
        userAgent: 'test-agent',
      },
    } as any;
    mockRes = {
      status: mockStatus,
    };
    mockNext = vi.fn();

    // Reset mocks
    vi.clearAllMocks();
  });

  it('should reject request without X-Tenant-Id header', async () => {
    const { resolveTenantFromHeader } = await import('../../../src/middleware/tenant-resolver.js');
    const middleware = resolveTenantFromHeader();

    await middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockStatus).toHaveBeenCalledWith(400);
    expect(mockJson).toHaveBeenCalledWith({
      error: 'TENANT_HEADER_MISSING',
      message: 'Missing X-Tenant-Id header',
      correlationId: 'test-correlation-id',
    });
    expect(mockNext).not.toHaveBeenCalled();
  });

  it('should reject request with invalid UUID format', async () => {
    const { resolveTenantFromHeader } = await import('../../../src/middleware/tenant-resolver.js');
    const middleware = resolveTenantFromHeader();
    mockReq.headers = { 'x-tenant-id': 'invalid-uuid' };

    await middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockStatus).toHaveBeenCalledWith(400);
    expect(mockJson).toHaveBeenCalledWith({
      error: 'INVALID_TENANT_ID',
      message: 'Invalid tenant ID format',
      correlationId: 'test-correlation-id',
    });
  });

  it('should reject request when tenant not found', async () => {
    const { tenantRepository } = await import('../../../src/repositories/tenant.repository.js');
    const { resolveTenantFromHeader } = await import('../../../src/middleware/tenant-resolver.js');
    
    (tenantRepository.findById as any).mockResolvedValue(null);
    
    const middleware = resolveTenantFromHeader();
    mockReq.headers = { 'x-tenant-id': '550e8400-e29b-41d4-a716-446655440000' };

    await middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockStatus).toHaveBeenCalledWith(404);
    expect(mockJson).toHaveBeenCalledWith({
      error: 'TENANT_NOT_FOUND',
      message: 'Tenant not found',
      correlationId: 'test-correlation-id',
    });
  });

  it('should reject request when tenant is inactive', async () => {
    const { tenantRepository } = await import('../../../src/repositories/tenant.repository.js');
    const { resolveTenantFromHeader } = await import('../../../src/middleware/tenant-resolver.js');
    
    (tenantRepository.findById as any).mockResolvedValue({
      id: '550e8400-e29b-41d4-a716-446655440000',
      slug: 'test-tenant',
      name: 'Test Tenant',
      is_active: false,
    });
    
    const middleware = resolveTenantFromHeader();
    mockReq.headers = { 'x-tenant-id': '550e8400-e29b-41d4-a716-446655440000' };

    await middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockStatus).toHaveBeenCalledWith(403);
    expect(mockJson).toHaveBeenCalledWith({
      error: 'TENANT_INACTIVE',
      message: 'Tenant is deactivated',
      correlationId: 'test-correlation-id',
    });
  });

  it('should attach tenant context on valid request', async () => {
    const { tenantRepository } = await import('../../../src/repositories/tenant.repository.js');
    const { resolveTenantFromHeader } = await import('../../../src/middleware/tenant-resolver.js');
    
    const mockTenant = {
      id: '550e8400-e29b-41d4-a716-446655440000',
      slug: 'test-tenant',
      name: 'Test Tenant',
      is_active: true,
    };
    (tenantRepository.findById as any).mockResolvedValue(mockTenant);
    
    const middleware = resolveTenantFromHeader();
    mockReq.headers = { 'x-tenant-id': '550e8400-e29b-41d4-a716-446655440000' };

    await middleware(mockReq as Request, mockRes as Response, mockNext);

    expect((mockReq as any).context.tenant).toEqual({
      tenantId: '550e8400-e29b-41d4-a716-446655440000',
      tenantSlug: 'test-tenant',
      tenantName: 'Test Tenant',
      isActive: true,
    });
    expect(mockNext).toHaveBeenCalled();
  });
});

// ============================================================================
// TESTS: requireTenant
// ============================================================================

describe('requireTenant middleware', () => {
  let mockReq: Partial<Request>;
  let mockRes: Partial<Response>;
  let mockNext: NextFunction;
  let mockJson: ReturnType<typeof vi.fn>;
  let mockStatus: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    mockJson = vi.fn();
    mockStatus = vi.fn().mockReturnValue({ json: mockJson });
    mockRes = {
      status: mockStatus,
    };
    mockNext = vi.fn();
  });

  it('should reject request without tenant context', async () => {
    const { requireTenant } = await import('../../../src/middleware/tenant-resolver.js');
    const middleware = requireTenant();
    mockReq = {
      context: {
        correlationId: 'test-correlation-id',
        ipAddress: '192.168.1.1',
        userAgent: 'test-agent',
      },
    } as any;

    middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockStatus).toHaveBeenCalledWith(400);
    expect(mockJson).toHaveBeenCalledWith({
      error: 'TENANT_REQUIRED',
      message: 'Tenant context is required for this endpoint',
      correlationId: 'test-correlation-id',
    });
    expect(mockNext).not.toHaveBeenCalled();
  });

  it('should call next() when tenant context is present', async () => {
    const { requireTenant } = await import('../../../src/middleware/tenant-resolver.js');
    const middleware = requireTenant();
    mockReq = {
      context: {
        correlationId: 'test-correlation-id',
        ipAddress: '192.168.1.1',
        userAgent: 'test-agent',
        tenant: {
          tenantId: '550e8400-e29b-41d4-a716-446655440000',
          tenantSlug: 'test-tenant',
          tenantName: 'Test Tenant',
          isActive: true,
        },
      },
    } as any;

    middleware(mockReq as Request, mockRes as Response, mockNext);

    expect(mockNext).toHaveBeenCalled();
    expect(mockStatus).not.toHaveBeenCalled();
  });
});

// ============================================================================
// TESTS: Error responses include correlationId
// ============================================================================

describe('Error responses include correlationId', () => {
  it('should include correlationId in all error responses from tenant resolver', async () => {
    const { tenantRepository } = await import('../../../src/repositories/tenant.repository.js');
    const { resolveTenantFromHeader } = await import('../../../src/middleware/tenant-resolver.js');
    
    const mockJson = vi.fn();
    const mockStatus = vi.fn().mockReturnValue({ json: mockJson });
    const mockReq = {
      headers: {},
      context: {
        correlationId: 'unique-correlation-123',
        ipAddress: '192.168.1.1',
        userAgent: 'test-agent',
      },
    } as any;
    const mockRes = { status: mockStatus } as any;
    const mockNext = vi.fn();

    const middleware = resolveTenantFromHeader();
    await middleware(mockReq, mockRes, mockNext);

    expect(mockJson).toHaveBeenCalledWith(
      expect.objectContaining({
        correlationId: 'unique-correlation-123',
      })
    );
  });

  it('should include correlationId in requireTenant error responses', async () => {
    const { requireTenant } = await import('../../../src/middleware/tenant-resolver.js');
    
    const mockJson = vi.fn();
    const mockStatus = vi.fn().mockReturnValue({ json: mockJson });
    const mockReq = {
      context: {
        correlationId: 'another-correlation-456',
        ipAddress: '192.168.1.1',
        userAgent: 'test-agent',
      },
    } as any;
    const mockRes = { status: mockStatus } as any;
    const mockNext = vi.fn();

    const middleware = requireTenant();
    middleware(mockReq, mockRes, mockNext);

    expect(mockJson).toHaveBeenCalledWith(
      expect.objectContaining({
        correlationId: 'another-correlation-456',
      })
    );
  });
});
