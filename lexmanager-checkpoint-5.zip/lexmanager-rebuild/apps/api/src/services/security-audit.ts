// ============================================================================
// SECURITY AUDIT HELPER
// apps/api/src/services/security-audit.ts
// 
// Best-effort security event logging for authentication flows.
// CRITICAL: Audit failures must NEVER break auth flows.
// PRIVACY: Never log secrets (tokens, passwords, reset tokens).
// ============================================================================

import { query } from '../db/connection.js';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Security-related audit actions
 */
export type SecurityAction =
  | 'LOGIN_SUCCESS'
  | 'LOGIN_FAILED'
  | 'LOGOUT'
  | 'LOGOUT_ALL'
  | 'REGISTER'
  | 'PASSWORD_RESET_REQUEST'
  | 'PASSWORD_RESET_COMPLETE'
  | 'REFRESH_TOKEN_ISSUED'
  | 'REFRESH_TOKEN_ROTATED'
  | 'REFRESH_TOKEN_REUSE'
  | 'REFRESH_TOKEN_REVOKED'
  | 'ACCOUNT_LOCKED'
  | 'ACCOUNT_UNLOCKED';

/**
 * Metadata for audit events
 */
export interface AuditMeta {
  ipAddress?: string | null;
  userAgent?: string | null;
  sessionId?: string | null;
  requestId?: string | null;
}

/**
 * Options for recording an audit event
 */
export interface SecurityAuditOptions {
  tenantId: string;
  userId?: string | null;
  action: SecurityAction;
  description: string;
  meta?: AuditMeta;
  /** Additional safe data (NEVER include secrets) */
  additionalData?: Record<string, unknown>;
  /** Whether this is a financial event (7-year retention) */
  isFinancial?: boolean;
}

// ============================================================================
// PRIVACY HELPERS
// ============================================================================

/**
 * List of field names that must NEVER be logged
 * Used to sanitize any additional data
 */
const SENSITIVE_FIELDS = new Set([
  'password',
  'password_hash',
  'passwordHash',
  'token',
  'refreshToken',
  'refresh_token',
  'accessToken',
  'access_token',
  'resetToken',
  'reset_token',
  'secret',
  'apiKey',
  'api_key',
  'privateKey',
  'private_key',
  'creditCard',
  'credit_card',
  'ssn',
  'socialSecurityNumber',
]);

/**
 * Sanitize an object by removing sensitive fields
 * Returns a new object without modifying the original
 */
function sanitizeData(data: Record<string, unknown> | null | undefined): Record<string, unknown> | null {
  if (!data) return null;

  const sanitized: Record<string, unknown> = {};
  
  for (const [key, value] of Object.entries(data)) {
    // Skip sensitive fields
    if (SENSITIVE_FIELDS.has(key) || SENSITIVE_FIELDS.has(key.toLowerCase())) {
      continue;
    }

    // Redact any value that looks like a token (long hex or base64)
    if (typeof value === 'string' && isLikelyToken(value)) {
      sanitized[key] = '[REDACTED]';
      continue;
    }

    // Recursively sanitize nested objects
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      sanitized[key] = sanitizeData(value as Record<string, unknown>);
    } else {
      sanitized[key] = value;
    }
  }

  return Object.keys(sanitized).length > 0 ? sanitized : null;
}

/**
 * Check if a string looks like a token (long hex or base64)
 */
function isLikelyToken(value: string): boolean {
  // Hex strings longer than 32 chars
  if (/^[0-9a-f]{32,}$/i.test(value)) return true;
  // Base64 strings longer than 40 chars
  if (/^[A-Za-z0-9+/=]{40,}$/.test(value)) return true;
  // JWT-like strings
  if (/^eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(value)) return true;
  return false;
}

// ============================================================================
// AUDIT RECORDING
// ============================================================================

/**
 * Record a security audit event
 * 
 * CRITICAL: This function is best-effort and will NEVER throw.
 * Auth flows must continue even if audit logging fails.
 * 
 * @param options Audit event options
 */
export async function recordSecurityAudit(options: SecurityAuditOptions): Promise<void> {
  try {
    const {
      tenantId,
      userId,
      action,
      description,
      meta,
      additionalData,
      isFinancial = false,
    } = options;

    // Sanitize additional data to ensure no secrets are logged
    const sanitizedData = sanitizeData(additionalData);

    // Calculate retention date (7 years for financial, 3 years otherwise)
    const retentionYears = isFinancial ? 7 : 3;
    const retentionDate = new Date();
    retentionDate.setFullYear(retentionDate.getFullYear() + retentionYears);

    // Insert audit log entry
    // Note: entry_hash and previous_hash are calculated by database trigger
    await query(
      `INSERT INTO audit.logs (
        tenant_id,
        user_id,
        action,
        action_category,
        entity_type,
        description,
        changes_json,
        ip_address,
        user_agent,
        request_id,
        retention_date,
        is_financial
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`,
      [
        tenantId,
        userId || null,
        action,
        'SECURITY',
        'auth',
        description,
        sanitizedData ? JSON.stringify(sanitizedData) : null,
        meta?.ipAddress || null,
        meta?.userAgent || null,
        meta?.requestId || null,
        retentionDate,
        isFinancial,
      ]
    );
  } catch (error) {
    // CRITICAL: Never throw from audit logging
    // Log to console for ops visibility, but don't break the auth flow
    console.error('[SecurityAudit] Failed to record audit event:', {
      action: options.action,
      tenantId: options.tenantId,
      error: error instanceof Error ? error.message : 'Unknown error',
    });
  }
}

// ============================================================================
// CONVENIENCE FUNCTIONS
// ============================================================================

/**
 * Record a successful login
 */
export async function auditLoginSuccess(
  tenantId: string,
  userId: string,
  meta?: AuditMeta
): Promise<void> {
  await recordSecurityAudit({
    tenantId,
    userId,
    action: 'LOGIN_SUCCESS',
    description: 'User logged in successfully',
    meta,
  });
}

/**
 * Record a failed login attempt
 */
export async function auditLoginFailed(
  tenantId: string,
  userId: string | null,
  reason: string,
  meta?: AuditMeta
): Promise<void> {
  await recordSecurityAudit({
    tenantId,
    userId,
    action: 'LOGIN_FAILED',
    description: `Login failed: ${reason}`,
    meta,
  });
}

/**
 * Record user registration
 */
export async function auditRegistration(
  tenantId: string,
  userId: string,
  email: string,
  isFirstUser: boolean,
  meta?: AuditMeta
): Promise<void> {
  await recordSecurityAudit({
    tenantId,
    userId,
    action: 'REGISTER',
    // Don't log email in description, just note it happened
    description: isFirstUser 
      ? 'First user registered (assigned admin role)' 
      : 'User registered',
    meta,
    additionalData: {
      isFirstUser,
      // Only log email domain for privacy
      emailDomain: email.split('@')[1],
    },
  });
}

/**
 * Record refresh token reuse detection (SECURITY EVENT)
 */
export async function auditRefreshTokenReuse(
  tenantId: string,
  userId: string,
  familyId: string,
  meta?: AuditMeta
): Promise<void> {
  await recordSecurityAudit({
    tenantId,
    userId,
    action: 'REFRESH_TOKEN_REUSE',
    description: `Refresh token reuse detected. Token family ${familyId} has been revoked. This may indicate token theft.`,
    meta,
    additionalData: {
      familyId,
      reason: 'Token reuse detected - possible theft',
      remediation: 'All tokens in family revoked',
    },
    // Token reuse is a security incident, keep longer
    isFinancial: false,
  });
}

/**
 * Record logout
 */
export async function auditLogout(
  tenantId: string,
  userId: string,
  logoutAll: boolean,
  sessionsRevoked: number,
  meta?: AuditMeta
): Promise<void> {
  await recordSecurityAudit({
    tenantId,
    userId,
    action: logoutAll ? 'LOGOUT_ALL' : 'LOGOUT',
    description: logoutAll 
      ? `User logged out from all devices (${sessionsRevoked} sessions revoked)`
      : 'User logged out',
    meta,
    additionalData: logoutAll ? { sessionsRevoked } : undefined,
  });
}

/**
 * Record password reset request
 */
export async function auditPasswordResetRequest(
  tenantId: string,
  userId: string | null,
  emailFound: boolean,
  meta?: AuditMeta
): Promise<void> {
  await recordSecurityAudit({
    tenantId,
    userId,
    action: 'PASSWORD_RESET_REQUEST',
    // Don't reveal if email was found
    description: 'Password reset requested',
    meta,
    additionalData: {
      // Only for internal audit, not exposed to user
      emailFound,
    },
  });
}

/**
 * Record password reset completion
 */
export async function auditPasswordResetComplete(
  tenantId: string,
  userId: string,
  meta?: AuditMeta
): Promise<void> {
  await recordSecurityAudit({
    tenantId,
    userId,
    action: 'PASSWORD_RESET_COMPLETE',
    description: 'Password was reset successfully. All refresh tokens revoked.',
    meta,
  });
}
