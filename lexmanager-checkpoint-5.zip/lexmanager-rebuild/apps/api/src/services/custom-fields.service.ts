// ============================================================================
// CUSTOM FIELDS SERVICE
// apps/api/src/services/custom-fields.service.ts
// ============================================================================

import {
  customFieldDefinitionRepository,
  type CustomFieldDefinition,
  type CustomFieldType,
  type CustomFieldEntityType,
  type CreateDefinitionData,
  type UpdateDefinitionData,
  type SelectOption,
  type FieldOptions,
} from '../repositories/custom-field-definition.repository.js';
import {
  customFieldValueRepository,
  type CustomFieldValue,
  type CustomFieldWithValue,
} from '../repositories/custom-field-value.repository.js';
import { rbacService, PERMISSIONS } from './rbac.service.js';
import { DatabaseError, DuplicateError, TenantScopingError } from '../db/errors.js';

// ============================================================================
// TYPES
// ============================================================================

export interface CreateDefinitionInput {
  entityType: CustomFieldEntityType;
  fieldKey: string;
  fieldType: CustomFieldType;
  label: string;
  labelHe?: string;
  description?: string;
  isRequired?: boolean;
  isSearchable?: boolean;
  displayOrder?: number;
  defaultValue?: unknown;
  options?: SelectOption[];
  validation?: Record<string, unknown>;
}

export interface UpdateDefinitionInput {
  label?: string;
  labelHe?: string;
  description?: string;
  isRequired?: boolean;
  isSearchable?: boolean;
  displayOrder?: number;
  defaultValue?: unknown;
  options?: SelectOption[];
  validation?: Record<string, unknown>;
}

export interface CustomFieldResult {
  definitionId: string;
  fieldKey: string;
  fieldType: CustomFieldType;
  label: string;
  labelHe: string | null;
  description: string | null;
  isRequired: boolean;
  displayOrder: number;
  options: SelectOption[] | null;
  value: unknown;
  displayValue: string | null;
}

// ============================================================================
// VALIDATION
// ============================================================================

const VALID_FIELD_TYPES: CustomFieldType[] = [
  'text', 'number', 'boolean', 'date', 'datetime', 'select', 'multi_select', 'json'
];

const VALID_ENTITY_TYPES: CustomFieldEntityType[] = [
  'clients', 'cases', 'tasks', 'documents', 'invoices', 'users'
];

const FIELD_KEY_PATTERN = /^[a-z][a-z0-9_]*$/;

// ============================================================================
// SERVICE
// ============================================================================

export class CustomFieldsService {
  // ==========================================================================
  // DEFINITION MANAGEMENT
  // ==========================================================================

  /**
   * Create a new custom field definition
   * Requires: custom_fields_manage permission
   */
  async createDefinition(
    tenantId: string,
    userId: string,
    input: CreateDefinitionInput
  ): Promise<CustomFieldDefinition> {
    // RBAC check
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.CUSTOM_FIELDS_MANAGE);

    // Validate input
    this.validateDefinitionInput(input);

    // Check field key availability
    const isAvailable = await customFieldDefinitionRepository.isFieldKeyAvailable(
      tenantId,
      input.entityType,
      input.fieldKey
    );

    if (!isAvailable) {
      throw new DuplicateError(
        `Custom field with key "${input.fieldKey}" already exists for ${input.entityType}`,
        'field_key'
      );
    }

    // Build options_json
    const optionsJson: FieldOptions = {};
    if (input.options) {
      optionsJson.options = input.options;
    }

    // Build default_value_json
    const defaultValueJson = input.defaultValue !== undefined
      ? { value: input.defaultValue }
      : undefined;

    // Create definition
    return customFieldDefinitionRepository.createDefinition(tenantId, {
      entity_type: input.entityType,
      field_key: input.fieldKey,
      field_type: input.fieldType,
      label: input.label,
      label_he: input.labelHe,
      description: input.description,
      is_required: input.isRequired,
      is_searchable: input.isSearchable,
      display_order: input.displayOrder,
      default_value_json: defaultValueJson,
      options_json: Object.keys(optionsJson).length > 0 ? optionsJson : undefined,
      validation_json: input.validation,
    });
  }

  /**
   * Update a custom field definition
   * Requires: custom_fields_manage permission
   */
  async updateDefinition(
    tenantId: string,
    userId: string,
    definitionId: string,
    input: UpdateDefinitionInput
  ): Promise<CustomFieldDefinition> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.CUSTOM_FIELDS_MANAGE);

    // Validate options if provided
    if (input.options !== undefined) {
      this.validateSelectOptions(input.options);
    }

    // Build update data
    const updateData: UpdateDefinitionData = {};

    if (input.label !== undefined) updateData.label = input.label;
    if (input.labelHe !== undefined) updateData.label_he = input.labelHe;
    if (input.description !== undefined) updateData.description = input.description;
    if (input.isRequired !== undefined) updateData.is_required = input.isRequired;
    if (input.isSearchable !== undefined) updateData.is_searchable = input.isSearchable;
    if (input.displayOrder !== undefined) updateData.display_order = input.displayOrder;
    if (input.defaultValue !== undefined) {
      updateData.default_value_json = { value: input.defaultValue };
    }
    if (input.options !== undefined) {
      updateData.options_json = { options: input.options };
    }
    if (input.validation !== undefined) {
      updateData.validation_json = input.validation;
    }

    return customFieldDefinitionRepository.updateDefinition(tenantId, definitionId, updateData);
  }

  /**
   * Delete a custom field definition (soft delete)
   * Requires: custom_fields_manage permission
   */
  async deleteDefinition(
    tenantId: string,
    userId: string,
    definitionId: string
  ): Promise<void> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.CUSTOM_FIELDS_MANAGE);
    await customFieldDefinitionRepository.softDelete(tenantId, definitionId);
  }

  /**
   * List definitions for an entity type
   */
  async listDefinitions(
    tenantId: string,
    entityType: CustomFieldEntityType
  ): Promise<CustomFieldDefinition[]> {
    this.validateEntityType(entityType);
    return customFieldDefinitionRepository.listByEntityType(tenantId, entityType);
  }

  /**
   * Get definition by field key
   */
  async getDefinitionByKey(
    tenantId: string,
    entityType: CustomFieldEntityType,
    fieldKey: string
  ): Promise<CustomFieldDefinition | null> {
    return customFieldDefinitionRepository.findByFieldKey(tenantId, entityType, fieldKey);
  }

  /**
   * Reorder definitions
   * Requires: custom_fields_manage permission
   */
  async reorderDefinitions(
    tenantId: string,
    userId: string,
    entityType: CustomFieldEntityType,
    orderedIds: string[]
  ): Promise<void> {
    await rbacService.requirePermission(tenantId, userId, PERMISSIONS.CUSTOM_FIELDS_MANAGE);
    await customFieldDefinitionRepository.reorder(tenantId, entityType, orderedIds);
  }

  // ==========================================================================
  // VALUE MANAGEMENT
  // ==========================================================================

  /**
   * Set a custom field value
   */
  async setValue(
    tenantId: string,
    entityType: CustomFieldEntityType,
    entityId: string,
    fieldKey: string,
    value: unknown
  ): Promise<CustomFieldValue> {
    // Get definition
    const definition = await customFieldDefinitionRepository.findByFieldKeyOrFail(
      tenantId,
      entityType,
      fieldKey
    );

    // Validate value against field type
    this.validateValue(definition.field_type, value, definition);

    // Prepare value data based on field type
    const valueData = this.prepareValueData(definition.field_type, value);

    // Set value
    return customFieldValueRepository.setValue(tenantId, {
      definition_id: definition.id,
      entity_type: entityType,
      entity_id: entityId,
      ...valueData,
    });
  }

  /**
   * Set multiple custom field values at once
   */
  async setValues(
    tenantId: string,
    entityType: CustomFieldEntityType,
    entityId: string,
    values: Record<string, unknown>
  ): Promise<void> {
    for (const [fieldKey, value] of Object.entries(values)) {
      await this.setValue(tenantId, entityType, entityId, fieldKey, value);
    }
  }

  /**
   * Get all custom field values for an entity
   * Returns merged definition + value, ordered by display_order
   */
  async getValuesForEntity(
    tenantId: string,
    entityType: CustomFieldEntityType,
    entityId: string
  ): Promise<CustomFieldResult[]> {
    const rows = await customFieldValueRepository.getValuesForEntity(
      tenantId,
      entityType,
      entityId
    );

    return rows.map(row => this.mapToResult(row));
  }

  /**
   * Get a specific field value
   */
  async getValue(
    tenantId: string,
    entityType: CustomFieldEntityType,
    entityId: string,
    fieldKey: string
  ): Promise<unknown> {
    const definition = await customFieldDefinitionRepository.findByFieldKey(
      tenantId,
      entityType,
      fieldKey
    );

    if (!definition) {
      return undefined;
    }

    const value = await customFieldValueRepository.getValue(
      tenantId,
      definition.id,
      entityType,
      entityId
    );

    if (!value) {
      return undefined;
    }

    return this.extractValue(definition.field_type, value);
  }

  /**
   * Delete a custom field value
   */
  async deleteValue(
    tenantId: string,
    entityType: CustomFieldEntityType,
    entityId: string,
    fieldKey: string
  ): Promise<boolean> {
    const definition = await customFieldDefinitionRepository.findByFieldKey(
      tenantId,
      entityType,
      fieldKey
    );

    if (!definition) {
      return false;
    }

    return customFieldValueRepository.deleteValue(
      tenantId,
      definition.id,
      entityType,
      entityId
    );
  }

  /**
   * Delete all custom field values for an entity
   */
  async deleteAllValuesForEntity(
    tenantId: string,
    entityType: CustomFieldEntityType,
    entityId: string
  ): Promise<number> {
    return customFieldValueRepository.deleteAllForEntity(tenantId, entityType, entityId);
  }

  // ==========================================================================
  // VALIDATION
  // ==========================================================================

  /**
   * Validate definition input
   */
  private validateDefinitionInput(input: CreateDefinitionInput): void {
    // Validate entity type
    this.validateEntityType(input.entityType);

    // Validate field type
    if (!VALID_FIELD_TYPES.includes(input.fieldType)) {
      throw new DatabaseError(
        `Invalid field type: ${input.fieldType}. Valid types: ${VALID_FIELD_TYPES.join(', ')}`,
        'INVALID_FIELD_TYPE',
        400
      );
    }

    // Validate field key format
    if (!FIELD_KEY_PATTERN.test(input.fieldKey)) {
      throw new DatabaseError(
        'Field key must start with a lowercase letter and contain only lowercase letters, numbers, and underscores',
        'INVALID_FIELD_KEY',
        400
      );
    }

    // Validate label
    if (!input.label || input.label.trim() === '') {
      throw new DatabaseError('Label is required', 'INVALID_LABEL', 400);
    }

    // Validate options for select/multi_select
    if (input.fieldType === 'select' || input.fieldType === 'multi_select') {
      if (!input.options || input.options.length === 0) {
        throw new DatabaseError(
          `Options are required for ${input.fieldType} fields`,
          'MISSING_OPTIONS',
          400
        );
      }
      this.validateSelectOptions(input.options);
    }
  }

  /**
   * Validate entity type
   */
  private validateEntityType(entityType: string): void {
    if (!VALID_ENTITY_TYPES.includes(entityType as CustomFieldEntityType)) {
      throw new DatabaseError(
        `Invalid entity type: ${entityType}. Valid types: ${VALID_ENTITY_TYPES.join(', ')}`,
        'INVALID_ENTITY_TYPE',
        400
      );
    }
  }

  /**
   * Validate select options
   */
  private validateSelectOptions(options: SelectOption[]): void {
    const values = new Set<string>();

    for (const option of options) {
      // Validate required fields
      if (!option.value || option.value.trim() === '') {
        throw new DatabaseError('Option value is required', 'INVALID_OPTION', 400);
      }
      if (!option.label || option.label.trim() === '') {
        throw new DatabaseError('Option label is required', 'INVALID_OPTION', 400);
      }

      // Check for duplicate values
      if (values.has(option.value)) {
        throw new DatabaseError(
          `Duplicate option value: ${option.value}`,
          'DUPLICATE_OPTION',
          400
        );
      }
      values.add(option.value);
    }
  }

  /**
   * Validate value against field type
   */
  private validateValue(
    fieldType: CustomFieldType,
    value: unknown,
    definition: CustomFieldDefinition
  ): void {
    // Handle null/undefined
    if (value === null || value === undefined) {
      if (definition.is_required) {
        throw new DatabaseError(
          `Required field "${definition.field_key}" cannot be null`,
          'REQUIRED_FIELD',
          400
        );
      }
      return;
    }

    switch (fieldType) {
      case 'text':
        if (typeof value !== 'string') {
          throw new DatabaseError(
            `Field "${definition.field_key}" expects a string`,
            'INVALID_VALUE_TYPE',
            400
          );
        }
        break;

      case 'number':
        if (typeof value !== 'number' || isNaN(value)) {
          throw new DatabaseError(
            `Field "${definition.field_key}" expects a number`,
            'INVALID_VALUE_TYPE',
            400
          );
        }
        break;

      case 'boolean':
        if (typeof value !== 'boolean') {
          throw new DatabaseError(
            `Field "${definition.field_key}" expects a boolean`,
            'INVALID_VALUE_TYPE',
            400
          );
        }
        break;

      case 'date':
      case 'datetime':
        if (!(value instanceof Date) && typeof value !== 'string') {
          throw new DatabaseError(
            `Field "${definition.field_key}" expects a date`,
            'INVALID_VALUE_TYPE',
            400
          );
        }
        break;

      case 'select':
        if (typeof value !== 'string') {
          throw new DatabaseError(
            `Field "${definition.field_key}" expects a string`,
            'INVALID_VALUE_TYPE',
            400
          );
        }
        // Validate against options (also validated by DB trigger)
        this.validateSelectValue(value, definition);
        break;

      case 'multi_select':
        if (!Array.isArray(value)) {
          throw new DatabaseError(
            `Field "${definition.field_key}" expects an array`,
            'INVALID_VALUE_TYPE',
            400
          );
        }
        // Validate each value against options
        for (const v of value) {
          this.validateSelectValue(v, definition);
        }
        break;

      case 'json':
        // Any value is valid for JSON
        break;
    }
  }

  /**
   * Validate a select value against options
   */
  private validateSelectValue(value: string, definition: CustomFieldDefinition): void {
    const options = (definition.options_json as FieldOptions)?.options || [];
    const validValues = options.map(o => o.value);

    if (!validValues.includes(value)) {
      throw new DatabaseError(
        `Invalid value "${value}" for field "${definition.field_key}". Valid options: ${validValues.join(', ')}`,
        'INVALID_OPTION_VALUE',
        400
      );
    }
  }

  // ==========================================================================
  // HELPERS
  // ==========================================================================

  /**
   * Prepare value data for storage
   */
  private prepareValueData(fieldType: CustomFieldType, value: unknown): {
    value_text?: string | null;
    value_number?: number | null;
    value_boolean?: boolean | null;
    value_date?: Date | null;
    value_datetime?: Date | null;
    value_json?: unknown | null;
  } {
    if (value === null || value === undefined) {
      return {
        value_text: null,
        value_number: null,
        value_boolean: null,
        value_date: null,
        value_datetime: null,
        value_json: null,
      };
    }

    switch (fieldType) {
      case 'text':
      case 'select':
        return { value_text: value as string };
      case 'number':
        return { value_number: value as number };
      case 'boolean':
        return { value_boolean: value as boolean };
      case 'date':
        return { value_date: value instanceof Date ? value : new Date(value as string) };
      case 'datetime':
        return { value_datetime: value instanceof Date ? value : new Date(value as string) };
      case 'multi_select':
      case 'json':
        return { value_json: value };
      default:
        return { value_text: String(value) };
    }
  }

  /**
   * Extract value from stored data
   */
  private extractValue(fieldType: CustomFieldType, value: CustomFieldValue): unknown {
    switch (fieldType) {
      case 'text':
      case 'select':
        return value.value_text;
      case 'number':
        return value.value_number;
      case 'boolean':
        return value.value_boolean;
      case 'date':
        return value.value_date;
      case 'datetime':
        return value.value_datetime;
      case 'multi_select':
      case 'json':
        return value.value_json;
      default:
        return value.value_text;
    }
  }

  /**
   * Map database row to result
   */
  private mapToResult(row: CustomFieldWithValue): CustomFieldResult {
    let value: unknown = null;

    switch (row.field_type) {
      case 'text':
      case 'select':
        value = row.value_text;
        break;
      case 'number':
        value = row.value_number;
        break;
      case 'boolean':
        value = row.value_boolean;
        break;
      case 'date':
        value = row.value_date;
        break;
      case 'datetime':
        value = row.value_datetime;
        break;
      case 'multi_select':
      case 'json':
        value = row.value_json;
        break;
    }

    return {
      definitionId: row.definition_id,
      fieldKey: row.field_key,
      fieldType: row.field_type,
      label: row.label,
      labelHe: row.label_he,
      description: row.description,
      isRequired: row.is_required,
      displayOrder: row.display_order,
      options: (row.options as FieldOptions)?.options || null,
      value,
      displayValue: row.display_value,
    };
  }
}

export const customFieldsService = new CustomFieldsService();
