// ============================================================================
// INTEGRATIONS INDEX
// apps/api/src/integrations/index.ts
// ============================================================================

// Mailer
export {
  createMailer,
  getMailer,
  setMailer,
  resetMailer,
  sendPasswordResetEmail,
  type Mailer,
  type SendEmailResult,
  type PasswordResetEmailData,
  type WelcomeEmailData,
} from './mailer.js';
