// ============================================================================
// SECURE LOGGER
// apps/api/src/security/logger.ts
// 
// Logger with automatic redaction of sensitive data
// ============================================================================

import { getConfig } from '../config/index.js';

// ============================================================================
// TYPES
// ============================================================================

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogContext {
  correlationId?: string;
  userId?: string;
  tenantId?: string;
  action?: string;
  entityType?: string;
  entityId?: string;
  duration?: number;
  [key: string]: unknown;
}

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  correlationId?: string;
  context?: Record<string, unknown>;
}

// ============================================================================
// REDACTION PATTERNS
// ============================================================================

/**
 * Patterns for sensitive data that should be redacted
 */
const REDACTION_PATTERNS: Array<{ pattern: RegExp; replacement: string; name: string }> = [
  // Israeli ID (Teudat Zehut) - 9 digits
  { 
    pattern: /\b\d{9}\b/g, 
    replacement: '[ISRAELI_ID_REDACTED]',
    name: 'Israeli ID'
  },
  
  // Credit card numbers (with or without spaces/dashes)
  { 
    pattern: /\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b/g, 
    replacement: '[CARD_REDACTED]',
    name: 'Credit Card'
  },
  
  // Israeli phone numbers
  { 
    pattern: /\b0[2-9]\d{7,8}\b/g, 
    replacement: '[PHONE_REDACTED]',
    name: 'Phone Number'
  },
  
  // Passport numbers (common patterns)
  { 
    pattern: /\b[A-Z]{1,2}\d{6,9}\b/g, 
    replacement: '[PASSPORT_REDACTED]',
    name: 'Passport'
  },
  
  // JWT tokens
  { 
    pattern: /eyJ[a-zA-Z0-9_-]+\.eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+/g, 
    replacement: '[JWT_REDACTED]',
    name: 'JWT Token'
  },
  
  // Password fields in JSON
  { 
    pattern: /"password"\s*:\s*"[^"]+"/gi, 
    replacement: '"password":"[REDACTED]"',
    name: 'Password JSON'
  },
  
  // API keys (common patterns)
  { 
    pattern: /\b(api[_-]?key|apikey|api[_-]?secret)\s*[:=]\s*['"]?[a-zA-Z0-9_-]{20,}['"]?/gi, 
    replacement: '[API_KEY_REDACTED]',
    name: 'API Key'
  },
  
  // Base64 encoded data (potentially sensitive)
  {
    pattern: /[A-Za-z0-9+/]{50,}={0,2}/g,
    replacement: '[BASE64_REDACTED]',
    name: 'Base64 Data'
  },
];

/**
 * Fields that should never be logged
 */
const SENSITIVE_FIELDS = new Set([
  'password',
  'password_hash',
  'passwordHash',
  'secret',
  'token',
  'accessToken',
  'refreshToken',
  'access_token',
  'refresh_token',
  'api_key',
  'apiKey',
  'private_key',
  'privateKey',
  'tax_id',
  'taxId',
  'id_number',
  'idNumber',
  'social_security',
  'socialSecurity',
  'ssn',
  'credit_card',
  'creditCard',
  'card_number',
  'cardNumber',
  'cvv',
  'bank_account',
  'bankAccount',
  'document_content',
  'documentContent',
  'file_content',
  'fileContent',
]);

// ============================================================================
// REDACTION FUNCTIONS
// ============================================================================

/**
 * Redact sensitive patterns from a string
 */
function redactString(value: string): string {
  let result = value;
  
  for (const { pattern, replacement } of REDACTION_PATTERNS) {
    result = result.replace(pattern, replacement);
  }
  
  return result;
}

/**
 * Recursively redact sensitive fields from an object
 */
function redactObject(obj: unknown, depth = 0): unknown {
  // Prevent infinite recursion
  if (depth > 10) return '[MAX_DEPTH_EXCEEDED]';
  
  if (obj === null || obj === undefined) {
    return obj;
  }
  
  if (typeof obj === 'string') {
    return redactString(obj);
  }
  
  if (Array.isArray(obj)) {
    return obj.map(item => redactObject(item, depth + 1));
  }
  
  if (typeof obj === 'object') {
    const result: Record<string, unknown> = {};
    
    for (const [key, value] of Object.entries(obj)) {
      // Check if field should be completely redacted
      if (SENSITIVE_FIELDS.has(key.toLowerCase())) {
        result[key] = '[REDACTED]';
      } else if (typeof value === 'string') {
        result[key] = redactString(value);
      } else if (typeof value === 'object' && value !== null) {
        result[key] = redactObject(value, depth + 1);
      } else {
        result[key] = value;
      }
    }
    
    return result;
  }
  
  return obj;
}

// ============================================================================
// LOGGER CLASS
// ============================================================================

export class SecureLogger {
  private readonly minLevel: LogLevel;
  private readonly format: 'json' | 'pretty';
  
  private readonly levelPriority: Record<LogLevel, number> = {
    debug: 0,
    info: 1,
    warn: 2,
    error: 3,
  };
  
  constructor() {
    const config = getConfig();
    this.minLevel = config.logging.level;
    this.format = config.logging.format;
  }
  
  /**
   * Check if a log level should be output
   */
  private shouldLog(level: LogLevel): boolean {
    return this.levelPriority[level] >= this.levelPriority[this.minLevel];
  }
  
  /**
   * Format and output a log entry
   */
  private log(level: LogLevel, message: string, context?: LogContext): void {
    if (!this.shouldLog(level)) return;
    
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message: redactString(message),
      correlationId: context?.correlationId,
      context: context ? redactObject(context) as Record<string, unknown> : undefined,
    };
    
    // Remove undefined fields
    if (!entry.correlationId) delete entry.correlationId;
    if (!entry.context || Object.keys(entry.context).length === 0) delete entry.context;
    
    const output = this.format === 'json'
      ? JSON.stringify(entry)
      : this.formatPretty(entry);
    
    // Use appropriate console method
    switch (level) {
      case 'error':
        console.error(output);
        break;
      case 'warn':
        console.warn(output);
        break;
      default:
        console.log(output);
    }
  }
  
  /**
   * Format log entry for pretty printing (development)
   */
  private formatPretty(entry: LogEntry): string {
    const levelColors: Record<LogLevel, string> = {
      debug: '\x1b[90m',  // Gray
      info: '\x1b[36m',   // Cyan
      warn: '\x1b[33m',   // Yellow
      error: '\x1b[31m',  // Red
    };
    const reset = '\x1b[0m';
    const color = levelColors[entry.level];
    
    let output = `${entry.timestamp} ${color}${entry.level.toUpperCase().padEnd(5)}${reset} ${entry.message}`;
    
    if (entry.correlationId) {
      output += ` [${entry.correlationId}]`;
    }
    
    if (entry.context && Object.keys(entry.context).length > 0) {
      output += '\n  ' + JSON.stringify(entry.context, null, 2).replace(/\n/g, '\n  ');
    }
    
    return output;
  }
  
  // Log methods
  debug(message: string, context?: LogContext): void {
    this.log('debug', message, context);
  }
  
  info(message: string, context?: LogContext): void {
    this.log('info', message, context);
  }
  
  warn(message: string, context?: LogContext): void {
    this.log('warn', message, context);
  }
  
  error(message: string, context?: LogContext): void {
    this.log('error', message, context);
  }
  
  /**
   * Log an error with stack trace
   */
  exception(error: Error, context?: LogContext): void {
    this.error(error.message, {
      ...context,
      errorName: error.name,
      stack: redactString(error.stack || ''),
    });
  }
  
  /**
   * Create a child logger with preset context
   */
  child(defaultContext: LogContext): ChildLogger {
    return new ChildLogger(this, defaultContext);
  }
}

/**
 * Child logger with preset context
 */
class ChildLogger {
  constructor(
    private parent: SecureLogger,
    private defaultContext: LogContext
  ) {}
  
  private mergeContext(context?: LogContext): LogContext {
    return { ...this.defaultContext, ...context };
  }
  
  debug(message: string, context?: LogContext): void {
    this.parent.debug(message, this.mergeContext(context));
  }
  
  info(message: string, context?: LogContext): void {
    this.parent.info(message, this.mergeContext(context));
  }
  
  warn(message: string, context?: LogContext): void {
    this.parent.warn(message, this.mergeContext(context));
  }
  
  error(message: string, context?: LogContext): void {
    this.parent.error(message, this.mergeContext(context));
  }
  
  exception(error: Error, context?: LogContext): void {
    this.parent.exception(error, this.mergeContext(context));
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

let loggerInstance: SecureLogger | null = null;

export function getLogger(): SecureLogger {
  if (!loggerInstance) {
    loggerInstance = new SecureLogger();
  }
  return loggerInstance;
}

// Export convenience functions
export const logger = {
  debug: (message: string, context?: LogContext) => getLogger().debug(message, context),
  info: (message: string, context?: LogContext) => getLogger().info(message, context),
  warn: (message: string, context?: LogContext) => getLogger().warn(message, context),
  error: (message: string, context?: LogContext) => getLogger().error(message, context),
  exception: (error: Error, context?: LogContext) => getLogger().exception(error, context),
  child: (context: LogContext) => getLogger().child(context),
};
