-- ============================================================================
-- LEXMANAGER DATABASE SCHEMA v2.0
-- Migration 002: Cross-Tenant Protection Triggers - DOWN
-- ============================================================================

BEGIN;

-- Drop triggers
DROP TRIGGER IF EXISTS trg_custom_field_values_validate_tenant_refs ON custom_field_values;
DROP TRIGGER IF EXISTS trg_clients_validate_tenant_refs ON clients;
DROP TRIGGER IF EXISTS trg_trust_transactions_validate_tenant_refs ON trust_transactions;
DROP TRIGGER IF EXISTS trg_trust_accounts_validate_tenant_refs ON trust_accounts;
DROP TRIGGER IF EXISTS trg_payments_validate_tenant_refs ON payments;
DROP TRIGGER IF EXISTS trg_invoice_lines_validate_tenant_refs ON invoice_lines;
DROP TRIGGER IF EXISTS trg_invoices_validate_tenant_refs ON invoices;
DROP TRIGGER IF EXISTS trg_time_entries_validate_tenant_refs ON time_entries;
DROP TRIGGER IF EXISTS trg_events_validate_tenant_refs ON calendar_events;
DROP TRIGGER IF EXISTS trg_documents_validate_tenant_refs ON documents;
DROP TRIGGER IF EXISTS trg_tasks_validate_tenant_refs ON tasks;

-- Drop trigger functions
DROP FUNCTION IF EXISTS validate_custom_field_value_tenant_refs();
DROP FUNCTION IF EXISTS validate_client_tenant_refs();
DROP FUNCTION IF EXISTS validate_trust_transaction_tenant_refs();
DROP FUNCTION IF EXISTS validate_trust_account_tenant_refs();
DROP FUNCTION IF EXISTS validate_payment_tenant_refs();
DROP FUNCTION IF EXISTS validate_invoice_line_tenant_refs();
DROP FUNCTION IF EXISTS validate_invoice_tenant_refs();
DROP FUNCTION IF EXISTS validate_time_entry_tenant_refs();
DROP FUNCTION IF EXISTS validate_event_tenant_refs();
DROP FUNCTION IF EXISTS validate_document_tenant_refs();
DROP FUNCTION IF EXISTS validate_task_tenant_refs();

-- Drop generic validation function
DROP FUNCTION IF EXISTS validate_same_tenant(UUID, TEXT, TEXT, UUID);

COMMIT;
