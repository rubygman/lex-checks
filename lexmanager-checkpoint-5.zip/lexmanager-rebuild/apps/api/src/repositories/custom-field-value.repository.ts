// ============================================================================
// CUSTOM FIELD VALUE REPOSITORY
// apps/api/src/repositories/custom-field-value.repository.ts
// ============================================================================

import { query } from '../db/connection.js';
import { parsePostgresError, TenantScopingError, NotFoundError } from '../db/errors.js';
import type { CustomFieldEntityType, CustomFieldType } from './custom-field-definition.repository.js';

// ============================================================================
// TYPES
// ============================================================================

export interface CustomFieldValue {
  id: string;
  tenant_id: string;
  definition_id: string;
  entity_type: CustomFieldEntityType;
  entity_id: string;
  value_text: string | null;
  value_number: number | null;
  value_boolean: boolean | null;
  value_date: Date | null;
  value_datetime: Date | null;
  value_json: unknown | null;
  created_at: Date;
  updated_at: Date;
}

export interface CustomFieldWithValue {
  definition_id: string;
  field_key: string;
  field_type: CustomFieldType;
  label: string;
  label_he: string | null;
  description: string | null;
  is_required: boolean;
  display_order: number;
  options: Record<string, unknown> | null;
  value_id: string | null;
  value_text: string | null;
  value_number: number | null;
  value_boolean: boolean | null;
  value_date: Date | null;
  value_datetime: Date | null;
  value_json: unknown | null;
  display_value: string | null;
}

export interface SetValueData {
  definition_id: string;
  entity_type: CustomFieldEntityType;
  entity_id: string;
  value_text?: string | null;
  value_number?: number | null;
  value_boolean?: boolean | null;
  value_date?: Date | null;
  value_datetime?: Date | null;
  value_json?: unknown | null;
}

// ============================================================================
// REPOSITORY
// ============================================================================

export class CustomFieldValueRepository {
  private readonly tableName = 'custom_field_values';

  /**
   * Validate tenant ID
   */
  private validateTenantId(tenantId: string, operation: string): void {
    if (!tenantId || tenantId.trim() === '') {
      throw new TenantScopingError(
        `${operation} on ${this.tableName} requires a valid tenantId. Received: "${tenantId}"`
      );
    }
  }

  /**
   * Set a field value (upsert)
   */
  async setValue(tenantId: string, data: SetValueData): Promise<CustomFieldValue> {
    this.validateTenantId(tenantId, 'setValue');

    try {
      const result = await query<CustomFieldValue>(
        `INSERT INTO ${this.tableName} (
          tenant_id, definition_id, entity_type, entity_id,
          value_text, value_number, value_boolean, value_date, value_datetime, value_json
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        ON CONFLICT (tenant_id, definition_id, entity_type, entity_id)
        DO UPDATE SET
          value_text = EXCLUDED.value_text,
          value_number = EXCLUDED.value_number,
          value_boolean = EXCLUDED.value_boolean,
          value_date = EXCLUDED.value_date,
          value_datetime = EXCLUDED.value_datetime,
          value_json = EXCLUDED.value_json,
          updated_at = CURRENT_TIMESTAMP
        RETURNING *`,
        [
          tenantId,
          data.definition_id,
          data.entity_type,
          data.entity_id,
          data.value_text ?? null,
          data.value_number ?? null,
          data.value_boolean ?? null,
          data.value_date ?? null,
          data.value_datetime ?? null,
          data.value_json ? JSON.stringify(data.value_json) : null,
        ]
      );

      return result.rows[0]!;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get a specific field value
   */
  async getValue(
    tenantId: string,
    definitionId: string,
    entityType: CustomFieldEntityType,
    entityId: string
  ): Promise<CustomFieldValue | null> {
    this.validateTenantId(tenantId, 'getValue');

    try {
      const result = await query<CustomFieldValue>(
        `SELECT * FROM ${this.tableName}
         WHERE tenant_id = $1 AND definition_id = $2 AND entity_type = $3 AND entity_id = $4`,
        [tenantId, definitionId, entityType, entityId]
      );

      return result.rows[0] || null;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Get all custom field values for an entity (merged with definitions)
   */
  async getValuesForEntity(
    tenantId: string,
    entityType: CustomFieldEntityType,
    entityId: string
  ): Promise<CustomFieldWithValue[]> {
    this.validateTenantId(tenantId, 'getValuesForEntity');

    try {
      const result = await query<CustomFieldWithValue>(
        `SELECT * FROM get_custom_fields_for_entity($1, $2, $3)`,
        [tenantId, entityType, entityId]
      );

      return result.rows;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Delete a field value
   */
  async deleteValue(
    tenantId: string,
    definitionId: string,
    entityType: CustomFieldEntityType,
    entityId: string
  ): Promise<boolean> {
    this.validateTenantId(tenantId, 'deleteValue');

    try {
      const result = await query(
        `DELETE FROM ${this.tableName}
         WHERE tenant_id = $1 AND definition_id = $2 AND entity_type = $3 AND entity_id = $4`,
        [tenantId, definitionId, entityType, entityId]
      );

      return (result.rowCount || 0) > 0;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Delete all values for an entity
   */
  async deleteAllForEntity(
    tenantId: string,
    entityType: CustomFieldEntityType,
    entityId: string
  ): Promise<number> {
    this.validateTenantId(tenantId, 'deleteAllForEntity');

    try {
      const result = await query(
        `DELETE FROM ${this.tableName}
         WHERE tenant_id = $1 AND entity_type = $2 AND entity_id = $3`,
        [tenantId, entityType, entityId]
      );

      return result.rowCount || 0;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Delete all values for a definition (when definition is deleted)
   */
  async deleteAllForDefinition(tenantId: string, definitionId: string): Promise<number> {
    this.validateTenantId(tenantId, 'deleteAllForDefinition');

    try {
      const result = await query(
        `DELETE FROM ${this.tableName}
         WHERE tenant_id = $1 AND definition_id = $2`,
        [tenantId, definitionId]
      );

      return result.rowCount || 0;
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Search entities by custom field value
   */
  async searchByValue(
    tenantId: string,
    entityType: CustomFieldEntityType,
    definitionId: string,
    searchValue: string,
    options: { limit?: number; offset?: number } = {}
  ): Promise<string[]> {
    this.validateTenantId(tenantId, 'searchByValue');

    const limit = options.limit ?? 100;
    const offset = options.offset ?? 0;

    try {
      const result = await query<{ entity_id: string }>(
        `SELECT DISTINCT entity_id FROM ${this.tableName}
         WHERE tenant_id = $1 
           AND entity_type = $2 
           AND definition_id = $3
           AND (
             value_text ILIKE '%' || $4 || '%'
             OR value_number::text = $4
             OR value_json::text ILIKE '%' || $4 || '%'
           )
         LIMIT $5 OFFSET $6`,
        [tenantId, entityType, definitionId, searchValue, limit, offset]
      );

      return result.rows.map(r => r.entity_id);
    } catch (error) {
      throw parsePostgresError(error);
    }
  }

  /**
   * Bulk set values for an entity
   */
  async bulkSetValues(
    tenantId: string,
    entityType: CustomFieldEntityType,
    entityId: string,
    values: Array<{
      definitionId: string;
      value: unknown;
      fieldType: CustomFieldType;
    }>
  ): Promise<void> {
    this.validateTenantId(tenantId, 'bulkSetValues');

    for (const item of values) {
      const valueData = this.prepareValueData(item.fieldType, item.value);
      
      await this.setValue(tenantId, {
        definition_id: item.definitionId,
        entity_type: entityType,
        entity_id: entityId,
        ...valueData,
      });
    }
  }

  /**
   * Prepare value data based on field type
   */
  private prepareValueData(
    fieldType: CustomFieldType,
    value: unknown
  ): Partial<SetValueData> {
    switch (fieldType) {
      case 'text':
      case 'select':
        return { value_text: value as string };
      case 'number':
        return { value_number: value as number };
      case 'boolean':
        return { value_boolean: value as boolean };
      case 'date':
        return { value_date: value as Date };
      case 'datetime':
        return { value_datetime: value as Date };
      case 'multi_select':
      case 'json':
        return { value_json: value };
      default:
        return { value_text: String(value) };
    }
  }
}

export const customFieldValueRepository = new CustomFieldValueRepository();
