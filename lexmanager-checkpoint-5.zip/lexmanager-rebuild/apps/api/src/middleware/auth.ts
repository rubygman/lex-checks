// ============================================================================
// AUTH MIDDLEWARE
// apps/api/src/middleware/auth.ts
// 
// JWT parsing, validation, and authentication enforcement
// ============================================================================

import type { Request, Response, NextFunction, RequestHandler } from 'express';
import jwt from 'jsonwebtoken';
import { getConfig } from '../config/index.js';
import { userRepository } from '../repositories/user.repository.js';
import { rbacService, PERMISSIONS, type PermissionCode } from '../services/rbac.service.js';
import type { TokenPayload } from '../services/auth.service.js';
import type { TenantContext } from './context.js';

// ============================================================================
// TYPES
// ============================================================================

export interface AuthContext {
  userId: string;
  tenantId: string;
  roleId: string;
  roleName: string;
  email: string;
  permissions?: Set<string>;  // Cached permissions
}

// Extend Express Request
declare global {
  namespace Express {
    interface Request {
      auth?: AuthContext;
    }
  }
}

// ============================================================================
// ERROR CLASSES
// ============================================================================

export class AuthenticationError extends Error {
  public readonly statusCode = 401;
  public readonly code: string;

  constructor(message: string, code: string = 'AUTHENTICATION_REQUIRED') {
    super(message);
    this.name = 'AuthenticationError';
    this.code = code;
  }
}

export class AuthorizationError extends Error {
  public readonly statusCode = 403;
  public readonly code: string;
  public readonly requiredPermission?: string;

  constructor(message: string, code: string = 'PERMISSION_DENIED', requiredPermission?: string) {
    super(message);
    this.name = 'AuthorizationError';
    this.code = code;
    this.requiredPermission = requiredPermission;
  }
}

// ============================================================================
// MIDDLEWARE: PARSE JWT (does not require auth, just parses if present)
// ============================================================================

/**
 * Parse JWT from Authorization header and attach auth context
 * Does NOT require authentication - use requireAuth for that
 */
export function authParser(): RequestHandler {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const authHeader = req.headers.authorization;

      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        // No token - continue without auth context
        return next();
      }

      const token = authHeader.substring(7);  // Remove 'Bearer '
      const config = getConfig();

      // Verify token
      let decoded: TokenPayload;
      try {
        decoded = jwt.verify(token, config.jwt.accessSecret, {
          issuer: config.jwt.issuer,
          audience: config.jwt.audience,
        }) as TokenPayload;
      } catch (error) {
        if (error instanceof jwt.TokenExpiredError) {
          return res.status(401).json({
            error: 'TOKEN_EXPIRED',
            message: 'Access token has expired',
            correlationId: req.context.correlationId,
          });
        }
        if (error instanceof jwt.JsonWebTokenError) {
          return res.status(401).json({
            error: 'INVALID_TOKEN',
            message: 'Invalid access token',
            correlationId: req.context.correlationId,
          });
        }
        throw error;
      }

      // Verify token type
      if (decoded.type !== 'access') {
        return res.status(401).json({
          error: 'INVALID_TOKEN_TYPE',
          message: 'Expected access token',
          correlationId: req.context.correlationId,
        });
      }

      // Attach auth context
      req.auth = {
        userId: decoded.sub,
        tenantId: decoded.tid,
        roleId: decoded.rid,
        roleName: decoded.rn,
        email: decoded.email,
      };

      next();
    } catch (error) {
      next(error);
    }
  };
}

// ============================================================================
// MIDDLEWARE: REQUIRE AUTH
// ============================================================================

/**
 * Require user to be authenticated
 * Must be used after authParser
 */
export function requireAuth(): RequestHandler {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      return res.status(401).json({
        error: 'AUTHENTICATION_REQUIRED',
        message: 'Authentication required',
        correlationId: req.context.correlationId,
      });
    }

    // Verify user still exists and is active
    try {
      const user = await userRepository.findById(req.auth.tenantId, req.auth.userId);
      
      if (!user) {
        return res.status(401).json({
          error: 'USER_NOT_FOUND',
          message: 'User no longer exists',
          correlationId: req.context.correlationId,
        });
      }

      if (!user.is_active) {
        return res.status(403).json({
          error: 'ACCOUNT_INACTIVE',
          message: 'Account has been deactivated',
          correlationId: req.context.correlationId,
        });
      }

      next();
    } catch (error) {
      next(error);
    }
  };
}

// ============================================================================
// MIDDLEWARE: REQUIRE TENANT ACCESS
// ============================================================================

/**
 * Require that authenticated user belongs to the resolved tenant
 * Must be used after both authParser and tenantResolver
 */
export function requireTenantAccess(): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      return res.status(401).json({
        error: 'AUTHENTICATION_REQUIRED',
        message: 'Authentication required',
        correlationId: req.context.correlationId,
      });
    }

    if (!req.context.tenant) {
      return res.status(400).json({
        error: 'TENANT_REQUIRED',
        message: 'Tenant context required',
        correlationId: req.context.correlationId,
      });
    }

    // Check user's tenant matches request tenant
    if (req.auth.tenantId !== req.context.tenant.tenantId) {
      return res.status(403).json({
        error: 'TENANT_ACCESS_DENIED',
        message: 'Access to this tenant is denied',
        correlationId: req.context.correlationId,
      });
    }

    next();
  };
}

// ============================================================================
// MIDDLEWARE: REQUIRE PERMISSION
// ============================================================================

/**
 * Require user to have a specific permission
 * Must be used after requireAuth
 */
export function requirePermission(permissionCode: PermissionCode | string): RequestHandler {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      return res.status(401).json({
        error: 'AUTHENTICATION_REQUIRED',
        message: 'Authentication required',
        correlationId: req.context.correlationId,
      });
    }

    try {
      // Load permissions if not cached
      if (!req.auth.permissions) {
        const permissions = await rbacService.loadPermissionsForRole(req.auth.roleId);
        req.auth.permissions = new Set(permissions);
      }

      // Check permission
      if (!req.auth.permissions.has(permissionCode)) {
        return res.status(403).json({
          error: 'PERMISSION_DENIED',
          message: `Permission denied: ${permissionCode} is required`,
          requiredPermission: permissionCode,
          correlationId: req.context.correlationId,
        });
      }

      next();
    } catch (error) {
      next(error);
    }
  };
}

/**
 * Require user to have ANY of the specified permissions
 */
export function requireAnyPermission(permissionCodes: (PermissionCode | string)[]): RequestHandler {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      return res.status(401).json({
        error: 'AUTHENTICATION_REQUIRED',
        message: 'Authentication required',
        correlationId: req.context.correlationId,
      });
    }

    try {
      // Load permissions if not cached
      if (!req.auth.permissions) {
        const permissions = await rbacService.loadPermissionsForRole(req.auth.roleId);
        req.auth.permissions = new Set(permissions);
      }

      // Check if user has ANY of the required permissions
      const hasAny = permissionCodes.some(code => req.auth!.permissions!.has(code));

      if (!hasAny) {
        return res.status(403).json({
          error: 'PERMISSION_DENIED',
          message: `Permission denied: one of [${permissionCodes.join(', ')}] is required`,
          correlationId: req.context.correlationId,
        });
      }

      next();
    } catch (error) {
      next(error);
    }
  };
}

/**
 * Require user to have ALL of the specified permissions
 */
export function requireAllPermissions(permissionCodes: (PermissionCode | string)[]): RequestHandler {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      return res.status(401).json({
        error: 'AUTHENTICATION_REQUIRED',
        message: 'Authentication required',
        correlationId: req.context.correlationId,
      });
    }

    try {
      // Load permissions if not cached
      if (!req.auth.permissions) {
        const permissions = await rbacService.loadPermissionsForRole(req.auth.roleId);
        req.auth.permissions = new Set(permissions);
      }

      // Check if user has ALL required permissions
      const missing = permissionCodes.filter(code => !req.auth!.permissions!.has(code));

      if (missing.length > 0) {
        return res.status(403).json({
          error: 'PERMISSION_DENIED',
          message: `Permission denied: missing permissions [${missing.join(', ')}]`,
          correlationId: req.context.correlationId,
        });
      }

      next();
    } catch (error) {
      next(error);
    }
  };
}

// ============================================================================
// MIDDLEWARE: REQUIRE ADMIN
// ============================================================================

/**
 * Require user to be an admin
 */
export function requireAdmin(): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      return res.status(401).json({
        error: 'AUTHENTICATION_REQUIRED',
        message: 'Authentication required',
        correlationId: req.context.correlationId,
      });
    }

    if (req.auth.roleName !== 'admin') {
      return res.status(403).json({
        error: 'ADMIN_REQUIRED',
        message: 'Admin access required',
        correlationId: req.context.correlationId,
      });
    }

    next();
  };
}

// ============================================================================
// HELPER: CHECK PERMISSION (for services)
// ============================================================================

/**
 * Check if auth context has a permission
 */
export async function hasPermission(
  auth: AuthContext,
  permissionCode: PermissionCode | string
): Promise<boolean> {
  if (!auth.permissions) {
    const permissions = await rbacService.loadPermissionsForRole(auth.roleId);
    auth.permissions = new Set(permissions);
  }
  return auth.permissions.has(permissionCode);
}

/**
 * Throw if auth context doesn't have permission
 */
export async function assertPermission(
  auth: AuthContext,
  permissionCode: PermissionCode | string
): Promise<void> {
  const allowed = await hasPermission(auth, permissionCode);
  if (!allowed) {
    throw new AuthorizationError(
      `Permission denied: ${permissionCode} is required`,
      'PERMISSION_DENIED',
      permissionCode
    );
  }
}
